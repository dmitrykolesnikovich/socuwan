/*    */ package frontend;
/*    */ 
/*    */ import java.awt.Font;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JMenuBar;
/*    */ import javax.swing.JMenuItem;
/*    */ import main.WorkSpace;
/*    */ 
/*    */ 
/*    */ public class MenuBar
/*    */   extends JMenuBar
/*    */ {
/*    */   private WorkSpace workspace;
/*    */   private MainFrame mainFrame;
/*    */   
/*    */   public MenuBar(WorkSpace workspace, MainFrame mainFrame)
/*    */   {
/* 20 */     this.workspace = workspace;
/* 21 */     this.mainFrame = mainFrame;
/* 22 */     createMenu(mainFrame);
/*    */   }
/*    */   
/*    */   private void createMenu(MainFrame mainFrame) {
/* 26 */     JMenu file = new JMenu("File");
/* 27 */     add(file);
/* 28 */     JMenuItem newFile = new JMenuItem("New");
/* 29 */     JMenuItem openFile = new JMenuItem("Open File");
/* 30 */     JMenuItem save = new JMenuItem("Save");
/* 31 */     file.add(newFile);
/* 32 */     file.add(openFile);
/* 33 */     file.add(save);
/* 34 */     addOpenFileFunction(openFile, mainFrame);
/* 35 */     addSaveFunction(save);
/* 36 */     addNewFileFunction(newFile);
/* 37 */     file.setFont(new Font("Segoe UI", 1, 12));
/* 38 */     newFile.setFont(new Font("Segoe UI", 1, 12));
/* 39 */     openFile.setFont(new Font("Segoe UI", 1, 12));
/* 40 */     save.setFont(new Font("Segoe UI", 1, 12));
/*    */     
/* 42 */     JMenu preview = new JMenu("Preview");
/* 43 */     preview.setFont(new Font("Segoe UI", 1, 12));
/* 44 */     add(preview);
/* 45 */     JMenuItem options = new JMenuItem("Options");
/* 46 */     options.setFont(new Font("Segoe UI", 1, 12));
/* 47 */     preview.add(options);
/* 48 */     addPreviewOptionsFunction(options);
/*    */   }
/*    */   
/*    */   private void addPreviewOptionsFunction(JMenuItem options) {
/* 52 */     options.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent arg0)
/*    */       {
/* 56 */         new PreviewOptionsPopUp();
/*    */       }
/*    */     });
/*    */   }
/*    */   
/* 61 */   private void addOpenFileFunction(JMenuItem open, final MainFrame mainFrame) { open.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/* 65 */         MenuBar.this.workspace.save();
/* 66 */         new FileChooseScreen(MenuBar.this.workspace.getAvailableItems(), MenuBar.this.workspace, mainFrame);
/*    */       }
/*    */     }); }
/*    */   
/*    */ 
/*    */   private void addSaveFunction(JMenuItem save)
/*    */   {
/* 73 */     save.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/* 77 */         MenuBar.this.workspace.save();
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   private void addNewFileFunction(JMenuItem newFile)
/*    */   {
/* 84 */     newFile.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e) {
/* 87 */         MenuBar.this.workspace.save();
/* 88 */         MenuBar.this.workspace.createNewItem();
/* 89 */         MenuBar.this.mainFrame.setItem(MenuBar.this.workspace.getCurrentItem());
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\MenuBar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */