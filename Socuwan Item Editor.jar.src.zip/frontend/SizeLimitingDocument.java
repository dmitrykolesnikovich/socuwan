/*    */ package frontend;
/*    */ 
/*    */ import java.awt.Toolkit;
/*    */ import javax.swing.text.AttributeSet;
/*    */ import javax.swing.text.BadLocationException;
/*    */ import javax.swing.text.Document;
/*    */ import javax.swing.text.DocumentFilter;
/*    */ import javax.swing.text.DocumentFilter.FilterBypass;
/*    */ 
/*    */ class SizeLimitingDocument
/*    */   extends DocumentFilter
/*    */ {
/*    */   private int max;
/*    */   
/*    */   public SizeLimitingDocument(int max)
/*    */   {
/* 17 */     this.max = max;
/*    */   }
/*    */   
/*    */   public void insertString(DocumentFilter.FilterBypass fp, int offset, String string, AttributeSet aset) throws BadLocationException
/*    */   {
/* 22 */     if (string.contains("\n")) {
/* 23 */       Toolkit.getDefaultToolkit().beep();
/* 24 */       return;
/*    */     }
/* 26 */     if (fp.getDocument().getLength() + string.length() < this.max) {
/* 27 */       super.insertString(fp, offset, string, aset);
/*    */     } else {
/* 29 */       Toolkit.getDefaultToolkit().beep();
/*    */     }
/*    */   }
/*    */   
/*    */   public void replace(DocumentFilter.FilterBypass fp, int offset, int length, String string, AttributeSet aset)
/*    */     throws BadLocationException
/*    */   {
/* 36 */     if (string.contains("\n")) {
/* 37 */       Toolkit.getDefaultToolkit().beep();
/* 38 */       return;
/*    */     }
/* 40 */     if (fp.getDocument().getLength() + string.length() - length <= this.max) {
/* 41 */       super.replace(fp, offset, length, string, aset);
/*    */     } else {
/* 43 */       Toolkit.getDefaultToolkit().beep();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\SizeLimitingDocument.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */