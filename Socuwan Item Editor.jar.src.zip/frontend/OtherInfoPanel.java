/*     */ package frontend;
/*     */ 
/*     */ import backend.Item;
/*     */ import categories.MainCategory;
/*     */ import categories.SubCategoryInterface;
/*     */ import components.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.NumberFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OtherInfoPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final int HEIGHT = 200;
/*     */   private static final int CATEGORY_FONT_SIZES = 15;
/*     */   private static final int STACKS_FONT_SIZE = 15;
/*     */   private static final int PRICE_FONT_SIZE = 15;
/*     */   private static final int DESCRITPION_FONT_SIZE = 15;
/*     */   private ItemHeaderPanel itemHeader;
/*     */   private Item item;
/*     */   private MainFrame mainFrame;
/*  43 */   private boolean settingUp = false;
/*     */   private JComboBox<MainCategory> mainCategory;
/*     */   private JComboBox<SubCategoryInterface> subCategory;
/*     */   private JCheckBox stacks;
/*     */   private JFormattedTextField price;
/*     */   private JTextArea description;
/*     */   
/*     */   public OtherInfoPanel(Item item, ItemHeaderPanel itemHeader, MainFrame main)
/*     */   {
/*  52 */     this.mainFrame = main;
/*  53 */     this.itemHeader = itemHeader;
/*  54 */     this.item = item;
/*  55 */     setPreferredSize(new Dimension(390, 200));
/*  56 */     setLayout(new GridBagLayout());
/*  57 */     addAllFields();
/*  58 */     setAllFields(item);
/*     */   }
/*     */   
/*     */   public void setNewItem(Item item) {
/*  62 */     this.item = item;
/*  63 */     setAllFields(item);
/*     */   }
/*     */   
/*     */   public void addAllFields() {
/*  67 */     GridBagConstraints gc = new GridBagConstraints();
/*  68 */     gc.fill = 1;
/*  69 */     addCategory1Box(gc);
/*  70 */     addCategory2Box(gc);
/*  71 */     addCheckBox(gc);
/*  72 */     addPrice(gc);
/*  73 */     addDescription(gc);
/*     */   }
/*     */   
/*     */   public void setAllFields(Item item) {
/*  77 */     this.stacks.setSelected(item.isStacks());
/*  78 */     this.price.setText(Long.toString(item.getPrice()));
/*  79 */     this.description.setText(item.getDescription());
/*  80 */     SubCategoryInterface sub = item.getSubCategory();
/*  81 */     this.settingUp = true;
/*  82 */     this.mainCategory.setSelectedItem(item.getMainCategoy());
/*  83 */     this.subCategory.setModel(new DefaultComboBoxModel(item.getMainCategoy().getSubCategories()));
/*     */     
/*  85 */     this.subCategory.setSelectedItem(sub);
/*  86 */     this.settingUp = false;
/*     */   }
/*     */   
/*     */   private void addCheckBox(GridBagConstraints gc) {
/*  90 */     gc.gridy = 2;
/*  91 */     this.stacks = new JCheckBox("Stacks?");
/*  92 */     this.stacks.setFont(new Font("Segoe UI", 1, 15));
/*  93 */     this.stacks.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*  97 */         OtherInfoPanel.this.item.setStacks(OtherInfoPanel.this.stacks.isSelected());
/*     */       }
/*     */       
/* 100 */     });
/* 101 */     add(this.stacks, gc);
/*     */   }
/*     */   
/*     */   private void addDescription(GridBagConstraints gc) {
/* 105 */     gc.gridy = 4;
/* 106 */     gc.weighty = 15.0D;
/* 107 */     this.description = new JTextArea(this.item.getDescription());
/* 108 */     this.description.setFont(new Font("Segoe UI", 1, 15));
/* 109 */     this.description.setLineWrap(true);
/* 110 */     this.description.setWrapStyleWord(true);
/* 111 */     this.description.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 113 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 117 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 121 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 125 */         OtherInfoPanel.this.item.setDescription(OtherInfoPanel.this.description.getText());
/*     */       }
/* 127 */     });
/* 128 */     ((AbstractDocument)this.description.getDocument()).setDocumentFilter(new SizeLimitingDocument(80));
/*     */     
/* 130 */     JScrollPane areaScrollPane = new JScrollPane(this.description);
/* 131 */     areaScrollPane.setVerticalScrollBarPolicy(21);
/* 132 */     areaScrollPane.setHorizontalScrollBarPolicy(31);
/* 133 */     add(areaScrollPane, gc);
/*     */   }
/*     */   
/*     */   private void addPrice(GridBagConstraints gc) {
/* 137 */     gc.gridy = 3;
/* 138 */     JPanel subPanel = new JPanel();
/* 139 */     add(subPanel, gc);
/* 140 */     subPanel.setLayout(new GridBagLayout());
/* 141 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 142 */     gc2.fill = 1;
/* 143 */     gc2.gridx = 0;
/* 144 */     gc2.gridy = 0;
/* 145 */     gc2.weightx = 1.0D;
/* 146 */     gc2.weighty = 1.0D;
/*     */     
/* 148 */     NumberFormat longFormat = NumberFormat.getIntegerInstance();
/*     */     
/* 150 */     NumberFormatter numberFormatter = new NumberFormatter(longFormat);
/* 151 */     numberFormatter.setValueClass(Long.class);
/* 152 */     numberFormatter.setAllowsInvalid(false);
/* 153 */     numberFormatter.setMinimum(Long.valueOf(0L));
/* 154 */     this.price = new JFormattedTextField(numberFormatter);
/* 155 */     this.price.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 157 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 161 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 165 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 169 */         if (OtherInfoPanel.this.price.getText().equals("")) {
/* 170 */           return;
/*     */         }
/* 172 */         OtherInfoPanel.this.item.setPrice(Long.parseLong(OtherInfoPanel.this.removeLetters(OtherInfoPanel.this.price.getText())));
/*     */       }
/* 174 */     });
/* 175 */     this.price.setColumns(40);
/* 176 */     JLabel priceTag = new JLabel("Price: ");
/* 177 */     priceTag.setFont(new Font("Segoe UI", 1, 15));
/* 178 */     subPanel.add(priceTag, gc2);
/* 179 */     gc2.gridx = 1;
/* 180 */     gc2.weightx = 7.0D;
/* 181 */     this.price.setFont(new Font("Segoe UI", 1, 15));
/* 182 */     subPanel.add(this.price, gc2);
/*     */   }
/*     */   
/*     */   private void addCategory1Box(GridBagConstraints gc) {
/* 186 */     gc.gridx = 0;
/* 187 */     gc.gridy = 0;
/* 188 */     gc.weightx = 1.0D;
/* 189 */     gc.weighty = 1.0D;
/* 190 */     this.mainCategory = new JComboBox(MainCategory.values());
/* 191 */     this.mainCategory.setName("Category");
/* 192 */     this.mainCategory.setFont(new Font("Segoe UI", 1, 15));
/* 193 */     this.mainCategory.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 197 */         if (OtherInfoPanel.this.item.getMainCategoy() == (MainCategory)OtherInfoPanel.this.mainCategory.getSelectedItem()) {
/* 198 */           return;
/*     */         }
/* 200 */         OtherInfoPanel.this.item.setMainCategory((MainCategory)OtherInfoPanel.this.mainCategory.getSelectedItem());
/* 201 */         OtherInfoPanel.this.subCategory.setModel(new DefaultComboBoxModel(OtherInfoPanel.this.item.getMainCategoy().getSubCategories()));
/*     */         
/* 203 */         OtherInfoPanel.this.item.setSubCategory((SubCategoryInterface)OtherInfoPanel.this.subCategory.getSelectedItem());
/* 204 */         OtherInfoPanel.this.setCategoryID();
/* 205 */         if (!OtherInfoPanel.this.settingUp) {
/* 206 */           Component primary = ((MainCategory)OtherInfoPanel.this.mainCategory.getSelectedItem()).generatePrimaryComponent(OtherInfoPanel.this.item);
/*     */           
/* 208 */           Component secondary = ((SubCategoryInterface)OtherInfoPanel.this.subCategory.getSelectedItem()).generateSecondaryComponent(OtherInfoPanel.this.item);
/*     */           
/* 210 */           OtherInfoPanel.this.item.setPrimaryComponent(primary);
/* 211 */           OtherInfoPanel.this.item.setSecondaryComponent(secondary);
/* 212 */           OtherInfoPanel.this.mainFrame.updateComponentPanels(primary, secondary, true);
/*     */         }
/*     */       }
/* 215 */     });
/* 216 */     add(this.mainCategory, gc);
/*     */   }
/*     */   
/*     */   private void addCategory2Box(GridBagConstraints gc) {
/* 220 */     gc.gridy = 1;
/* 221 */     this.subCategory = new JComboBox();
/* 222 */     this.subCategory.setName("Category2");
/* 223 */     this.subCategory.setFont(new Font("Segoe UI", 1, 15));
/* 224 */     this.subCategory.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 228 */         OtherInfoPanel.this.item.setSubCategory((SubCategoryInterface)OtherInfoPanel.this.subCategory.getSelectedItem());
/* 229 */         OtherInfoPanel.this.setCategoryID();
/* 230 */         if (!OtherInfoPanel.this.settingUp) {
/* 231 */           Component secondary = ((SubCategoryInterface)OtherInfoPanel.this.subCategory.getSelectedItem()).generateSecondaryComponent(OtherInfoPanel.this.item);
/*     */           
/* 233 */           OtherInfoPanel.this.item.setSecondaryComponent(secondary);
/* 234 */           OtherInfoPanel.this.mainFrame.updateSecondaryPanel(secondary, true);
/* 235 */           OtherInfoPanel.this.item.getPrimaryComponent().notifySecondaryCategoryChange((SubCategoryInterface)OtherInfoPanel.this.subCategory.getSelectedItem());
/*     */         }
/*     */         
/*     */       }
/* 239 */     });
/* 240 */     add(this.subCategory, gc);
/*     */   }
/*     */   
/*     */   private String removeLetters(String original) {
/* 244 */     String number = original.replaceAll("[^0-9]", "");
/* 245 */     return number;
/*     */   }
/*     */   
/*     */   private void setCategoryID() {
/* 249 */     this.itemHeader.updateCategoryID();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\OtherInfoPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */