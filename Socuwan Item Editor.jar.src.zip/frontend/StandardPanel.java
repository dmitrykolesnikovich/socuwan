/*    */ package frontend;
/*    */ 
/*    */ import backend.Item;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardPanel
/*    */   extends JPanel
/*    */ {
/*    */   public static final int HEIGHT = 350;
/* 16 */   private boolean empty = true;
/*    */   private ItemHeaderPanel header;
/*    */   private OtherInfoPanel info;
/*    */   private MainFrame mainFrame;
/*    */   
/*    */   public StandardPanel(MainFrame main)
/*    */   {
/* 23 */     this.mainFrame = main;
/* 24 */     setBorder(BorderFactory.createTitledBorder("Standard Information"));
/* 25 */     setPreferredSize(new Dimension(405, 350));
/* 26 */     super.setLayout(new GridBagLayout());
/*    */   }
/*    */   
/*    */   public void setItem(Item item) {
/* 30 */     if (this.empty) {
/* 31 */       this.empty = false;
/* 32 */       GridBagConstraints gc = new GridBagConstraints();
/* 33 */       gc.gridx = 0;
/* 34 */       gc.gridy = 0;
/* 35 */       gc.weightx = 1.0D;
/* 36 */       gc.weighty = 1.0D;
/* 37 */       this.header = new ItemHeaderPanel(item);
/* 38 */       add(this.header, gc);
/* 39 */       gc.gridy = 1;
/* 40 */       gc.weighty = 2.0D;
/* 41 */       this.info = new OtherInfoPanel(item, this.header, this.mainFrame);
/* 42 */       add(this.info, gc);
/*    */     } else {
/* 44 */       this.header.setNewItem(item);
/* 45 */       this.info.setNewItem(item);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\StandardPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */