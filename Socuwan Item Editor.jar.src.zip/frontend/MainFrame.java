/*     */ package frontend;
/*     */ 
/*     */ import backend.Item;
/*     */ import components.Component;
/*     */ import components.ComponentPanel;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import main.MainApp;
/*     */ import main.WorkSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MainFrame
/*     */ {
/*     */   private static final String TITLE = "Socuwan Item Fabricator";
/*     */   private static final int WIDTH = 1280;
/*     */   private static final int HEIGHT = 720;
/*     */   private static final int PANEL_WIDTHS = 420;
/*     */   private static final int PANEL_HEIGHTS = 650;
/*     */   public static final String FONT_NAME = "Segoe UI";
/*     */   public static final int CANVAS_WIDTH = 405;
/*     */   public static final int CANVAS_HEIGHT = 275;
/*     */   public static final int INNER_PANEL_WIDTHS = 405;
/*     */   private JFrame frame;
/*     */   private JPanel panelMain;
/*     */   private JPanel panel1;
/*     */   private JPanel panel2;
/*     */   private StandardPanel standardPanel;
/*     */   private ComponentPanel primaryPanel;
/*     */   private ComponentPanel secondaryPanel;
/*     */   private Canvas canvas;
/*     */   
/*     */   public MainFrame(final WorkSpace workspace)
/*     */   {
/*  56 */     initFrame();
/*  57 */     setIcon();
/*  58 */     initMenuBar(workspace);
/*  59 */     initMainPanels();
/*  60 */     initInnerPanels();
/*  61 */     this.frame.setVisible(true);
/*  62 */     this.frame.addWindowListener(new WindowListener()
/*     */     {
/*     */       public void windowActivated(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowClosed(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowClosing(WindowEvent arg0)
/*     */       {
/*  74 */         workspace.save();
/*  75 */         MainApp.close = true;
/*     */         try {
/*  77 */           Thread.sleep(200L);
/*     */         } catch (InterruptedException e) {
/*  79 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowDeactivated(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowDeiconified(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void windowIconified(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void windowOpened(WindowEvent arg0) {}
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   public void setItem(Item item)
/*     */   {
/* 102 */     updateComponentPanels(item.getPrimaryComponent(), item.getSecondaryComponent(), false);
/* 103 */     this.standardPanel.setItem(item);
/* 104 */     this.frame.validate();
/* 105 */     this.frame.repaint();
/*     */   }
/*     */   
/*     */   public void updateComponentPanels(Component primary, Component secondary, boolean wipe) {
/* 109 */     if (this.primaryPanel != null) {
/* 110 */       if (wipe) {
/* 111 */         this.primaryPanel.destroy();
/*     */       }
/* 113 */       this.panel1.remove(this.primaryPanel);
/* 114 */       this.primaryPanel = null;
/*     */     }
/* 116 */     if (primary != null) {
/* 117 */       this.primaryPanel = primary.createComponentPanel();
/* 118 */       this.panel1.add(this.primaryPanel);
/*     */     }
/* 120 */     updateSecondaryPanel(secondary, wipe);
/* 121 */     this.panel1.validate();
/* 122 */     this.panel1.repaint();
/* 123 */     this.panel2.validate();
/* 124 */     this.panel2.repaint();
/*     */   }
/*     */   
/*     */   public void updateSecondaryPanel(Component secondary, boolean wipe) {
/* 128 */     if (this.secondaryPanel != null) {
/* 129 */       if (wipe) {
/* 130 */         this.secondaryPanel.destroy();
/*     */       }
/* 132 */       this.panel2.remove(this.secondaryPanel);
/* 133 */       this.secondaryPanel = null;
/*     */     }
/* 135 */     if (secondary != null) {
/* 136 */       this.secondaryPanel = secondary.createComponentPanel();
/* 137 */       this.panel2.add(this.secondaryPanel);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initFrame() {
/* 142 */     this.frame = new JFrame("Socuwan Item Fabricator");
/* 143 */     this.frame.setDefaultCloseOperation(3);
/* 144 */     this.frame.setSize(1280, 720);
/* 145 */     this.frame.setResizable(false);
/* 146 */     this.frame.setLocationRelativeTo(null);
/* 147 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void initMenuBar(WorkSpace workspace) {
/* 151 */     MenuBar menuBar = new MenuBar(workspace, this);
/* 152 */     this.frame.setJMenuBar(menuBar);
/*     */   }
/*     */   
/*     */   private void setIcon() {
/* 156 */     BufferedImage myPicture = null;
/*     */     try {
/* 158 */       myPicture = ImageIO.read(MainApp.class.getResourceAsStream("/res/defaultIcon.png"));
/* 159 */       ImageIcon original = new ImageIcon(myPicture);
/* 160 */       this.frame.setIconImage(original.getImage());
/*     */     } catch (IOException e) {
/* 162 */       System.err.println("Couldn't change app icon!");
/*     */     }
/*     */   }
/*     */   
/*     */   private void initMainPanels() {
/* 167 */     GridBagConstraints gc = new GridBagConstraints();
/* 168 */     gc.gridx = 0;
/* 169 */     gc.gridy = 0;
/* 170 */     gc.weightx = 1.0D;
/* 171 */     gc.weighty = 1.0D;
/* 172 */     this.panelMain = new JPanel();
/* 173 */     this.panelMain.setPreferredSize(new Dimension(420, 650));
/* 174 */     this.frame.add(this.panelMain, gc);
/* 175 */     gc.gridx = 1;
/* 176 */     this.panel1 = new JPanel();
/* 177 */     this.panel1.setPreferredSize(new Dimension(420, 650));
/* 178 */     this.frame.add(this.panel1, gc);
/* 179 */     gc.gridx = 2;
/* 180 */     this.panel2 = new JPanel();
/* 181 */     this.panel2.setPreferredSize(new Dimension(420, 650));
/* 182 */     this.frame.add(this.panel2, gc);
/*     */   }
/*     */   
/*     */   public Canvas getCanvas() {
/* 186 */     return this.canvas;
/*     */   }
/*     */   
/*     */   private void initInnerPanels() {
/* 190 */     GridBagConstraints gc = new GridBagConstraints();
/* 191 */     gc.gridx = 0;
/* 192 */     gc.gridy = 0;
/* 193 */     gc.weightx = 1.0D;
/* 194 */     gc.weighty = 1.0D;
/* 195 */     this.standardPanel = new StandardPanel(this);
/* 196 */     this.panelMain.add(this.standardPanel, gc);
/*     */     
/* 198 */     this.canvas = new Canvas();
/* 199 */     this.canvas.setPreferredSize(new Dimension(405, 275));
/* 200 */     gc.gridy = 1;
/* 201 */     this.panelMain.add(this.canvas);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\MainFrame.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */