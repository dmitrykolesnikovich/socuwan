/*    */ package frontend;
/*    */ 
/*    */ import java.awt.Toolkit;
/*    */ import javax.swing.text.AttributeSet;
/*    */ import javax.swing.text.Document;
/*    */ import javax.swing.text.DocumentFilter;
/*    */ import javax.swing.text.DocumentFilter.FilterBypass;
/*    */ 
/*    */ class MyDocumentFilter extends DocumentFilter
/*    */ {
/*    */   private int max;
/*    */   
/*    */   public MyDocumentFilter(int max)
/*    */   {
/* 15 */     this.max = max;
/*    */   }
/*    */   
/*    */   public void insertString(DocumentFilter.FilterBypass fp, int offset, String string, AttributeSet aset) throws javax.swing.text.BadLocationException
/*    */   {
/* 20 */     int len = string.length();
/* 21 */     boolean isValidInteger = true;
/*    */     
/* 23 */     for (int i = 0; i < len; i++) {
/* 24 */       if (!Character.isDigit(string.charAt(i))) {
/* 25 */         isValidInteger = false;
/* 26 */         break;
/*    */       }
/*    */     }
/* 29 */     if ((isValidInteger) && (fp.getDocument().getLength() + string.length() < this.max)) {
/* 30 */       super.insertString(fp, offset, string, aset);
/*    */     } else {
/* 32 */       Toolkit.getDefaultToolkit().beep();
/*    */     }
/*    */   }
/*    */   
/*    */   public void replace(DocumentFilter.FilterBypass fp, int offset, int length, String string, AttributeSet aset)
/*    */     throws javax.swing.text.BadLocationException
/*    */   {
/* 39 */     int len = string.length();
/* 40 */     boolean isValidInteger = true;
/*    */     
/* 42 */     for (int i = 0; i < len; i++) {
/* 43 */       if (!Character.isDigit(string.charAt(i))) {
/* 44 */         isValidInteger = false;
/* 45 */         break;
/*    */       }
/*    */     }
/* 48 */     if ((isValidInteger) && (fp.getDocument().getLength() + string.length() - length <= this.max)) {
/* 49 */       super.replace(fp, offset, length, string, aset);
/*    */     } else {
/* 51 */       Toolkit.getDefaultToolkit().beep();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\MyDocumentFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */