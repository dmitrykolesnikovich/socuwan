/*     */ package frontend;
/*     */ 
/*     */ import backend.Item;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemHeaderPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final int ICON_SIZE = 85;
/*     */   private static final int HEIGHT = 100;
/*     */   private Item item;
/*     */   private JLabel icon;
/*     */   private JTextField name;
/*     */   private JTextField id;
/*     */   private JLabel categoryID;
/*     */   
/*     */   public ItemHeaderPanel(Item item)
/*     */   {
/*  44 */     this.item = item;
/*  45 */     setPreferredSize(new Dimension(390, 100));
/*  46 */     setLayout(new GridBagLayout());
/*  47 */     setAllItemInfo();
/*     */   }
/*     */   
/*     */   public void setNewItem(Item item) {
/*  51 */     this.item = item;
/*  52 */     resetAllItemInfo();
/*     */   }
/*     */   
/*     */   public void updateCategoryID() {
/*  56 */     this.categoryID.setText(this.item.getCatID());
/*     */   }
/*     */   
/*     */   public void setIcon(File newIcon)
/*     */   {
/*     */     try {
/*  62 */       BufferedImage myPicture = ImageIO.read(newIcon);
/*  63 */       ImageIcon original = new ImageIcon(myPicture);
/*  64 */       ImageIcon resized = resizeImage(original);
/*  65 */       this.icon.setIcon(resized);
/*  66 */       this.item.setIcon(newIcon);
/*     */     } catch (Exception e) {
/*  68 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setAllItemInfo() {
/*  73 */     GridBagConstraints gc = new GridBagConstraints();
/*  74 */     gc.gridx = 0;
/*  75 */     gc.gridy = 0;
/*  76 */     gc.weightx = 1.0D;
/*  77 */     gc.weighty = 1.0D;
/*  78 */     gc.fill = 1;
/*  79 */     BufferedImage myPicture = this.item.getIcon();
/*  80 */     ImageIcon original = new ImageIcon(myPicture);
/*  81 */     ImageIcon resized = resizeImage(original);
/*  82 */     this.icon = new JLabel(resized);
/*  83 */     this.icon.addMouseListener(new MouseListener()
/*     */     {
/*     */       public void mouseClicked(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseEntered(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseExited(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mousePressed(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void mouseReleased(MouseEvent arg0)
/*     */       {
/* 102 */         new IconChooseScreen(ItemHeaderPanel.this);
/*     */       }
/*     */       
/* 105 */     });
/* 106 */     this.icon.setPreferredSize(new Dimension(85, 85));
/* 107 */     add(this.icon, gc);
/* 108 */     gc.gridx = 1;
/* 109 */     gc.weightx = 5.0D;
/*     */     
/* 111 */     JPanel panel = new JPanel();
/* 112 */     panel.setPreferredSize(new Dimension(100, 20));
/* 113 */     add(panel, gc);
/* 114 */     panel.setLayout(new GridBagLayout());
/* 115 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 116 */     gc2.fill = 1;
/* 117 */     gc2.gridx = 0;
/* 118 */     gc2.gridy = 0;
/* 119 */     gc2.weightx = 1.0D;
/* 120 */     gc2.weighty = 2.0D;
/* 121 */     this.name = new JTextField(this.item.getName(), 30);
/* 122 */     this.name.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 124 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 128 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 132 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 136 */         ItemHeaderPanel.this.item.setName(ItemHeaderPanel.this.name.getText());
/*     */       }
/* 138 */     });
/* 139 */     this.name.setFont(new Font("Segoe UI", 1, 25));
/* 140 */     panel.add(this.name, gc2);
/* 141 */     gc2.gridy = 1;
/* 142 */     gc2.weighty = 2.0D;
/* 143 */     this.id = new JTextField(this.item.getUniqueID(), 30);
/* 144 */     ((AbstractDocument)this.id.getDocument()).setDocumentFilter(new MyDocumentFilter(5));
/*     */     
/* 146 */     this.id.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 148 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 152 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 156 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 160 */         String text = ItemHeaderPanel.this.removeLetters();
/* 161 */         if (text.equals("")) {
/* 162 */           return;
/*     */         }
/* 164 */         ItemHeaderPanel.this.item.setUniqueID(Integer.parseInt(text));
/*     */       }
/* 166 */     });
/* 167 */     this.id.setFont(new Font("Segoe UI", 1, 20));
/* 168 */     JPanel idLine = new JPanel();
/* 169 */     idLine.setLayout(new GridBagLayout());
/* 170 */     panel.add(idLine, gc2);
/* 171 */     GridBagConstraints gc3 = new GridBagConstraints();
/* 172 */     gc3.fill = 1;
/* 173 */     gc3.gridx = 0;
/* 174 */     gc3.gridy = 0;
/* 175 */     gc3.weightx = 0.20000000298023224D;
/* 176 */     gc3.weighty = 1.0D;
/* 177 */     this.categoryID = new JLabel(this.item.getCatID());
/* 178 */     this.categoryID.setFont(new Font("Segoe UI", 1, 20));
/* 179 */     idLine.add(this.categoryID, gc3);
/* 180 */     gc3.gridx = 1;
/* 181 */     gc3.weightx = 18.0D;
/* 182 */     idLine.add(this.id, gc3);
/*     */   }
/*     */   
/*     */   private String removeLetters()
/*     */   {
/* 187 */     String text = this.id.getText();
/* 188 */     String number = text.replaceAll("[^0-9]", "");
/* 189 */     return number;
/*     */   }
/*     */   
/*     */   private void resetAllItemInfo() {
/* 193 */     BufferedImage myPicture = this.item.getIcon();
/* 194 */     ImageIcon original = new ImageIcon(myPicture);
/* 195 */     ImageIcon resized = resizeImage(original);
/* 196 */     this.icon.setIcon(resized);
/* 197 */     this.name.setText(this.item.getName());
/* 198 */     this.id.setText(this.item.getUniqueID());
/* 199 */     this.categoryID.setText(this.item.getCatID());
/*     */   }
/*     */   
/*     */   private ImageIcon resizeImage(ImageIcon original)
/*     */   {
/* 204 */     Image img = original.getImage();
/* 205 */     Image resized = getScaledImage(img, 85, 85);
/* 206 */     return new ImageIcon(resized);
/*     */   }
/*     */   
/*     */   private Image getScaledImage(Image srcImg, int w, int h) {
/* 210 */     BufferedImage resizedImg = new BufferedImage(w, h, 2);
/* 211 */     Graphics2D g2 = resizedImg.createGraphics();
/* 212 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     
/* 214 */     g2.drawImage(srcImg, 0, 0, w, h, null);
/* 215 */     g2.dispose();
/* 216 */     return resizedImg;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\ItemHeaderPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */