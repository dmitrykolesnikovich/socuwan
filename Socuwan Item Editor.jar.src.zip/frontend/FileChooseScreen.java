/*     */ package frontend;
/*     */ 
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.WorkSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileChooseScreen
/*     */ {
/*     */   private static final int MAIN_FONT_SIZE = 15;
/*     */   private static final int LIST_FONT_SIZE = 13;
/*     */   private static final String MESSAGE = "Choose an item file!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private WorkSpace workspace;
/*     */   private MainFrame mainFrame;
/*     */   private JList<ItemFile> list;
/*     */   private JButton confirm;
/*     */   
/*     */   public FileChooseScreen(List<File> files, WorkSpace workspace, MainFrame mainFrame)
/*     */   {
/*  38 */     this.workspace = workspace;
/*  39 */     this.mainFrame = mainFrame;
/*  40 */     setUpFrame();
/*  41 */     addLabel();
/*  42 */     List<File> goodFiles = getRidOfBadFiles(files);
/*  43 */     addFileList(goodFiles);
/*  44 */     addButton();
/*  45 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  49 */     this.frame = new JDialog();
/*  50 */     this.frame.setAlwaysOnTop(true);
/*  51 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  52 */     this.frame.setSize(300, 300);
/*  53 */     this.frame.setResizable(false);
/*  54 */     this.frame.setLocationRelativeTo(null);
/*  55 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  59 */     GridBagConstraints gc = new GridBagConstraints();
/*  60 */     gc.gridx = 0;
/*  61 */     gc.gridy = 1;
/*  62 */     gc.weightx = 1.0D;
/*  63 */     gc.weighty = 1.0D;
/*     */     
/*  65 */     ItemFile[] data = getAllFilesInList(files);
/*  66 */     this.list = new JList(data);
/*  67 */     this.list.setFont(new Font("Segoe UI", 1, 13));
/*  68 */     this.list.setSelectionMode(1);
/*  69 */     this.list.setLayoutOrientation(0);
/*  70 */     this.list.setVisibleRowCount(-1);
/*  71 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  72 */     listScroller.setPreferredSize(new Dimension(250, 180));
/*  73 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private ItemFile[] getAllFilesInList(List<File> files) {
/*  77 */     ItemFile[] listedFiles = new ItemFile[files.size()];
/*  78 */     for (int i = 0; i < listedFiles.length; i++) {
/*  79 */       listedFiles[i] = new ItemFile((File)files.get(i));
/*     */     }
/*  81 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  85 */     JLabel text = new JLabel("Choose an item file!");
/*  86 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  87 */     GridBagConstraints gc = new GridBagConstraints();
/*  88 */     gc.gridx = 0;
/*  89 */     gc.gridy = 0;
/*  90 */     gc.weightx = 1.0D;
/*  91 */     gc.weighty = 0.4D;
/*  92 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/*  96 */     this.confirm = new JButton("Open");
/*  97 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/*  98 */     GridBagConstraints gc = new GridBagConstraints();
/*  99 */     gc.gridx = 0;
/* 100 */     gc.gridy = 2;
/* 101 */     gc.weightx = 1.0D;
/* 102 */     gc.weighty = 0.4D;
/* 103 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 107 */         if (!FileChooseScreen.this.list.isSelectionEmpty()) {
/* 108 */           File chosen = ((ItemFile)FileChooseScreen.this.list.getSelectedValue()).getFile();
/*     */           try {
/* 110 */             FileChooseScreen.this.workspace.open(chosen);
/* 111 */             FileChooseScreen.this.frame.setVisible(false);
/* 112 */             FileChooseScreen.this.mainFrame.setItem(FileChooseScreen.this.workspace.getCurrentItem());
/*     */           }
/*     */           catch (Exception e) {
/* 115 */             e.printStackTrace();
/* 116 */             System.err.println("INVALID FILE FORMAT!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 122 */     });
/* 123 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getRidOfBadFiles(List<File> files) {
/* 127 */     List<File> goodFiles = new ArrayList();
/* 128 */     for (File file : files) {
/*     */       try {
/* 130 */         Integer.parseInt(file.getName());
/* 131 */         if (file.isDirectory()) {
/* 132 */           goodFiles.add(file);
/*     */         }
/*     */       } catch (Exception e) {
/* 135 */         System.err.println("Bad Item File!");
/*     */       }
/*     */     }
/* 138 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\FileChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */