/*    */ package frontend;
/*    */ 
/*    */ import instances.HumanEntity;
/*    */ import java.awt.Dialog.ModalityType;
/*    */ import java.awt.Font;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JCheckBox;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JLabel;
/*    */ import main.MainApp;
/*    */ import main.PlayerAnimation;
/*    */ 
/*    */ public class PreviewOptionsPopUp
/*    */ {
/*    */   private JDialog frame;
/*    */   
/*    */   public PreviewOptionsPopUp()
/*    */   {
/* 23 */     setUpFrame();
/* 24 */     addRotationChoice();
/* 25 */     addAnimationChoice();
/* 26 */     this.frame.setVisible(true);
/*    */   }
/*    */   
/*    */   private void setUpFrame() {
/* 30 */     this.frame = new JDialog();
/* 31 */     this.frame.setAlwaysOnTop(true);
/* 32 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/* 33 */     this.frame.setSize(200, 200);
/* 34 */     this.frame.setResizable(false);
/* 35 */     this.frame.setLocationRelativeTo(null);
/* 36 */     this.frame.setLayout(new GridBagLayout());
/*    */   }
/*    */   
/*    */   private void addRotationChoice() {
/* 40 */     final JCheckBox rotate = new JCheckBox("Rotate Player");
/* 41 */     rotate.setSelected(MainApp.rotatePreview);
/* 42 */     rotate.setFont(new Font("Segoe UI", 1, 14));
/* 43 */     rotate.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent arg0)
/*    */       {
/* 47 */         MainApp.rotatePreview = rotate.isSelected();
/*    */       }
/*    */       
/* 50 */     });
/* 51 */     this.frame.add(rotate, getGC(0, 1, 2));
/*    */   }
/*    */   
/*    */   private void addAnimationChoice() {
/* 55 */     JLabel label = new JLabel("Animation: ");
/* 56 */     label.setFont(new Font("Segoe UI", 1, 14));
/* 57 */     this.frame.add(label, getGC(0, 0, 1));
/* 58 */     final JComboBox<PlayerAnimation> animations = new JComboBox(PlayerAnimation.values());
/*    */     
/* 60 */     animations.setFont(new Font("Segoe UI", 1, 14));
/* 61 */     animations.setSelectedItem(MainApp.character.getCurrentPlayerAnimation());
/* 62 */     animations.addActionListener(new ActionListener()
/*    */     {
/*    */ 
/*    */       public void actionPerformed(ActionEvent arg0) {
/* 66 */         MainApp.character.doAnimation((PlayerAnimation)animations.getSelectedItem()); }
/* 67 */     });
/* 68 */     this.frame.add(animations, getGC(1, 0, 1));
/*    */   }
/*    */   
/*    */   private GridBagConstraints getGC(int x, int y, int width) {
/* 72 */     GridBagConstraints gc = new GridBagConstraints();
/* 73 */     gc.gridx = x;
/* 74 */     gc.gridy = y;
/* 75 */     gc.gridwidth = width;
/* 76 */     gc.weightx = 1.0D;
/* 77 */     gc.weighty = 1.0D;
/* 78 */     return gc;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\PreviewOptionsPopUp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */