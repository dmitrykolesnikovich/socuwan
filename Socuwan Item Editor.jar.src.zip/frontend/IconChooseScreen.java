/*     */ package frontend;
/*     */ 
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.Configs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IconChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose an icon!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   private ItemHeaderPanel header;
/*     */   
/*     */   public IconChooseScreen(ItemHeaderPanel header)
/*     */   {
/*  36 */     this.header = header;
/*  37 */     setUpFrame();
/*  38 */     addLabel();
/*  39 */     addFileList(getAllIconFiles());
/*  40 */     addButton();
/*  41 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  45 */     this.frame = new JDialog();
/*  46 */     this.frame.setAlwaysOnTop(true);
/*  47 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  48 */     this.frame.setSize(300, 500);
/*  49 */     this.frame.setResizable(false);
/*  50 */     this.frame.setLocationRelativeTo(null);
/*  51 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  55 */     GridBagConstraints gc = new GridBagConstraints();
/*  56 */     gc.gridx = 0;
/*  57 */     gc.gridy = 1;
/*  58 */     gc.weightx = 1.0D;
/*  59 */     gc.weighty = 1.0D;
/*     */     
/*  61 */     FileInList[] data = getAllFilesInList(files);
/*  62 */     this.list = new JList(data);
/*  63 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  64 */     this.list.setSelectionMode(1);
/*  65 */     this.list.setLayoutOrientation(0);
/*  66 */     this.list.setVisibleRowCount(-1);
/*  67 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  68 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  69 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  73 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  74 */     for (int i = 0; i < listedFiles.length; i++) {
/*  75 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  77 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  81 */     JLabel text = new JLabel("Choose an icon!");
/*  82 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  83 */     GridBagConstraints gc = new GridBagConstraints();
/*  84 */     gc.gridx = 0;
/*  85 */     gc.gridy = 0;
/*  86 */     gc.weightx = 1.0D;
/*  87 */     gc.weighty = 0.4D;
/*  88 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/*  92 */     this.confirm = new JButton("Open");
/*  93 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/*  94 */     GridBagConstraints gc = new GridBagConstraints();
/*  95 */     gc.gridx = 0;
/*  96 */     gc.gridy = 2;
/*  97 */     gc.weightx = 1.0D;
/*  98 */     gc.weighty = 0.4D;
/*  99 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 103 */         if (!IconChooseScreen.this.list.isSelectionEmpty()) {
/* 104 */           File chosen = ((FileInList)IconChooseScreen.this.list.getSelectedValue()).getFile();
/* 105 */           IconChooseScreen.this.header.setIcon(chosen);
/* 106 */           IconChooseScreen.this.frame.setVisible(false);
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 111 */     });
/* 112 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllIconFiles() {
/* 116 */     File[] allFiles = Configs.ICONS_REPOS.listFiles();
/* 117 */     List<File> goodFiles = new ArrayList();
/* 118 */     for (File file : allFiles) {
/* 119 */       if (file.getName().endsWith(".png")) {
/* 120 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 123 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\IconChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */