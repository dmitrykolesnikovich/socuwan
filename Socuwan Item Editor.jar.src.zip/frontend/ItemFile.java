/*    */ package frontend;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class ItemFile
/*    */ {
/*    */   private File file;
/*    */   private String fileName;
/*    */   
/*    */   public ItemFile(File file)
/*    */   {
/* 17 */     File configs = new File(file, "info.txt");
/*    */     try {
/* 19 */       int id = Integer.parseInt(file.getName().split("\\.")[0]);
/* 20 */       BufferedReader reader = openFile(configs);
/* 21 */       this.fileName = (id + " - " + reader.readLine().split(";")[0]);
/* 22 */       closeFile(reader);
/*    */     } catch (Exception e) {
/* 24 */       this.fileName = ("INVALID: " + file.getName());
/*    */     }
/* 26 */     this.file = file;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 30 */     return this.fileName;
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 34 */     return this.file;
/*    */   }
/*    */   
/*    */   private static BufferedReader openFile(File file) {
/* 38 */     BufferedReader reader = null;
/*    */     try {
/* 40 */       FileReader isr = new FileReader(file);
/* 41 */       reader = new BufferedReader(isr);
/*    */     } catch (FileNotFoundException e) {
/* 43 */       System.err.println("File not found!");
/* 44 */       e.printStackTrace();
/*    */     }
/* 46 */     return reader;
/*    */   }
/*    */   
/*    */   private static void closeFile(BufferedReader file) {
/*    */     try {
/* 51 */       file.close();
/*    */     } catch (IOException e) {
/* 53 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\frontend\ItemFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */