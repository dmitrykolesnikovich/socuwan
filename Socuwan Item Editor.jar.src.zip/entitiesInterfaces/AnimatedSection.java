/*     */ package entitiesInterfaces;
/*     */ 
/*     */ import animations.AnimatablePart;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AnimatedSection implements AnimatablePart
/*     */ {
/*     */   private static final int NO_MORE_CHILDREN = -1;
/*     */   private BoneBlueprint bone;
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private double rotW;
/*     */   private double rotX;
/*     */   private double rotY;
/*     */   private double rotZ;
/*     */   private float scale;
/*  20 */   private List<AnimatedSection> childrenNodes = new ArrayList();
/*     */   private AnimatedSection parentNode;
/*     */   private int currentChild;
/*     */   private boolean hasParent;
/*     */   private AnimatedEntityInterface parentEntity;
/*     */   
/*     */   public AnimatedSection(AnimatedEntityInterface parentEntity, BoneBlueprint bone, AnimatedSection parent)
/*     */   {
/*  28 */     this.bone = bone;
/*  29 */     this.x = 0.0F;
/*  30 */     this.y = 0.0F;
/*  31 */     this.z = 0.0F;
/*  32 */     this.rotW = 1.0D;
/*  33 */     this.rotX = 0.0D;
/*  34 */     this.rotY = 0.0D;
/*  35 */     this.rotZ = 0.0D;
/*  36 */     this.scale = 1.0F;
/*  37 */     this.hasParent = true;
/*  38 */     this.parentNode = parent;
/*  39 */     this.currentChild = -1;
/*  40 */     this.parentEntity = parentEntity;
/*     */   }
/*     */   
/*     */   public AnimatedSection(AnimatedEntityInterface parentEntity, BoneBlueprint bone) {
/*  44 */     this.bone = bone;
/*  45 */     this.x = 0.0F;
/*  46 */     this.y = 0.0F;
/*  47 */     this.z = 0.0F;
/*  48 */     this.rotW = 1.0D;
/*  49 */     this.rotX = 0.0D;
/*  50 */     this.rotY = 0.0D;
/*  51 */     this.rotZ = 0.0D;
/*  52 */     this.scale = 1.0F;
/*  53 */     this.hasParent = false;
/*  54 */     this.currentChild = -1;
/*  55 */     this.parentEntity = parentEntity;
/*     */   }
/*     */   
/*     */   public BoneBlueprint getBone() {
/*  59 */     return this.bone;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  63 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  67 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  71 */     return this.z;
/*     */   }
/*     */   
/*     */   public double getRotW() {
/*  75 */     return this.rotW;
/*     */   }
/*     */   
/*     */   public double getRotX() {
/*  79 */     return this.rotX;
/*     */   }
/*     */   
/*     */   public double getRotY() {
/*  83 */     return this.rotY;
/*     */   }
/*     */   
/*     */   public double getRotZ() {
/*  87 */     return this.rotZ;
/*     */   }
/*     */   
/*     */   public float getScale() {
/*  91 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setPosition(float x, float y, float z) {
/*  95 */     this.x = x;
/*  96 */     this.y = y;
/*  97 */     this.z = z;
/*     */   }
/*     */   
/*     */   public void setScale(float scale) {
/* 101 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public void setRotation(double w, double x, double y, double z) {
/* 105 */     this.rotW = w;
/* 106 */     this.rotX = x;
/* 107 */     this.rotY = y;
/* 108 */     this.rotZ = z;
/*     */   }
/*     */   
/*     */   public void addChild(AnimatedSection child) {
/* 112 */     this.childrenNodes.add(child);
/* 113 */     this.currentChild += 1;
/*     */   }
/*     */   
/*     */   public AnimatedSection getNextChild() {
/* 117 */     if (this.currentChild == -1) {
/* 118 */       this.currentChild = (this.childrenNodes.size() - 1);
/* 119 */       return null;
/*     */     }
/* 121 */     return (AnimatedSection)this.childrenNodes.get(this.currentChild--);
/*     */   }
/*     */   
/*     */   public AnimatedSection getParent()
/*     */   {
/* 126 */     return this.parentNode;
/*     */   }
/*     */   
/*     */   public boolean hasParent() {
/* 130 */     return this.hasParent;
/*     */   }
/*     */   
/*     */   public AnimatedEntityInterface getParentEntity() {
/* 134 */     return this.parentEntity;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\entitiesInterfaces\AnimatedSection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */