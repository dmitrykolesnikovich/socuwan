package entitiesInterfaces;

import blueprintInterfaces.AnimatedBlueprintInterface;

public abstract interface AnimatedEntityInterface
  extends EntityInterface
{
  public abstract AnimatedBlueprintInterface getBlueprint();
  
  public abstract AnimatedSection[] getSections();
  
  public abstract AnimatedSection[] getHeadNodes();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\entitiesInterfaces\AnimatedEntityInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */