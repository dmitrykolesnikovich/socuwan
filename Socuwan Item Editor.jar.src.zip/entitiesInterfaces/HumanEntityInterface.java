package entitiesInterfaces;

import accessories.AccessoryInterface;
import accessories.ClothesInstanceInterface;
import accessories.ClothesSection;
import java.util.List;
import java.util.Map;

public abstract interface HumanEntityInterface
  extends AnimatedEntityInterface
{
  public abstract Map<ClothesInstanceInterface, ClothesSection> getClothesSectionsOnNode(int paramInt);
  
  public abstract List<AccessoryInterface> getAccessoriesOnNode(int paramInt);
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\entitiesInterfaces\HumanEntityInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */