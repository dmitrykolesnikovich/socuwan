/*     */ package components;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.NumberFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FoodPanel
/*     */   extends ComponentPanel
/*     */ {
/*     */   private static final String FILLING_NAME = "Fulfillingness (0-100): ";
/*     */   private static final String RELEASE_NAME = "Release Speed (seconds): ";
/*     */   private static final int FONT_SIZE = 20;
/*     */   private JFormattedTextField fulfillingnes;
/*     */   private JFormattedTextField energyRelease;
/*     */   private FoodComponent foodStats;
/*     */   
/*     */   public FoodPanel(FoodComponent foodStats)
/*     */   {
/*  31 */     this.foodStats = foodStats;
/*  32 */     setPreferredSize(new Dimension(405, 100));
/*  33 */     setBorder(BorderFactory.createTitledBorder("Food Statistics"));
/*  34 */     setLayout(new GridBagLayout());
/*  35 */     GridBagConstraints gc = new GridBagConstraints();
/*  36 */     gc.fill = 1;
/*  37 */     gc.gridx = 0;
/*  38 */     gc.gridy = 0;
/*  39 */     gc.weightx = 1.0D;
/*  40 */     gc.weighty = 1.0D;
/*  41 */     setUpFulfillingPanel(gc);
/*  42 */     gc.gridy = 1;
/*  43 */     setUpReleasePanel(gc);
/*     */   }
/*     */   
/*     */   private void setUpFulfillingPanel(GridBagConstraints gc) {
/*  47 */     JPanel panel = new JPanel();
/*  48 */     panel.setLayout(new GridBagLayout());
/*  49 */     GridBagConstraints gc2 = new GridBagConstraints();
/*  50 */     gc2.fill = 1;
/*  51 */     gc2.gridx = 0;
/*  52 */     gc2.gridy = 0;
/*  53 */     gc2.weightx = 1.0D;
/*  54 */     gc2.weighty = 1.0D;
/*  55 */     JLabel label = new JLabel("Fulfillingness (0-100): ");
/*  56 */     label.setFont(new Font("Segoe UI", 1, 20));
/*  57 */     panel.add(label, gc2);
/*  58 */     gc2.gridx = 1;
/*  59 */     gc2.weightx = 2.0D;
/*  60 */     NumberFormat floatFormat = NumberFormat.getNumberInstance();
/*  61 */     floatFormat.setMinimumFractionDigits(1);
/*  62 */     floatFormat.setMaximumFractionDigits(5);
/*  63 */     NumberFormatter numberFormatter = new NumberFormatter(floatFormat);
/*  64 */     numberFormatter.setValueClass(Float.class);
/*  65 */     numberFormatter.setAllowsInvalid(false);
/*  66 */     numberFormatter.setMinimum(Float.valueOf(0.0F));
/*  67 */     numberFormatter.setMaximum(Float.valueOf(100.0F));
/*  68 */     this.fulfillingnes = new JFormattedTextField(numberFormatter);
/*  69 */     this.fulfillingnes.setText(Float.toString(this.foodStats.getFulfillingness()));
/*  70 */     this.fulfillingnes.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/*  72 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/*  76 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/*  80 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/*  84 */         if (FoodPanel.this.fulfillingnes.getText().equals("")) {
/*  85 */           return;
/*     */         }
/*  87 */         FoodPanel.this.foodStats.setFulfillingness(Float.parseFloat(FoodPanel.this.removeLetters(FoodPanel.this.fulfillingnes.getText())));
/*     */       }
/*  89 */     });
/*  90 */     this.fulfillingnes.setFont(new Font("Segoe UI", 1, 20));
/*  91 */     this.fulfillingnes.setColumns(40);
/*  92 */     panel.add(this.fulfillingnes, gc2);
/*     */     
/*  94 */     add(panel, gc);
/*     */   }
/*     */   
/*     */   private void setUpReleasePanel(GridBagConstraints gc) {
/*  98 */     JPanel panel = new JPanel();
/*  99 */     panel.setLayout(new GridBagLayout());
/* 100 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 101 */     gc2.fill = 1;
/* 102 */     gc2.gridx = 0;
/* 103 */     gc2.gridy = 0;
/* 104 */     gc2.weightx = 1.0D;
/* 105 */     gc2.weighty = 1.0D;
/* 106 */     JLabel label = new JLabel("Release Speed (seconds): ");
/* 107 */     label.setFont(new Font("Segoe UI", 1, 20));
/* 108 */     panel.add(label, gc2);
/* 109 */     gc2.gridx = 1;
/* 110 */     gc2.weightx = 4.0D;
/* 111 */     NumberFormat floatFormat = NumberFormat.getNumberInstance();
/* 112 */     floatFormat.setMinimumFractionDigits(1);
/* 113 */     floatFormat.setMaximumFractionDigits(5);
/* 114 */     NumberFormatter numberFormatter = new NumberFormatter(floatFormat);
/* 115 */     numberFormatter.setValueClass(Float.class);
/* 116 */     numberFormatter.setAllowsInvalid(false);
/* 117 */     numberFormatter.setMinimum(Float.valueOf(0.0F));
/* 118 */     this.energyRelease = new JFormattedTextField(numberFormatter);
/* 119 */     this.energyRelease.setText(Float.toString(this.foodStats.getReleaseTime()));
/* 120 */     this.energyRelease.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 122 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 126 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 130 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 134 */         if (FoodPanel.this.energyRelease.getText().equals("")) {
/* 135 */           return;
/*     */         }
/* 137 */         FoodPanel.this.foodStats.setReleaseTime(Float.parseFloat(FoodPanel.this.removeLetters(FoodPanel.this.energyRelease.getText())));
/*     */       }
/* 139 */     });
/* 140 */     this.energyRelease.setFont(new Font("Segoe UI", 1, 20));
/* 141 */     this.energyRelease.setColumns(70);
/* 142 */     panel.add(this.energyRelease, gc2);
/*     */     
/* 144 */     add(panel, gc);
/*     */   }
/*     */   
/*     */   private String removeLetters(String original) {
/* 148 */     String number = original.replaceAll(",", "");
/* 149 */     return number;
/*     */   }
/*     */   
/*     */   public void destroy() {}
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\components\FoodPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */