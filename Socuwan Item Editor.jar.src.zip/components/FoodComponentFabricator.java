/*   */ package components;
/*   */ 
/*   */ import backend.Item;
/*   */ 
/*   */ public class FoodComponentFabricator implements ComponentFabricator
/*   */ {
/*   */   public Component createNewComponent(Item item)
/*   */   {
/* 9 */     return new FoodComponent();
/*   */   }
/*   */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\components\FoodComponentFabricator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */