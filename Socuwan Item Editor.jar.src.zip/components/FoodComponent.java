/*    */ package components;
/*    */ 
/*    */ import categories.SubCategoryInterface;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FoodComponent
/*    */   extends Component
/*    */ {
/*    */   private static final String SEPARATOR = ";";
/*    */   public static final String IDENTIFIER = "FOOD";
/* 16 */   private float fulfillingness = 0.0F;
/* 17 */   private float releaseTime = 0.0F;
/*    */   
/*    */   public FoodComponent() {}
/*    */   
/*    */   public FoodComponent(BufferedReader reader) throws Exception {
/* 22 */     String[] values = reader.readLine().split(";");
/* 23 */     this.fulfillingness = Float.parseFloat(values[0]);
/* 24 */     this.releaseTime = Float.parseFloat(values[1]);
/*    */   }
/*    */   
/*    */   public void exportInfo(PrintWriter infoFile)
/*    */   {
/* 29 */     infoFile.println("FOOD");
/* 30 */     infoFile.print(this.fulfillingness);
/* 31 */     infoFile.print(";");
/* 32 */     infoFile.print(this.releaseTime);
/* 33 */     infoFile.println();
/*    */   }
/*    */   
/*    */   public float getFulfillingness() {
/* 37 */     return this.fulfillingness;
/*    */   }
/*    */   
/*    */   public void setFulfillingness(float fulfillingness) {
/* 41 */     this.fulfillingness = fulfillingness;
/*    */   }
/*    */   
/*    */   public float getReleaseTime() {
/* 45 */     return this.releaseTime;
/*    */   }
/*    */   
/*    */   public void setReleaseTime(float releaseTime) {
/* 49 */     this.releaseTime = releaseTime;
/*    */   }
/*    */   
/*    */   public ComponentPanel createComponentPanel()
/*    */   {
/* 54 */     return new FoodPanel(this);
/*    */   }
/*    */   
/*    */   public void notifyNewItemFile(File itemFile) {}
/*    */   
/*    */   public void notifySecondaryCategoryChange(SubCategoryInterface sub) {}
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\components\FoodComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */