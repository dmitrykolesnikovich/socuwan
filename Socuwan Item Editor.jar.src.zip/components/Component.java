package components;

import categories.SubCategoryInterface;
import java.io.File;
import java.io.PrintWriter;

public abstract class Component
{
  public abstract void exportInfo(PrintWriter paramPrintWriter);
  
  public abstract ComponentPanel createComponentPanel();
  
  public abstract void notifyNewItemFile(File paramFile);
  
  public abstract void notifySecondaryCategoryChange(SubCategoryInterface paramSubCategoryInterface);
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\components\Component.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */