package components;

import backend.Item;

public abstract interface ComponentFabricator
{
  public abstract Component createNewComponent(Item paramItem);
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\components\ComponentFabricator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */