package org.lwjgl.opencl;

public final class KHRDepthImages
{
  public static final int CL_DEPTH = 4285;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opencl\KHRDepthImages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */