package org.lwjgl.opencl;

public final class KHRInitializeMemory
{
  public static final int CL_CONTEXT_MEMORY_INITIALIZE_KHR = 8206;
  public static final int CL_CONTEXT_MEMORY_INITIALIZE_LOCAL_KHR = 1;
  public static final int CL_CONTEXT_MEMORY_INITIALIZE_PRIVATE_KHR = 2;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opencl\KHRInitializeMemory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */