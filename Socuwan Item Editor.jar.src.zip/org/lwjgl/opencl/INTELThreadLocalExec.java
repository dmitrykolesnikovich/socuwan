package org.lwjgl.opencl;

public final class INTELThreadLocalExec
{
  public static final int CL_QUEUE_THREAD_LOCAL_EXEC_ENABLE_INTEL = Integer.MIN_VALUE;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opencl\INTELThreadLocalExec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */