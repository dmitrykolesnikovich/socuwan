package org.lwjgl.opencl;

public final class KHRImage2DFromBuffer
{
  public static final int CL_DEVICE_IMAGE_PITCH_ALIGNMENT = 4170;
  public static final int CL_DEVICE_IMAGE_BASE_ADDRESS_ALIGNMENT = 4171;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opencl\KHRImage2DFromBuffer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */