package org.lwjgl.opencl;

public final class INTELImmediateExecution
{
  public static final int CL_QUEUE_IMMEDIATE_EXECUTION_ENABLE_INTEL = 4;
  public static final int CL_EXEC_IMMEDIATE_EXECUTION_INTEL = 4;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opencl\INTELImmediateExecution.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */