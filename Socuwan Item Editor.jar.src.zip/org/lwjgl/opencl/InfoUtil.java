package org.lwjgl.opencl;

abstract interface InfoUtil<T extends CLObject>
{
  public abstract int getInfoInt(T paramT, int paramInt);
  
  public abstract long getInfoSize(T paramT, int paramInt);
  
  public abstract long[] getInfoSizeArray(T paramT, int paramInt);
  
  public abstract long getInfoLong(T paramT, int paramInt);
  
  public abstract String getInfoString(T paramT, int paramInt);
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opencl\InfoUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */