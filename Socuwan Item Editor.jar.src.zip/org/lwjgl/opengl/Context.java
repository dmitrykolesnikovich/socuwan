package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;

abstract interface Context
{
  public abstract boolean isCurrent()
    throws LWJGLException;
  
  public abstract void makeCurrent()
    throws LWJGLException;
  
  public abstract void releaseCurrent()
    throws LWJGLException;
  
  public abstract void releaseDrawable()
    throws LWJGLException;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\Context.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */