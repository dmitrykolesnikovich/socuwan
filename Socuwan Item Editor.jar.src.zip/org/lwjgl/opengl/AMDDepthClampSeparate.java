package org.lwjgl.opengl;

public final class AMDDepthClampSeparate
{
  public static final int GL_DEPTH_CLAMP_NEAR_AMD = 36894;
  public static final int GL_DEPTH_CLAMP_FAR_AMD = 36895;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\AMDDepthClampSeparate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */