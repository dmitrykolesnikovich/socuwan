package org.lwjgl.opengl;

public final class ARBPointSprite
{
  public static final int GL_POINT_SPRITE_ARB = 34913;
  public static final int GL_COORD_REPLACE_ARB = 34914;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\ARBPointSprite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */