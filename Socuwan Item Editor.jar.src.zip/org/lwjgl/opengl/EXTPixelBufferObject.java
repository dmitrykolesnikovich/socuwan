package org.lwjgl.opengl;

public final class EXTPixelBufferObject
  extends ARBBufferObject
{
  public static final int GL_PIXEL_PACK_BUFFER_EXT = 35051;
  public static final int GL_PIXEL_UNPACK_BUFFER_EXT = 35052;
  public static final int GL_PIXEL_PACK_BUFFER_BINDING_EXT = 35053;
  public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_EXT = 35055;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\EXTPixelBufferObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */