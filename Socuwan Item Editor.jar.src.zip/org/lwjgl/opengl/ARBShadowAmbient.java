package org.lwjgl.opengl;

public final class ARBShadowAmbient
{
  public static final int GL_TEXTURE_COMPARE_FAIL_VALUE_ARB = 32959;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\ARBShadowAmbient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */