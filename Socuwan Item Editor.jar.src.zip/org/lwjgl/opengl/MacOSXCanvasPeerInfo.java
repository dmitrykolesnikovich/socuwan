/*     */ package org.lwjgl.opengl;
/*     */ 
/*     */ import java.applet.Applet;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.nio.ByteBuffer;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.lwjgl.LWJGLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MacOSXCanvasPeerInfo
/*     */   extends MacOSXPeerInfo
/*     */ {
/*  57 */   private final AWTSurfaceLock awt_surface = new AWTSurfaceLock();
/*     */   public ByteBuffer window_handle;
/*     */   
/*     */   protected MacOSXCanvasPeerInfo(PixelFormat pixel_format, ContextAttribs attribs, boolean support_pbuffer) throws LWJGLException {
/*  61 */     super(pixel_format, attribs, true, true, support_pbuffer, true);
/*     */   }
/*     */   
/*     */   protected void initHandle(Canvas component) throws LWJGLException {
/*  65 */     boolean forceCALayer = true;
/*  66 */     boolean autoResizable = true;
/*     */     
/*  68 */     String javaVersion = System.getProperty("java.version");
/*     */     
/*  70 */     if ((javaVersion.startsWith("1.5")) || (javaVersion.startsWith("1.6")))
/*     */     {
/*     */ 
/*     */ 
/*  74 */       forceCALayer = false;
/*     */     }
/*  76 */     else if (javaVersion.startsWith("1.7")) {
/*  77 */       autoResizable = false;
/*     */     }
/*     */     
/*  80 */     Insets insets = getInsets(component);
/*     */     
/*  82 */     int top = insets != null ? insets.top : 0;
/*  83 */     int left = insets != null ? insets.left : 0;
/*     */     
/*  85 */     this.window_handle = nInitHandle(this.awt_surface.lockAndGetHandle(component), getHandle(), this.window_handle, forceCALayer, autoResizable, component.getX() - left, component.getY() - top);
/*     */     
/*  87 */     if (javaVersion.startsWith("1.7"))
/*     */     {
/*     */ 
/*  90 */       addComponentListener(component);
/*     */       
/*  92 */       if (SwingUtilities.getWindowAncestor(component.getParent()) != null) {
/*  93 */         Point componentPosition = SwingUtilities.convertPoint(component, component.getLocation(), null);
/*  94 */         Point parentPosition = SwingUtilities.convertPoint(component.getParent(), component.getLocation(), null);
/*     */         
/*  96 */         if ((componentPosition.getX() == parentPosition.getX()) && (componentPosition.getY() == parentPosition.getY())) {
/*  97 */           insets = getWindowInsets(component);
/*     */           
/*  99 */           top = insets != null ? insets.top : 0;
/* 100 */           left = insets != null ? insets.left : 0;
/*     */           
/* 102 */           int x = (int)componentPosition.getX() - left;
/* 103 */           int y = (int)-componentPosition.getY() + top - component.getHeight();
/*     */           
/* 105 */           int width = component.getWidth();
/* 106 */           int height = component.getHeight();
/*     */           
/* 108 */           nSetLayerBounds(getHandle(), x, y, width, height);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addComponentListener(final Canvas component)
/*     */   {
/* 116 */     ComponentListener[] components = component.getComponentListeners();
/*     */     
/*     */ 
/* 119 */     for (int i = 0; i < components.length; i++) {
/* 120 */       ComponentListener c = components[i];
/* 121 */       if (c.toString() == "CanvasPeerInfoListener") {
/* 122 */         return;
/*     */       }
/*     */     }
/*     */     
/* 126 */     ComponentListener comp = new ComponentListener()
/*     */     {
/*     */       public void componentHidden(ComponentEvent e) {}
/*     */       
/*     */ 
/*     */       public void componentMoved(ComponentEvent e)
/*     */       {
/* 133 */         if (SwingUtilities.getWindowAncestor(component.getParent()) != null) {
/* 134 */           Point componentPosition = SwingUtilities.convertPoint(component, component.getLocation(), null);
/* 135 */           Point parentPosition = SwingUtilities.convertPoint(component.getParent(), component.getLocation(), null);
/*     */           
/* 137 */           if ((componentPosition.getX() == parentPosition.getX()) && (componentPosition.getY() == parentPosition.getY())) {
/* 138 */             Insets insets = MacOSXCanvasPeerInfo.this.getWindowInsets(component);
/*     */             
/* 140 */             int top = insets != null ? insets.top : 0;
/* 141 */             int left = insets != null ? insets.left : 0;
/*     */             
/* 143 */             MacOSXCanvasPeerInfo.nSetLayerBounds(MacOSXCanvasPeerInfo.this.getHandle(), (int)componentPosition.getX() - left, (int)componentPosition.getY() - top, component.getWidth(), component.getHeight());
/* 144 */             return;
/*     */           }
/*     */         }
/*     */         
/* 148 */         Insets insets = MacOSXCanvasPeerInfo.this.getInsets(component);
/*     */         
/* 150 */         int top = insets != null ? insets.top : 0;
/* 151 */         int left = insets != null ? insets.left : 0;
/*     */         
/*     */ 
/* 154 */         MacOSXCanvasPeerInfo.nSetLayerBounds(MacOSXCanvasPeerInfo.this.getHandle(), component.getX() - left, component.getY() - top, component.getWidth(), component.getHeight());
/*     */       }
/*     */       
/*     */       public void componentResized(ComponentEvent e)
/*     */       {
/* 159 */         if (SwingUtilities.getWindowAncestor(component.getParent()) != null) {
/* 160 */           Point componentPosition = SwingUtilities.convertPoint(component, component.getLocation(), null);
/* 161 */           Point parentPosition = SwingUtilities.convertPoint(component.getParent(), component.getLocation(), null);
/*     */           
/* 163 */           if ((componentPosition.getX() == parentPosition.getX()) && (componentPosition.getY() == parentPosition.getY())) {
/* 164 */             Insets insets = MacOSXCanvasPeerInfo.this.getWindowInsets(component);
/*     */             
/* 166 */             int top = insets != null ? insets.top : 0;
/* 167 */             int left = insets != null ? insets.left : 0;
/*     */             
/* 169 */             MacOSXCanvasPeerInfo.nSetLayerBounds(MacOSXCanvasPeerInfo.this.getHandle(), (int)componentPosition.getX() - left, (int)componentPosition.getY() - top, component.getWidth(), component.getHeight());
/* 170 */             return;
/*     */           }
/*     */         }
/*     */         
/* 174 */         Insets insets = MacOSXCanvasPeerInfo.this.getInsets(component);
/*     */         
/* 176 */         int top = insets != null ? insets.top : 0;
/* 177 */         int left = insets != null ? insets.left : 0;
/*     */         
/*     */ 
/* 180 */         MacOSXCanvasPeerInfo.nSetLayerBounds(MacOSXCanvasPeerInfo.this.getHandle(), component.getX() - left, component.getY() - top, component.getWidth(), component.getHeight());
/*     */       }
/*     */       
/*     */ 
/*     */       public void componentShown(ComponentEvent e) {}
/*     */       
/*     */       public String toString()
/*     */       {
/* 188 */         return "CanvasPeerInfoListener";
/*     */       }
/*     */       
/* 191 */     };
/* 192 */     component.addComponentListener(comp);
/*     */   }
/*     */   
/*     */   private static native ByteBuffer nInitHandle(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2, ByteBuffer paramByteBuffer3, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2) throws LWJGLException;
/*     */   
/*     */   private static native void nSetLayerPosition(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
/*     */   
/*     */   private static native void nSetLayerBounds(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */   protected void doUnlock() throws LWJGLException {
/* 202 */     this.awt_surface.unlock();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Insets getWindowInsets(Canvas canvas)
/*     */   {
/* 209 */     Container parent = canvas.getParent();
/*     */     
/* 211 */     while (parent != null) {
/* 212 */       if (((parent instanceof Window)) || ((parent instanceof Applet))) {
/* 213 */         return parent.getInsets();
/*     */       }
/*     */       
/* 216 */       parent = parent.getParent();
/*     */     }
/*     */     
/*     */ 
/* 220 */     return null;
/*     */   }
/*     */   
/*     */   private Insets getInsets(Canvas component) {
/* 224 */     Component parent = component.getParent();
/*     */     
/* 226 */     while (parent != null) {
/* 227 */       if ((parent instanceof Container)) {
/* 228 */         return ((Container)parent).getInsets();
/*     */       }
/* 230 */       parent = parent.getParent();
/*     */     }
/*     */     
/* 233 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\MacOSXCanvasPeerInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */