package org.lwjgl.opengl;

public final class EXTTextureSharedExponent
{
  public static final int GL_RGB9_E5_EXT = 35901;
  public static final int GL_UNSIGNED_INT_5_9_9_9_REV_EXT = 35902;
  public static final int GL_TEXTURE_SHARED_SIZE_EXT = 35903;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\EXTTextureSharedExponent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */