package org.lwjgl.opengl;

public final class ARBStencilTexturing
{
  public static final int GL_DEPTH_STENCIL_TEXTURE_MODE = 37098;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\ARBStencilTexturing.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */