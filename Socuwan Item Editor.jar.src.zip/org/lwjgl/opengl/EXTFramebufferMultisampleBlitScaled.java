package org.lwjgl.opengl;

public final class EXTFramebufferMultisampleBlitScaled
{
  public static final int GL_SCALED_RESOLVE_FASTEST_EXT = 37050;
  public static final int GL_SCALED_RESOLVE_NICEST_EXT = 37051;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\EXTFramebufferMultisampleBlitScaled.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */