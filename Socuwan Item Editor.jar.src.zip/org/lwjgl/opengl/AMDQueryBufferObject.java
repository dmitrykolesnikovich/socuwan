package org.lwjgl.opengl;

public final class AMDQueryBufferObject
{
  public static final int GL_QUERY_RESULT_NO_WAIT_AMD = 37268;
  public static final int GL_QUERY_BUFFER_AMD = 37266;
  public static final int GL_QUERY_BUFFER_BINDING_AMD = 37267;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\AMDQueryBufferObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */