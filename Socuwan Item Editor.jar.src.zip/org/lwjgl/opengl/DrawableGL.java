/*     */ package org.lwjgl.opengl;
/*     */ 
/*     */ import org.lwjgl.LWJGLException;
/*     */ import org.lwjgl.LWJGLUtil;
/*     */ import org.lwjgl.PointerBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DrawableGL
/*     */   implements DrawableLWJGL
/*     */ {
/*     */   protected PixelFormat pixel_format;
/*     */   protected PeerInfo peer_info;
/*     */   protected ContextGL context;
/*     */   
/*     */   public void setPixelFormat(PixelFormatLWJGL pf)
/*     */     throws LWJGLException
/*     */   {
/*  56 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setPixelFormat(PixelFormatLWJGL pf, ContextAttribs attribs) throws LWJGLException {
/*  60 */     this.pixel_format = ((PixelFormat)pf);
/*  61 */     this.peer_info = Display.getImplementation().createPeerInfo(this.pixel_format, attribs);
/*     */   }
/*     */   
/*     */   public PixelFormatLWJGL getPixelFormat() {
/*  65 */     return this.pixel_format;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public ContextGL getContext()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 9	org/lwjgl/opengl/GlobalLock:lock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 10	org/lwjgl/opengl/DrawableGL:context	Lorg/lwjgl/opengl/ContextGL;
/*     */     //   10: aload_1
/*     */     //   11: monitorexit
/*     */     //   12: areturn
/*     */     //   13: astore_2
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: aload_2
/*     */     //   17: athrow
/*     */     // Line number table:
/*     */     //   Java source line #69	-> byte code offset #0
/*     */     //   Java source line #70	-> byte code offset #6
/*     */     //   Java source line #71	-> byte code offset #13
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	18	0	this	DrawableGL
/*     */     //   4	11	1	Ljava/lang/Object;	Object
/*     */     //   13	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	12	13	finally
/*     */     //   13	16	13	finally
/*     */   }
/*     */   
/*     */   public ContextGL createSharedContext()
/*     */     throws LWJGLException
/*     */   {
/*  75 */     synchronized (GlobalLock.lock) {
/*  76 */       checkDestroyed();
/*  77 */       return new ContextGL(this.peer_info, this.context.getContextAttribs(), this.context);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void checkGLError() {}
/*     */   
/*     */   public void setSwapInterval(int swap_interval)
/*     */   {
/*  86 */     ContextGL.setSwapInterval(swap_interval);
/*     */   }
/*     */   
/*     */   public void swapBuffers()
/*     */     throws LWJGLException
/*     */   {}
/*     */   
/*     */   public void initContext(float r, float g, float b)
/*     */   {
/*  95 */     GL11.glClearColor(r, g, b, 0.0F);
/*     */     
/*  97 */     GL11.glClear(16384);
/*     */   }
/*     */   
/*     */   public boolean isCurrent() throws LWJGLException {
/* 101 */     synchronized (GlobalLock.lock) {
/* 102 */       checkDestroyed();
/* 103 */       return this.context.isCurrent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void makeCurrent() throws LWJGLException {
/* 108 */     synchronized (GlobalLock.lock) {
/* 109 */       checkDestroyed();
/* 110 */       this.context.makeCurrent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void releaseContext() throws LWJGLException {
/* 115 */     synchronized (GlobalLock.lock) {
/* 116 */       checkDestroyed();
/* 117 */       if (this.context.isCurrent())
/* 118 */         this.context.releaseCurrent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 123 */     synchronized (GlobalLock.lock) {
/* 124 */       if (this.context == null) {
/* 125 */         return;
/*     */       }
/*     */       try {
/* 128 */         releaseContext();
/*     */         
/* 130 */         this.context.forceDestroy();
/* 131 */         this.context = null;
/*     */         
/* 133 */         if (this.peer_info != null) {
/* 134 */           this.peer_info.destroy();
/* 135 */           this.peer_info = null;
/*     */         }
/*     */       } catch (LWJGLException e) {
/* 138 */         LWJGLUtil.log("Exception occurred while destroying Drawable: " + e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCLSharingProperties(PointerBuffer properties) throws LWJGLException {
/* 144 */     synchronized (GlobalLock.lock) {
/* 145 */       checkDestroyed();
/* 146 */       this.context.setCLSharingProperties(properties);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void checkDestroyed() {
/* 151 */     if (this.context == null) {
/* 152 */       throw new IllegalStateException("The Drawable has no context available.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\DrawableGL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */