package org.lwjgl.opengl;

public final class AMDBlendMinmaxFactor
{
  public static final int GL_FACTOR_MIN_AMD = 36892;
  public static final int GL_FACTOR_MAX_AMD = 36893;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\AMDBlendMinmaxFactor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */