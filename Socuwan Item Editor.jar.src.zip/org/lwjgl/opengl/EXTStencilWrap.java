package org.lwjgl.opengl;

public final class EXTStencilWrap
{
  public static final int GL_INCR_WRAP_EXT = 34055;
  public static final int GL_DECR_WRAP_EXT = 34056;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\EXTStencilWrap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */