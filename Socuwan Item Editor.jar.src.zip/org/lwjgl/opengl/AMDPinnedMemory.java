package org.lwjgl.opengl;

public final class AMDPinnedMemory
{
  public static final int GL_EXTERNAL_VIRTUAL_MEMORY_BUFFER_AMD = 37216;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\AMDPinnedMemory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */