/*      */ package org.lwjgl.opengl;
/*      */ 
/*      */ import java.awt.Canvas;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.lwjgl.BufferUtils;
/*      */ import org.lwjgl.LWJGLException;
/*      */ import org.lwjgl.LWJGLUtil;
/*      */ import org.lwjgl.MemoryUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class LinuxDisplay
/*      */   implements DisplayImplementation
/*      */ {
/*      */   public static final int CurrentTime = 0;
/*      */   public static final int GrabSuccess = 0;
/*      */   public static final int AutoRepeatModeOff = 0;
/*      */   public static final int AutoRepeatModeOn = 1;
/*      */   public static final int AutoRepeatModeDefault = 2;
/*      */   public static final int None = 0;
/*      */   private static final int KeyPressMask = 1;
/*      */   private static final int KeyReleaseMask = 2;
/*      */   private static final int ButtonPressMask = 4;
/*      */   private static final int ButtonReleaseMask = 8;
/*      */   private static final int NotifyAncestor = 0;
/*      */   private static final int NotifyNonlinear = 3;
/*      */   private static final int NotifyPointer = 5;
/*      */   private static final int NotifyPointerRoot = 6;
/*      */   private static final int NotifyDetailNone = 7;
/*      */   private static final int SetModeInsert = 0;
/*      */   private static final int SaveSetRoot = 1;
/*      */   private static final int SaveSetUnmap = 1;
/*      */   private static final int X_SetInputFocus = 42;
/*      */   private static final int FULLSCREEN_LEGACY = 1;
/*      */   private static final int FULLSCREEN_NETWM = 2;
/*      */   private static final int WINDOWED = 3;
/*   98 */   private static int current_window_mode = 3;
/*      */   private static final int XRANDR = 10;
/*      */   private static final int XF86VIDMODE = 11;
/*      */   private static final int NONE = 12;
/*      */   private static long display;
/*      */   private static long current_window;
/*      */   private static long saved_error_handler;
/*      */   private static int display_connection_usage_count;
/*      */   private final LinuxEvent event_buffer;
/*      */   private final LinuxEvent tmp_event_buffer;
/*      */   private int current_displaymode_extension;
/*      */   private long delete_atom;
/*      */   
/*      */   LinuxDisplay()
/*      */   {
/*  113 */     this.event_buffer = new LinuxEvent();
/*  114 */     this.tmp_event_buffer = new LinuxEvent();
/*      */     
/*      */ 
/*  117 */     this.current_displaymode_extension = 12;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  144 */     this.mouseInside = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  159 */     this.last_window_focus = 0L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  166 */     this.focus_listener = new FocusListener() {
/*      */       public void focusGained(FocusEvent e) {
/*  168 */         synchronized (GlobalLock.lock) {
/*  169 */           LinuxDisplay.this.parent_focused = true;
/*  170 */           LinuxDisplay.this.parent_focus_changed = true;
/*      */         }
/*      */       }
/*      */       
/*  174 */       public void focusLost(FocusEvent e) { synchronized (GlobalLock.lock) {
/*  175 */           LinuxDisplay.this.parent_focused = false;
/*  176 */           LinuxDisplay.this.parent_focus_changed = true;
/*      */         }
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private static ByteBuffer getCurrentGammaRamp()
/*      */     throws LWJGLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 17	org/lwjgl/opengl/LinuxDisplay:isXF86VidModeSupported	()Z
/*      */     //   9: ifeq +21 -> 30
/*      */     //   12: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   15: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*      */     //   18: invokestatic 20	org/lwjgl/opengl/LinuxDisplay:nGetCurrentGammaRamp	(JI)Ljava/nio/ByteBuffer;
/*      */     //   21: astore_0
/*      */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   25: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   28: aload_0
/*      */     //   29: areturn
/*      */     //   30: aconst_null
/*      */     //   31: astore_0
/*      */     //   32: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   35: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   38: aload_0
/*      */     //   39: areturn
/*      */     //   40: astore_1
/*      */     //   41: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   44: aload_1
/*      */     //   45: athrow
/*      */     //   46: astore_2
/*      */     //   47: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   50: aload_2
/*      */     //   51: athrow
/*      */     // Line number table:
/*      */     //   Java source line #182	-> byte code offset #0
/*      */     //   Java source line #184	-> byte code offset #3
/*      */     //   Java source line #186	-> byte code offset #6
/*      */     //   Java source line #187	-> byte code offset #12
/*      */     //   Java source line #191	-> byte code offset #22
/*      */     //   Java source line #194	-> byte code offset #25
/*      */     //   Java source line #189	-> byte code offset #30
/*      */     //   Java source line #191	-> byte code offset #32
/*      */     //   Java source line #194	-> byte code offset #35
/*      */     //   Java source line #191	-> byte code offset #40
/*      */     //   Java source line #194	-> byte code offset #46
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   21	18	0	localByteBuffer	ByteBuffer
/*      */     //   40	5	1	localObject1	Object
/*      */     //   46	5	2	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	22	40	finally
/*      */     //   30	32	40	finally
/*      */     //   40	41	40	finally
/*      */     //   3	25	46	finally
/*      */     //   30	35	46	finally
/*      */     //   40	47	46	finally
/*      */   }
/*      */   
/*      */   private static native ByteBuffer nGetCurrentGammaRamp(long paramLong, int paramInt)
/*      */     throws LWJGLException;
/*      */   
/*      */   private static int getBestDisplayModeExtension()
/*      */   {
/*      */     int result;
/*      */     int result;
/*  201 */     if (isXrandrSupported()) {
/*  202 */       LWJGLUtil.log("Using Xrandr for display mode switching");
/*  203 */       result = 10; } else { int result;
/*  204 */       if (isXF86VidModeSupported()) {
/*  205 */         LWJGLUtil.log("Using XF86VidMode for display mode switching");
/*  206 */         result = 11;
/*      */       } else {
/*  208 */         LWJGLUtil.log("No display mode extensions available");
/*  209 */         result = 12;
/*      */       } }
/*  211 */     return result;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private static boolean isXrandrSupported()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: ldc 28
/*      */     //   2: invokestatic 29	org/lwjgl/opengl/Display:getPrivilegedBoolean	(Ljava/lang/String;)Z
/*      */     //   5: ifeq +5 -> 10
/*      */     //   8: iconst_0
/*      */     //   9: ireturn
/*      */     //   10: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   13: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   16: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   19: invokestatic 30	org/lwjgl/opengl/LinuxDisplay:nIsXrandrSupported	(J)Z
/*      */     //   22: istore_0
/*      */     //   23: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   26: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   29: iload_0
/*      */     //   30: ireturn
/*      */     //   31: astore_1
/*      */     //   32: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   35: aload_1
/*      */     //   36: athrow
/*      */     //   37: astore_0
/*      */     //   38: new 32	java/lang/StringBuilder
/*      */     //   41: dup
/*      */     //   42: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   45: ldc 34
/*      */     //   47: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   50: aload_0
/*      */     //   51: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   54: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   57: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   60: iconst_0
/*      */     //   61: istore_1
/*      */     //   62: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   65: iload_1
/*      */     //   66: ireturn
/*      */     //   67: astore_2
/*      */     //   68: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   71: aload_2
/*      */     //   72: athrow
/*      */     // Line number table:
/*      */     //   Java source line #215	-> byte code offset #0
/*      */     //   Java source line #216	-> byte code offset #8
/*      */     //   Java source line #217	-> byte code offset #10
/*      */     //   Java source line #219	-> byte code offset #13
/*      */     //   Java source line #221	-> byte code offset #16
/*      */     //   Java source line #223	-> byte code offset #23
/*      */     //   Java source line #229	-> byte code offset #26
/*      */     //   Java source line #223	-> byte code offset #31
/*      */     //   Java source line #225	-> byte code offset #37
/*      */     //   Java source line #226	-> byte code offset #38
/*      */     //   Java source line #227	-> byte code offset #60
/*      */     //   Java source line #229	-> byte code offset #62
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   22	8	0	bool1	boolean
/*      */     //   37	14	0	e	LWJGLException
/*      */     //   31	5	1	localObject1	Object
/*      */     //   61	5	1	bool2	boolean
/*      */     //   67	5	2	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   16	23	31	finally
/*      */     //   31	32	31	finally
/*      */     //   13	26	37	org/lwjgl/LWJGLException
/*      */     //   31	37	37	org/lwjgl/LWJGLException
/*      */     //   13	26	67	finally
/*      */     //   31	62	67	finally
/*      */     //   67	68	67	finally
/*      */   }
/*      */   
/*      */   private static native boolean nIsXrandrSupported(long paramLong)
/*      */     throws LWJGLException;
/*      */   
/*      */   /* Error */
/*      */   private static boolean isXF86VidModeSupported()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: invokestatic 38	org/lwjgl/opengl/LinuxDisplay:nIsXF86VidModeSupported	(J)Z
/*      */     //   12: istore_0
/*      */     //   13: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   16: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   19: iload_0
/*      */     //   20: ireturn
/*      */     //   21: astore_1
/*      */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   25: aload_1
/*      */     //   26: athrow
/*      */     //   27: astore_0
/*      */     //   28: new 32	java/lang/StringBuilder
/*      */     //   31: dup
/*      */     //   32: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   35: ldc 39
/*      */     //   37: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   40: aload_0
/*      */     //   41: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   44: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   47: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   50: iconst_0
/*      */     //   51: istore_1
/*      */     //   52: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   55: iload_1
/*      */     //   56: ireturn
/*      */     //   57: astore_2
/*      */     //   58: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   61: aload_2
/*      */     //   62: athrow
/*      */     // Line number table:
/*      */     //   Java source line #235	-> byte code offset #0
/*      */     //   Java source line #237	-> byte code offset #3
/*      */     //   Java source line #239	-> byte code offset #6
/*      */     //   Java source line #241	-> byte code offset #13
/*      */     //   Java source line #247	-> byte code offset #16
/*      */     //   Java source line #241	-> byte code offset #21
/*      */     //   Java source line #243	-> byte code offset #27
/*      */     //   Java source line #244	-> byte code offset #28
/*      */     //   Java source line #245	-> byte code offset #50
/*      */     //   Java source line #247	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   12	8	0	bool1	boolean
/*      */     //   27	14	0	e	LWJGLException
/*      */     //   21	5	1	localObject1	Object
/*      */     //   51	5	1	bool2	boolean
/*      */     //   57	5	2	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	13	21	finally
/*      */     //   21	22	21	finally
/*      */     //   3	16	27	org/lwjgl/LWJGLException
/*      */     //   21	27	27	org/lwjgl/LWJGLException
/*      */     //   3	16	57	finally
/*      */     //   21	52	57	finally
/*      */     //   57	58	57	finally
/*      */   }
/*      */   
/*      */   private static native boolean nIsXF86VidModeSupported(long paramLong)
/*      */     throws LWJGLException;
/*      */   
/*      */   /* Error */
/*      */   private static boolean isNetWMFullscreenSupported()
/*      */     throws LWJGLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: ldc 40
/*      */     //   2: invokestatic 29	org/lwjgl/opengl/Display:getPrivilegedBoolean	(Ljava/lang/String;)Z
/*      */     //   5: ifeq +5 -> 10
/*      */     //   8: iconst_0
/*      */     //   9: ireturn
/*      */     //   10: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   13: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   16: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   19: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*      */     //   22: invokestatic 41	org/lwjgl/opengl/LinuxDisplay:nIsNetWMFullscreenSupported	(JI)Z
/*      */     //   25: istore_0
/*      */     //   26: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   29: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   32: iload_0
/*      */     //   33: ireturn
/*      */     //   34: astore_1
/*      */     //   35: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   38: aload_1
/*      */     //   39: athrow
/*      */     //   40: astore_0
/*      */     //   41: new 32	java/lang/StringBuilder
/*      */     //   44: dup
/*      */     //   45: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   48: ldc 42
/*      */     //   50: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   53: aload_0
/*      */     //   54: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   57: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   60: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   63: iconst_0
/*      */     //   64: istore_1
/*      */     //   65: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   68: iload_1
/*      */     //   69: ireturn
/*      */     //   70: astore_2
/*      */     //   71: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   74: aload_2
/*      */     //   75: athrow
/*      */     // Line number table:
/*      */     //   Java source line #253	-> byte code offset #0
/*      */     //   Java source line #254	-> byte code offset #8
/*      */     //   Java source line #255	-> byte code offset #10
/*      */     //   Java source line #257	-> byte code offset #13
/*      */     //   Java source line #259	-> byte code offset #16
/*      */     //   Java source line #261	-> byte code offset #26
/*      */     //   Java source line #267	-> byte code offset #29
/*      */     //   Java source line #261	-> byte code offset #34
/*      */     //   Java source line #263	-> byte code offset #40
/*      */     //   Java source line #264	-> byte code offset #41
/*      */     //   Java source line #265	-> byte code offset #63
/*      */     //   Java source line #267	-> byte code offset #65
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   25	8	0	bool1	boolean
/*      */     //   40	14	0	e	LWJGLException
/*      */     //   34	5	1	localObject1	Object
/*      */     //   64	5	1	bool2	boolean
/*      */     //   70	5	2	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   16	26	34	finally
/*      */     //   34	35	34	finally
/*      */     //   13	29	40	org/lwjgl/LWJGLException
/*      */     //   34	40	40	org/lwjgl/LWJGLException
/*      */     //   13	29	70	finally
/*      */     //   34	65	70	finally
/*      */     //   70	71	70	finally
/*      */   }
/*      */   
/*      */   private static native boolean nIsNetWMFullscreenSupported(long paramLong, int paramInt)
/*      */     throws LWJGLException;
/*      */   
/*      */   static void lockAWT()
/*      */   {
/*      */     try
/*      */     {
/*      */       
/*      */     }
/*      */     catch (LWJGLException e)
/*      */     {
/*  280 */       LWJGLUtil.log("Caught exception while locking AWT: " + e);
/*      */     }
/*      */   }
/*      */   
/*      */   private static native void nLockAWT() throws LWJGLException;
/*      */   
/*      */   static void unlockAWT() {
/*      */     try {
/*      */       
/*  289 */     } catch (LWJGLException e) { LWJGLUtil.log("Caught exception while unlocking AWT: " + e);
/*      */     }
/*      */   }
/*      */   
/*      */   private static native void nUnlockAWT()
/*      */     throws LWJGLException;
/*      */   
/*      */   static void incDisplay() throws LWJGLException
/*      */   {
/*  298 */     if (display_connection_usage_count == 0)
/*      */     {
/*      */       try {
/*  301 */         GLContext.loadOpenGLLibrary();
/*  302 */         org.lwjgl.opengles.GLContext.loadOpenGLLibrary();
/*      */       }
/*      */       catch (Throwable t) {}
/*  305 */       saved_error_handler = setErrorHandler();
/*  306 */       display = openDisplay();
/*      */     }
/*      */     
/*  309 */     display_connection_usage_count += 1; }
/*      */   
/*      */   private static native int callErrorHandler(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   private static native long setErrorHandler();
/*      */   
/*      */   private static native long resetErrorHandler(long paramLong);
/*      */   private static native void synchronize(long paramLong, boolean paramBoolean);
/*  317 */   private static int globalErrorHandler(long display, long event_ptr, long error_display, long serial, long error_code, long request_code, long minor_code) throws LWJGLException { if ((xembedded) && (request_code == 42L)) { return 0;
/*      */     }
/*  319 */     if (display == getDisplay()) {
/*  320 */       String error_msg = getErrorText(display, error_code);
/*  321 */       throw new LWJGLException("X Error - disp: 0x" + Long.toHexString(error_display) + " serial: " + serial + " error: " + error_msg + " request_code: " + request_code + " minor_code: " + minor_code); }
/*  322 */     if (saved_error_handler != 0L)
/*  323 */       return callErrorHandler(saved_error_handler, display, event_ptr);
/*  324 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static native String getErrorText(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */ 
/*      */   static void decDisplay() {}
/*      */   
/*      */ 
/*      */ 
/*      */   static native long openDisplay()
/*      */     throws LWJGLException;
/*      */   
/*      */ 
/*      */ 
/*      */   static native void closeDisplay(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private int getWindowMode(boolean fullscreen)
/*      */     throws LWJGLException
/*      */   {
/*  349 */     if (fullscreen) {
/*  350 */       if ((this.current_displaymode_extension == 10) && (isNetWMFullscreenSupported())) {
/*  351 */         LWJGLUtil.log("Using NetWM for fullscreen window");
/*  352 */         return 2;
/*      */       }
/*  354 */       LWJGLUtil.log("Using legacy mode for fullscreen window");
/*  355 */       return 1;
/*      */     }
/*      */     
/*  358 */     return 3;
/*      */   }
/*      */   
/*      */   static long getDisplay() {
/*  362 */     if (display_connection_usage_count <= 0)
/*  363 */       throw new InternalError("display_connection_usage_count = " + display_connection_usage_count);
/*  364 */     return display;
/*      */   }
/*      */   
/*      */   static int getDefaultScreen() {
/*  368 */     return nGetDefaultScreen(getDisplay());
/*      */   }
/*      */   
/*      */   static native int nGetDefaultScreen(long paramLong);
/*      */   
/*  373 */   static long getWindow() { return current_window; }
/*      */   
/*      */   private void ungrabKeyboard()
/*      */   {
/*  377 */     if (this.keyboard_grabbed) {
/*  378 */       nUngrabKeyboard(getDisplay());
/*  379 */       this.keyboard_grabbed = false;
/*      */     }
/*      */   }
/*      */   
/*      */   static native int nUngrabKeyboard(long paramLong);
/*      */   
/*  385 */   private void grabKeyboard() { if (!this.keyboard_grabbed) {
/*  386 */       int res = nGrabKeyboard(getDisplay(), getWindow());
/*  387 */       if (res == 0)
/*  388 */         this.keyboard_grabbed = true;
/*      */     }
/*      */   }
/*      */   
/*      */   static native int nGrabKeyboard(long paramLong1, long paramLong2);
/*      */   
/*  394 */   private void grabPointer() { if (!this.pointer_grabbed) {
/*  395 */       int result = nGrabPointer(getDisplay(), getWindow(), 0L);
/*  396 */       if (result == 0) {
/*  397 */         this.pointer_grabbed = true;
/*      */         
/*  399 */         if (isLegacyFullscreen())
/*  400 */           nSetViewPort(getDisplay(), getWindow(), getDefaultScreen());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static native int nGrabPointer(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   private static native void nSetViewPort(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*  409 */   private void ungrabPointer() { if (this.pointer_grabbed) {
/*  410 */       this.pointer_grabbed = false;
/*  411 */       nUngrabPointer(getDisplay());
/*      */     }
/*      */   }
/*      */   
/*      */   static native int nUngrabPointer(long paramLong);
/*      */   
/*  417 */   private static boolean isFullscreen() { return (current_window_mode == 1) || (current_window_mode == 2); }
/*      */   
/*      */   private boolean shouldGrab()
/*      */   {
/*  421 */     return (!this.input_released) && (this.grab) && (this.mouse != null);
/*      */   }
/*      */   
/*      */   private void updatePointerGrab() {
/*  425 */     if ((isFullscreen()) || (shouldGrab())) {
/*  426 */       grabPointer();
/*      */     } else {
/*  428 */       ungrabPointer();
/*      */     }
/*  430 */     updateCursor();
/*      */   }
/*      */   
/*      */   private void updateCursor() { long cursor;
/*      */     long cursor;
/*  435 */     if (shouldGrab()) {
/*  436 */       cursor = this.blank_cursor;
/*      */     } else {
/*  438 */       cursor = this.current_cursor;
/*      */     }
/*  440 */     nDefineCursor(getDisplay(), getWindow(), cursor);
/*      */   }
/*      */   
/*      */   private static native void nDefineCursor(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*  445 */   private static boolean isLegacyFullscreen() { return current_window_mode == 1; }
/*      */   
/*      */   private void updateKeyboardGrab()
/*      */   {
/*  449 */     if (isLegacyFullscreen()) {
/*  450 */       grabKeyboard();
/*      */     } else
/*  452 */       ungrabKeyboard();
/*      */   }
/*      */   
/*      */   public void createWindow(DrawableLWJGL drawable, DisplayMode mode, Canvas parent, int x, int y) throws LWJGLException {
/*      */     
/*      */     try {
/*  458 */       incDisplay();
/*      */       try {
/*  460 */         if ((drawable instanceof DrawableGLES)) {
/*  461 */           this.peer_info = new LinuxDisplayPeerInfo();
/*      */         }
/*  463 */         ByteBuffer handle = this.peer_info.lockAndGetHandle();
/*      */         try {
/*  465 */           current_window_mode = getWindowMode(Display.isFullscreen());
/*      */           
/*      */ 
/*      */ 
/*  469 */           if (current_window_mode != 3) {
/*  470 */             Compiz.setLegacyFullscreenSupport(true);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  476 */           boolean undecorated = (Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated")) || ((current_window_mode != 3) && (Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated_fs")));
/*      */           
/*  478 */           this.parent = parent;
/*  479 */           this.parent_window = (parent != null ? getHandle(parent) : getRootWindow(getDisplay(), getDefaultScreen()));
/*  480 */           this.resizable = Display.isResizable();
/*  481 */           this.resized = false;
/*  482 */           this.window_x = x;
/*  483 */           this.window_y = y;
/*  484 */           this.window_width = mode.getWidth();
/*  485 */           this.window_height = mode.getHeight();
/*      */           
/*  487 */           current_window = nCreateWindow(getDisplay(), getDefaultScreen(), handle, mode, current_window_mode, x, y, undecorated, this.parent_window, this.resizable);
/*      */           
/*      */ 
/*  490 */           this.wm_class = Display.getPrivilegedString("LWJGL_WM_CLASS");
/*  491 */           if (this.wm_class == null) this.wm_class = Display.getTitle();
/*  492 */           setClassHint(Display.getTitle(), this.wm_class);
/*      */           
/*  494 */           mapRaised(getDisplay(), current_window);
/*  495 */           xembedded = (parent != null) && (isAncestorXEmbedded(this.parent_window));
/*  496 */           this.blank_cursor = createBlankCursor();
/*  497 */           this.current_cursor = 0L;
/*  498 */           this.focused = false;
/*  499 */           this.input_released = false;
/*  500 */           this.pointer_grabbed = false;
/*  501 */           this.keyboard_grabbed = false;
/*  502 */           this.close_requested = false;
/*  503 */           this.grab = false;
/*  504 */           this.minimized = false;
/*  505 */           this.dirty = true;
/*      */           
/*  507 */           if ((drawable instanceof DrawableGLES)) {
/*  508 */             ((DrawableGLES)drawable).initialize(current_window, getDisplay(), 4, (org.lwjgl.opengles.PixelFormat)drawable.getPixelFormat());
/*      */           }
/*  510 */           if (parent != null) {
/*  511 */             parent.addFocusListener(this.focus_listener);
/*  512 */             this.parent_focused = parent.isFocusOwner();
/*  513 */             this.parent_focus_changed = true;
/*      */           }
/*      */         } finally {
/*  516 */           this.peer_info.unlock();
/*      */         }
/*      */       }
/*      */       catch (LWJGLException e) {
/*  520 */         throw e;
/*      */       }
/*      */     } finally {
/*  523 */       unlockAWT(); } }
/*      */   
/*      */   private static native long nCreateWindow(long paramLong1, int paramInt1, ByteBuffer paramByteBuffer, DisplayMode paramDisplayMode, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, long paramLong2, boolean paramBoolean2) throws LWJGLException;
/*      */   
/*      */   private static native long getRootWindow(long paramLong, int paramInt);
/*      */   
/*      */   private static native boolean hasProperty(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   private static native long getParentWindow(long paramLong1, long paramLong2) throws LWJGLException;
/*      */   private static native int getChildCount(long paramLong1, long paramLong2) throws LWJGLException;
/*      */   private static native void mapRaised(long paramLong1, long paramLong2);
/*      */   private static native void reparentWindow(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2);
/*      */   private static native long nGetInputFocus(long paramLong) throws LWJGLException;
/*      */   private static native void nSetInputFocus(long paramLong1, long paramLong2, long paramLong3);
/*      */   private static native void nSetWindowSize(long paramLong1, long paramLong2, int paramInt1, int paramInt2, boolean paramBoolean);
/*      */   private static native int nGetX(long paramLong1, long paramLong2);
/*      */   private static native int nGetY(long paramLong1, long paramLong2);
/*      */   private static native int nGetWidth(long paramLong1, long paramLong2);
/*      */   private static native int nGetHeight(long paramLong1, long paramLong2);
/*  542 */   private static boolean isAncestorXEmbedded(long window) throws LWJGLException { long xembed_atom = internAtom("_XEMBED_INFO", true);
/*  543 */     if (xembed_atom != 0L) {
/*  544 */       long w = window;
/*  545 */       while (w != 0L) {
/*  546 */         if (hasProperty(getDisplay(), w, xembed_atom))
/*  547 */           return true;
/*  548 */         w = getParentWindow(getDisplay(), w);
/*      */       }
/*      */     }
/*  551 */     return false;
/*      */   }
/*      */   
/*      */   private static long getHandle(Canvas parent) throws LWJGLException {
/*  555 */     AWTCanvasImplementation awt_impl = AWTGLCanvas.createImplementation();
/*  556 */     LinuxPeerInfo parent_peer_info = (LinuxPeerInfo)awt_impl.createPeerInfo(parent, null, null);
/*  557 */     ByteBuffer parent_peer_info_handle = parent_peer_info.lockAndGetHandle();
/*      */     try {
/*  559 */       return parent_peer_info.getDrawable();
/*      */     } finally {
/*  561 */       parent_peer_info.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateInputGrab() {
/*  566 */     updatePointerGrab();
/*  567 */     updateKeyboardGrab();
/*      */   }
/*      */   
/*      */   public void destroyWindow() {
/*      */     
/*      */     try {
/*  573 */       if (this.parent != null) {
/*  574 */         this.parent.removeFocusListener(this.focus_listener);
/*      */       }
/*      */       try {
/*  577 */         setNativeCursor(null);
/*      */       } catch (LWJGLException e) {
/*  579 */         LWJGLUtil.log("Failed to reset cursor: " + e.getMessage());
/*      */       }
/*  581 */       nDestroyCursor(getDisplay(), this.blank_cursor);
/*  582 */       this.blank_cursor = 0L;
/*  583 */       ungrabKeyboard();
/*  584 */       nDestroyWindow(getDisplay(), getWindow());
/*  585 */       decDisplay();
/*      */       
/*  587 */       if (current_window_mode != 3)
/*  588 */         Compiz.setLegacyFullscreenSupport(false);
/*      */     } finally {
/*  590 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   static native void nDestroyWindow(long paramLong1, long paramLong2);
/*      */   
/*      */   public void switchDisplayMode(DisplayMode mode) throws LWJGLException {
/*      */     
/*  598 */     try { switchDisplayModeOnTmpDisplay(mode);
/*  599 */       this.current_mode = mode;
/*      */     } finally {
/*  601 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   private void switchDisplayModeOnTmpDisplay(DisplayMode mode) throws LWJGLException {
/*      */     
/*      */     try {
/*  608 */       nSwitchDisplayMode(getDisplay(), getDefaultScreen(), this.current_displaymode_extension, mode);
/*      */     } finally {
/*  610 */       decDisplay();
/*      */     }
/*      */   }
/*      */   
/*      */   private static native void nSwitchDisplayMode(long paramLong, int paramInt1, int paramInt2, DisplayMode paramDisplayMode) throws LWJGLException;
/*      */   
/*      */   private static long internAtom(String atom_name, boolean only_if_exists) throws LWJGLException {
/*      */     
/*  618 */     try { return nInternAtom(getDisplay(), atom_name, only_if_exists);
/*      */     } finally {
/*  620 */       decDisplay();
/*      */     }
/*      */   }
/*      */   
/*      */   static native long nInternAtom(long paramLong, String paramString, boolean paramBoolean);
/*      */   
/*      */   public void resetDisplayMode() {
/*      */     
/*  628 */     try { if ((this.current_displaymode_extension == 10) && (this.savedXrandrConfig.length > 0))
/*      */       {
/*  630 */         AccessController.doPrivileged(new PrivilegedAction() {
/*      */           public Object run() {
/*  632 */             XRandR.setConfiguration(LinuxDisplay.this.savedXrandrConfig);
/*  633 */             return null;
/*      */           }
/*      */           
/*      */ 
/*      */         });
/*      */       } else {
/*  639 */         switchDisplayMode(this.saved_mode);
/*      */       }
/*  641 */       if (isXF86VidModeSupported()) {
/*  642 */         doSetGamma(this.saved_gamma);
/*      */       }
/*  644 */       Compiz.setLegacyFullscreenSupport(false);
/*      */     } catch (LWJGLException e) {
/*  646 */       LWJGLUtil.log("Caught exception while resetting mode: " + e);
/*      */     } finally {
/*  648 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getGammaRampLength()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 17	org/lwjgl/opengl/LinuxDisplay:isXF86VidModeSupported	()Z
/*      */     //   3: ifne +5 -> 8
/*      */     //   6: iconst_0
/*      */     //   7: ireturn
/*      */     //   8: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   11: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   14: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   17: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*      */     //   20: invokestatic 172	org/lwjgl/opengl/LinuxDisplay:nGetGammaRampLength	(JI)I
/*      */     //   23: istore_1
/*      */     //   24: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   27: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   30: iload_1
/*      */     //   31: ireturn
/*      */     //   32: astore_1
/*      */     //   33: new 32	java/lang/StringBuilder
/*      */     //   36: dup
/*      */     //   37: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   40: ldc -83
/*      */     //   42: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   45: aload_1
/*      */     //   46: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   49: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   52: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   55: iconst_0
/*      */     //   56: istore_2
/*      */     //   57: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   60: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   63: iload_2
/*      */     //   64: ireturn
/*      */     //   65: astore_3
/*      */     //   66: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   69: aload_3
/*      */     //   70: athrow
/*      */     //   71: astore_1
/*      */     //   72: new 32	java/lang/StringBuilder
/*      */     //   75: dup
/*      */     //   76: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   79: ldc -82
/*      */     //   81: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   84: aload_1
/*      */     //   85: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   88: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   91: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   94: iconst_0
/*      */     //   95: istore_2
/*      */     //   96: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   99: iload_2
/*      */     //   100: ireturn
/*      */     //   101: astore 4
/*      */     //   103: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   106: aload 4
/*      */     //   108: athrow
/*      */     // Line number table:
/*      */     //   Java source line #653	-> byte code offset #0
/*      */     //   Java source line #654	-> byte code offset #6
/*      */     //   Java source line #655	-> byte code offset #8
/*      */     //   Java source line #658	-> byte code offset #11
/*      */     //   Java source line #660	-> byte code offset #14
/*      */     //   Java source line #665	-> byte code offset #24
/*      */     //   Java source line #672	-> byte code offset #27
/*      */     //   Java source line #661	-> byte code offset #32
/*      */     //   Java source line #662	-> byte code offset #33
/*      */     //   Java source line #663	-> byte code offset #55
/*      */     //   Java source line #665	-> byte code offset #57
/*      */     //   Java source line #672	-> byte code offset #60
/*      */     //   Java source line #665	-> byte code offset #65
/*      */     //   Java source line #667	-> byte code offset #71
/*      */     //   Java source line #668	-> byte code offset #72
/*      */     //   Java source line #669	-> byte code offset #94
/*      */     //   Java source line #672	-> byte code offset #96
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	109	0	this	LinuxDisplay
/*      */     //   23	8	1	i	int
/*      */     //   32	14	1	e	LWJGLException
/*      */     //   71	14	1	e	LWJGLException
/*      */     //   56	44	2	j	int
/*      */     //   65	5	3	localObject1	Object
/*      */     //   101	6	4	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	24	32	org/lwjgl/LWJGLException
/*      */     //   14	24	65	finally
/*      */     //   32	57	65	finally
/*      */     //   65	66	65	finally
/*      */     //   11	27	71	org/lwjgl/LWJGLException
/*      */     //   32	60	71	org/lwjgl/LWJGLException
/*      */     //   65	71	71	org/lwjgl/LWJGLException
/*      */     //   11	27	101	finally
/*      */     //   32	60	101	finally
/*      */     //   65	96	101	finally
/*      */     //   101	103	101	finally
/*      */   }
/*      */   
/*      */   private static native int nGetGammaRampLength(long paramLong, int paramInt)
/*      */     throws LWJGLException;
/*      */   
/*      */   public void setGammaRamp(FloatBuffer gammaRamp)
/*      */     throws LWJGLException
/*      */   {
/*  678 */     if (!isXF86VidModeSupported())
/*  679 */       throw new LWJGLException("No gamma ramp support (Missing XF86VM extension)");
/*  680 */     doSetGamma(convertToNativeRamp(gammaRamp));
/*      */   }
/*      */   
/*      */   private void doSetGamma(ByteBuffer native_gamma) throws LWJGLException {
/*      */     
/*      */     try {
/*  686 */       setGammaRampOnTmpDisplay(native_gamma);
/*  687 */       this.current_gamma = native_gamma;
/*      */     } finally {
/*  689 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   private static void setGammaRampOnTmpDisplay(ByteBuffer native_gamma) throws LWJGLException {
/*      */     
/*      */     try {
/*  696 */       nSetGammaRamp(getDisplay(), getDefaultScreen(), native_gamma);
/*      */     } finally {
/*  698 */       decDisplay();
/*      */     }
/*      */   }
/*      */   
/*      */   private static native void nSetGammaRamp(long paramLong, int paramInt, ByteBuffer paramByteBuffer) throws LWJGLException;
/*      */   
/*  704 */   private static ByteBuffer convertToNativeRamp(FloatBuffer ramp) throws LWJGLException { return nConvertToNativeRamp(ramp, ramp.position(), ramp.remaining()); }
/*      */   
/*      */   private static native ByteBuffer nConvertToNativeRamp(FloatBuffer paramFloatBuffer, int paramInt1, int paramInt2) throws LWJGLException;
/*      */   
/*      */   public String getAdapter() {
/*  709 */     return null;
/*      */   }
/*      */   
/*      */   public String getVersion() {
/*  713 */     return null;
/*      */   }
/*      */   
/*      */   public DisplayMode init() throws LWJGLException {
/*      */     
/*      */     try {
/*  719 */       Compiz.init();
/*      */       
/*  721 */       this.delete_atom = internAtom("WM_DELETE_WINDOW", false);
/*  722 */       this.current_displaymode_extension = getBestDisplayModeExtension();
/*  723 */       if (this.current_displaymode_extension == 12)
/*  724 */         throw new LWJGLException("No display mode extension is available");
/*  725 */       DisplayMode[] modes = getAvailableDisplayModes();
/*  726 */       if ((modes == null) || (modes.length == 0))
/*  727 */         throw new LWJGLException("No modes available");
/*  728 */       switch (this.current_displaymode_extension) {
/*      */       case 10: 
/*  730 */         this.savedXrandrConfig = ((XRandR.Screen[])AccessController.doPrivileged(new PrivilegedAction() {
/*      */           public XRandR.Screen[] run() {
/*  732 */             return XRandR.getConfiguration();
/*      */           }
/*  734 */         }));
/*  735 */         this.saved_mode = getCurrentXRandrMode();
/*  736 */         break;
/*      */       case 11: 
/*  738 */         this.saved_mode = modes[0];
/*  739 */         break;
/*      */       default: 
/*  741 */         throw new LWJGLException("Unknown display mode extension: " + this.current_displaymode_extension);
/*      */       }
/*  743 */       this.current_mode = this.saved_mode;
/*  744 */       this.saved_gamma = getCurrentGammaRamp();
/*  745 */       this.current_gamma = this.saved_gamma;
/*  746 */       return this.saved_mode;
/*      */     } finally {
/*  748 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private static DisplayMode getCurrentXRandrMode()
/*      */     throws LWJGLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*      */     //   12: invokestatic 196	org/lwjgl/opengl/LinuxDisplay:nGetCurrentXRandrMode	(JI)Lorg/lwjgl/opengl/DisplayMode;
/*      */     //   15: astore_0
/*      */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   22: aload_0
/*      */     //   23: areturn
/*      */     //   24: astore_1
/*      */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   28: aload_1
/*      */     //   29: athrow
/*      */     //   30: astore_2
/*      */     //   31: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   34: aload_2
/*      */     //   35: athrow
/*      */     // Line number table:
/*      */     //   Java source line #753	-> byte code offset #0
/*      */     //   Java source line #755	-> byte code offset #3
/*      */     //   Java source line #757	-> byte code offset #6
/*      */     //   Java source line #759	-> byte code offset #16
/*      */     //   Java source line #762	-> byte code offset #19
/*      */     //   Java source line #759	-> byte code offset #24
/*      */     //   Java source line #762	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   15	8	0	localDisplayMode	DisplayMode
/*      */     //   24	5	1	localObject1	Object
/*      */     //   30	5	2	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	16	24	finally
/*      */     //   24	25	24	finally
/*      */     //   3	19	30	finally
/*      */     //   24	31	30	finally
/*      */   }
/*      */   
/*      */   private static native DisplayMode nGetCurrentXRandrMode(long paramLong, int paramInt)
/*      */     throws LWJGLException;
/*      */   
/*      */   public void setTitle(String title)
/*      */   {
/*      */     
/*      */     try
/*      */     {
/*  772 */       ByteBuffer titleText = MemoryUtil.encodeUTF8(title);
/*  773 */       nSetTitle(getDisplay(), getWindow(), MemoryUtil.getAddress(titleText), titleText.remaining() - 1);
/*      */     } finally {
/*  775 */       unlockAWT();
/*      */     }
/*      */     
/*      */ 
/*  779 */     if (Display.isCreated()) setClassHint(title, this.wm_class);
/*      */   }
/*      */   
/*      */   private static native void nSetTitle(long paramLong1, long paramLong2, long paramLong3, int paramInt);
/*      */   
/*      */   private void setClassHint(String wm_name, String wm_class) {
/*      */     
/*      */     try {
/*  787 */       ByteBuffer nameText = MemoryUtil.encodeUTF8(wm_name);
/*  788 */       ByteBuffer classText = MemoryUtil.encodeUTF8(wm_class);
/*      */       
/*  790 */       nSetClassHint(getDisplay(), getWindow(), MemoryUtil.getAddress(nameText), MemoryUtil.getAddress(classText));
/*      */     } finally {
/*  792 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   private static native void nSetClassHint(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*  798 */   public boolean isCloseRequested() { boolean result = this.close_requested;
/*  799 */     this.close_requested = false;
/*  800 */     return result;
/*      */   }
/*      */   
/*      */   public boolean isVisible() {
/*  804 */     return !this.minimized;
/*      */   }
/*      */   
/*      */   public boolean isActive() {
/*  808 */     return (this.focused) || (isLegacyFullscreen());
/*      */   }
/*      */   
/*      */   public boolean isDirty() {
/*  812 */     boolean result = this.dirty;
/*  813 */     this.dirty = false;
/*  814 */     return result;
/*      */   }
/*      */   
/*      */   public PeerInfo createPeerInfo(PixelFormat pixel_format, ContextAttribs attribs) throws LWJGLException {
/*  818 */     this.peer_info = new LinuxDisplayPeerInfo(pixel_format);
/*  819 */     return this.peer_info;
/*      */   }
/*      */   
/*      */   private void relayEventToParent(LinuxEvent event_buffer, int event_mask) {
/*  823 */     this.tmp_event_buffer.copyFrom(event_buffer);
/*  824 */     this.tmp_event_buffer.setWindow(this.parent_window);
/*  825 */     this.tmp_event_buffer.sendEvent(getDisplay(), this.parent_window, true, event_mask);
/*      */   }
/*      */   
/*      */   private void relayEventToParent(LinuxEvent event_buffer) {
/*  829 */     if (this.parent == null)
/*  830 */       return;
/*  831 */     switch (event_buffer.getType()) {
/*      */     case 2: 
/*  833 */       relayEventToParent(event_buffer, 1);
/*  834 */       break;
/*      */     case 3: 
/*  836 */       relayEventToParent(event_buffer, 1);
/*  837 */       break;
/*      */     case 4: 
/*  839 */       if ((xembedded) || (!this.focused)) relayEventToParent(event_buffer, 1);
/*      */       break;
/*      */     case 5: 
/*  842 */       if ((xembedded) || (!this.focused)) { relayEventToParent(event_buffer, 1);
/*      */       }
/*      */       break;
/*      */     }
/*      */   }
/*      */   
/*      */   private void processEvents()
/*      */   {
/*  850 */     while (LinuxEvent.getPending(getDisplay()) > 0) {
/*  851 */       this.event_buffer.nextEvent(getDisplay());
/*  852 */       long event_window = this.event_buffer.getWindow();
/*  853 */       relayEventToParent(this.event_buffer);
/*  854 */       if ((event_window == getWindow()) && (!this.event_buffer.filterEvent(event_window)) && ((this.mouse == null) || (!this.mouse.filterEvent(this.grab, shouldWarpPointer(), this.event_buffer))) && ((this.keyboard == null) || (!this.keyboard.filterEvent(this.event_buffer))))
/*      */       {
/*      */ 
/*      */ 
/*  858 */         switch (this.event_buffer.getType()) {
/*      */         case 9: 
/*  860 */           setFocused(true, this.event_buffer.getFocusDetail());
/*  861 */           break;
/*      */         case 10: 
/*  863 */           setFocused(false, this.event_buffer.getFocusDetail());
/*  864 */           break;
/*      */         case 33: 
/*  866 */           if ((this.event_buffer.getClientFormat() == 32) && (this.event_buffer.getClientData(0) == this.delete_atom))
/*  867 */             this.close_requested = true;
/*      */           break;
/*      */         case 19: 
/*  870 */           this.dirty = true;
/*  871 */           this.minimized = false;
/*  872 */           break;
/*      */         case 18: 
/*  874 */           this.dirty = true;
/*  875 */           this.minimized = true;
/*  876 */           break;
/*      */         case 12: 
/*  878 */           this.dirty = true;
/*  879 */           break;
/*      */         case 22: 
/*  881 */           int x = nGetX(getDisplay(), getWindow());
/*  882 */           int y = nGetY(getDisplay(), getWindow());
/*      */           
/*  884 */           int width = nGetWidth(getDisplay(), getWindow());
/*  885 */           int height = nGetHeight(getDisplay(), getWindow());
/*      */           
/*  887 */           this.window_x = x;
/*  888 */           this.window_y = y;
/*      */           
/*  890 */           if ((this.window_width != width) || (this.window_height != height)) {
/*  891 */             this.resized = true;
/*  892 */             this.window_width = width;
/*  893 */             this.window_height = height;
/*      */           }
/*      */           
/*      */           break;
/*      */         case 7: 
/*  898 */           this.mouseInside = true;
/*  899 */           break;
/*      */         case 8: 
/*  901 */           this.mouseInside = false;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void update()
/*      */   {
/*      */     
/*      */     try
/*      */     {
/*  912 */       processEvents();
/*  913 */       checkInput();
/*      */     } finally {
/*  915 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   public void reshape(int x, int y, int width, int height) {
/*      */     
/*      */     try {
/*  922 */       nReshape(getDisplay(), getWindow(), x, y, width, height);
/*      */     } finally {
/*  924 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   private static native void nReshape(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   /* Error */
/*      */   public DisplayMode[] getAvailableDisplayModes()
/*      */     throws LWJGLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*      */     //   12: aload_0
/*      */     //   13: getfield 9	org/lwjgl/opengl/LinuxDisplay:current_displaymode_extension	I
/*      */     //   16: invokestatic 229	org/lwjgl/opengl/LinuxDisplay:nGetAvailableDisplayModes	(JII)[Lorg/lwjgl/opengl/DisplayMode;
/*      */     //   19: astore_1
/*      */     //   20: aload_1
/*      */     //   21: astore_2
/*      */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   25: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   28: aload_2
/*      */     //   29: areturn
/*      */     //   30: astore_3
/*      */     //   31: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   34: aload_3
/*      */     //   35: athrow
/*      */     //   36: astore 4
/*      */     //   38: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   41: aload 4
/*      */     //   43: athrow
/*      */     // Line number table:
/*      */     //   Java source line #930	-> byte code offset #0
/*      */     //   Java source line #932	-> byte code offset #3
/*      */     //   Java source line #934	-> byte code offset #6
/*      */     //   Java source line #935	-> byte code offset #20
/*      */     //   Java source line #937	-> byte code offset #22
/*      */     //   Java source line #940	-> byte code offset #25
/*      */     //   Java source line #937	-> byte code offset #30
/*      */     //   Java source line #940	-> byte code offset #36
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	44	0	this	LinuxDisplay
/*      */     //   19	2	1	modes	DisplayMode[]
/*      */     //   21	8	2	arrayOfDisplayMode1	DisplayMode[]
/*      */     //   30	5	3	localObject1	Object
/*      */     //   36	6	4	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	22	30	finally
/*      */     //   30	31	30	finally
/*      */     //   3	25	36	finally
/*      */     //   30	38	36	finally
/*      */   }
/*      */   
/*      */   private static native DisplayMode[] nGetAvailableDisplayModes(long paramLong, int paramInt1, int paramInt2)
/*      */     throws LWJGLException;
/*      */   
/*      */   public boolean hasWheel()
/*      */   {
/*  947 */     return true;
/*      */   }
/*      */   
/*      */   public int getButtonCount() {
/*  951 */     return this.mouse.getButtonCount();
/*      */   }
/*      */   
/*      */   public void createMouse() throws LWJGLException {
/*      */     
/*      */     try {
/*  957 */       this.mouse = new LinuxMouse(getDisplay(), getWindow(), getWindow());
/*      */     } finally {
/*  959 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   public void destroyMouse() {
/*  964 */     this.mouse = null;
/*  965 */     updateInputGrab();
/*      */   }
/*      */   
/*      */   public void pollMouse(IntBuffer coord_buffer, ByteBuffer buttons) {
/*      */     
/*      */     try {
/*  971 */       this.mouse.poll(this.grab, coord_buffer, buttons);
/*      */     } finally {
/*  973 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   public void readMouse(ByteBuffer buffer) {
/*      */     
/*      */     try {
/*  980 */       this.mouse.read(buffer);
/*      */     } finally {
/*  982 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCursorPosition(int x, int y) {
/*      */     
/*      */     try {
/*  989 */       this.mouse.setCursorPosition(x, y);
/*      */     } finally {
/*  991 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkInput() {
/*  996 */     if (this.parent == null) { return;
/*      */     }
/*  998 */     if (xembedded) {
/*  999 */       long current_focus_window = 0L;
/*      */       
/* 1001 */       if ((this.last_window_focus != current_focus_window) || (this.parent_focused != this.focused)) {
/* 1002 */         if (isParentWindowActive(current_focus_window)) {
/* 1003 */           if (this.parent_focused) {
/* 1004 */             nSetInputFocus(getDisplay(), current_window, 0L);
/* 1005 */             this.last_window_focus = current_window;
/* 1006 */             this.focused = true;
/*      */           }
/*      */           else
/*      */           {
/* 1010 */             nSetInputFocus(getDisplay(), this.parent_proxy_focus_window, 0L);
/* 1011 */             this.last_window_focus = this.parent_proxy_focus_window;
/* 1012 */             this.focused = false;
/*      */           }
/*      */         }
/*      */         else {
/* 1016 */           this.last_window_focus = current_focus_window;
/* 1017 */           this.focused = false;
/*      */         }
/*      */         
/*      */       }
/*      */     }
/* 1022 */     else if ((this.parent_focus_changed) && (this.parent_focused)) {
/* 1023 */       setInputFocusUnsafe(getWindow());
/* 1024 */       this.parent_focus_changed = false;
/*      */     }
/*      */   }
/*      */   
/*      */   private void setInputFocusUnsafe(long window)
/*      */   {
/*      */     try {
/* 1031 */       nSetInputFocus(getDisplay(), window, 0L);
/* 1032 */       nSync(getDisplay(), false);
/*      */     }
/*      */     catch (LWJGLException e) {
/* 1035 */       LWJGLUtil.log("Got exception while trying to focus: " + e);
/*      */     }
/*      */   }
/*      */   
/*      */   private PeerInfo peer_info;
/*      */   private ByteBuffer saved_gamma;
/*      */   private ByteBuffer current_gamma;
/*      */   private DisplayMode saved_mode;
/*      */   private DisplayMode current_mode;
/*      */   private XRandR.Screen[] savedXrandrConfig;
/*      */   private boolean keyboard_grabbed;
/*      */   private boolean pointer_grabbed;
/*      */   private boolean input_released;
/*      */   private boolean grab;
/*      */   private boolean focused;
/*      */   private static native void nSync(long paramLong, boolean paramBoolean) throws LWJGLException;
/*      */   
/*      */   private boolean isParentWindowActive(long window) {
/*      */     try {
/* 1054 */       if (window == current_window) { return true;
/*      */       }
/*      */       
/* 1057 */       if (getChildCount(getDisplay(), window) != 0) { return false;
/*      */       }
/*      */       
/* 1060 */       long parent_window = getParentWindow(getDisplay(), window);
/*      */       
/*      */ 
/* 1063 */       if (parent_window == 0L) { return false;
/*      */       }
/*      */       
/* 1066 */       long w = current_window;
/*      */       
/* 1068 */       while (w != 0L) {
/* 1069 */         w = getParentWindow(getDisplay(), w);
/* 1070 */         if (w == parent_window) {
/* 1071 */           this.parent_proxy_focus_window = window;
/* 1072 */           return true;
/*      */         }
/*      */       }
/*      */     } catch (LWJGLException e) {
/* 1076 */       LWJGLUtil.log("Failed to detect if parent window is active: " + e.getMessage());
/* 1077 */       return true;
/*      */     }
/*      */     
/* 1080 */     return false;
/*      */   }
/*      */   
/*      */   private void setFocused(boolean got_focus, int focus_detail) {
/* 1084 */     if ((this.focused == got_focus) || (focus_detail == 7) || (focus_detail == 5) || (focus_detail == 6) || (xembedded))
/* 1085 */       return;
/* 1086 */     this.focused = got_focus;
/*      */     
/* 1088 */     if (this.focused) {
/* 1089 */       acquireInput();
/*      */     }
/*      */     else {
/* 1092 */       releaseInput();
/*      */     }
/*      */   }
/*      */   
/*      */   private void releaseInput() {
/* 1097 */     if ((isLegacyFullscreen()) || (this.input_released))
/* 1098 */       return;
/* 1099 */     this.input_released = true;
/* 1100 */     updateInputGrab();
/* 1101 */     if (current_window_mode == 2) {
/* 1102 */       nIconifyWindow(getDisplay(), getWindow(), getDefaultScreen());
/*      */       try {
/* 1104 */         if ((this.current_displaymode_extension == 10) && (this.savedXrandrConfig.length > 0))
/*      */         {
/* 1106 */           AccessController.doPrivileged(new PrivilegedAction() {
/*      */             public Object run() {
/* 1108 */               XRandR.setConfiguration(LinuxDisplay.this.savedXrandrConfig);
/* 1109 */               return null;
/*      */             }
/*      */             
/*      */ 
/*      */           });
/*      */         } else {
/* 1115 */           switchDisplayModeOnTmpDisplay(this.saved_mode);
/*      */         }
/* 1117 */         setGammaRampOnTmpDisplay(this.saved_gamma);
/*      */       } catch (LWJGLException e) {
/* 1119 */         LWJGLUtil.log("Failed to restore saved mode: " + e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static native void nIconifyWindow(long paramLong1, long paramLong2, int paramInt);
/*      */   
/* 1126 */   private void acquireInput() { if ((isLegacyFullscreen()) || (!this.input_released))
/* 1127 */       return;
/* 1128 */     this.input_released = false;
/* 1129 */     updateInputGrab();
/* 1130 */     if (current_window_mode == 2) {
/*      */       try {
/* 1132 */         switchDisplayModeOnTmpDisplay(this.current_mode);
/* 1133 */         setGammaRampOnTmpDisplay(this.current_gamma);
/*      */       } catch (LWJGLException e) {
/* 1135 */         LWJGLUtil.log("Failed to restore mode: " + e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void grabMouse(boolean new_grab) {
/*      */     
/*      */     try {
/* 1143 */       if (new_grab != this.grab) {
/* 1144 */         this.grab = new_grab;
/* 1145 */         updateInputGrab();
/* 1146 */         this.mouse.changeGrabbed(this.grab, shouldWarpPointer());
/*      */       }
/*      */     } finally {
/* 1149 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean shouldWarpPointer() {
/* 1154 */     return (this.pointer_grabbed) && (shouldGrab());
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getNativeCursorCapabilities()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: invokestatic 253	org/lwjgl/opengl/LinuxDisplay:nGetNativeCursorCapabilities	(J)I
/*      */     //   12: istore_1
/*      */     //   13: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   16: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   19: iload_1
/*      */     //   20: ireturn
/*      */     //   21: astore_2
/*      */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   25: aload_2
/*      */     //   26: athrow
/*      */     //   27: astore_1
/*      */     //   28: new 254	java/lang/RuntimeException
/*      */     //   31: dup
/*      */     //   32: aload_1
/*      */     //   33: invokespecial 255	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   36: athrow
/*      */     //   37: astore_3
/*      */     //   38: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   41: aload_3
/*      */     //   42: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1158	-> byte code offset #0
/*      */     //   Java source line #1160	-> byte code offset #3
/*      */     //   Java source line #1162	-> byte code offset #6
/*      */     //   Java source line #1164	-> byte code offset #13
/*      */     //   Java source line #1169	-> byte code offset #16
/*      */     //   Java source line #1164	-> byte code offset #21
/*      */     //   Java source line #1166	-> byte code offset #27
/*      */     //   Java source line #1167	-> byte code offset #28
/*      */     //   Java source line #1169	-> byte code offset #37
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	43	0	this	LinuxDisplay
/*      */     //   12	8	1	i	int
/*      */     //   27	6	1	e	LWJGLException
/*      */     //   21	5	2	localObject1	Object
/*      */     //   37	5	3	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	13	21	finally
/*      */     //   21	22	21	finally
/*      */     //   3	16	27	org/lwjgl/LWJGLException
/*      */     //   21	27	27	org/lwjgl/LWJGLException
/*      */     //   3	16	37	finally
/*      */     //   21	38	37	finally
/*      */   }
/*      */   
/*      */   private static native int nGetNativeCursorCapabilities(long paramLong)
/*      */     throws LWJGLException;
/*      */   
/*      */   public void setNativeCursor(Object handle)
/*      */     throws LWJGLException
/*      */   {
/* 1175 */     this.current_cursor = getCursorHandle(handle);
/* 1176 */     lockAWT();
/*      */     try {
/* 1178 */       updateCursor();
/*      */     } finally {
/* 1180 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getMinCursorSize()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: invokestatic 79	org/lwjgl/opengl/LinuxDisplay:getWindow	()J
/*      */     //   12: invokestatic 257	org/lwjgl/opengl/LinuxDisplay:nGetMinCursorSize	(JJ)I
/*      */     //   15: istore_1
/*      */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   22: iload_1
/*      */     //   23: ireturn
/*      */     //   24: astore_2
/*      */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   28: aload_2
/*      */     //   29: athrow
/*      */     //   30: astore_1
/*      */     //   31: new 32	java/lang/StringBuilder
/*      */     //   34: dup
/*      */     //   35: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   38: ldc_w 258
/*      */     //   41: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   44: aload_1
/*      */     //   45: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   48: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   51: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   54: iconst_0
/*      */     //   55: istore_2
/*      */     //   56: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   59: iload_2
/*      */     //   60: ireturn
/*      */     //   61: astore_3
/*      */     //   62: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   65: aload_3
/*      */     //   66: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1185	-> byte code offset #0
/*      */     //   Java source line #1187	-> byte code offset #3
/*      */     //   Java source line #1189	-> byte code offset #6
/*      */     //   Java source line #1191	-> byte code offset #16
/*      */     //   Java source line #1197	-> byte code offset #19
/*      */     //   Java source line #1191	-> byte code offset #24
/*      */     //   Java source line #1193	-> byte code offset #30
/*      */     //   Java source line #1194	-> byte code offset #31
/*      */     //   Java source line #1195	-> byte code offset #54
/*      */     //   Java source line #1197	-> byte code offset #56
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	67	0	this	LinuxDisplay
/*      */     //   15	8	1	i	int
/*      */     //   30	15	1	e	LWJGLException
/*      */     //   24	5	2	localObject1	Object
/*      */     //   55	5	2	j	int
/*      */     //   61	5	3	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	16	24	finally
/*      */     //   24	25	24	finally
/*      */     //   3	19	30	org/lwjgl/LWJGLException
/*      */     //   24	30	30	org/lwjgl/LWJGLException
/*      */     //   3	19	61	finally
/*      */     //   24	56	61	finally
/*      */     //   61	62	61	finally
/*      */   }
/*      */   
/*      */   private static native int nGetMinCursorSize(long paramLong1, long paramLong2);
/*      */   
/*      */   /* Error */
/*      */   public int getMaxCursorSize()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: invokestatic 79	org/lwjgl/opengl/LinuxDisplay:getWindow	()J
/*      */     //   12: invokestatic 259	org/lwjgl/opengl/LinuxDisplay:nGetMaxCursorSize	(JJ)I
/*      */     //   15: istore_1
/*      */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   22: iload_1
/*      */     //   23: ireturn
/*      */     //   24: astore_2
/*      */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   28: aload_2
/*      */     //   29: athrow
/*      */     //   30: astore_1
/*      */     //   31: new 32	java/lang/StringBuilder
/*      */     //   34: dup
/*      */     //   35: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   38: ldc_w 260
/*      */     //   41: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   44: aload_1
/*      */     //   45: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   48: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   51: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   54: iconst_0
/*      */     //   55: istore_2
/*      */     //   56: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   59: iload_2
/*      */     //   60: ireturn
/*      */     //   61: astore_3
/*      */     //   62: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   65: aload_3
/*      */     //   66: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1203	-> byte code offset #0
/*      */     //   Java source line #1205	-> byte code offset #3
/*      */     //   Java source line #1207	-> byte code offset #6
/*      */     //   Java source line #1209	-> byte code offset #16
/*      */     //   Java source line #1215	-> byte code offset #19
/*      */     //   Java source line #1209	-> byte code offset #24
/*      */     //   Java source line #1211	-> byte code offset #30
/*      */     //   Java source line #1212	-> byte code offset #31
/*      */     //   Java source line #1213	-> byte code offset #54
/*      */     //   Java source line #1215	-> byte code offset #56
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	67	0	this	LinuxDisplay
/*      */     //   15	8	1	i	int
/*      */     //   30	15	1	e	LWJGLException
/*      */     //   24	5	2	localObject1	Object
/*      */     //   55	5	2	j	int
/*      */     //   61	5	3	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	16	24	finally
/*      */     //   24	25	24	finally
/*      */     //   3	19	30	org/lwjgl/LWJGLException
/*      */     //   24	30	30	org/lwjgl/LWJGLException
/*      */     //   3	19	61	finally
/*      */     //   24	56	61	finally
/*      */     //   61	62	61	finally
/*      */   }
/*      */   
/*      */   private static native int nGetMaxCursorSize(long paramLong1, long paramLong2);
/*      */   
/*      */   public void createKeyboard()
/*      */     throws LWJGLException
/*      */   {
/*      */     
/*      */     try
/*      */     {
/* 1224 */       this.keyboard = new LinuxKeyboard(getDisplay(), getWindow());
/*      */     } finally {
/* 1226 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   public void destroyKeyboard() {
/*      */     
/*      */     try {
/* 1233 */       this.keyboard.destroy(getDisplay());
/* 1234 */       this.keyboard = null;
/*      */     } finally {
/* 1236 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   public void pollKeyboard(ByteBuffer keyDownBuffer) {
/*      */     
/*      */     try {
/* 1243 */       this.keyboard.poll(keyDownBuffer);
/*      */     } finally {
/* 1245 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   public void readKeyboard(ByteBuffer buffer) {
/*      */     
/*      */     try {
/* 1252 */       this.keyboard.read(buffer);
/*      */     } finally {
/* 1254 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   private static native long nCreateCursor(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, IntBuffer paramIntBuffer1, int paramInt6, IntBuffer paramIntBuffer2, int paramInt7) throws LWJGLException;
/*      */   
/*      */   private static long createBlankCursor() {
/* 1261 */     return nCreateBlankCursor(getDisplay(), getWindow());
/*      */   }
/*      */   
/*      */   static native long nCreateBlankCursor(long paramLong1, long paramLong2);
/*      */   
/*      */   /* Error */
/*      */   public Object createCursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/*      */     throws LWJGLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: iload_1
/*      */     //   10: iload_2
/*      */     //   11: iload_3
/*      */     //   12: iload 4
/*      */     //   14: iload 5
/*      */     //   16: aload 6
/*      */     //   18: aload 6
/*      */     //   20: invokevirtual 267	java/nio/IntBuffer:position	()I
/*      */     //   23: aload 7
/*      */     //   25: aload 7
/*      */     //   27: ifnull +11 -> 38
/*      */     //   30: aload 7
/*      */     //   32: invokevirtual 267	java/nio/IntBuffer:position	()I
/*      */     //   35: goto +4 -> 39
/*      */     //   38: iconst_m1
/*      */     //   39: invokestatic 268	org/lwjgl/opengl/LinuxDisplay:nCreateCursor	(JIIIIILjava/nio/IntBuffer;ILjava/nio/IntBuffer;I)J
/*      */     //   42: lstore 8
/*      */     //   44: lload 8
/*      */     //   46: invokestatic 269	java/lang/Long:valueOf	(J)Ljava/lang/Long;
/*      */     //   49: astore 10
/*      */     //   51: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   54: aload 10
/*      */     //   56: areturn
/*      */     //   57: astore 8
/*      */     //   59: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   62: aload 8
/*      */     //   64: athrow
/*      */     //   65: astore 11
/*      */     //   67: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   70: aload 11
/*      */     //   72: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1266	-> byte code offset #0
/*      */     //   Java source line #1268	-> byte code offset #3
/*      */     //   Java source line #1270	-> byte code offset #6
/*      */     //   Java source line #1271	-> byte code offset #44
/*      */     //   Java source line #1277	-> byte code offset #51
/*      */     //   Java source line #1272	-> byte code offset #57
/*      */     //   Java source line #1273	-> byte code offset #59
/*      */     //   Java source line #1274	-> byte code offset #62
/*      */     //   Java source line #1277	-> byte code offset #65
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	73	0	this	LinuxDisplay
/*      */     //   0	73	1	width	int
/*      */     //   0	73	2	height	int
/*      */     //   0	73	3	xHotspot	int
/*      */     //   0	73	4	yHotspot	int
/*      */     //   0	73	5	numImages	int
/*      */     //   0	73	6	images	IntBuffer
/*      */     //   0	73	7	delays	IntBuffer
/*      */     //   42	3	8	cursor	long
/*      */     //   57	6	8	e	LWJGLException
/*      */     //   49	6	10	localLong	Long
/*      */     //   65	6	11	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	51	57	org/lwjgl/LWJGLException
/*      */     //   3	51	65	finally
/*      */     //   57	67	65	finally
/*      */   }
/*      */   
/*      */   private static long getCursorHandle(Object cursor_handle)
/*      */   {
/* 1282 */     return cursor_handle != null ? ((Long)cursor_handle).longValue() : 0L;
/*      */   }
/*      */   
/*      */   public void destroyCursor(Object cursorHandle) {
/*      */     
/*      */     try {
/* 1288 */       nDestroyCursor(getDisplay(), getCursorHandle(cursorHandle));
/* 1289 */       decDisplay();
/*      */     } finally {
/* 1291 */       unlockAWT();
/*      */     }
/*      */   }
/*      */   
/*      */   static native void nDestroyCursor(long paramLong1, long paramLong2);
/*      */   
/*      */   /* Error */
/*      */   public int getPbufferCapabilities()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   9: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*      */     //   12: invokestatic 272	org/lwjgl/opengl/LinuxDisplay:nGetPbufferCapabilities	(JI)I
/*      */     //   15: istore_1
/*      */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   22: iload_1
/*      */     //   23: ireturn
/*      */     //   24: astore_2
/*      */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   28: aload_2
/*      */     //   29: athrow
/*      */     //   30: astore_1
/*      */     //   31: new 32	java/lang/StringBuilder
/*      */     //   34: dup
/*      */     //   35: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   38: ldc_w 273
/*      */     //   41: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   44: aload_1
/*      */     //   45: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   48: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   51: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   54: iconst_0
/*      */     //   55: istore_2
/*      */     //   56: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   59: iload_2
/*      */     //   60: ireturn
/*      */     //   61: astore_3
/*      */     //   62: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   65: aload_3
/*      */     //   66: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1297	-> byte code offset #0
/*      */     //   Java source line #1299	-> byte code offset #3
/*      */     //   Java source line #1301	-> byte code offset #6
/*      */     //   Java source line #1303	-> byte code offset #16
/*      */     //   Java source line #1309	-> byte code offset #19
/*      */     //   Java source line #1303	-> byte code offset #24
/*      */     //   Java source line #1305	-> byte code offset #30
/*      */     //   Java source line #1306	-> byte code offset #31
/*      */     //   Java source line #1307	-> byte code offset #54
/*      */     //   Java source line #1309	-> byte code offset #56
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	67	0	this	LinuxDisplay
/*      */     //   15	8	1	i	int
/*      */     //   30	15	1	e	LWJGLException
/*      */     //   24	5	2	localObject1	Object
/*      */     //   55	5	2	j	int
/*      */     //   61	5	3	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	16	24	finally
/*      */     //   24	25	24	finally
/*      */     //   3	19	30	org/lwjgl/LWJGLException
/*      */     //   24	30	30	org/lwjgl/LWJGLException
/*      */     //   3	19	61	finally
/*      */     //   24	56	61	finally
/*      */     //   61	62	61	finally
/*      */   }
/*      */   
/*      */   private static native int nGetPbufferCapabilities(long paramLong, int paramInt);
/*      */   
/*      */   public boolean isBufferLost(PeerInfo handle)
/*      */   {
/* 1315 */     return false;
/*      */   }
/*      */   
/*      */   public PeerInfo createPbuffer(int width, int height, PixelFormat pixel_format, ContextAttribs attribs, IntBuffer pixelFormatCaps, IntBuffer pBufferAttribs)
/*      */     throws LWJGLException
/*      */   {
/* 1321 */     return new LinuxPbufferPeerInfo(width, height, pixel_format);
/*      */   }
/*      */   
/*      */   public void setPbufferAttrib(PeerInfo handle, int attrib, int value) {
/* 1325 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void bindTexImageToPbuffer(PeerInfo handle, int buffer) {
/* 1329 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void releaseTexImageFromPbuffer(PeerInfo handle, int buffer) {
/* 1333 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean minimized;
/*      */   
/*      */   private boolean dirty;
/*      */   private boolean close_requested;
/*      */   private long current_cursor;
/*      */   private long blank_cursor;
/*      */   
/*      */   private static ByteBuffer convertIcons(ByteBuffer[] icons)
/*      */   {
/* 1346 */     int bufferSize = 0;
/*      */     
/*      */ 
/* 1349 */     for (ByteBuffer icon : icons) {
/* 1350 */       int size = icon.limit() / 4;
/* 1351 */       int dimension = (int)Math.sqrt(size);
/* 1352 */       if (dimension > 0) {
/* 1353 */         bufferSize += 8;
/* 1354 */         bufferSize += dimension * dimension * 4;
/*      */       }
/*      */     }
/*      */     
/* 1358 */     if (bufferSize == 0) { return null;
/*      */     }
/* 1360 */     ByteBuffer icon_argb = BufferUtils.createByteBuffer(bufferSize);
/* 1361 */     icon_argb.order(ByteOrder.BIG_ENDIAN);
/*      */     
/* 1363 */     for (ByteBuffer icon : icons) {
/* 1364 */       int size = icon.limit() / 4;
/* 1365 */       int dimension = (int)Math.sqrt(size);
/*      */       
/* 1367 */       icon_argb.putInt(dimension);
/* 1368 */       icon_argb.putInt(dimension);
/*      */       
/* 1370 */       for (int y = 0; y < dimension; y++) {
/* 1371 */         for (int x = 0; x < dimension; x++)
/*      */         {
/* 1373 */           byte r = icon.get(x * 4 + y * dimension * 4);
/* 1374 */           byte g = icon.get(x * 4 + y * dimension * 4 + 1);
/* 1375 */           byte b = icon.get(x * 4 + y * dimension * 4 + 2);
/* 1376 */           byte a = icon.get(x * 4 + y * dimension * 4 + 3);
/*      */           
/* 1378 */           icon_argb.put(a);
/* 1379 */           icon_argb.put(r);
/* 1380 */           icon_argb.put(g);
/* 1381 */           icon_argb.put(b);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1386 */     return icon_argb;
/*      */   }
/*      */   
/*      */   private boolean mouseInside;
/*      */   private boolean resizable;
/*      */   private boolean resized;
/*      */   private int window_x;
/*      */   private int window_y;
/*      */   private int window_width;
/*      */   /* Error */
/*      */   public int setIcon(ByteBuffer[] icons)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*      */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*      */     //   6: aload_1
/*      */     //   7: invokestatic 286	org/lwjgl/opengl/LinuxDisplay:convertIcons	([Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
/*      */     //   10: astore_2
/*      */     //   11: aload_2
/*      */     //   12: ifnonnull +13 -> 25
/*      */     //   15: iconst_0
/*      */     //   16: istore_3
/*      */     //   17: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   20: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   23: iload_3
/*      */     //   24: ireturn
/*      */     //   25: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*      */     //   28: invokestatic 79	org/lwjgl/opengl/LinuxDisplay:getWindow	()J
/*      */     //   31: aload_2
/*      */     //   32: aload_2
/*      */     //   33: invokevirtual 287	java/nio/ByteBuffer:capacity	()I
/*      */     //   36: invokestatic 288	org/lwjgl/opengl/LinuxDisplay:nSetWindowIcon	(JJLjava/nio/ByteBuffer;I)V
/*      */     //   39: aload_1
/*      */     //   40: arraylength
/*      */     //   41: istore_3
/*      */     //   42: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   45: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   48: iload_3
/*      */     //   49: ireturn
/*      */     //   50: astore 4
/*      */     //   52: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*      */     //   55: aload 4
/*      */     //   57: athrow
/*      */     //   58: astore_2
/*      */     //   59: new 32	java/lang/StringBuilder
/*      */     //   62: dup
/*      */     //   63: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*      */     //   66: ldc_w 289
/*      */     //   69: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   72: aload_2
/*      */     //   73: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   76: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   79: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*      */     //   82: iconst_0
/*      */     //   83: istore_3
/*      */     //   84: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   87: iload_3
/*      */     //   88: ireturn
/*      */     //   89: astore 5
/*      */     //   91: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*      */     //   94: aload 5
/*      */     //   96: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1402	-> byte code offset #0
/*      */     //   Java source line #1404	-> byte code offset #3
/*      */     //   Java source line #1407	-> byte code offset #6
/*      */     //   Java source line #1408	-> byte code offset #11
/*      */     //   Java source line #1412	-> byte code offset #17
/*      */     //   Java source line #1418	-> byte code offset #20
/*      */     //   Java source line #1409	-> byte code offset #25
/*      */     //   Java source line #1410	-> byte code offset #39
/*      */     //   Java source line #1412	-> byte code offset #42
/*      */     //   Java source line #1418	-> byte code offset #45
/*      */     //   Java source line #1412	-> byte code offset #50
/*      */     //   Java source line #1414	-> byte code offset #58
/*      */     //   Java source line #1415	-> byte code offset #59
/*      */     //   Java source line #1416	-> byte code offset #82
/*      */     //   Java source line #1418	-> byte code offset #84
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	97	0	this	LinuxDisplay
/*      */     //   0	97	1	icons	ByteBuffer[]
/*      */     //   10	23	2	icons_data	ByteBuffer
/*      */     //   58	15	2	e	LWJGLException
/*      */     //   16	72	3	i	int
/*      */     //   50	6	4	localObject1	Object
/*      */     //   89	6	5	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	17	50	finally
/*      */     //   25	42	50	finally
/*      */     //   50	52	50	finally
/*      */     //   3	20	58	org/lwjgl/LWJGLException
/*      */     //   25	45	58	org/lwjgl/LWJGLException
/*      */     //   50	58	58	org/lwjgl/LWJGLException
/*      */     //   3	20	89	finally
/*      */     //   25	45	89	finally
/*      */     //   50	84	89	finally
/*      */     //   89	91	89	finally
/*      */   }
/*      */   
/*      */   private static native void nSetWindowIcon(long paramLong1, long paramLong2, ByteBuffer paramByteBuffer, int paramInt);
/*      */   
/*      */   public int getX()
/*      */   {
/* 1425 */     return this.window_x;
/*      */   }
/*      */   
/*      */   public int getY() {
/* 1429 */     return this.window_y;
/*      */   }
/*      */   
/*      */   public int getWidth() {
/* 1433 */     return this.window_width;
/*      */   }
/*      */   
/*      */   public int getHeight() {
/* 1437 */     return this.window_height;
/*      */   }
/*      */   
/*      */   public boolean isInsideWindow() {
/* 1441 */     return this.mouseInside;
/*      */   }
/*      */   
/*      */   public void setResizable(boolean resizable) {
/* 1445 */     if (this.resizable == resizable) {
/* 1446 */       return;
/*      */     }
/*      */     
/* 1449 */     this.resizable = resizable;
/* 1450 */     nSetWindowSize(getDisplay(), getWindow(), this.window_width, this.window_height, resizable);
/*      */   }
/*      */   
/*      */   public boolean wasResized() {
/* 1454 */     if (this.resized) {
/* 1455 */       this.resized = false;
/* 1456 */       return true;
/*      */     }
/*      */     
/* 1459 */     return false;
/*      */   }
/*      */   
/*      */   public float getPixelScaleFactor() {
/* 1463 */     return 1.0F;
/*      */   }
/*      */   
/*      */   private int window_height;
/*      */   private Canvas parent;
/*      */   private long parent_window;
/*      */   private static boolean xembedded;
/*      */   private long parent_proxy_focus_window;
/*      */   private boolean parent_focused;
/*      */   private boolean parent_focus_changed;
/*      */   private long last_window_focus;
/*      */   private LinuxKeyboard keyboard;
/*      */   private LinuxMouse mouse;
/*      */   private String wm_class;
/*      */   private final FocusListener focus_listener;
/*      */   private static final class Compiz
/*      */   {
/*      */     private static boolean applyFix;
/*      */     private static Provider provider;
/*      */     
/*      */     static void init() {
/* 1484 */       if (Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.nocompiz_lfs")) {
/* 1485 */         return;
/*      */       }
/* 1487 */       AccessController.doPrivileged(new PrivilegedAction()
/*      */       {
/*      */         public Object run() {
/*      */           try {
/* 1491 */             if (!LinuxDisplay.Compiz.isProcessActive("compiz")) {
/* 1492 */               Object localObject1 = null;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1582 */               return null;
/*      */             }
/* 1494 */             LinuxDisplay.Compiz.access$402(null);
/*      */             
/* 1496 */             String providerName = null;
/*      */             
/*      */ 
/* 1499 */             if (LinuxDisplay.Compiz.isProcessActive("dbus-daemon")) {
/* 1500 */               providerName = "Dbus";
/* 1501 */               LinuxDisplay.Compiz.access$402(new LinuxDisplay.Compiz.Provider()
/*      */               {
/*      */                 private static final String KEY = "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen";
/*      */                 
/*      */                 public boolean hasLegacyFullscreenSupport() throws LWJGLException {
/* 1506 */                   List output = LinuxDisplay.Compiz.run(new String[] { "dbus-send", "--print-reply", "--type=method_call", "--dest=org.freedesktop.compiz", "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen", "org.freedesktop.compiz.get" });
/*      */                   
/*      */ 
/*      */ 
/* 1510 */                   if ((output == null) || (output.size() < 2)) {
/* 1511 */                     throw new LWJGLException("Invalid Dbus reply.");
/*      */                   }
/* 1513 */                   String line = (String)output.get(0);
/*      */                   
/* 1515 */                   if (!line.startsWith("method return")) {
/* 1516 */                     throw new LWJGLException("Invalid Dbus reply.");
/*      */                   }
/* 1518 */                   line = ((String)output.get(1)).trim();
/* 1519 */                   if ((!line.startsWith("boolean")) || (line.length() < 12)) {
/* 1520 */                     throw new LWJGLException("Invalid Dbus reply.");
/*      */                   }
/* 1522 */                   return "true".equalsIgnoreCase(line.substring("boolean".length() + 1));
/*      */                 }
/*      */                 
/*      */                 public void setLegacyFullscreenSupport(boolean state) throws LWJGLException {
/* 1526 */                   if (LinuxDisplay.Compiz.run(new String[] { "dbus-send", "--type=method_call", "--dest=org.freedesktop.compiz", "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen", "org.freedesktop.compiz.set", "boolean:" + Boolean.toString(state) }) == null)
/*      */                   {
/*      */ 
/* 1529 */                     throw new LWJGLException("Failed to apply Compiz LFS workaround.");
/*      */                   }
/*      */                 }
/*      */               });
/*      */             } else {
/*      */               try {
/* 1535 */                 Runtime.getRuntime().exec("gconftool");
/*      */                 
/* 1537 */                 providerName = "gconftool";
/* 1538 */                 LinuxDisplay.Compiz.access$402(new LinuxDisplay.Compiz.Provider()
/*      */                 {
/*      */                   private static final String KEY = "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen";
/*      */                   
/*      */                   public boolean hasLegacyFullscreenSupport() throws LWJGLException {
/* 1543 */                     List output = LinuxDisplay.Compiz.run(new String[] { "gconftool", "-g", "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen" });
/*      */                     
/*      */ 
/*      */ 
/* 1547 */                     if ((output == null) || (output.size() == 0)) {
/* 1548 */                       throw new LWJGLException("Invalid gconftool reply.");
/*      */                     }
/* 1550 */                     return Boolean.parseBoolean(((String)output.get(0)).trim());
/*      */                   }
/*      */                   
/*      */                   public void setLegacyFullscreenSupport(boolean state) throws LWJGLException {
/* 1554 */                     if (LinuxDisplay.Compiz.run(new String[] { "gconftool", "-s", "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen", "-s", Boolean.toString(state), "-t", "bool" }) == null)
/*      */                     {
/*      */ 
/* 1557 */                       throw new LWJGLException("Failed to apply Compiz LFS workaround.");
/*      */                     }
/* 1559 */                     if (state)
/*      */                     {
/*      */                       try
/*      */                       {
/* 1563 */                         Thread.sleep(200L);
/*      */                       } catch (InterruptedException e) {
/* 1565 */                         e.printStackTrace();
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 });
/*      */               }
/*      */               catch (IOException e) {}
/*      */             }
/*      */             
/*      */ 
/* 1575 */             if ((LinuxDisplay.Compiz.provider != null) && (!LinuxDisplay.Compiz.provider.hasLegacyFullscreenSupport())) {
/* 1576 */               LinuxDisplay.Compiz.access$602(true);
/* 1577 */               LWJGLUtil.log("Using " + providerName + " to apply Compiz LFS workaround.");
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1582 */             return null;
/*      */           }
/*      */           catch (LWJGLException e)
/*      */           {
/* 1579 */             e = 
/*      */             
/*      */ 
/* 1582 */               e;return null; } finally {} return null;
/*      */         }
/*      */       });
/*      */     }
/*      */     
/*      */     static void setLegacyFullscreenSupport(boolean enabled)
/*      */     {
/* 1589 */       if (!applyFix) {
/* 1590 */         return;
/*      */       }
/* 1592 */       AccessController.doPrivileged(new PrivilegedAction() {
/*      */         public Object run() {
/*      */           try {
/* 1595 */             LinuxDisplay.Compiz.provider.setLegacyFullscreenSupport(this.val$enabled);
/*      */           } catch (LWJGLException e) {
/* 1597 */             LWJGLUtil.log("Failed to change Compiz Legacy Fullscreen Support. Reason: " + e.getMessage());
/*      */           }
/* 1599 */           return null;
/*      */         }
/*      */       });
/*      */     }
/*      */     
/*      */     private static List<String> run(String... command) throws LWJGLException {
/* 1605 */       List<String> output = new ArrayList();
/*      */       try
/*      */       {
/* 1608 */         Process p = Runtime.getRuntime().exec(command);
/*      */         try {
/* 1610 */           int exitValue = p.waitFor();
/* 1611 */           if (exitValue != 0)
/* 1612 */             return null;
/*      */         } catch (InterruptedException e) {
/* 1614 */           throw new LWJGLException("Process interrupted.", e);
/*      */         }
/*      */         
/* 1617 */         BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
/*      */         
/*      */         String line;
/* 1620 */         while ((line = br.readLine()) != null) {
/* 1621 */           output.add(line);
/*      */         }
/* 1623 */         br.close();
/*      */       } catch (IOException e) {
/* 1625 */         throw new LWJGLException("Process failed.", e);
/*      */       }
/*      */       
/* 1628 */       return output;
/*      */     }
/*      */     
/*      */     private static boolean isProcessActive(String processName) throws LWJGLException {
/* 1632 */       List<String> output = run(new String[] { "ps", "-C", processName });
/* 1633 */       if (output == null) {
/* 1634 */         return false;
/*      */       }
/* 1636 */       for (String line : output) {
/* 1637 */         if (line.contains(processName)) {
/* 1638 */           return true;
/*      */         }
/*      */       }
/* 1641 */       return false;
/*      */     }
/*      */     
/*      */     private static abstract interface Provider
/*      */     {
/*      */       public abstract boolean hasLegacyFullscreenSupport()
/*      */         throws LWJGLException;
/*      */       
/*      */       public abstract void setLegacyFullscreenSupport(boolean paramBoolean)
/*      */         throws LWJGLException;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\LinuxDisplay.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */