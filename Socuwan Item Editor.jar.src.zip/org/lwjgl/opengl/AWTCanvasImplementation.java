package org.lwjgl.opengl;

import java.awt.Canvas;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import org.lwjgl.LWJGLException;

abstract interface AWTCanvasImplementation
{
  public abstract PeerInfo createPeerInfo(Canvas paramCanvas, PixelFormat paramPixelFormat, ContextAttribs paramContextAttribs)
    throws LWJGLException;
  
  public abstract GraphicsConfiguration findConfiguration(GraphicsDevice paramGraphicsDevice, PixelFormat paramPixelFormat)
    throws LWJGLException;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\AWTCanvasImplementation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */