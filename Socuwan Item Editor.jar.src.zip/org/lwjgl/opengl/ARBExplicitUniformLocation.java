package org.lwjgl.opengl;

public final class ARBExplicitUniformLocation
{
  public static final int GL_MAX_UNIFORM_LOCATIONS = 33390;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\ARBExplicitUniformLocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */