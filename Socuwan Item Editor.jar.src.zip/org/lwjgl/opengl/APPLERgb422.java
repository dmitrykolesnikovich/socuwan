package org.lwjgl.opengl;

public final class APPLERgb422
{
  public static final int GL_RGB_422_APPLE = 35359;
  public static final int GL_UNSIGNED_SHORT_8_8_APPLE = 34234;
  public static final int GL_UNSIGNED_SHORT_8_8_REV_APPLE = 34235;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\APPLERgb422.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */