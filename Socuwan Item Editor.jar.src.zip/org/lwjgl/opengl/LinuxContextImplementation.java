/*     */ package org.lwjgl.opengl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import org.lwjgl.LWJGLException;
/*     */ 
/*     */ final class LinuxContextImplementation
/*     */   implements ContextImplementation
/*     */ {
/*     */   /* Error */
/*     */   public ByteBuffer create(PeerInfo peer_info, IntBuffer attribs, ByteBuffer shared_context_handle)
/*     */     throws LWJGLException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: invokestatic 2	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*     */     //   3: aload_1
/*     */     //   4: invokevirtual 3	org/lwjgl/opengl/PeerInfo:lockAndGetHandle	()Ljava/nio/ByteBuffer;
/*     */     //   7: astore 4
/*     */     //   9: aload 4
/*     */     //   11: aload_2
/*     */     //   12: aload_3
/*     */     //   13: invokestatic 4	org/lwjgl/opengl/LinuxContextImplementation:nCreate	(Ljava/nio/ByteBuffer;Ljava/nio/IntBuffer;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
/*     */     //   16: astore 5
/*     */     //   18: aload_1
/*     */     //   19: invokevirtual 5	org/lwjgl/opengl/PeerInfo:unlock	()V
/*     */     //   22: invokestatic 6	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*     */     //   25: aload 5
/*     */     //   27: areturn
/*     */     //   28: astore 6
/*     */     //   30: aload_1
/*     */     //   31: invokevirtual 5	org/lwjgl/opengl/PeerInfo:unlock	()V
/*     */     //   34: aload 6
/*     */     //   36: athrow
/*     */     //   37: astore 7
/*     */     //   39: invokestatic 6	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*     */     //   42: aload 7
/*     */     //   44: athrow
/*     */     // Line number table:
/*     */     //   Java source line #47	-> byte code offset #0
/*     */     //   Java source line #49	-> byte code offset #3
/*     */     //   Java source line #51	-> byte code offset #9
/*     */     //   Java source line #53	-> byte code offset #18
/*     */     //   Java source line #56	-> byte code offset #22
/*     */     //   Java source line #53	-> byte code offset #28
/*     */     //   Java source line #56	-> byte code offset #37
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	45	0	this	LinuxContextImplementation
/*     */     //   0	45	1	peer_info	PeerInfo
/*     */     //   0	45	2	attribs	IntBuffer
/*     */     //   0	45	3	shared_context_handle	ByteBuffer
/*     */     //   7	3	4	peer_handle	ByteBuffer
/*     */     //   16	10	5	localByteBuffer1	ByteBuffer
/*     */     //   28	7	6	localObject1	Object
/*     */     //   37	6	7	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	18	28	finally
/*     */     //   28	30	28	finally
/*     */     //   3	22	37	finally
/*     */     //   28	39	37	finally
/*     */   }
/*     */   
/*     */   private static native ByteBuffer nCreate(ByteBuffer paramByteBuffer1, IntBuffer paramIntBuffer, ByteBuffer paramByteBuffer2)
/*     */     throws LWJGLException;
/*     */   
/*     */   native long getGLXContext(ByteBuffer paramByteBuffer);
/*     */   
/*     */   native long getDisplay(ByteBuffer paramByteBuffer);
/*     */   
/*     */   public void releaseDrawable(ByteBuffer context_handle)
/*     */     throws LWJGLException
/*     */   {}
/*     */   
/*     */   public void swapBuffers()
/*     */     throws LWJGLException
/*     */   {
/*  70 */     ContextGL current_context = ContextGL.getCurrentContext();
/*  71 */     if (current_context == null)
/*  72 */       throw new IllegalStateException("No context is current");
/*  73 */     synchronized (current_context) {
/*  74 */       PeerInfo current_peer_info = current_context.getPeerInfo();
/*  75 */       LinuxDisplay.lockAWT();
/*     */       try {
/*  77 */         ByteBuffer peer_handle = current_peer_info.lockAndGetHandle();
/*     */         try {
/*  79 */           nSwapBuffers(peer_handle);
/*     */         } finally {
/*  81 */           current_peer_info.unlock();
/*     */         }
/*     */       } finally {
/*  84 */         LinuxDisplay.unlockAWT();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static native void nSwapBuffers(ByteBuffer paramByteBuffer) throws LWJGLException;
/*     */   
/*     */   public void releaseCurrentContext() throws LWJGLException {
/*  92 */     ContextGL current_context = ContextGL.getCurrentContext();
/*  93 */     if (current_context == null)
/*  94 */       throw new IllegalStateException("No context is current");
/*  95 */     synchronized (current_context) {
/*  96 */       PeerInfo current_peer_info = current_context.getPeerInfo();
/*  97 */       LinuxDisplay.lockAWT();
/*     */       try {
/*  99 */         ByteBuffer peer_handle = current_peer_info.lockAndGetHandle();
/*     */         try {
/* 101 */           nReleaseCurrentContext(peer_handle);
/*     */         } finally {
/* 103 */           current_peer_info.unlock();
/*     */         }
/*     */       } finally {
/* 106 */         LinuxDisplay.unlockAWT();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static native void nReleaseCurrentContext(ByteBuffer paramByteBuffer) throws LWJGLException;
/*     */   
/*     */   public void update(ByteBuffer context_handle) {}
/*     */   
/*     */   public void makeCurrent(PeerInfo peer_info, ByteBuffer handle) throws LWJGLException
/*     */   {
/*     */     
/*     */     try {
/* 119 */       ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*     */       try {
/* 121 */         nMakeCurrent(peer_handle, handle);
/*     */       } finally {
/* 123 */         peer_info.unlock();
/*     */       }
/*     */     } finally {
/* 126 */       LinuxDisplay.unlockAWT();
/*     */     }
/*     */   }
/*     */   
/*     */   private static native void nMakeCurrent(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2) throws LWJGLException;
/*     */   
/*     */   public boolean isCurrent(ByteBuffer handle) throws LWJGLException {
/*     */     
/*     */     try {
/* 135 */       boolean result = nIsCurrent(handle);
/* 136 */       return result;
/*     */     } finally {
/* 138 */       LinuxDisplay.unlockAWT();
/*     */     }
/*     */   }
/*     */   
/*     */   private static native boolean nIsCurrent(ByteBuffer paramByteBuffer) throws LWJGLException;
/*     */   
/*     */   public void setSwapInterval(int value) {
/* 145 */     ContextGL current_context = ContextGL.getCurrentContext();
/* 146 */     PeerInfo peer_info = current_context.getPeerInfo();
/*     */     
/* 148 */     if (current_context == null)
/* 149 */       throw new IllegalStateException("No context is current");
/* 150 */     synchronized (current_context) {
/* 151 */       LinuxDisplay.lockAWT();
/*     */       try {
/* 153 */         ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*     */         try {
/* 155 */           nSetSwapInterval(peer_handle, current_context.getHandle(), value);
/*     */         } finally {
/* 157 */           peer_info.unlock();
/*     */         }
/*     */       }
/*     */       catch (LWJGLException e) {
/* 161 */         e.printStackTrace();
/*     */       } finally {
/* 163 */         LinuxDisplay.unlockAWT();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static native void nSetSwapInterval(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2, int paramInt);
/*     */   
/*     */   public void destroy(PeerInfo peer_info, ByteBuffer handle) throws LWJGLException {
/*     */     
/*     */     try {
/* 173 */       ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*     */       try {
/* 175 */         nDestroy(peer_handle, handle);
/*     */       } finally {
/* 177 */         peer_info.unlock();
/*     */       }
/*     */     } finally {
/* 180 */       LinuxDisplay.unlockAWT();
/*     */     }
/*     */   }
/*     */   
/*     */   private static native void nDestroy(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/*     */     throws LWJGLException;
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\LinuxContextImplementation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */