package org.lwjgl.opengl;

public final class ARBCompressedTexturePixelStorage
{
  public static final int GL_UNPACK_COMPRESSED_BLOCK_WIDTH = 37159;
  public static final int GL_UNPACK_COMPRESSED_BLOCK_HEIGHT = 37160;
  public static final int GL_UNPACK_COMPRESSED_BLOCK_DEPTH = 37161;
  public static final int GL_UNPACK_COMPRESSED_BLOCK_SIZE = 37162;
  public static final int GL_PACK_COMPRESSED_BLOCK_WIDTH = 37163;
  public static final int GL_PACK_COMPRESSED_BLOCK_HEIGHT = 37164;
  public static final int GL_PACK_COMPRESSED_BLOCK_DEPTH = 37165;
  public static final int GL_PACK_COMPRESSED_BLOCK_SIZE = 37166;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\org\lwjgl\opengl\ARBCompressedTexturePixelStorage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */