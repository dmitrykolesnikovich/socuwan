/*    */ package main;
/*    */ 
/*    */ import animations.Animation;
/*    */ import animations.AnimationLoader;
/*    */ 
/*    */ public enum PlayerAnimation
/*    */ {
/*  8 */   IDLE("Idle", "standing"), 
/*  9 */   RUNNING("Running", "runningImproved");
/*    */   
/*    */   private Animation possibleAnimation;
/*    */   private String name;
/*    */   
/*    */   private PlayerAnimation(String name, String possibleAnimName) {
/* 15 */     this.name = name;
/* 16 */     this.possibleAnimation = AnimationLoader.loadAnimationFile(possibleAnimName);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 20 */     return this.name;
/*    */   }
/*    */   
/*    */   public Animation getAnimation() {
/* 24 */     return this.possibleAnimation;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\main\PlayerAnimation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */