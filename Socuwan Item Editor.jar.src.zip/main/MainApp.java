/*    */ package main;
/*    */ 
/*    */ import atmosphere.Sky;
/*    */ import atmosphere.SkyBox;
/*    */ import atmosphere.Sun;
/*    */ import clothes.Clothe;
/*    */ import entitiesInterfaces.Light;
/*    */ import epicRenderEngine.RenderEngine;
/*    */ import frontend.MainFrame;
/*    */ import instances.Camera;
/*    */ import instances.HumanEntity;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Locale;
/*    */ import javax.swing.JOptionPane;
/*    */ import toolbox.Colour;
/*    */ import toolbox.MyKeyboard;
/*    */ import toolbox.MyMouse;
/*    */ 
/*    */ public class MainApp
/*    */ {
/*    */   public static HumanEntity character;
/* 24 */   public static boolean close = false;
/* 25 */   public static boolean rotatePreview = true;
/*    */   
/*    */   public static void init() {
/* 28 */     Locale.setDefault(Locale.US);
/*    */     
/* 30 */     System.out.println(new File("natives").getAbsolutePath());
/*    */     
/* 32 */     String osname = System.getProperty("os.name").toLowerCase();
/* 33 */     System.out.println("OS Name: " + osname);
/* 34 */     System.out.println("OS Arch: " + System.getProperty("os.arch"));
/* 35 */     String pathExtension = "";
/*    */     
/* 37 */     if (osname.contains("win")) {
/* 38 */       pathExtension = "win";
/* 39 */     } else if (osname.contains("lin")) {
/* 40 */       pathExtension = "lin";
/* 41 */     } else if (osname.contains("mac")) {
/* 42 */       pathExtension = "mac";
/*    */     } else {
/* 44 */       JOptionPane.showMessageDialog(null, "Sorry, but your system is not supported by LWJGL :(");
/* 45 */       System.exit(-1);
/*    */     }
/*    */     
/*    */ 
/* 49 */     System.setProperty("org.lwjgl.librarypath", new File("natives").getAbsolutePath() + "/" + pathExtension);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 56 */     init();
/*    */     
/* 58 */     MainFrame mainFrame = new MainFrame(new WorkSpace());
/* 59 */     MyMouse mouse = new MyMouse();
/* 60 */     MyKeyboard keyboard = new MyKeyboard();
/* 61 */     InputProcessor inputs = new InputProcessor(mouse, keyboard);
/* 62 */     Camera camera = new Camera(mouse);
/* 63 */     RenderEngine engine = new RenderEngine(camera, mainFrame.getCanvas());
/* 64 */     Sky sky = new Sky(camera, 500.0F);
/* 65 */     sky.getSun().setPosition(1000.0F, 500.0F, 1000.0F);
/* 66 */     sky.setSkyColour(new Colour(1.0F, 0.7F, 0.8F));
/* 67 */     sky.getSkyBox().setTextures(RenderEngine.loadTexture("skybox/daySky"), RenderEngine.loadTexture("skybox/daySky"), 0.5F);
/*    */     
/*    */ 
/* 70 */     java.util.List<Light> emptyList = new ArrayList();
/*    */     
/* 72 */     character = new HumanEntity(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/* 73 */     camera.setParentEntity(character);
/*    */     
/* 75 */     while (!close) {
/* 76 */       epicRenderEngine.Loader.dealWithRequests();
/* 77 */       sky.getSkyBox().update(new Colour(1.0F, 0.7F, 0.8F));
/* 78 */       camera.moveCamera(RenderEngine.getDeltaInSeconds());
/* 79 */       engine.updateView();
/* 80 */       inputs.checkInput();
/* 81 */       if (character.isShowing()) {
/* 82 */         character.getCurrentClothes().update();
/* 83 */         if (rotatePreview) {
/* 84 */           character.increaseRotationValue(0.0F, RenderEngine.getDeltaInSeconds() * 60.0F, 0.0F);
/*    */         }
/* 86 */         character.animateForCurrentFrame(RenderEngine.getDeltaInSeconds());
/* 87 */         engine.processHumanEntity(character);
/*    */       }
/* 89 */       engine.render(sky, emptyList);
/* 90 */       engine.updateDisplay();
/*    */     }
/*    */     
/* 93 */     engine.closeDisplay();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\main\MainApp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */