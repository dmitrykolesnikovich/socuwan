/*    */ package main;
/*    */ 
/*    */ import backend.Item;
/*    */ import categories.MainCategory;
/*    */ import clothesComponent.ClotheBlueprint;
/*    */ import components.Component;
/*    */ import components.FoodComponent;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ public class ItemImporter
/*    */ {
/*    */   public static void loadItemInfo(Item bareItem)
/*    */     throws Exception
/*    */   {
/* 21 */     BufferedReader reader = openFile(bareItem.getInfoFile());
/* 22 */     readData(bareItem, reader);
/* 23 */     String identifier = reader.readLine();
/* 24 */     bareItem.setPrimaryComponent(readComponent(identifier, reader, bareItem));
/* 25 */     identifier = reader.readLine();
/* 26 */     bareItem.setSecondaryComponent(readComponent(identifier, reader, bareItem));
/* 27 */     closeFile(reader);
/*    */   }
/*    */   
/*    */   private static Component readComponent(String identifier, BufferedReader reader, Item item) throws Exception {
/* 31 */     if (identifier.equals("CLOTHES"))
/* 32 */       return new ClotheBlueprint(reader, item);
/* 33 */     if (identifier.equals("FOOD")) {
/* 34 */       return new FoodComponent(reader);
/*    */     }
/* 36 */     return null;
/*    */   }
/*    */   
/*    */   private static void readData(Item item, BufferedReader reader) throws Exception
/*    */   {
/* 41 */     String[] values = reader.readLine().split(";");
/* 42 */     int pointer = 0;
/* 43 */     item.setUniqueID(Integer.parseInt(item.getSuperFile().getName()));
/* 44 */     String catID = item.getSuperFile().getName().substring(0, 4);
/* 45 */     item.setMainCategory(MainCategory.getMainCategory(catID));
/* 46 */     item.setSubCategory(MainCategory.getSubCategory(catID));
/* 47 */     item.setName(values[(pointer++)]);
/* 48 */     int stackIndicator = Integer.parseInt(values[(pointer++)]);
/* 49 */     boolean stacks = false;
/* 50 */     if (stackIndicator == 1) {
/* 51 */       stacks = true;
/*    */     }
/* 53 */     item.setStacks(stacks);
/* 54 */     item.setPrice(Long.parseLong(values[(pointer++)]));
/* 55 */     item.setDescription(values[(pointer++)]);
/*    */   }
/*    */   
/*    */   private static BufferedReader openFile(File file) {
/* 59 */     BufferedReader reader = null;
/*    */     try {
/* 61 */       FileReader isr = new FileReader(file);
/* 62 */       reader = new BufferedReader(isr);
/*    */     } catch (FileNotFoundException e) {
/* 64 */       System.err.println("File not found!");
/* 65 */       e.printStackTrace();
/* 66 */       System.exit(-1);
/*    */     }
/* 68 */     return reader;
/*    */   }
/*    */   
/*    */   private static void closeFile(BufferedReader file) {
/*    */     try {
/* 73 */       file.close();
/*    */     } catch (IOException e) {
/* 75 */       e.printStackTrace();
/* 76 */       System.exit(-1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\main\ItemImporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */