/*    */ package main;
/*    */ 
/*    */ import backend.Item;
/*    */ import instances.HumanEntity;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorkSpace
/*    */ {
/*    */   private Item currentItem;
/*    */   
/*    */   public void save()
/*    */   {
/* 19 */     if (this.currentItem != null) {
/* 20 */       this.currentItem.save();
/* 21 */       System.out.println("SAVED!");
/*    */     }
/*    */   }
/*    */   
/*    */   public void createNewItem() {
/* 26 */     MainApp.character.unequip();
/*    */     try {
/* 28 */       this.currentItem = new Item(Math.abs(new Random().nextInt()), Configs.SAVES_FILE);
/*    */     } catch (Exception e) {
/* 30 */       System.err.println("Couldn't create new file!");
/* 31 */       e.printStackTrace();
/* 32 */       System.exit(-1);
/*    */     }
/*    */   }
/*    */   
/*    */   public List<File> getAvailableItems() {
/* 37 */     File[] files = Configs.SAVES_FILE.listFiles();
/* 38 */     List<File> itemFiles = new ArrayList();
/* 39 */     for (File file : files) {
/* 40 */       itemFiles.add(file);
/*    */     }
/* 42 */     return itemFiles;
/*    */   }
/*    */   
/*    */   public Item getCurrentItem() {
/* 46 */     return this.currentItem;
/*    */   }
/*    */   
/*    */   public void open(File itemFile) throws Exception {
/* 50 */     MainApp.character.unequip();
/* 51 */     this.currentItem = new Item(itemFile);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\main\WorkSpace.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */