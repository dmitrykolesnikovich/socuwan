/*    */ package main;
/*    */ 
/*    */ import backend.Item;
/*    */ import components.Component;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ public class ItemExporter
/*    */ {
/*    */   public static final String SEPARATOR = ";";
/*    */   public static final String NO_COMPONENT = "NULL";
/*    */   
/*    */   public static boolean exportItem(Item item)
/*    */   {
/* 18 */     File itemFolder = item.getSuperFile();
/* 19 */     PrintWriter writer = openSaveFile(item.getInfoFile());
/* 20 */     printData(writer, item);
/* 21 */     exportComponents(writer, item);
/* 22 */     closeFile(writer);
/* 23 */     File newSuperfile = new File(Configs.SAVES_FILE, getName(item));
/* 24 */     if (itemFolder.renameTo(newSuperfile)) {
/* 25 */       item.setSuperFile(newSuperfile);
/* 26 */       return true;
/*    */     }
/* 28 */     return false;
/*    */   }
/*    */   
/*    */   private static void printData(PrintWriter writer, Item item)
/*    */   {
/* 33 */     writer.print(item.getName());
/* 34 */     int stacks = 0;
/* 35 */     if (item.isStacks()) {
/* 36 */       stacks = 1;
/*    */     }
/* 38 */     writer.print(";");
/* 39 */     writer.print(stacks);
/* 40 */     writer.print(";");
/* 41 */     writer.print(item.getPrice());
/* 42 */     writer.print(";");
/* 43 */     writer.print(item.getDescription());
/* 44 */     writer.println();
/*    */   }
/*    */   
/*    */   private static void exportComponents(PrintWriter writer, Item item) {
/* 48 */     Component primary = item.getPrimaryComponent();
/* 49 */     if (primary != null) {
/* 50 */       primary.exportInfo(writer);
/*    */     } else {
/* 52 */       writer.println("NULL");
/*    */     }
/* 54 */     Component secondary = item.getSecondaryComponent();
/* 55 */     if (secondary != null) {
/* 56 */       secondary.exportInfo(writer);
/*    */     } else {
/* 58 */       writer.println("NULL");
/*    */     }
/*    */   }
/*    */   
/*    */   private static PrintWriter openSaveFile(File file) {
/* 63 */     FileWriter fileWriter = null;
/*    */     try {
/* 65 */       fileWriter = new FileWriter(file, false);
/*    */     } catch (Exception e) {
/* 67 */       e.printStackTrace();
/* 68 */       System.err.println("Problem opening file to write!");
/* 69 */       System.exit(-1);
/*    */     }
/* 71 */     BufferedWriter bWriter = new BufferedWriter(fileWriter);
/* 72 */     return new PrintWriter(bWriter);
/*    */   }
/*    */   
/*    */   private static String getName(Item item)
/*    */   {
/* 77 */     return item.getStringID();
/*    */   }
/*    */   
/*    */   private static void closeFile(PrintWriter file) {
/* 81 */     file.close();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\main\ItemExporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */