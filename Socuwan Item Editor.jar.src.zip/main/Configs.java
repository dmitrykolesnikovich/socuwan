/*    */ package main;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Configs
/*    */ {
/*    */   public static final String FILE_SEPARATOR = "/";
/*    */   public static final String NEW_LINE_CHAR = "\n";
/*    */   public static final String RES_LOC = "/res/";
/*    */   public static final String FONT_NAME = "Segoe UI";
/*    */   public static final String NATIVES_FOLDER = "natives";
/*    */   public static final String ITEM_INFO_FILE = "info.txt";
/*    */   public static final String ITEM_ICON_FILE = "icon.png";
/*    */   public static final String DEFAULT_ICON_LOC = "/res/defaultIcon.png";
/*    */   public static final String DEFAULT_DIFFUSE_LOC = "/res/defaultDiffuseTexture.png";
/*    */   public static final String DEFAULT_EXTRA_LOC = "/res/defaultExtraTexture.png";
/* 21 */   public static final File REPOSITORY = new File("repository");
/* 22 */   public static final File SAVES_FILE = new File(REPOSITORY, "items");
/* 23 */   public static final File MODELS_REPOS = new File(REPOSITORY, "models");
/* 24 */   public static final File ICONS_REPOS = new File(REPOSITORY, "icons");
/* 25 */   public static final File TEXTURES_REPOS = new File(REPOSITORY, "itemTextures");
/*    */   
/*    */   public static final String ITEM_DIFFUSE_NAME = "diffuse.png";
/*    */   public static final String ITEM_EXTRA_NAME = "extra.png";
/*    */   public static final String ITEM_TEXTURE_FOLDER_NAME = "texture";
/*    */   public static final String ITEM_CONFIG_FILE_NAME = "configs.txt";
/*    */   public static final String SKY_TEXTURE = "skybox/daySky";
/*    */   public static final String SHADERS_LOC = "/renderPrograms/";
/*    */   public static final String CLUTTER_VERTEX_FILE = "/renderPrograms/clutterVertex.txt";
/*    */   public static final String CLUTTER_FRAGMENT_FILE = "/renderPrograms/clutterFragment.txt";
/*    */   public static final String PARTICLE_VERTEX_FILE = "/renderPrograms/particlesVertex.txt";
/*    */   public static final String PARTICLE_FRAGMENT_FILE = "/renderPrograms/particlesFragment.txt";
/*    */   public static final String HR_STATIC_VERTEX_FILE = "/renderPrograms/simpleVertex.txt";
/*    */   public static final String HR_STATIC_FRAGMENT_FILE = "/renderPrograms/simpleFragment.txt";
/*    */   public static final String HR_TERRAIN_VERTEX_FILE = "/renderPrograms/terrainVertex.txt";
/*    */   public static final String HR_TERRAIN_FRAGMENT_FILE = "/renderPrograms/terrainFragment.txt";
/*    */   public static final String LR_STATIC_VERTEX_FILE = "/renderPrograms/simpleLowResVertex.txt";
/*    */   public static final String LR_STATIC_FRAGMENT_FILE = "/renderPrograms/simpleLowResFragment.txt";
/*    */   public static final String LR_TERRAIN_VERTEX_FILE = "/renderPrograms/terrainLowResVertex.txt";
/*    */   public static final String LR_TERRAIN_FRAGMENT_FILE = "/renderPrograms/terrainLowResFragment.txt";
/*    */   public static final String SKYBOX_VERTEX_FILE = "/renderPrograms/skyboxVertex.txt";
/*    */   public static final String SKYBOX_FRAGMENT_FILE = "/renderPrograms/skyboxFragment.txt";
/*    */   
/*    */   static
/*    */   {
/* 50 */     if (!REPOSITORY.exists()) {
/* 51 */       REPOSITORY.mkdir();
/*    */     }
/* 53 */     if (!SAVES_FILE.exists()) {
/* 54 */       SAVES_FILE.mkdir();
/*    */     }
/* 56 */     if (!MODELS_REPOS.exists()) {
/* 57 */       MODELS_REPOS.mkdir();
/*    */     }
/* 59 */     if (!ICONS_REPOS.exists()) {
/* 60 */       ICONS_REPOS.mkdir();
/*    */     }
/* 62 */     if (!TEXTURES_REPOS.exists()) {
/* 63 */       TEXTURES_REPOS.mkdir();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\main\Configs.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */