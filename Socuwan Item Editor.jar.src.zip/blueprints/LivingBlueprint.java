/*    */ package blueprints;
/*    */ 
/*    */ import animations.LivingAnimationBundle;
/*    */ import blueprintInterfaces.BoneBlueprint;
/*    */ import org.lwjgl.util.vector.Vector3f;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ 
/*    */ public class LivingBlueprint
/*    */   extends MovingEntityBlueprint
/*    */ {
/*    */   private String name;
/*    */   private LivingAnimationBundle animations;
/*    */   private float maxHealth;
/*    */   private Vector3f collisionElipsisSizes;
/*    */   private Vector3f elipsisOffset;
/*    */   private int profile;
/*    */   
/*    */   public LivingBlueprint(int id, String name, int profile, float maxHealth, BoneBlueprint[] headBones, int numberOfBones, ModelTexture texture, LivingAnimationBundle animations, Vector3f collisionElipsis, Vector3f elipsisOffset)
/*    */   {
/* 21 */     super(id, headBones, numberOfBones, texture);
/* 22 */     this.profile = profile;
/* 23 */     this.animations = animations;
/* 24 */     this.name = name;
/* 25 */     this.maxHealth = maxHealth;
/* 26 */     this.collisionElipsisSizes = collisionElipsis;
/* 27 */     this.elipsisOffset = elipsisOffset;
/*    */   }
/*    */   
/*    */   public LivingAnimationBundle getCreatureAnimationSet() {
/* 31 */     return this.animations;
/*    */   }
/*    */   
/*    */   public int getProfileTexture() {
/* 35 */     return this.profile;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 39 */     return this.name;
/*    */   }
/*    */   
/*    */   public float getMaxHealth() {
/* 43 */     return this.maxHealth;
/*    */   }
/*    */   
/*    */   public Vector3f getCollisionElipsis() {
/* 47 */     return this.collisionElipsisSizes;
/*    */   }
/*    */   
/*    */   public Vector3f getCollisionElipsisOffset() {
/* 51 */     return this.elipsisOffset;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\blueprints\LivingBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */