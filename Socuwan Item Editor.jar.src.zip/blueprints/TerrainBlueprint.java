/*    */ package blueprints;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TerrainBlueprint
/*    */ {
/*    */   private int id;
/*    */   private RawModel model;
/*    */   private float[][] terrainHeights;
/*    */   private static final String HEIGHTS_FILE_DIRECTORY = "/res/";
/*    */   private static final String HEIGHTS_FILE_EXTENSION = "HEIGHTS_TABLE.csv";
/*    */   private static final String HEIGHTS_FILE_SEPARATOR = ";";
/*    */   
/*    */   public TerrainBlueprint(int id, RawModel model)
/*    */   {
/* 23 */     this.id = id;
/* 24 */     this.model = model;
/* 25 */     loadInTerrainHeights();
/*    */   }
/*    */   
/*    */   public int getID() {
/* 29 */     return this.id;
/*    */   }
/*    */   
/*    */   public RawModel getModel() {
/* 33 */     return this.model;
/*    */   }
/*    */   
/*    */   public float[][] getTerrainHeights() {
/* 37 */     return this.terrainHeights;
/*    */   }
/*    */   
/*    */   private void loadInTerrainHeights() {
/* 41 */     InputStreamReader isr = null;
/*    */     try {
/* 43 */       isr = new InputStreamReader(getClass().getResourceAsStream("/res/largeFlatTerrainHEIGHTS_TABLE.csv"));
/*    */       
/* 45 */       BufferedReader reader = new BufferedReader(isr);
/*    */       
/* 47 */       String[] values = reader.readLine().split(";");
/* 48 */       this.terrainHeights = new float[Integer.parseInt(values[0])][Integer.parseInt(values[1])];
/*    */       
/* 50 */       for (int i = 0; i < this.terrainHeights.length; i++) {
/* 51 */         String[] line = reader.readLine().split(";");
/* 52 */         for (int j = 0; j < this.terrainHeights[i].length; j++) {
/* 53 */           this.terrainHeights[i][j] = Float.parseFloat(line[j]);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 57 */       System.err.println("No valid csv heights file found for the terrain");
/* 58 */       System.exit(0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\blueprints\TerrainBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */