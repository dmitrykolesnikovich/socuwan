/*    */ package blueprints;
/*    */ 
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ public class MovingEntityBlueprint extends AnimatedBlueprint
/*    */ {
/*    */   private boolean solid;
/*    */   
/*    */   public MovingEntityBlueprint(int id, blueprintInterfaces.BoneBlueprint[] headBones, int numberOfBones, ModelTexture texture)
/*    */   {
/* 11 */     super(id, headBones, numberOfBones, texture);
/* 12 */     this.solid = false;
/*    */   }
/*    */   
/*    */   public boolean isSolid()
/*    */   {
/* 17 */     return this.solid;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\blueprints\MovingEntityBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */