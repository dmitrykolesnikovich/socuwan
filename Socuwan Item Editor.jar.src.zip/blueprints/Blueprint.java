/*    */ package blueprints;
/*    */ 
/*    */ import blueprintInterfaces.BlueprintInterface;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ public abstract class Blueprint implements BlueprintInterface
/*    */ {
/*    */   private ModelTexture texture;
/*  9 */   private float furthestPoint = 10.0F;
/* 10 */   private float visibleRange = 1000.0F;
/*    */   
/*    */   private int id;
/* 13 */   private boolean visibleUnderWater = false;
/* 14 */   private boolean reflection = true;
/* 15 */   private boolean limitedReflection = false;
/* 16 */   private float reflectionLimit = 0.0F;
/*    */   
/*    */   public Blueprint(int id, ModelTexture texture) {
/* 19 */     this.id = id;
/* 20 */     this.texture = texture;
/*    */   }
/*    */   
/*    */   public void turnOffReflection() {
/* 24 */     this.reflection = false;
/*    */   }
/*    */   
/*    */   public void setLimitedReflection(float distance) {
/* 28 */     this.reflection = true;
/* 29 */     this.limitedReflection = true;
/* 30 */     this.reflectionLimit = distance;
/*    */   }
/*    */   
/*    */   public boolean hasLimitedReflection() {
/* 34 */     return this.limitedReflection;
/*    */   }
/*    */   
/*    */   public float getReflectionLimit() {
/* 38 */     return this.reflectionLimit;
/*    */   }
/*    */   
/*    */   public void setVisibleUnderWater() {
/* 42 */     this.visibleUnderWater = true;
/*    */   }
/*    */   
/*    */   public boolean isVisibleUnderWater() {
/* 46 */     return this.visibleUnderWater;
/*    */   }
/*    */   
/*    */   public boolean hasReflection() {
/* 50 */     return this.reflection;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 54 */     return this.id;
/*    */   }
/*    */   
/*    */   public ModelTexture getTexture() {
/* 58 */     return this.texture;
/*    */   }
/*    */   
/*    */   public void limitVisibility(float distance) {
/* 62 */     this.visibleRange = distance;
/*    */   }
/*    */   
/*    */   public float getVisibleRange() {
/* 66 */     return this.visibleRange;
/*    */   }
/*    */   
/*    */   public void setFurthestPoint(float furthestPoint) {
/* 70 */     this.furthestPoint = furthestPoint;
/*    */   }
/*    */   
/*    */   public float getFurthestPoint() {
/* 74 */     return this.furthestPoint;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\blueprints\Blueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */