/*    */ package blueprints;
/*    */ 
/*    */ import blueprintInterfaces.AnimatedBlueprintInterface;
/*    */ import blueprintInterfaces.BoneBlueprint;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ public class AnimatedBlueprint extends Blueprint implements AnimatedBlueprintInterface
/*    */ {
/*    */   private int numberOfBones;
/*    */   private BoneBlueprint[] headBones;
/*    */   
/*    */   public AnimatedBlueprint(int id, BoneBlueprint[] headBones, int numberOfBones, ModelTexture texture)
/*    */   {
/* 14 */     super(id, texture);
/* 15 */     this.headBones = headBones;
/* 16 */     this.numberOfBones = numberOfBones;
/*    */   }
/*    */   
/*    */   public BoneBlueprint[] getHeadBones() {
/* 20 */     return this.headBones;
/*    */   }
/*    */   
/*    */   public int getNumberOfBones() {
/* 24 */     return this.numberOfBones;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\blueprints\AnimatedBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */