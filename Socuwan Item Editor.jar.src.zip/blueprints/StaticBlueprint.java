/*    */ package blueprints;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import blueprintInterfaces.StaticBlueprintInterface;
/*    */ import epicRenderEngine.Loader;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ public class StaticBlueprint
/*    */   extends Blueprint implements StaticBlueprintInterface
/*    */ {
/*    */   private RawModel model;
/*    */   private boolean solid;
/* 13 */   private boolean fadeOut = false;
/*    */   private int instanceDataVBO;
/*    */   
/*    */   public StaticBlueprint(int id, RawModel model, ModelTexture texture) {
/* 17 */     super(id, texture);
/* 18 */     this.model = model;
/* 19 */     if (model.isSolid()) {
/* 20 */       this.solid = true;
/*    */     } else {
/* 22 */       this.solid = false;
/*    */     }
/*    */   }
/*    */   
/*    */   public RawModel getModel() {
/* 27 */     return this.model;
/*    */   }
/*    */   
/*    */   public boolean fadesOut()
/*    */   {
/* 32 */     return this.fadeOut;
/*    */   }
/*    */   
/*    */   public void setToFadeOut()
/*    */   {
/* 37 */     this.fadeOut = true;
/* 38 */     this.instanceDataVBO = Loader.createInterleavedInstanceVBO(this.model.getVaoID(), 3, 200, new int[] { 4, 4, 4, 3, 1 });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isSolid()
/*    */   {
/* 45 */     return this.solid;
/*    */   }
/*    */   
/*    */   public int getInstanceDataVBO()
/*    */   {
/* 50 */     return this.instanceDataVBO;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\blueprints\StaticBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */