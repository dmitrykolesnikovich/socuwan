/*    */ package blueprints;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ public class LightBlueprint extends StaticBlueprint
/*    */ {
/*    */   private float lightPosX;
/*    */   private float lightPosY;
/*    */   private float lightPosZ;
/*    */   
/*    */   public LightBlueprint(int id, RawModel model, ModelTexture texture, float lightX, float lightY, float lightZ)
/*    */   {
/* 14 */     super(id, model, texture);
/* 15 */     this.lightPosX = lightX;
/* 16 */     this.lightPosY = lightY;
/* 17 */     this.lightPosZ = lightZ;
/*    */   }
/*    */   
/*    */   public float getLightOffsetX() {
/* 21 */     return this.lightPosX;
/*    */   }
/*    */   
/*    */   public float getLightOffsetY() {
/* 25 */     return this.lightPosY;
/*    */   }
/*    */   
/*    */   public float getLightOffsetZ() {
/* 29 */     return this.lightPosZ;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\blueprints\LightBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */