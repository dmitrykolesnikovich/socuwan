/*    */ package categories;
/*    */ 
/*    */ import backend.Item;
/*    */ import components.Component;
/*    */ 
/*    */ public enum OreSubCategory
/*    */   implements SubCategoryInterface
/*    */ {
/*  9 */   GEMS("Gems", "15");
/*    */   
/*    */   private String id;
/*    */   private String name;
/*    */   
/*    */   private OreSubCategory(String name, String id) {
/* 15 */     this.name = name;
/* 16 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 21 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 26 */     return this.id;
/*    */   }
/*    */   
/*    */   public Component generateSecondaryComponent(Item item)
/*    */   {
/* 31 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\categories\OreSubCategory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */