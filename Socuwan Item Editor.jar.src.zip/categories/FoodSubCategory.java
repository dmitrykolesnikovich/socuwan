/*    */ package categories;
/*    */ 
/*    */ import backend.Item;
/*    */ import components.Component;
/*    */ 
/*    */ public enum FoodSubCategory
/*    */   implements SubCategoryInterface
/*    */ {
/*  9 */   MEAT("Meat", "18"), 
/* 10 */   FISH("Fish", "19"), 
/* 11 */   VEGETABLE("Vegetable", "20"), 
/* 12 */   FRUIT("Fruit", "21"), 
/* 13 */   PASTRY("Pastry", "22"), 
/* 14 */   PIZZA("Pizza", "23"), 
/* 15 */   CONFECTIONARY("Confectionary", "24");
/*    */   
/*    */   private String id;
/*    */   private String name;
/*    */   
/*    */   private FoodSubCategory(String name, String id) {
/* 21 */     this.name = name;
/* 22 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 27 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 32 */     return this.id;
/*    */   }
/*    */   
/*    */   public Component generateSecondaryComponent(Item item)
/*    */   {
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\categories\FoodSubCategory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */