/*    */ package categories;
/*    */ 
/*    */ import backend.Item;
/*    */ import components.Component;
/*    */ 
/*    */ public enum ClothesSubCategory
/*    */   implements SubCategoryInterface
/*    */ {
/*  9 */   HEADWEAR("Headwear", "10"), 
/* 10 */   BODYWEAR("Bodywear", "11"), 
/* 11 */   LEGWEAR("Legwear", "12"), 
/* 12 */   BOOTS("Boots", "13"), 
/* 13 */   GLOVES("Gloves", "14"), 
/* 14 */   WEAPON("Weapon", "17"), 
/* 15 */   JEWELLERY("Jewellery", "18"), 
/* 16 */   NECKWEAR("Neckwear", "19"), 
/* 17 */   CAPE("Cape", "20"), 
/* 18 */   SHIELD("Shield", "21");
/*    */   
/*    */   private String id;
/*    */   private String name;
/*    */   
/*    */   private ClothesSubCategory(String name, String id)
/*    */   {
/* 25 */     this.name = name;
/* 26 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 31 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 36 */     return this.id;
/*    */   }
/*    */   
/*    */   public Component generateSecondaryComponent(Item item)
/*    */   {
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\categories\ClothesSubCategory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */