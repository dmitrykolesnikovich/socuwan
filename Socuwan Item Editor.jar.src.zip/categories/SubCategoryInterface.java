package categories;

import backend.Item;
import components.Component;

public abstract interface SubCategoryInterface
{
  public abstract String toString();
  
  public abstract String getId();
  
  public abstract Component generateSecondaryComponent(Item paramItem);
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\categories\SubCategoryInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */