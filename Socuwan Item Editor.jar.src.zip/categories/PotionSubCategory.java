/*    */ package categories;
/*    */ 
/*    */ import backend.Item;
/*    */ import components.Component;
/*    */ 
/*    */ public enum PotionSubCategory
/*    */   implements SubCategoryInterface
/*    */ {
/*  9 */   HEALTH_POTION("Health potion", "10");
/*    */   
/*    */   private String id;
/*    */   private String name;
/*    */   
/*    */   private PotionSubCategory(String name, String id)
/*    */   {
/* 16 */     this.name = name;
/* 17 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 22 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 27 */     return this.id;
/*    */   }
/*    */   
/*    */   public Component generateSecondaryComponent(Item item)
/*    */   {
/* 32 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\categories\PotionSubCategory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */