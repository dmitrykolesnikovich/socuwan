/*    */ package categories;
/*    */ 
/*    */ import backend.Item;
/*    */ import clothesComponent.ClothesComponentFabricator;
/*    */ import components.Component;
/*    */ import components.ComponentFabricator;
/*    */ import components.FoodComponentFabricator;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MainCategory
/*    */ {
/* 14 */   CLOTHES("Clothes", "10", new ClothesComponentFabricator(), ClothesSubCategory.values()), 
/* 15 */   ORES("Ores", "11", null, OreSubCategory.values()), 
/* 16 */   POTIONS("Potions", "12", null, PotionSubCategory.values()), 
/* 17 */   MISCLEANEOUS("Miscleaneous", "13", null, MiscleaneousSubCategory.values()), 
/* 18 */   FOOD("Food", "14", new FoodComponentFabricator(), FoodSubCategory.values());
/*    */   
/*    */   private String name;
/*    */   private String id;
/*    */   private SubCategoryInterface[] subCategories;
/*    */   private ComponentFabricator componentCreator;
/*    */   
/*    */   private MainCategory(String name, String id, ComponentFabricator fabricator, SubCategoryInterface[] subCategories) {
/* 26 */     this.name = name;
/* 27 */     this.id = id;
/* 28 */     this.componentCreator = fabricator;
/* 29 */     this.subCategories = subCategories;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 33 */     return this.name;
/*    */   }
/*    */   
/*    */   public Component generatePrimaryComponent(Item item) {
/* 37 */     if (this.componentCreator != null) {
/* 38 */       return this.componentCreator.createNewComponent(item);
/*    */     }
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 45 */     return this.id;
/*    */   }
/*    */   
/*    */   public SubCategoryInterface[] getSubCategories() {
/* 49 */     return this.subCategories;
/*    */   }
/*    */   
/*    */   public static MainCategory getMainCategory(String catID) {
/* 53 */     String mainID = catID.substring(0, 2);
/* 54 */     for (MainCategory mainCat : values()) {
/* 55 */       if (mainCat.id.equals(mainID)) {
/* 56 */         return mainCat;
/*    */       }
/*    */     }
/* 59 */     System.err.println("NO MAIN CATEGORY FOUND FOR THAT ID: " + catID);
/* 60 */     System.exit(-1);
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   public static SubCategoryInterface getSubCategory(String catID) {
/* 65 */     MainCategory mainCat = getMainCategory(catID);
/* 66 */     String subID = catID.substring(2);
/* 67 */     for (SubCategoryInterface subCat : mainCat.subCategories) {
/* 68 */       if (subCat.getId().equals(subID)) {
/* 69 */         return subCat;
/*    */       }
/*    */     }
/* 72 */     System.err.println("NO SUB CATEGORY FOUND FOR THAT ID: " + catID);
/* 73 */     System.exit(-1);
/* 74 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\categories\MainCategory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */