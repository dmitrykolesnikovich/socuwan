/*    */ package clothes;
/*    */ 
/*    */ import accessories.ClothesBlueprintInterface;
/*    */ import accessories.ClothesInstanceInterface;
/*    */ import accessories.ClothesSection;
/*    */ import clothesComponent.ClotheBlueprint;
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Equipper
/*    */ {
/*    */   protected static final int NUMBER_OF_SLOTS = 10;
/*    */   private Clothe equippedClothe;
/*    */   private Map<Integer, Map<ClothesInstanceInterface, ClothesSection>> clothesDistribution;
/*    */   
/*    */   public Equipper(int numberOfBodySections)
/*    */   {
/* 19 */     setUpClothesDistribution(numberOfBodySections);
/*    */   }
/*    */   
/*    */   public void update() {
/* 23 */     if (this.equippedClothe == null) {
/* 24 */       System.err.println("Why update equipper when no clothes worn!");
/* 25 */       return;
/*    */     }
/* 27 */     for (int i = 0; i < this.clothesDistribution.size(); i++) {
/* 28 */       Map<ClothesInstanceInterface, ClothesSection> currentPartClothing = (Map)this.clothesDistribution.get(Integer.valueOf(i));
/*    */       
/* 30 */       currentPartClothing.clear();
/*    */     }
/* 32 */     addClotheToDistribution(this.equippedClothe);
/*    */   }
/*    */   
/*    */   public Clothe unequipClotheFromSlot() {
/* 36 */     Clothe unequip = this.equippedClothe;
/* 37 */     this.equippedClothe = null;
/* 38 */     if (unequip == null) {
/* 39 */       return null;
/*    */     }
/* 41 */     removeClotheFromDistribution(unequip);
/* 42 */     return unequip;
/*    */   }
/*    */   
/*    */   public Clothe getClotheWorn() {
/* 46 */     return this.equippedClothe;
/*    */   }
/*    */   
/*    */   public Map<ClothesInstanceInterface, ClothesSection> getClothesOnPart(int partID) {
/* 50 */     return (Map)this.clothesDistribution.get(Integer.valueOf(partID));
/*    */   }
/*    */   
/*    */   public Clothe equipClothes(Clothe clothe) {
/* 54 */     Clothe unequipped = unequipClotheFromSlot();
/* 55 */     addClotheToDistribution(clothe);
/* 56 */     this.equippedClothe = clothe;
/* 57 */     return unequipped;
/*    */   }
/*    */   
/*    */   private void removeClotheFromDistribution(Clothe clothe) {
/* 61 */     for (ClothesSection section : clothe.getItemBlueprint().getSections()) {
/* 62 */       int partID = section.getPartID();
/* 63 */       Map<ClothesInstanceInterface, ClothesSection> currentPartClothing = (Map)this.clothesDistribution.get(Integer.valueOf(partID));
/*    */       
/* 65 */       currentPartClothing.remove(clothe);
/*    */     }
/*    */   }
/*    */   
/*    */   private void addClotheToDistribution(ClothesInstanceInterface clothe) {
/* 70 */     for (ClothesSection section : clothe.getItemBlueprint().getSections()) {
/* 71 */       int partID = section.getPartID();
/* 72 */       Map<ClothesInstanceInterface, ClothesSection> currentPartClothing = (Map)this.clothesDistribution.get(Integer.valueOf(partID));
/*    */       
/* 74 */       currentPartClothing.put(clothe, section);
/*    */     }
/*    */   }
/*    */   
/*    */   private void setUpClothesDistribution(int numberOfBodySections) {
/* 79 */     this.clothesDistribution = new HashMap();
/* 80 */     for (int i = 0; i < numberOfBodySections; i++) {
/* 81 */       Map<ClothesInstanceInterface, ClothesSection> newMap = new HashMap();
/* 82 */       this.clothesDistribution.put(Integer.valueOf(i), newMap);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothes\Equipper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */