/*    */ package clothes;
/*    */ 
/*    */ import accessories.ClothesInstanceInterface;
/*    */ import categories.ClothesSubCategory;
/*    */ import clothesComponent.ClotheBlueprint;
/*    */ import clothesComponent.CombatType;
/*    */ import epicRenderEngine.RenderEngine;
/*    */ import materials.Material;
/*    */ import materials.Tier;
/*    */ import toolbox.Colour;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Clothe
/*    */   implements ClothesInstanceInterface
/*    */ {
/*    */   private static final float PER_TIER_TIME = 2.0F;
/*    */   private Colour material1;
/*    */   private Colour material2;
/*    */   private Tier tier;
/* 21 */   private Tier tier2 = Tier.TIER_1;
/*    */   
/*    */   private ClotheBlueprint blueprint;
/* 24 */   private float countDown = 2.0F;
/*    */   
/*    */   public Clothe(ClotheBlueprint clothe) {
/* 27 */     this.blueprint = clothe;
/* 28 */     this.tier = Tier.TIER_1;
/* 29 */     updateMaterialColours();
/*    */   }
/*    */   
/*    */   public void update() {
/* 33 */     if (this.blueprint.getCombatType() != CombatType.NON_COMBAT) {
/* 34 */       this.countDown -= RenderEngine.getDeltaInSeconds();
/* 35 */       if (this.countDown <= 0.0F) {
/* 36 */         this.countDown = 2.0F;
/* 37 */         int tierNumber = this.tier.ordinal();
/* 38 */         tierNumber++;
/* 39 */         if (tierNumber > 10) {
/* 40 */           tierNumber = 1;
/*    */         }
/* 42 */         this.tier = Tier.values()[tierNumber];
/* 43 */         this.tier2 = Tier.values()[(new java.util.Random().nextInt(9) + 1)];
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public ClotheBlueprint getItemBlueprint() {
/* 49 */     return this.blueprint;
/*    */   }
/*    */   
/*    */   public Colour getMaterial1Colour() {
/* 53 */     updateMaterialColours();
/* 54 */     return this.material1;
/*    */   }
/*    */   
/*    */   public Colour getMaterial2Colour() {
/* 58 */     updateMaterialColours();
/* 59 */     return this.material2;
/*    */   }
/*    */   
/*    */   private void setMaterial1Colour(Colour colour) {
/* 63 */     this.material1 = colour;
/*    */   }
/*    */   
/*    */   private void setBothMaterialColours(Colour colour1, Colour colour2) {
/* 67 */     this.material1 = colour1;
/* 68 */     this.material2 = colour2;
/*    */   }
/*    */   
/*    */   private void updateMaterialColours() {
/* 72 */     if (this.blueprint.getCombatType() != CombatType.NON_COMBAT) {
/* 73 */       if (this.blueprint.getType() == ClothesSubCategory.WEAPON) {
/* 74 */         Material primaryMat = this.blueprint.getCombatType().getPrimaryWeaponMaterial(this.tier);
/* 75 */         Material secondaryMat = this.blueprint.getCombatType().getSecondaryWeaponMaterial(this.tier2);
/* 76 */         setBothMaterialColours(primaryMat.getColour(), secondaryMat.getColour());
/*    */       } else {
/* 78 */         Material material = this.blueprint.getCombatType().getArmourMaterialSet(this.tier);
/* 79 */         setMaterial1Colour(material.getColour());
/* 80 */         this.material2 = null;
/*    */       }
/*    */     } else {
/* 83 */       this.material1 = null;
/* 84 */       this.material2 = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothes\Clothe.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */