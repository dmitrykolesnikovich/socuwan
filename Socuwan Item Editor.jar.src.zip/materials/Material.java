package materials;

import toolbox.Colour;

public abstract interface Material
{
  public abstract Tier getTier();
  
  public abstract String getName();
  
  public abstract Colour getColour();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\materials\Material.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */