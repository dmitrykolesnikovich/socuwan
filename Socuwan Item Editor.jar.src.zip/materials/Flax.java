/*    */ package materials;
/*    */ 
/*    */ import toolbox.Colour;
/*    */ 
/*    */ public enum Flax implements Material
/*    */ {
/*  7 */   WEED("Weed", Tier.TIER_1, new Colour(0.686F, 0.725F, 0.416F)), 
/*  8 */   FENNEL("Fennel", Tier.TIER_2, new Colour(0.824F, 0.745F, 0.192F)), 
/*  9 */   LANGVINE("Langvine", Tier.TIER_3, new Colour(0.282F, 0.733F, 0.349F)), 
/* 10 */   IVY("Ivy", Tier.TIER_4, new Colour(0.09F, 0.42F, 0.047F)), 
/* 11 */   FLUXROOT("Fluxroot", Tier.TIER_5, new Colour(0.882F, 0.4F, 0.745F)), 
/* 12 */   FLAX("Flax", Tier.TIER_6, new Colour(0.643F, 0.4F, 0.843F)), 
/* 13 */   ROSEVINE("Rosevine", Tier.TIER_7, new Colour(0.937F, 0.239F, 0.239F)), 
/* 14 */   BLOODTHORN("Bloodthorn", Tier.TIER_8, new Colour(0.4F, 0.0F, 0.008F)), 
/* 15 */   NIGHTSHADE("Nightshade", Tier.TIER_9, new Colour(0.0F, 0.012F, 0.141F)), 
/* 16 */   SPIRITLEAF("Spiritleaf", Tier.TIER_10, new Colour(1.0F, 1.0F, 1.0F));
/*    */   
/*    */   private String name;
/*    */   private Tier tier;
/*    */   private Colour colour;
/*    */   
/*    */   private Flax(String name, Tier tier, Colour colour)
/*    */   {
/* 24 */     this.tier = tier;
/* 25 */     this.name = name;
/* 26 */     this.colour = colour;
/*    */   }
/*    */   
/*    */   public Tier getTier()
/*    */   {
/* 31 */     return this.tier;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 36 */     return this.name;
/*    */   }
/*    */   
/*    */   public Colour getColour() {
/* 40 */     return this.colour;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\materials\Flax.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */