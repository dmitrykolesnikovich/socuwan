/*    */ package materials;
/*    */ 
/*    */ 
/*    */ public enum MaterialSet
/*    */ {
/*  6 */   GEMS(Gem.values()), 
/*  7 */   WOODS(Wood.values()), 
/*  8 */   METALS(Metal.values()), 
/*  9 */   FLAXES(Flax.values());
/*    */   
/*    */   private Material[] materialSet;
/*    */   
/*    */   private MaterialSet(Material[] materialSet) {
/* 14 */     this.materialSet = materialSet;
/*    */   }
/*    */   
/*    */   public Material getMaterial(Tier tier) {
/* 18 */     if (tier == Tier.NO_TIER) {
/* 19 */       return null;
/*    */     }
/* 21 */     int matIndex = tier.getTierNumber() - 1;
/* 22 */     return this.materialSet[matIndex];
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\materials\MaterialSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */