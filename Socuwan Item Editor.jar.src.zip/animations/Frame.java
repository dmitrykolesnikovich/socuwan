/*    */ package animations;
/*    */ 
/*    */ 
/*    */ public class Frame
/*    */ {
/*    */   private int time;
/*    */   private float x;
/*    */   private float y;
/*    */   private float z;
/*    */   private double rotW;
/*    */   private double rotX;
/*    */   private double rotY;
/*    */   private double rotZ;
/*    */   private float scale;
/*    */   
/*    */   public Frame(int time, float x, float y, float z, double rotW, double rotX, double rotY, double rotZ, float scale)
/*    */   {
/* 18 */     this.time = time;
/* 19 */     this.x = x;
/* 20 */     this.y = y;
/* 21 */     this.z = z;
/* 22 */     this.rotW = rotW;
/* 23 */     this.rotX = rotX;
/* 24 */     this.rotY = rotY;
/* 25 */     this.rotZ = rotZ;
/* 26 */     this.scale = scale;
/*    */   }
/*    */   
/*    */   public int getTime() {
/* 30 */     return this.time;
/*    */   }
/*    */   
/*    */   public float getX() {
/* 34 */     return this.x;
/*    */   }
/*    */   
/* 37 */   public float getY() { return this.y; }
/*    */   
/*    */   public float getZ() {
/* 40 */     return this.z;
/*    */   }
/*    */   
/*    */   public double getRotW() {
/* 44 */     return this.rotW;
/*    */   }
/*    */   
/*    */   public double getRotX() {
/* 48 */     return this.rotX;
/*    */   }
/*    */   
/*    */   public double getRotY() {
/* 52 */     return this.rotY;
/*    */   }
/*    */   
/*    */   public double getRotZ() {
/* 56 */     return this.rotZ;
/*    */   }
/*    */   
/*    */   public float getScale() {
/* 60 */     return this.scale;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\animations\Frame.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */