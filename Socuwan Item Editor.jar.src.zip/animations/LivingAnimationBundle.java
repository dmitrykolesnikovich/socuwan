/*    */ package animations;
/*    */ 
/*    */ public class LivingAnimationBundle
/*    */ {
/*    */   private Animation standing;
/*    */   private Animation running;
/*    */   private Animation jumping;
/*    */   private Animation falling;
/*    */   
/*    */   public LivingAnimationBundle(Animation standing, Animation running, Animation jumping, Animation falling, Animation sprinting, Animation turning, Animation backwards, Animation die, Animation collapse, Animation... additionals) {
/* 11 */     this.standing = standing;
/* 12 */     this.running = running;
/* 13 */     this.jumping = jumping;
/* 14 */     this.falling = falling;
/* 15 */     this.sprinting = sprinting;
/* 16 */     this.turning = turning;
/* 17 */     this.backwards = backwards;
/* 18 */     this.die = die;
/* 19 */     this.collapse = collapse; }
/*    */   
/*    */   private Animation sprinting;
/*    */   
/* 23 */   public Animation getStanding() { return this.standing; }
/*    */   
/*    */   private Animation turning;
/*    */   
/* 27 */   public Animation getRunning() { return this.running; }
/*    */   
/*    */   private Animation backwards;
/*    */   
/* 31 */   public Animation getJumping() { return this.jumping; }
/*    */   
/*    */   private Animation die;
/*    */   private Animation collapse;
/* 35 */   public Animation getFalling() { return this.falling; }
/*    */   
/*    */   public Animation getSprinting()
/*    */   {
/* 39 */     return this.sprinting;
/*    */   }
/*    */   
/*    */   public Animation getTurning() {
/* 43 */     return this.turning;
/*    */   }
/*    */   
/*    */   public Animation getBackwards() {
/* 47 */     return this.backwards;
/*    */   }
/*    */   
/*    */   public Animation getDie() {
/* 51 */     return this.die;
/*    */   }
/*    */   
/*    */   public Animation getCollapse() {
/* 55 */     return this.collapse;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\animations\LivingAnimationBundle.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */