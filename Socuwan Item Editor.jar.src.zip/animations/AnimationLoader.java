/*     */ package animations;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimationLoader
/*     */ {
/*     */   private static final int IS_TRUE = 1;
/*     */   
/*     */   public static Animation loadAnimationFile(String fileName)
/*     */   {
/*  16 */     BufferedReader animReader = null;
/*     */     try {
/*  18 */       InputStream location = Class.class.getResourceAsStream("/res/" + fileName + ".txt");
/*  19 */       InputStreamReader isr = new InputStreamReader(location);
/*  20 */       animReader = new BufferedReader(isr);
/*     */     } catch (Exception e) {
/*  22 */       System.err.println("Failed to load animation " + fileName);
/*  23 */       System.exit(-1);
/*     */     }
/*  25 */     Animation animation = null;
/*  26 */     AnimationSection[] sections = null;
/*     */     try {
/*  28 */       animation = initializeAnimation(animReader);
/*  29 */       int numberOfParts = Integer.parseInt(animReader.readLine());
/*  30 */       sections = new AnimationSection[numberOfParts];
/*     */     } catch (Exception e) {
/*  32 */       System.err.println("Failed to initialize animation " + fileName);
/*  33 */       e.printStackTrace();
/*  34 */       System.exit(-1);
/*     */     }
/*     */     try
/*     */     {
/*  38 */       for (int i = 0; i < sections.length; i++) {
/*  39 */         sections[i] = createSection(animReader, animation);
/*     */       }
/*     */     } catch (Exception e) {
/*  42 */       System.err.println("Error reading frames data for animation " + fileName);
/*  43 */       e.printStackTrace();
/*  44 */       System.exit(-1);
/*     */     }
/*  46 */     animation.setAnimationSections(sections);
/*  47 */     return animation;
/*     */   }
/*     */   
/*     */   private static Animation initializeAnimation(BufferedReader reader) throws Exception
/*     */   {
/*  52 */     int pointer = 0;
/*  53 */     String[] line = reader.readLine().split(";");
/*  54 */     int id = Integer.parseInt(line[(pointer++)]);
/*  55 */     int length = Integer.parseInt(line[(pointer++)]);
/*  56 */     int looperFlag = Integer.parseInt(line[(pointer++)]);
/*  57 */     boolean isLooping = false;
/*  58 */     if (looperFlag == 1) {
/*  59 */       isLooping = true;
/*     */     }
/*  61 */     float maxPos = Float.parseFloat(line[(pointer++)]);
/*  62 */     float maxRot = Float.parseFloat(line[(pointer++)]);
/*  63 */     float maxScale = Float.parseFloat(line[(pointer++)]);
/*     */     
/*  65 */     return new Animation(id, length, isLooping, maxPos, maxRot, maxScale);
/*     */   }
/*     */   
/*     */ 
/*     */   private static AnimationSection createSection(BufferedReader reader, Animation animation)
/*     */     throws Exception
/*     */   {
/*  72 */     String[] line = reader.readLine().split(";");
/*  73 */     int pointer = 0;
/*  74 */     int partID = Integer.parseInt(line[(pointer++)]);
/*  75 */     int numberOfFrames = Integer.parseInt(line[(pointer++)]);
/*  76 */     int hasPosFlag = Integer.parseInt(line[(pointer++)]);
/*  77 */     boolean hasPos = false;
/*  78 */     if (hasPosFlag == 1) {
/*  79 */       hasPos = true;
/*     */     }
/*  81 */     int hasRotFlag = Integer.parseInt(line[(pointer++)]);
/*  82 */     boolean hasRot = false;
/*  83 */     if (hasRotFlag == 1) {
/*  84 */       hasRot = true;
/*     */     }
/*  86 */     int hasScaleFlag = Integer.parseInt(line[(pointer++)]);
/*  87 */     boolean hasScale = false;
/*  88 */     if (hasScaleFlag == 1) {
/*  89 */       hasScale = true;
/*     */     }
/*  91 */     AnimationSection section = new AnimationSection(partID, animation, hasPos, hasRot, hasScale);
/*  92 */     Frame[] frames = new Frame[numberOfFrames];
/*     */     
/*  94 */     for (int i = 0; i < frames.length; i++) {
/*  95 */       frames[i] = createFrame(reader, hasPos, hasRot, hasScale);
/*     */     }
/*  97 */     section.setFrames(frames);
/*  98 */     return section;
/*     */   }
/*     */   
/*     */ 
/*     */   private static Frame createFrame(BufferedReader reader, boolean hasPosChange, boolean hasRotChange, boolean hasScaleChange)
/*     */     throws Exception
/*     */   {
/* 105 */     String[] line = reader.readLine().split(";");
/* 106 */     int pointer = 0;
/* 107 */     int time = Integer.parseInt(line[(pointer++)]);
/* 108 */     float x = 0.0F;
/* 109 */     float y = 0.0F;
/* 110 */     float z = 0.0F;
/* 111 */     double rotW = 0.0D;
/* 112 */     double rotX = 0.0D;
/* 113 */     double rotY = 0.0D;
/* 114 */     double rotZ = 0.0D;
/* 115 */     float scale = 1.0F;
/* 116 */     if (hasPosChange) {
/* 117 */       x = Float.parseFloat(line[(pointer++)]);
/* 118 */       y = Float.parseFloat(line[(pointer++)]);
/* 119 */       z = Float.parseFloat(line[(pointer++)]);
/*     */     }
/* 121 */     if (hasRotChange) {
/* 122 */       rotW = Double.parseDouble(line[(pointer++)]);
/* 123 */       rotX = Double.parseDouble(line[(pointer++)]);
/* 124 */       rotY = Double.parseDouble(line[(pointer++)]);
/* 125 */       rotZ = Double.parseDouble(line[(pointer++)]);
/*     */     }
/* 127 */     if (hasScaleChange) {
/* 128 */       scale = Float.parseFloat(line[(pointer++)]);
/*     */     }
/* 130 */     return new Frame(time, x, y, z, rotW, rotX, rotY, rotZ, scale);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\animations\AnimationLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */