package animations;

public abstract interface AnimatablePart
{
  public abstract void setPosition(float paramFloat1, float paramFloat2, float paramFloat3);
  
  public abstract void setRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public abstract void setScale(float paramFloat);
  
  public abstract float getX();
  
  public abstract float getY();
  
  public abstract float getZ();
  
  public abstract double getRotW();
  
  public abstract double getRotX();
  
  public abstract double getRotY();
  
  public abstract double getRotZ();
  
  public abstract float getScale();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\animations\AnimatablePart.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */