package accessories;

import texture.ModelTexture;

public abstract interface ClothesBlueprintInterface
{
  public abstract boolean needsCaching();
  
  public abstract ClothesSection[] getSections();
  
  public abstract ModelTexture getTextureAtlas();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\accessories\ClothesBlueprintInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */