/*     */ package accessories;
/*     */ 
/*     */ import blueprintInterfaces.RawModel;
/*     */ import epicRenderEngine.Loader;
/*     */ import instances.HumanEntity;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import main.MainApp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClothesSection
/*     */ {
/*     */   private static final String MODEL_NAME = "model";
/*     */   private static final String NAME_SEPARATOR = "_";
/*     */   private static final String MODEL_FILE_TYPE = ".csv";
/*     */   private File itemFile;
/*  24 */   private boolean hasModel = false;
/*     */   
/*  26 */   private int partID = 0;
/*     */   private RawModel model;
/*  28 */   private boolean fullyCoversSkin = false;
/*  29 */   private boolean coversAccessory = false;
/*     */   
/*     */   public ClothesSection(int partID, boolean fullyCoversSkin, boolean coversAccessory, File itemFile)
/*     */   {
/*  33 */     this.partID = partID;
/*  34 */     this.itemFile = itemFile;
/*  35 */     this.hasModel = true;
/*  36 */     this.fullyCoversSkin = fullyCoversSkin;
/*  37 */     this.coversAccessory = coversAccessory;
/*  38 */     Loader.requestClothesSectionLoading(this);
/*     */   }
/*     */   
/*     */   public ClothesSection(File itemFile) {
/*  42 */     this.itemFile = itemFile;
/*     */   }
/*     */   
/*     */   public void setItemFile(File itemFile) {
/*  46 */     this.itemFile = itemFile;
/*     */   }
/*     */   
/*     */   public void setNewModelFile(File modelFile) {
/*  50 */     this.hasModel = true;
/*     */     try {
/*  52 */       File file = new File(this.itemFile, getFileName());
/*  53 */       Files.copy(modelFile.toPath(), file.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  57 */       e.printStackTrace();
/*     */     }
/*  59 */     Loader.requestClothesSectionLoading(this);
/*     */   }
/*     */   
/*     */   public File getModelFile() {
/*  63 */     return new File(this.itemFile, getFileName());
/*     */   }
/*     */   
/*     */   public void destroy() {
/*  67 */     for (File file : this.itemFile.listFiles()) {
/*  68 */       if (file.getName().contains(getFileName())) {
/*     */         try {
/*  70 */           Files.deleteIfExists(file.toPath());
/*     */         } catch (IOException e) {
/*  72 */           e.printStackTrace();
/*     */         }
/*  74 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasModel() {
/*  80 */     return this.hasModel;
/*     */   }
/*     */   
/*     */   public void setPartID(int partID) {
/*  84 */     if (this.hasModel) {
/*  85 */       File original = getModelFile();
/*  86 */       this.partID = partID;
/*  87 */       File newName = getModelFile();
/*  88 */       original.renameTo(newName);
/*     */     } else {
/*  90 */       this.partID = partID;
/*     */     }
/*  92 */     MainApp.character.updateClothes();
/*     */   }
/*     */   
/*     */   public void setModel(RawModel model) {
/*  96 */     this.model = model;
/*     */   }
/*     */   
/*     */   public void setFullyCoversSkin(boolean fullyCoversSkin) {
/* 100 */     this.fullyCoversSkin = fullyCoversSkin;
/*     */   }
/*     */   
/*     */   public void setCoversAccessory(boolean coversAccessory) {
/* 104 */     this.coversAccessory = coversAccessory;
/*     */   }
/*     */   
/*     */   public int getPartID() {
/* 108 */     return this.partID;
/*     */   }
/*     */   
/*     */   public RawModel getModel() {
/* 112 */     return this.model;
/*     */   }
/*     */   
/*     */   public boolean isFullyCoveringSkin() {
/* 116 */     return this.fullyCoversSkin;
/*     */   }
/*     */   
/*     */   public boolean isCoveringAccessory() {
/* 120 */     return this.coversAccessory;
/*     */   }
/*     */   
/*     */   private String getFileName() {
/* 124 */     return "model_" + this.partID + ".csv";
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\accessories\ClothesSection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */