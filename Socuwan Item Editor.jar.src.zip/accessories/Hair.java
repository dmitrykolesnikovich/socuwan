/*    */ package accessories;
/*    */ 
/*    */ import toolbox.Colour;
/*    */ 
/*    */ public class Hair implements AccessoryInterface
/*    */ {
/*    */   private HairStyle style;
/*    */   private HairColour colour;
/*    */   
/*    */   public Hair(HairStyle style, HairColour colour) {
/* 11 */     this.colour = colour;
/* 12 */     this.style = style;
/*    */   }
/*    */   
/*    */   public AccessoryBlueprint getBlueprint()
/*    */   {
/* 17 */     return this.style.getBlueprint();
/*    */   }
/*    */   
/*    */   public Colour getMaterial1Colour()
/*    */   {
/* 22 */     return this.colour.getColour();
/*    */   }
/*    */   
/*    */   public Colour getMaterial2Colour()
/*    */   {
/* 27 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\accessories\Hair.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */