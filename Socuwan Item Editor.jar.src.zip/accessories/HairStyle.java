/*    */ package accessories;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import epicRenderEngine.RenderEngine;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ public enum HairStyle
/*    */ {
/*  9 */   SIMPLE_HAIR(RenderEngine.loadModelFile(60, "hair"), new ModelTexture(0, "hair"));
/*    */   
/*    */   private static final int HEAD_SECTION_ID = 3;
/*    */   private AccessoryBlueprint blueprint;
/*    */   
/*    */   private HairStyle(RawModel model, ModelTexture texture) {
/* 15 */     texture.setShineAndReflectivity(7.0F, 0.3F, 0.3F, 0.3F);
/* 16 */     this.blueprint = new AccessoryBlueprint(3, model, texture);
/*    */   }
/*    */   
/*    */   protected AccessoryBlueprint getBlueprint() {
/* 20 */     return this.blueprint;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\accessories\HairStyle.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */