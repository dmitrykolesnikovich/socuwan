/*    */ package accessories;
/*    */ 
/*    */ import toolbox.Colour;
/*    */ 
/*    */ public enum HairColour
/*    */ {
/*  7 */   BROWN(new Colour(87.0F, 60.0F, 21.0F, true)), 
/*  8 */   BLONDE(new Colour(215.0F, 190.0F, 104.0F, true)), 
/*  9 */   GINGER(new Colour(211.0F, 99.0F, 24.0F, true)), 
/* 10 */   WHITE(new Colour(230.0F, 230.0F, 230.0F, true)), 
/* 11 */   LIGHT_BROWN(new Colour(179.0F, 129.0F, 83.0F, true)), 
/* 12 */   BLACK(new Colour(0.1F, 0.1F, 0.1F)), 
/* 13 */   GREY(new Colour(0.5F, 0.5F, 0.5F));
/*    */   
/*    */   private Colour colour;
/*    */   
/*    */   private HairColour(Colour colour) {
/* 18 */     this.colour = colour;
/*    */   }
/*    */   
/*    */   protected Colour getColour() {
/* 22 */     return this.colour;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\accessories\HairColour.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */