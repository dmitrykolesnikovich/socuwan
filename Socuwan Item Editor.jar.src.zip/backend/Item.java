/*     */ package backend;
/*     */ 
/*     */ import categories.MainCategory;
/*     */ import categories.MiscleaneousSubCategory;
/*     */ import categories.SubCategoryInterface;
/*     */ import components.Component;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.FileSystem;
/*     */ import java.nio.file.FileSystems;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import javax.imageio.ImageIO;
/*     */ import main.ItemExporter;
/*     */ import main.ItemImporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Item
/*     */ {
/*     */   public static final int FULL_ID_SIZE = 9;
/*     */   public static final int CAT_ID_SIZE = 4;
/*     */   public static final int UNIQUE_ID_SIZE = 5;
/*     */   public static final int MAX_DESC_LENGTH = 80;
/*     */   private File superFile;
/*     */   private String uniqueID;
/*  35 */   private String name = "Item Name";
/*  36 */   private boolean stacks = false;
/*  37 */   private long price = 0L;
/*  38 */   private String description = "Item description...";
/*  39 */   private MainCategory mainCategory = MainCategory.MISCLEANEOUS;
/*  40 */   private SubCategoryInterface subCategory = MiscleaneousSubCategory.MISCLEANEOUS;
/*     */   private Component primaryComponent;
/*     */   private Component secondaryComponent;
/*     */   
/*     */   public Item(int uniqueID, File saves) throws Exception
/*     */   {
/*  46 */     setUniqueID(uniqueID);
/*  47 */     this.superFile = new File(saves, this.name);
/*  48 */     this.superFile.mkdirs();
/*  49 */     File info = new File(this.superFile, "info.txt");
/*  50 */     info.createNewFile();
/*  51 */     save();
/*     */   }
/*     */   
/*     */   public Item(File superFile) throws Exception {
/*  55 */     this.superFile = superFile;
/*  56 */     ItemImporter.loadItemInfo(this);
/*     */   }
/*     */   
/*     */   public String getStringID() {
/*  60 */     return getCatID() + this.uniqueID;
/*     */   }
/*     */   
/*     */   public String getUniqueID() {
/*  64 */     return this.uniqueID;
/*     */   }
/*     */   
/*     */   public String getCatID() {
/*  68 */     return this.mainCategory.getId() + this.subCategory.getId();
/*     */   }
/*     */   
/*     */   public void setUniqueID(int id) {
/*  72 */     String partID = Integer.toString(id);
/*  73 */     String buffedID = "";
/*  74 */     for (int i = 0; i < 5 - partID.length(); i++) {
/*  75 */       buffedID = buffedID + "0";
/*     */     }
/*  77 */     buffedID = buffedID + partID;
/*  78 */     this.uniqueID = buffedID.substring(buffedID.length() - 5);
/*     */   }
/*     */   
/*     */   public void setPrimaryComponent(Component component) {
/*  82 */     this.primaryComponent = component;
/*     */   }
/*     */   
/*     */   public void setSecondaryComponent(Component component) {
/*  86 */     this.secondaryComponent = component;
/*     */   }
/*     */   
/*     */   public MainCategory getMainCategoy() {
/*  90 */     return this.mainCategory;
/*     */   }
/*     */   
/*     */   public SubCategoryInterface getSubCategory() {
/*  94 */     return this.subCategory;
/*     */   }
/*     */   
/*     */   public void setMainCategory(MainCategory main) {
/*  98 */     this.mainCategory = main;
/*     */   }
/*     */   
/*     */   public void setSubCategory(SubCategoryInterface sub) {
/* 102 */     this.subCategory = sub;
/*     */   }
/*     */   
/*     */   public void setSuperFile(File superFile) {
/* 106 */     this.superFile = superFile;
/* 107 */     if (this.primaryComponent != null) {
/* 108 */       this.primaryComponent.notifyNewItemFile(superFile);
/*     */     }
/* 110 */     if (this.secondaryComponent != null) {
/* 111 */       this.secondaryComponent.notifyNewItemFile(superFile);
/*     */     }
/*     */   }
/*     */   
/*     */   public Component getPrimaryComponent() {
/* 116 */     return this.primaryComponent;
/*     */   }
/*     */   
/*     */   public Component getSecondaryComponent() {
/* 120 */     return this.secondaryComponent;
/*     */   }
/*     */   
/*     */   public void save() {
/* 124 */     ItemExporter.exportItem(this);
/*     */   }
/*     */   
/*     */   public File getSuperFile() {
/* 128 */     return this.superFile;
/*     */   }
/*     */   
/*     */   public File getInfoFile() {
/* 132 */     File[] files = this.superFile.listFiles();
/* 133 */     for (File file : files) {
/* 134 */       if (file.getName().equals("info.txt")) {
/* 135 */         return file;
/*     */       }
/*     */     }
/* 138 */     return null;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 142 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 146 */     this.name = name;
/*     */   }
/*     */   
/*     */   public boolean isStacks() {
/* 150 */     return this.stacks;
/*     */   }
/*     */   
/*     */   public void setStacks(boolean stacks) {
/* 154 */     this.stacks = stacks;
/*     */   }
/*     */   
/*     */   public long getPrice() {
/* 158 */     return this.price;
/*     */   }
/*     */   
/*     */   public void setPrice(long price) {
/* 162 */     this.price = price;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 166 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/* 170 */     this.description = description;
/*     */   }
/*     */   
/*     */   public void setIcon(File icon) throws Exception {
/* 174 */     Files.copy(icon.toPath(), FileSystems.getDefault().getPath(this.superFile.getPath() + "/" + "icon.png", new String[0]), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */   }
/*     */   
/*     */   public BufferedImage getIcon()
/*     */   {
/*     */     try {
/* 180 */       File[] files = this.superFile.listFiles();
/* 181 */       for (File file : files) {
/* 182 */         if (file.getName().equals("icon.png")) {
/* 183 */           return ImageIO.read(file);
/*     */         }
/*     */       }
/* 186 */       return ImageIO.read(Item.class.getResourceAsStream("/res/defaultIcon.png"));
/*     */     } catch (Exception e) {
/* 188 */       e.printStackTrace();
/* 189 */       System.err.println("Couldn't find/load icon for item."); }
/* 190 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\backend\Item.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */