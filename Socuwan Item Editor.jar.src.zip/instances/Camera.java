/*     */ package instances;
/*     */ 
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import toolbox.MyMouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Camera
/*     */   implements epicRenderEngine.Camera
/*     */ {
/*  12 */   private final float FIELD_OF_VIEW = 70.0F;
/*  13 */   private final float NEAR_PLANE = 0.1F;
/*  14 */   private final float FAR_PLANE = 1040.0F;
/*     */   
/*     */   private Entity parentEntity;
/*     */   
/*     */   private MyMouse mouse;
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private float horizontalDistanceFromPlayer;
/*     */   private float verticalDistanceFromPlayer;
/*     */   private float pitch;
/*     */   private float yaw;
/*  26 */   private float actualDistanceFromPlayer = 11.4F;
/*  27 */   private float angleOfElevation = 0.37F;
/*  28 */   private float angleAroundPlayer = 200.0F;
/*  29 */   private boolean change = false;
/*     */   
/*     */   private static final float CAMERA_AIM_OFFSET = 2.5F;
/*     */   private static final int INFLUENCE_OF_MOUSEDY = 50;
/*     */   private static final int INFLUENCE_OF_MOUSEDX = 1;
/*     */   private static final int INFLUENCE_OF_MOUSE_WHEEL = 100;
/*     */   private static final float MAX_ANGLE_OF_ELEVATION = 1.5F;
/*     */   private static final float PITCH_OFFSET = 8.0F;
/*     */   private static final float MINIMUM_ZOOM = 8.0F;
/*     */   private static final float MAX_HORIZONTAL_CHANGE = 2000.0F;
/*     */   private static final float MAX_VERTICAL_CHANGE = 20.0F;
/*     */   
/*     */   public Camera(MyMouse mouse)
/*     */   {
/*  43 */     this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */     
/*  45 */     this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*  46 */     this.mouse = mouse;
/*     */   }
/*     */   
/*     */   public void setParentEntity(Entity entity) {
/*  50 */     this.parentEntity = entity;
/*     */   }
/*     */   
/*     */   public void moveCamera(float delta) {
/*  54 */     this.change = false;
/*  55 */     calculateHorizontalAngle(delta);
/*  56 */     calculateVerticalAngle(delta);
/*  57 */     calculateZoom();
/*  58 */     calculateDistances();
/*  59 */     calculatePosition();
/*     */   }
/*     */   
/*     */   public float getX() {
/*  63 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  67 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  71 */     return this.z;
/*     */   }
/*     */   
/*     */   public float getPitch() {
/*  75 */     return this.pitch;
/*     */   }
/*     */   
/*     */   public float getYaw() {
/*  79 */     return this.yaw;
/*     */   }
/*     */   
/*     */   public float getFieldOfView() {
/*  83 */     return 70.0F;
/*     */   }
/*     */   
/*     */   public float getNearPlane() {
/*  87 */     return 0.1F;
/*     */   }
/*     */   
/*     */   public float getFarPlane() {
/*  91 */     return 1040.0F;
/*     */   }
/*     */   
/*     */   private void calculatePosition() {
/*  95 */     float playerRot = 0.0F;
/*  96 */     this.x = (this.parentEntity.getX() - (float)(this.horizontalDistanceFromPlayer * Math.sin(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/*  99 */     this.z = (this.parentEntity.getZ() - (float)(this.horizontalDistanceFromPlayer * Math.cos(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/*     */ 
/* 103 */     float height = 0.0F;
/* 104 */     this.y = (this.verticalDistanceFromPlayer + 2.5F + height);
/*     */     
/* 106 */     if (this.parentEntity.getY() + 2.5F > this.y) {
/* 107 */       this.y = (this.parentEntity.getY() + 2.5F);
/*     */     }
/* 109 */     this.yaw = (playerRot + 180.0F + this.angleAroundPlayer);
/* 110 */     this.pitch = ((float)Math.toDegrees(this.angleOfElevation) - 8.0F);
/*     */   }
/*     */   
/*     */   private void calculateHorizontalAngle(float delta) {
/* 114 */     if ((this.mouse.isLeftButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 115 */       float angleChange = this.mouse.getDX() / 1.0F;
/* 116 */       if (angleChange > 2000.0F * delta) {
/* 117 */         angleChange = 2000.0F * delta;
/* 118 */       } else if (angleChange < -2000.0F * delta) {
/* 119 */         angleChange = -2000.0F * delta;
/*     */       }
/* 121 */       this.angleAroundPlayer -= angleChange;
/*     */       
/* 123 */       if (this.angleAroundPlayer >= 180.0F) {
/* 124 */         this.angleAroundPlayer -= 360.0F;
/* 125 */       } else if (this.angleAroundPlayer <= -180.0F) {
/* 126 */         this.angleAroundPlayer += 360.0F;
/*     */       }
/* 128 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateVerticalAngle(float delta)
/*     */   {
/* 134 */     if ((this.mouse.isRightButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 135 */       float angleChange = this.mouse.getDY() / 50.0F;
/* 136 */       if (angleChange > 20.0F * delta) {
/* 137 */         angleChange = 20.0F * delta;
/* 138 */       } else if (angleChange < -20.0F * delta) {
/* 139 */         angleChange = -20.0F * delta;
/*     */       }
/* 141 */       this.angleOfElevation -= angleChange;
/* 142 */       if (this.angleOfElevation >= 1.5F) {
/* 143 */         this.angleOfElevation = 1.5F;
/* 144 */       } else if (this.angleOfElevation <= 0.0F) {
/* 145 */         this.angleOfElevation = 0.0F;
/*     */       }
/* 147 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateZoom() {
/* 152 */     if (Keyboard.isKeyDown(46)) {
/* 153 */       this.actualDistanceFromPlayer -= 1.0F;
/* 154 */       this.change = true;
/*     */     }
/* 156 */     float zoomLevel = this.mouse.getDWheel() / 100;
/* 157 */     if (zoomLevel != 0.0F) {
/* 158 */       this.actualDistanceFromPlayer -= zoomLevel;
/* 159 */       if (this.actualDistanceFromPlayer < 8.0F) {
/* 160 */         this.actualDistanceFromPlayer = 8.0F;
/*     */       }
/* 162 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateDistances() {
/* 167 */     if (this.change) {
/* 168 */       this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */       
/* 170 */       this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\instances\Camera.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */