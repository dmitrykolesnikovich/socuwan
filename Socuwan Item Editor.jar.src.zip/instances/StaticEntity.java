/*    */ package instances;
/*    */ 
/*    */ import blueprints.StaticBlueprint;
/*    */ import entitiesInterfaces.StaticEntityInterface;
/*    */ 
/*    */ public class StaticEntity extends Entity implements StaticEntityInterface
/*    */ {
/*    */   public StaticEntity(StaticBlueprint blueprint, int textIndex, float x, float y, float z, float rotX, float rotY, float rotZ, float scale)
/*    */   {
/* 10 */     super(blueprint, textIndex, x, y, z, rotX, rotY, rotZ, scale);
/*    */   }
/*    */   
/*    */   public StaticBlueprint getBlueprint() {
/* 14 */     return (StaticBlueprint)super.getBlueprint();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\instances\StaticEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */