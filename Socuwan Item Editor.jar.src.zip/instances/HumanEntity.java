/*     */ package instances;
/*     */ 
/*     */ import accessories.AccessoryBlueprint;
/*     */ import accessories.AccessoryInterface;
/*     */ import accessories.ClothesInstanceInterface;
/*     */ import accessories.ClothesSection;
/*     */ import accessories.Hair;
/*     */ import accessories.HairColour;
/*     */ import accessories.HairStyle;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import blueprints.AnimatedBlueprint;
/*     */ import clothes.Clothe;
/*     */ import clothes.Equipper;
/*     */ import entitiesInterfaces.HumanEntityInterface;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import main.PlayerAnimation;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ public class HumanEntity extends AnimatedEntity implements HumanEntityInterface
/*     */ {
/*  24 */   private static final AnimatedBlueprint HUMAN_BLUEPRINT = ;
/*     */   
/*  26 */   private Hair hair = null;
/*     */   
/*     */   private Equipper equipment;
/*  29 */   private boolean show = false;
/*     */   private PlayerAnimation currentAnimation;
/*     */   
/*     */   public HumanEntity(float x, float y, float z, float rotX, float rotY, float rotZ, float scale) {
/*  33 */     super(HUMAN_BLUEPRINT, 0, x, y, z, rotX, rotY, rotZ, scale);
/*  34 */     this.equipment = new Equipper(HUMAN_BLUEPRINT.getNumberOfBones());
/*  35 */     this.currentAnimation = PlayerAnimation.IDLE;
/*  36 */     super.suggestAnimation(this.currentAnimation.getAnimation());
/*  37 */     setHair(HairStyle.SIMPLE_HAIR, HairColour.BROWN);
/*     */   }
/*     */   
/*     */   public void doAnimation(PlayerAnimation animation) {
/*  41 */     this.currentAnimation = animation;
/*  42 */     super.suggestAnimation(this.currentAnimation.getAnimation());
/*     */   }
/*     */   
/*     */   public PlayerAnimation getCurrentPlayerAnimation()
/*     */   {
/*  47 */     return this.currentAnimation;
/*     */   }
/*     */   
/*     */   public boolean isShowing() {
/*  51 */     return this.show;
/*     */   }
/*     */   
/*     */   public Clothe getCurrentClothes() {
/*  55 */     return this.equipment.getClotheWorn();
/*     */   }
/*     */   
/*     */   public void equip(Clothe clothe) {
/*  59 */     this.equipment.equipClothes(clothe);
/*  60 */     this.show = true;
/*     */   }
/*     */   
/*     */   public void updateClothes() {
/*  64 */     this.equipment.update();
/*     */   }
/*     */   
/*     */   public Clothe unequip() {
/*  68 */     this.show = false;
/*  69 */     return this.equipment.unequipClotheFromSlot();
/*     */   }
/*     */   
/*     */   public void setHair(HairStyle hairstyle, HairColour hairColour) {
/*  73 */     this.hair = new Hair(hairstyle, hairColour);
/*     */   }
/*     */   
/*     */   public List<AccessoryInterface> getAccessoriesOnNode(int sectionID) {
/*  77 */     List<AccessoryInterface> accessories = new ArrayList();
/*  78 */     if ((this.hair != null) && 
/*  79 */       (sectionID == this.hair.getBlueprint().getSectionID())) {
/*  80 */       accessories.add(this.hair);
/*     */     }
/*     */     
/*  83 */     return accessories;
/*     */   }
/*     */   
/*     */   public Map<ClothesInstanceInterface, ClothesSection> getClothesSectionsOnNode(int sectionID) {
/*  87 */     return this.equipment.getClothesOnPart(sectionID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static AnimatedBlueprint createBlueprint()
/*     */   {
/*  94 */     BoneBlueprint hip = new BoneBlueprint(0, RenderEngine.loadModelFile(33, "hip"), 0.0F, 0.0F, 0.0F);
/*  95 */     BoneBlueprint waist = new BoneBlueprint(1, RenderEngine.loadModelFile(32, "waist"), 0.0F, 4.05F, 0.0F);
/*     */     
/*  97 */     BoneBlueprint chest = new BoneBlueprint(2, RenderEngine.loadModelFile(31, "chest"), 0.0F, 4.85F, 0.0F);
/*     */     
/*  99 */     BoneBlueprint head = new BoneBlueprint(3, RenderEngine.loadModelFile(30, "head"), 0.0F, 5.9F, 0.0F);
/* 100 */     BoneBlueprint upperRightArm = new BoneBlueprint(4, RenderEngine.loadModelFile(40, "upperRightArm"), -1.15F, 5.5F, 0.0F);
/*     */     
/* 102 */     BoneBlueprint lowerRightArm = new BoneBlueprint(5, RenderEngine.loadModelFile(41, "lowerRightArm"), -1.15F, 4.4F, 0.0F);
/*     */     
/* 104 */     BoneBlueprint rightHand = new BoneBlueprint(6, RenderEngine.loadModelFile(42, "rightHand"), -1.15F, 3.3F, 0.0F);
/*     */     
/* 106 */     BoneBlueprint upperLeftArm = new BoneBlueprint(7, RenderEngine.loadModelFile(43, "upperLeftArm"), 1.15F, 5.5F, 0.0F);
/*     */     
/* 108 */     BoneBlueprint lowerLeftArm = new BoneBlueprint(8, RenderEngine.loadModelFile(44, "lowerLeftArm"), 1.15F, 4.4F, 0.0F);
/*     */     
/* 110 */     BoneBlueprint leftHand = new BoneBlueprint(9, RenderEngine.loadModelFile(45, "leftHand"), 1.15F, 3.3F, 0.0F);
/*     */     
/* 112 */     BoneBlueprint upperRightLeg = new BoneBlueprint(10, RenderEngine.loadModelFile(34, "upperRightLeg"), -0.45F, 3.2F, 0.0F);
/*     */     
/* 114 */     BoneBlueprint lowerRightLeg = new BoneBlueprint(11, RenderEngine.loadModelFile(35, "lowerRightLeg"), -0.45F, 1.7F, 0.0F);
/*     */     
/* 116 */     BoneBlueprint rightFoot = new BoneBlueprint(12, RenderEngine.loadModelFile(36, "rightFoot"), -0.45F, 0.37F, 0.0F);
/*     */     
/* 118 */     BoneBlueprint upperLeftLeg = new BoneBlueprint(13, RenderEngine.loadModelFile(37, "upperLeftLeg"), 0.45F, 3.2F, 0.0F);
/*     */     
/* 120 */     BoneBlueprint lowerLeftLeg = new BoneBlueprint(14, RenderEngine.loadModelFile(38, "lowerLeftLeg"), 0.45F, 1.7F, 0.0F);
/*     */     
/* 122 */     BoneBlueprint leftFoot = new BoneBlueprint(15, RenderEngine.loadModelFile(39, "leftFoot"), 0.45F, 0.37F, 0.0F);
/*     */     
/*     */ 
/* 125 */     hip.addChildren(new BoneBlueprint[] { waist, upperRightLeg, upperLeftLeg });
/* 126 */     waist.addChildren(new BoneBlueprint[] { chest });
/* 127 */     chest.addChildren(new BoneBlueprint[] { head, upperLeftArm, upperRightArm });
/* 128 */     upperLeftArm.addChildren(new BoneBlueprint[] { lowerLeftArm });
/* 129 */     lowerLeftArm.addChildren(new BoneBlueprint[] { leftHand });
/* 130 */     upperRightArm.addChildren(new BoneBlueprint[] { lowerRightArm });
/* 131 */     lowerRightArm.addChildren(new BoneBlueprint[] { rightHand });
/* 132 */     upperLeftLeg.addChildren(new BoneBlueprint[] { lowerLeftLeg });
/* 133 */     upperRightLeg.addChildren(new BoneBlueprint[] { lowerRightLeg });
/* 134 */     lowerLeftLeg.addChildren(new BoneBlueprint[] { leftFoot });
/* 135 */     lowerRightLeg.addChildren(new BoneBlueprint[] { rightFoot });
/*     */     
/* 137 */     return new AnimatedBlueprint(0, new BoneBlueprint[] { hip }, 16, new ModelTexture(0, "test"));
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\instances\HumanEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */