/*     */ package instances;
/*     */ 
/*     */ import animations.Animation;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import blueprints.AnimatedBlueprint;
/*     */ import entitiesInterfaces.AnimatedEntityInterface;
/*     */ import entitiesInterfaces.AnimatedSection;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class AnimatedEntity
/*     */   extends Entity
/*     */   implements AnimatedEntityInterface
/*     */ {
/*     */   private AnimatedSection[] headNodes;
/*     */   private AnimatedSection[] sections;
/*     */   private Animation currentAnimation;
/*     */   private float currentAnimationTime;
/*     */   private Animation nextAnimation;
/*     */   
/*     */   public AnimatedEntity(AnimatedBlueprint blueprint, int textureIndex, float x, float y, float z, float rotX, float rotY, float rotZ, float scale)
/*     */   {
/*  24 */     super(blueprint, textureIndex, x, y, z, rotX, rotY, rotZ, scale);
/*  25 */     createInstancesOfBones(blueprint);
/*     */   }
/*     */   
/*     */   public AnimatedBlueprint getBlueprint() {
/*  29 */     return (AnimatedBlueprint)super.getBlueprint();
/*     */   }
/*     */   
/*     */   public AnimatedSection[] getSections() {
/*  33 */     return this.sections;
/*     */   }
/*     */   
/*     */   public AnimatedSection[] getHeadNodes() {
/*  37 */     return this.headNodes;
/*     */   }
/*     */   
/*     */   public void suggestAnimation(Animation anim) {
/*  41 */     this.nextAnimation = anim;
/*     */   }
/*     */   
/*     */   protected float getCurrentAnimationTime() {
/*  45 */     return this.currentAnimationTime;
/*     */   }
/*     */   
/*     */   protected Animation getCurrentAnimation() {
/*  49 */     return this.currentAnimation;
/*     */   }
/*     */   
/*     */   public void animateForCurrentFrame(float deltaInSeconds) {
/*  53 */     if (this.nextAnimation == null) {
/*  54 */       return;
/*     */     }
/*  56 */     if (this.nextAnimation == this.currentAnimation) {
/*  57 */       this.currentAnimationTime = this.currentAnimation.increaseAnimationTime(this.currentAnimationTime, deltaInSeconds);
/*     */     }
/*     */     else {
/*  60 */       this.currentAnimation = this.nextAnimation;
/*  61 */       this.currentAnimationTime = 0.0F;
/*     */     }
/*  63 */     this.currentAnimation.animateEntitySectionsAtTime(this.sections, this.currentAnimationTime, deltaInSeconds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void createInstancesOfBones(AnimatedBlueprint blueprint)
/*     */   {
/*  70 */     this.sections = new AnimatedSection[blueprint.getNumberOfBones()];
/*  71 */     List<AnimatedSection> nodesToProcess = new ArrayList();
/*  72 */     createHeadNodes(blueprint.getHeadBones(), nodesToProcess);
/*  73 */     while (!nodesToProcess.isEmpty()) {
/*  74 */       processNode((AnimatedSection)nodesToProcess.remove(0), nodesToProcess);
/*     */     }
/*     */   }
/*     */   
/*     */   private void createHeadNodes(BoneBlueprint[] headBones, List<AnimatedSection> nodesToProcess) {
/*  79 */     int bonesNumber = headBones.length;
/*  80 */     this.headNodes = new AnimatedSection[bonesNumber];
/*  81 */     for (int i = 0; i < bonesNumber; i++) {
/*  82 */       AnimatedSection section = new AnimatedSection(this, headBones[i]);
/*  83 */       this.headNodes[i] = section;
/*  84 */       nodesToProcess.add(section);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processNode(AnimatedSection node, List<AnimatedSection> nodesToProcess) {
/*  89 */     BoneBlueprint nodeBone = node.getBone();
/*     */     try {
/*  91 */       this.sections[nodeBone.getPartID()] = node;
/*     */     } catch (ArrayIndexOutOfBoundsException e) {
/*  93 */       System.err.println("Mismatch for number of bones for animated model! ");
/*  94 */       System.err.println(nodeBone.getPartID() + " is out of bounds!");
/*  95 */       System.exit(-1);
/*     */     }
/*  97 */     List<BoneBlueprint> children = nodeBone.getChildren();
/*  98 */     for (BoneBlueprint child : children) {
/*  99 */       AnimatedSection section = new AnimatedSection(this, child, node);
/* 100 */       node.addChild(section);
/* 101 */       nodesToProcess.add(section);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\instances\AnimatedEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */