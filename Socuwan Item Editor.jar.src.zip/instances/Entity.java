/*     */ package instances;
/*     */ 
/*     */ import blueprints.Blueprint;
/*     */ import entitiesInterfaces.EntityInterface;
/*     */ import texture.ModelTexture;
/*     */ import toolbox.Colour;
/*     */ 
/*     */ public abstract class Entity
/*     */   implements EntityInterface
/*     */ {
/*     */   private Blueprint blueprint;
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private float rotX;
/*     */   private float rotY;
/*     */   private float rotZ;
/*     */   private float scale;
/*     */   private float disFromCamera;
/*     */   private int currentLevelOfDetail;
/*     */   private float textureOffsetX;
/*     */   private float textureOffsetY;
/*     */   private float textureSize;
/*  24 */   private Colour material1Colour = null;
/*  25 */   private Colour material2Colour = null;
/*     */   
/*  27 */   private boolean solid = false;
/*     */   private boolean hasReflection;
/*     */   
/*     */   public Entity(Blueprint blueprint, int textureIndex, float x, float y, float z, float rotX, float rotY, float rotZ, float scale)
/*     */   {
/*  32 */     this.blueprint = blueprint;
/*  33 */     setTextureCoords(textureIndex);
/*  34 */     this.x = x;
/*  35 */     this.y = y;
/*  36 */     this.z = z;
/*  37 */     this.rotX = rotX;
/*  38 */     this.rotY = rotY;
/*  39 */     this.rotZ = rotZ;
/*  40 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  44 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  48 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  52 */     return this.z;
/*     */   }
/*     */   
/*     */   public void translatePosition(float dX, float dY, float dZ)
/*     */   {
/*  57 */     this.x += dX;
/*  58 */     this.y += dY;
/*  59 */     this.z += dZ;
/*     */   }
/*     */   
/*     */   public void setX(float x) {
/*  63 */     this.x = x;
/*     */   }
/*     */   
/*     */   public void setY(float y) {
/*  67 */     this.y = y;
/*     */   }
/*     */   
/*     */   public void setZ(float z) {
/*  71 */     this.z = z;
/*     */   }
/*     */   
/*     */   public float getRotX() {
/*  75 */     return this.rotX;
/*     */   }
/*     */   
/*     */   public float getRotY() {
/*  79 */     return this.rotY;
/*     */   }
/*     */   
/*     */   public float getRotZ() {
/*  83 */     return this.rotZ;
/*     */   }
/*     */   
/*     */   public void setRotY(float rotY) {
/*  87 */     this.rotY = rotY;
/*     */   }
/*     */   
/*     */   public void setRotZ(float rotZ) {
/*  91 */     this.rotZ = rotZ;
/*     */   }
/*     */   
/*     */   public void increaseRotationValue(float dX, float dY, float dZ) {
/*  95 */     this.rotX += dX;
/*  96 */     this.rotY += dY;
/*  97 */     this.rotZ += dZ;
/*     */   }
/*     */   
/*     */   public float getScale() {
/* 101 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void increaseScale(float dScale) {
/* 105 */     this.scale += dScale;
/*     */   }
/*     */   
/*     */   public boolean isSolid()
/*     */   {
/* 110 */     return this.solid;
/*     */   }
/*     */   
/*     */   public float getFurthestPoint() {
/* 114 */     return this.blueprint.getFurthestPoint() * this.scale;
/*     */   }
/*     */   
/*     */   public Blueprint getBlueprint()
/*     */   {
/* 119 */     return this.blueprint;
/*     */   }
/*     */   
/*     */   public void setDistance(float distance)
/*     */   {
/* 124 */     this.disFromCamera = distance;
/*     */   }
/*     */   
/*     */   public float getDistance()
/*     */   {
/* 129 */     return this.disFromCamera;
/*     */   }
/*     */   
/*     */   public void setLOD(int lod)
/*     */   {
/* 134 */     this.currentLevelOfDetail = lod;
/*     */   }
/*     */   
/*     */   public boolean isVisible()
/*     */   {
/* 139 */     return this.disFromCamera < this.blueprint.getVisibleRange() * this.scale;
/*     */   }
/*     */   
/*     */   public float getVisibleDistance()
/*     */   {
/* 144 */     return this.blueprint.getVisibleRange() * this.scale;
/*     */   }
/*     */   
/*     */   public void setReflectionFlag()
/*     */   {
/* 149 */     if (this.blueprint.hasReflection()) {
/* 150 */       if (this.blueprint.hasLimitedReflection()) {
/* 151 */         if (this.disFromCamera < this.blueprint.getReflectionLimit() * this.scale) {
/* 152 */           this.hasReflection = true;
/*     */         } else {
/* 154 */           this.hasReflection = false;
/*     */         }
/*     */       } else {
/* 157 */         this.hasReflection = true;
/*     */       }
/*     */     } else {
/* 160 */       this.hasReflection = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasReflection()
/*     */   {
/* 166 */     return this.hasReflection;
/*     */   }
/*     */   
/*     */   public int getLOD()
/*     */   {
/* 171 */     return this.currentLevelOfDetail;
/*     */   }
/*     */   
/*     */   public float[] getInstanceTextureCoords()
/*     */   {
/* 176 */     return new float[] { this.textureSize, this.textureOffsetX, this.textureOffsetY };
/*     */   }
/*     */   
/*     */   public Colour getMaterial1Colour()
/*     */   {
/* 181 */     return this.material1Colour;
/*     */   }
/*     */   
/*     */   public Colour getMaterial2Colour()
/*     */   {
/* 186 */     return this.material2Colour;
/*     */   }
/*     */   
/*     */   private void setTextureCoords(int textureAtlasIndex) {
/* 190 */     ModelTexture texture = this.blueprint.getTexture();
/* 191 */     this.textureOffsetX = texture.getXOffset(textureAtlasIndex);
/* 192 */     this.textureOffsetY = texture.getYOffset(textureAtlasIndex);
/* 193 */     this.textureSize = texture.getSize();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\instances\Entity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */