/*     */ package epicRenderEngine;
/*     */ 
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL13;
/*     */ import org.lwjgl.opengl.GL15;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import org.lwjgl.util.vector.Vector4f;
/*     */ import toolbox.Colour;
/*     */ import toolbox.Maths;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenglUtils
/*     */ {
/*  21 */   private static boolean cullingBackFace = false;
/*  22 */   private static boolean inWireframe = false;
/*  23 */   private static boolean isBlending = false;
/*     */   
/*     */   public static void prepareNewRenderParse(Colour skyColour) {
/*  26 */     GL11.glClear(16640);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  31 */     GL11.glClearColor(skyColour.getR(), skyColour.getG(), skyColour.getB(), 1.0F);
/*  32 */     disableBlending();
/*  33 */     enableDepthTesting();
/*     */   }
/*     */   
/*     */   public static void enableBlending() {
/*  37 */     if (!isBlending) {
/*  38 */       GL11.glEnable(3042);
/*  39 */       GL11.glBlendFunc(770, 771);
/*  40 */       isBlending = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void enableAdditiveBlending() {
/*  45 */     GL11.glEnable(3042);
/*  46 */     GL11.glBlendFunc(770, 1);
/*     */   }
/*     */   
/*     */   public static void disableBlending() {
/*  50 */     if (isBlending) {
/*  51 */       GL11.glDisable(3042);
/*  52 */       isBlending = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void disableDepthTesting() {
/*  57 */     GL11.glDisable(2929);
/*     */   }
/*     */   
/*     */   public static void enableDepthTesting() {
/*  61 */     GL11.glEnable(2929);
/*     */   }
/*     */   
/*     */   public static void bindGuiVAO(int vaoID) {
/*  65 */     GL30.glBindVertexArray(vaoID);
/*  66 */     GL20.glEnableVertexAttribArray(0);
/*  67 */     GL20.glEnableVertexAttribArray(1);
/*     */   }
/*     */   
/*     */   public static void bindJustPositionVAO(int vaoID) {
/*  71 */     GL30.glBindVertexArray(vaoID);
/*  72 */     GL20.glEnableVertexAttribArray(0);
/*     */   }
/*     */   
/*     */   public static void bindVAO(int vaoID, int... attributes) {
/*  76 */     GL30.glBindVertexArray(vaoID);
/*  77 */     for (int i : attributes) {
/*  78 */       GL20.glEnableVertexAttribArray(i);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unbindVAO(int vaoID, int... attributes) {
/*  83 */     for (int i : attributes) {
/*  84 */       GL20.glDisableVertexAttribArray(i);
/*     */     }
/*  86 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   public static void bindVAO(int vaoID) {
/*  90 */     GL30.glBindVertexArray(vaoID);
/*  91 */     GL20.glEnableVertexAttribArray(0);
/*  92 */     GL20.glEnableVertexAttribArray(1);
/*  93 */     GL20.glEnableVertexAttribArray(2);
/*     */   }
/*     */   
/*     */   public static void bindIndicesVBO(int vboID) {
/*  97 */     GL15.glBindBuffer(34963, vboID);
/*     */   }
/*     */   
/*     */   public static void bindTextureToBank(int textureID, int bankID) {
/* 101 */     GL13.glActiveTexture(33984 + bankID);
/* 102 */     GL11.glBindTexture(3553, textureID);
/* 103 */     GL11.glTexParameteri(3553, 33084, 0);
/*     */   }
/*     */   
/*     */   public static void bindTextureToBank(int textureID, int bankID, int lodBias) {
/* 107 */     GL13.glActiveTexture(33984 + bankID);
/* 108 */     GL11.glBindTexture(3553, textureID);
/* 109 */     GL11.glTexParameteri(3553, 33084, lodBias);
/* 110 */     GL13.glActiveTexture(0);
/*     */   }
/*     */   
/*     */   public static void cullBackFaces(boolean cull) {
/* 114 */     if ((cull) && (!cullingBackFace)) {
/* 115 */       GL11.glEnable(2884);
/* 116 */       GL11.glCullFace(1029);
/* 117 */       cullingBackFace = true;
/* 118 */     } else if ((!cull) && (cullingBackFace)) {
/* 119 */       GL11.glDisable(2884);
/* 120 */       cullingBackFace = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void goWireframe(boolean goWireframe) {
/* 125 */     if ((goWireframe) && (!inWireframe)) {
/* 126 */       GL11.glPolygonMode(1032, 6913);
/* 127 */       inWireframe = true;
/* 128 */     } else if ((!goWireframe) && (inWireframe)) {
/* 129 */       GL11.glPolygonMode(1032, 6914);
/* 130 */       inWireframe = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unbindIndicesVBO() {
/* 135 */     GL15.glBindBuffer(34963, 0);
/*     */   }
/*     */   
/*     */   public static void unbindVAO() {
/* 139 */     GL20.glDisableVertexAttribArray(2);
/* 140 */     GL20.glDisableVertexAttribArray(1);
/* 141 */     GL20.glDisableVertexAttribArray(0);
/* 142 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   public static void resetModelMatrix(Matrix4f matrix, float x, float y, float z, float rX, float rY, float rZ, float scale)
/*     */   {
/* 147 */     matrix.setIdentity();
/* 148 */     translateMatrix(matrix, x, y, z);
/* 149 */     rotateMatrix(matrix, rX, 1.0F, 0.0F, 0.0F);
/* 150 */     rotateMatrix(matrix, rY, 0.0F, 1.0F, 0.0F);
/* 151 */     rotateMatrix(matrix, rZ, 0.0F, 0.0F, 1.0F);
/* 152 */     scaleMatrix(matrix, scale);
/*     */   }
/*     */   
/*     */   public static Vector4f toEyeCoords(Matrix4f view, float posX, float posY, float posZ) {
/* 156 */     Vector3f lightPos = new Vector3f(posX, posY, posZ);
/* 157 */     Vector4f eyeCoords = new Vector4f();
/* 158 */     Matrix4f.transform(view, new Vector4f(lightPos.x, lightPos.y, lightPos.z, 1.0F), eyeCoords);
/* 159 */     return eyeCoords;
/*     */   }
/*     */   
/*     */   public static void translateMatrix(Matrix4f matrix, float x, float y, float z) {
/* 163 */     Vector3f position = new Vector3f(x, y, z);
/* 164 */     Matrix4f.translate(position, matrix, matrix);
/*     */   }
/*     */   
/*     */   public static void rotateMatrix(Matrix4f matrix, float value, float x, float y, float z) {
/* 168 */     Matrix4f.rotate(Maths.degreesToRadians(value), new Vector3f(x, y, z), matrix, matrix);
/*     */   }
/*     */   
/*     */   public static void rotateMatrixWithQuaternion(Matrix4f modelMatrix, double w, double x, double y, double z)
/*     */   {
/* 173 */     Matrix4f rotation = Maths.quaternionToMatrix(w, x, y, z);
/* 174 */     Matrix4f.mul(modelMatrix, rotation, modelMatrix);
/*     */   }
/*     */   
/*     */   public static void scaleMatrix(Matrix4f matrix, float value) {
/* 178 */     Vector3f scale = new Vector3f(value, value, value);
/* 179 */     Matrix4f.scale(scale, matrix, matrix);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\epicRenderEngine\OpenglUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */