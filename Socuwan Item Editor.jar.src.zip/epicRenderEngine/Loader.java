/*     */ package epicRenderEngine;
/*     */ 
/*     */ import accessories.ClothesSection;
/*     */ import blueprintInterfaces.RawModel;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL15;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ import org.newdawn.slick.opengl.Texture;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ public class Loader
/*     */ {
/*     */   private static final String MODEL_FILE_EXT = ".csv";
/*     */   private static final float MIPMAP_BIAS = -0.5F;
/*  27 */   private static Map<Integer, Integer> vaoCache = new java.util.HashMap();
/*  28 */   private static List<Integer> vboCache = new ArrayList();
/*  29 */   private static List<Integer> textureCache = new ArrayList();
/*     */   
/*  31 */   private static ModelTexture waitingDiffuse = null;
/*  32 */   private static ModelTexture waitingExtra = null;
/*  33 */   private static List<ClothesSection> waitingSections = new ArrayList();
/*     */   
/*     */   public static int loadMipmappedTexture(String fileName) {
/*  36 */     return loadTexture(fileName, true);
/*     */   }
/*     */   
/*     */   public static int loadTexture(String fileName) {
/*  40 */     return loadTexture(fileName, false);
/*     */   }
/*     */   
/*     */   public static synchronized void dealWithRequests()
/*     */   {
/*  45 */     if ((waitingDiffuse != null) && 
/*  46 */       (waitingDiffuse.getDiffuseFile() != null)) {
/*  47 */       waitingDiffuse.setDiffuseTexture(loadTexture(waitingDiffuse.getDiffuseFile()));
/*     */     }
/*     */     
/*     */ 
/*  51 */     waitingDiffuse = null;
/*  52 */     if ((waitingExtra != null) && 
/*  53 */       (waitingExtra.getSpecularFile() != null)) {
/*  54 */       waitingExtra.setExtraTexture(loadTexture(waitingExtra.getSpecularFile()));
/*     */     }
/*     */     
/*     */ 
/*  58 */     waitingExtra = null;
/*     */     
/*  60 */     if (!waitingSections.isEmpty()) {
/*  61 */       for (ClothesSection waitingSection : waitingSections) {
/*  62 */         File modelFile = waitingSection.getModelFile();
/*  63 */         waitingSection.setModel(loadModelFile(modelFile));
/*     */       }
/*     */     }
/*  66 */     waitingSections.clear();
/*     */   }
/*     */   
/*     */   public static synchronized void requestDiffuseTextureLoading(ModelTexture texture) {
/*  70 */     waitingDiffuse = texture;
/*     */   }
/*     */   
/*     */   public static synchronized void requestExtraTextureLoading(ModelTexture texture) {
/*  74 */     waitingExtra = texture;
/*     */   }
/*     */   
/*     */   public static synchronized void requestClothesSectionLoading(ClothesSection section) {
/*  78 */     waitingSections.add(section);
/*     */   }
/*     */   
/*     */   public static void clearVaoFromMemory(Integer vao) {
/*  82 */     Integer vbo = (Integer)vaoCache.remove(vao);
/*  83 */     if (vbo != null) {
/*  84 */       GL15.glDeleteBuffers(vbo.intValue());
/*  85 */       GL30.glDeleteVertexArrays(vao.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] normals, float[] textureCoords) {
/*  90 */     int vertexArrayID = createVAO();
/*  91 */     storeInterleavedDataInVAO(vertexArrayID, vertices, normals, textureCoords);
/*  92 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] textureCoords) {
/*  96 */     int vertexArrayID = createVAO();
/*  97 */     storeInterleavedDataInVAO(vertexArrayID, vertices, textureCoords);
/*  98 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] textureCoords, int[] indices) {
/* 102 */     int vertexArrayID = createVAO();
/* 103 */     createIndicesVBO(indices);
/* 104 */     storeInterleavedDataInVAO(vertexArrayID, vertices, textureCoords);
/* 105 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] normals, float[] textureCoords, int[] indices)
/*     */   {
/* 110 */     int vertexArrayID = createVAO();
/* 111 */     createIndicesVBO(indices);
/* 112 */     storeInterleavedDataInVAO(vertexArrayID, vertices, normals, textureCoords);
/* 113 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices) {
/* 117 */     int vertexArrayID = createVAO();
/* 118 */     storePositionDataInVAO(vertexArrayID, vertices);
/* 119 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int createIndicesVBO(int[] indices) {
/* 123 */     IntBuffer indicesBuffer = BufferUtils.createIntBuffer(indices.length);
/* 124 */     indicesBuffer.put(indices);
/* 125 */     indicesBuffer.flip();
/* 126 */     int indicesBufferId = GL15.glGenBuffers();
/* 127 */     vboCache.add(Integer.valueOf(indicesBufferId));
/* 128 */     GL15.glBindBuffer(34963, indicesBufferId);
/* 129 */     GL15.glBufferData(34963, indicesBuffer, 35044);
/* 130 */     return indicesBufferId;
/*     */   }
/*     */   
/*     */   protected static void cleanUpModelMemory() {
/* 134 */     GL20.glDisableVertexAttribArray(0);
/* 135 */     GL15.glBindBuffer(34962, 0);
/* 136 */     GL30.glBindVertexArray(0);
/*     */     
/* 138 */     for (Iterator i$ = textureCache.iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 139 */       GL11.glDeleteTextures(id);
/*     */     }
/* 141 */     for (Iterator i$ = vboCache.iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 142 */       GL15.glDeleteBuffers(id);
/*     */     }
/* 144 */     for (Iterator i$ = vaoCache.keySet().iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 145 */       GL30.glDeleteVertexArrays(id);
/* 146 */       GL15.glDeleteBuffers(((Integer)vaoCache.get(Integer.valueOf(id))).intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   protected static RawModel loadModelFile(int id, String modelFile) {
/* 151 */     BufferedReader reader = openModelFile(modelFile);
/* 152 */     float[] vertices = readIntoArray(reader);
/* 153 */     float[] textureCoords = readIntoArray(reader);
/* 154 */     float[] normals = readIntoArray(reader);
/* 155 */     int[][] indicesData = readInAllIndices(reader);
/* 156 */     int vertexArrayID = loadModelToVAO(vertices, normals, textureCoords, indicesData[0]);
/* 157 */     RawModel model = new RawModel(id, vertexArrayID, indicesData[1]);
/*     */     
/* 159 */     addAditionalModelSettings(model, reader);
/*     */     try {
/* 161 */       reader.close();
/*     */     }
/*     */     catch (IOException e) {}
/* 164 */     return model;
/*     */   }
/*     */   
/*     */   protected static RawModel loadModelFile(File modelFile) {
/* 168 */     BufferedReader reader = openFile(modelFile);
/* 169 */     float[] vertices = readIntoArray(reader);
/* 170 */     float[] textureCoords = readIntoArray(reader);
/* 171 */     float[] normals = readIntoArray(reader);
/* 172 */     int[][] indicesData = readInAllIndices(reader);
/* 173 */     int vertexArrayID = loadModelToVAO(vertices, normals, textureCoords, indicesData[0]);
/* 174 */     RawModel model = new RawModel(0, vertexArrayID, indicesData[1]);
/*     */     
/* 176 */     addAditionalModelSettings(model, reader);
/*     */     try {
/* 178 */       reader.close();
/*     */     }
/*     */     catch (IOException e) {}
/* 181 */     return model;
/*     */   }
/*     */   
/*     */   private static BufferedReader openFile(File file) {
/* 185 */     BufferedReader reader = null;
/*     */     try {
/* 187 */       java.io.FileReader isr = new java.io.FileReader(file);
/* 188 */       reader = new BufferedReader(isr);
/*     */     } catch (java.io.FileNotFoundException e) {
/* 190 */       System.err.println("File not found!");
/* 191 */       e.printStackTrace();
/* 192 */       System.exit(-1);
/*     */     }
/* 194 */     return reader;
/*     */   }
/*     */   
/*     */   private static void storeInterleavedDataInVAO(int vaoID, float[] vertices, float[] normals, float[] textureCoords)
/*     */   {
/* 199 */     FloatBuffer interleavedData = interleaveDataInBuffer(vertices, normals, textureCoords);
/* 200 */     int bufferObjectID = GL15.glGenBuffers();
/* 201 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 202 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 203 */     GL15.glBufferData(34962, interleavedData, 35044);
/*     */     
/* 205 */     int vertexByteCount = 32;
/* 206 */     GL20.glVertexAttribPointer(0, 3, 5126, false, vertexByteCount, 0L);
/* 207 */     GL20.glVertexAttribPointer(1, 3, 5126, false, vertexByteCount, 12L);
/*     */     
/* 209 */     GL20.glVertexAttribPointer(2, 2, 5126, false, vertexByteCount, 24L);
/*     */     
/*     */ 
/* 212 */     GL15.glBindBuffer(34962, 0);
/* 213 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   private static void storePositionDataInVAO(int vaoID, float[] vertices) {
/* 217 */     FloatBuffer buffer = BufferUtils.createFloatBuffer(vertices.length);
/* 218 */     buffer.put(vertices);
/* 219 */     buffer.flip();
/* 220 */     int bufferObjectID = GL15.glGenBuffers();
/* 221 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 222 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 223 */     GL15.glBufferData(34962, buffer, 35044);
/* 224 */     GL20.glVertexAttribPointer(0, 3, 5126, false, 0, 0L);
/* 225 */     GL15.glBindBuffer(34962, 0);
/* 226 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   public static void updateInstanceVBO(int vbo, float[] data, int elementMaxCount, int elementSize, FloatBuffer buffer)
/*     */   {
/* 231 */     if (data.length >= elementMaxCount * elementSize) {
/* 232 */       System.err.println("TOO MUCH DATA UPDATED IN VBO!");
/* 233 */       return;
/*     */     }
/* 235 */     buffer.clear();
/* 236 */     buffer.put(data);
/* 237 */     buffer.flip();
/* 238 */     GL15.glBindBuffer(34962, vbo);
/* 239 */     GL15.glBufferData(34962, elementMaxCount * elementSize * 4, 35040);
/*     */     
/* 241 */     GL15.glBufferSubData(34962, 0L, buffer);
/* 242 */     GL15.glBindBuffer(34962, 0);
/*     */   }
/*     */   
/*     */   public static int createEmptyInstanceVBO(int vaoID, int attribute, int maxElementCount, int elementSize)
/*     */   {
/* 247 */     GL30.glBindVertexArray(vaoID);
/* 248 */     int vboID = GL15.glGenBuffers();
/* 249 */     vboCache.add(Integer.valueOf(vboID));
/* 250 */     GL15.glBindBuffer(34962, vboID);
/* 251 */     GL15.glBufferData(34962, maxElementCount * elementSize * 4, 35040);
/*     */     
/* 253 */     GL20.glVertexAttribPointer(attribute, elementSize, 5126, false, 0, 0L);
/* 254 */     org.lwjgl.opengl.GL33.glVertexAttribDivisor(attribute, 1);
/* 255 */     GL15.glBindBuffer(34962, 0);
/* 256 */     GL30.glBindVertexArray(0);
/* 257 */     return vboID;
/*     */   }
/*     */   
/*     */   public static int createInterleavedInstanceVBO(int vaoID, int startingAttribute, int maxElementCount, int... sizes)
/*     */   {
/* 262 */     GL30.glBindVertexArray(vaoID);
/* 263 */     int vboID = GL15.glGenBuffers();
/* 264 */     vboCache.add(Integer.valueOf(vboID));
/* 265 */     int totalElementSize = 0;
/* 266 */     for (int size : sizes) {
/* 267 */       totalElementSize += size;
/*     */     }
/* 269 */     totalElementSize *= 4;
/* 270 */     GL15.glBindBuffer(34962, vboID);
/* 271 */     GL15.glBufferData(34962, maxElementCount * totalElementSize, 35040);
/*     */     
/*     */ 
/* 274 */     int offset = 0;
/* 275 */     for (int i = 0; i < sizes.length; i++) {
/* 276 */       GL20.glVertexAttribPointer(i + startingAttribute, sizes[i], 5126, false, totalElementSize, offset);
/*     */       
/* 278 */       org.lwjgl.opengl.GL33.glVertexAttribDivisor(i + startingAttribute, 1);
/* 279 */       offset += sizes[i] * 4;
/*     */     }
/*     */     
/* 282 */     GL15.glBindBuffer(34962, 0);
/* 283 */     GL30.glBindVertexArray(0);
/* 284 */     return vboID;
/*     */   }
/*     */   
/*     */   private static void storeInterleavedDataInVAO(int vaoID, float[] vertices, float[] textureCoords) {
/* 288 */     FloatBuffer interleavedData = interleaveDataInBuffer(vertices, textureCoords);
/* 289 */     int bufferObjectID = GL15.glGenBuffers();
/* 290 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 291 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 292 */     GL15.glBufferData(34962, interleavedData, 35044);
/*     */     
/* 294 */     int vertexByteCount = 20;
/* 295 */     GL20.glVertexAttribPointer(0, 3, 5126, false, vertexByteCount, 0L);
/* 296 */     GL20.glVertexAttribPointer(1, 2, 5126, false, vertexByteCount, 12L);
/*     */     
/*     */ 
/* 299 */     GL15.glBindBuffer(34962, 0);
/* 300 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   private static FloatBuffer interleaveDataInBuffer(float[] vertices, float[] normals, float[] textureCoords)
/*     */   {
/* 305 */     FloatBuffer interleavedBuffer = BufferUtils.createFloatBuffer(vertices.length + normals.length + textureCoords.length);
/*     */     
/* 307 */     int veticesPointer = 0;
/* 308 */     int normalsPointer = 0;
/* 309 */     int texturePointer = 0;
/* 310 */     for (int i = 0; i < vertices.length / 3; i++) {
/* 311 */       interleavedBuffer.put(new float[] { vertices[(veticesPointer++)], vertices[(veticesPointer++)], vertices[(veticesPointer++)] });
/*     */       
/* 313 */       interleavedBuffer.put(new float[] { normals[(normalsPointer++)], normals[(normalsPointer++)], normals[(normalsPointer++)] });
/*     */       
/* 315 */       interleavedBuffer.put(new float[] { textureCoords[(texturePointer++)], textureCoords[(texturePointer++)] });
/*     */     }
/*     */     
/* 318 */     interleavedBuffer.flip();
/* 319 */     return interleavedBuffer;
/*     */   }
/*     */   
/*     */   private static FloatBuffer interleaveDataInBuffer(float[] vertices, float[] textureCoords) {
/* 323 */     FloatBuffer interleavedBuffer = BufferUtils.createFloatBuffer(vertices.length + textureCoords.length);
/*     */     
/* 325 */     int veticesPointer = 0;
/* 326 */     int texturePointer = 0;
/* 327 */     for (int i = 0; i < vertices.length / 3; i++) {
/* 328 */       interleavedBuffer.put(new float[] { vertices[(veticesPointer++)], vertices[(veticesPointer++)], vertices[(veticesPointer++)] });
/*     */       
/* 330 */       interleavedBuffer.put(new float[] { textureCoords[(texturePointer++)], textureCoords[(texturePointer++)] });
/*     */     }
/*     */     
/* 333 */     interleavedBuffer.flip();
/* 334 */     return interleavedBuffer;
/*     */   }
/*     */   
/*     */   private static int createVAO() {
/* 338 */     int vertexArrayID = GL30.glGenVertexArrays();
/* 339 */     GL30.glBindVertexArray(vertexArrayID);
/* 340 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   private static BufferedReader openModelFile(String fileStem) {
/* 344 */     BufferedReader reader = null;
/*     */     try {
/* 346 */       java.io.InputStream in = Class.class.getResourceAsStream("/res/" + fileStem + ".csv");
/*     */       
/* 348 */       java.io.InputStreamReader isr = new java.io.InputStreamReader(in);
/* 349 */       reader = new BufferedReader(isr);
/*     */     } catch (Exception e) {
/* 351 */       e.printStackTrace();
/* 352 */       System.out.println();
/* 353 */       System.err.println("Unable to find model file: " + fileStem);
/* 354 */       System.exit(-1);
/*     */     }
/* 356 */     return reader;
/*     */   }
/*     */   
/*     */   private static float[] readIntoArray(BufferedReader reader) {
/* 360 */     float[] theArray = null;
/*     */     try {
/* 362 */       String line1 = reader.readLine();
/* 363 */       if (line1.contains("FP")) {
/* 364 */         line1 = reader.readLine();
/*     */       }
/* 366 */       theArray = new float[Integer.valueOf(line1).intValue()];
/* 367 */       String[] line = reader.readLine().split(",");
/* 368 */       for (int i = 0; i < theArray.length; i++) {
/* 369 */         theArray[i] = Float.valueOf(line[i]).floatValue();
/*     */       }
/*     */     } catch (Exception e) {
/* 372 */       e.printStackTrace();
/* 373 */       System.err.println("Problem loading file data!");
/* 374 */       System.exit(-1);
/*     */     }
/* 376 */     return theArray;
/*     */   }
/*     */   
/*     */   private static int[][] readInAllIndices(BufferedReader reader) {
/*     */     try {
/* 381 */       List<Integer> listOfIndices = new ArrayList();
/* 382 */       List<Integer> listOfLengths = new ArrayList();
/* 383 */       listOfLengths.add(Integer.valueOf(reader.readLine()));
/* 384 */       String[] line = reader.readLine().split(",");
/* 385 */       for (int i = 0; i < line.length; i++) {
/* 386 */         listOfIndices.add(Integer.valueOf(line[i]));
/*     */       }
/*     */       
/*     */       String fullLine;
/* 390 */       while (((fullLine = reader.readLine()) != null) && (!fullLine.equals("NEWSECTION"))) {
/* 391 */         line = fullLine.split(",");
/* 392 */         int lod = Integer.valueOf(line[0]).intValue();
/* 393 */         while (listOfLengths.size() < lod) {
/* 394 */           listOfLengths.add(Integer.valueOf(0));
/*     */         }
/* 396 */         listOfLengths.add(Integer.valueOf(Integer.valueOf(line[1]).intValue()));
/* 397 */         line = reader.readLine().split(",");
/* 398 */         for (int i = 0; i < line.length; i++) {
/* 399 */           listOfIndices.add(Integer.valueOf(line[i]));
/*     */         }
/*     */       }
/* 402 */       int[] indicesArray = new int[listOfIndices.size()];
/* 403 */       for (int i = 0; i < indicesArray.length; i++) {
/* 404 */         indicesArray[i] = ((Integer)listOfIndices.get(i)).intValue();
/*     */       }
/* 406 */       int[] lengthsArray = new int[listOfLengths.size()];
/* 407 */       for (int i = 0; i < lengthsArray.length; i++) {
/* 408 */         lengthsArray[i] = ((Integer)listOfLengths.get(i)).intValue();
/*     */       }
/* 410 */       return new int[][] { indicesArray, lengthsArray };
/*     */     }
/*     */     catch (Exception e) {
/* 413 */       e.printStackTrace();
/* 414 */       System.err.println("Problem loading indices data!");
/* 415 */       System.exit(-1); }
/* 416 */     return (int[][])null;
/*     */   }
/*     */   
/*     */   private static int loadTexture(String fileName, boolean mipmap)
/*     */   {
/* 421 */     Texture texture = null;
/*     */     try {
/* 423 */       texture = org.newdawn.slick.opengl.TextureLoader.getTexture("PNG", Class.class.getResourceAsStream("/res/" + fileName + ".png"));
/*     */     }
/*     */     catch (Exception e) {
/* 426 */       e.printStackTrace();
/* 427 */       System.err.println("Tried to load texture " + fileName + ".png , didn't work");
/* 428 */       System.exit(-1);
/*     */     }
/* 430 */     if (mipmap) {
/* 431 */       GL30.glGenerateMipmap(3553);
/* 432 */       GL11.glTexParameteri(3553, 10240, 9729);
/* 433 */       GL11.glTexParameteri(3553, 10241, 9987);
/*     */       
/* 435 */       GL11.glTexParameterf(3553, 34049, -0.5F);
/*     */     }
/* 437 */     textureCache.add(Integer.valueOf(texture.getTextureID()));
/* 438 */     return texture.getTextureID();
/*     */   }
/*     */   
/*     */   private static void addAditionalModelSettings(RawModel model, BufferedReader reader) {
/* 442 */     String sectionHeader = null;
/*     */     for (;;) {
/*     */       try {
/* 445 */         sectionHeader = reader.readLine();
/*     */       } catch (IOException e) {
/* 447 */         e.printStackTrace();
/* 448 */         System.exit(-1);
/*     */       }
/* 450 */       if (sectionHeader == null)
/* 451 */         return;
/* 452 */       if (!sectionHeader.equals("<CDOS>")) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static int loadTexture(File file)
/*     */   {
/* 459 */     Texture texture = null;
/*     */     try {
/* 461 */       java.io.FileInputStream stream = new java.io.FileInputStream(file);
/* 462 */       texture = org.newdawn.slick.opengl.TextureLoader.getTexture("PNG", stream);
/* 463 */       stream.close();
/*     */     } catch (Exception e) {
/* 465 */       e.printStackTrace();
/* 466 */       System.err.println("Tried to load texture " + file.getName() + ", didn't work");
/* 467 */       System.exit(-1);
/*     */     }
/* 469 */     textureCache.add(Integer.valueOf(texture.getTextureID()));
/* 470 */     return texture.getTextureID();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\epicRenderEngine\Loader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */