/*    */ package epicRenderEngine;
/*    */ 
/*    */ import atmosphere.Sky;
/*    */ import blueprintInterfaces.RawModel;
/*    */ import entitiesInterfaces.AnimatedEntityInterface;
/*    */ import entitiesInterfaces.HumanEntityInterface;
/*    */ import entitiesInterfaces.Light;
/*    */ import entitiesInterfaces.StaticEntityInterface;
/*    */ import java.awt.Canvas;
/*    */ import java.util.List;
/*    */ import processing.LightSorter;
/*    */ import processing.RenderProcessor;
/*    */ import renderPrograms.MasterRenderer;
/*    */ import terrains.TerrainBlock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderEngine
/*    */ {
/*    */   private RenderProcessor processor;
/*    */   private MasterRenderer renderer;
/*    */   private LightSorter lightSorter;
/*    */   
/*    */   public RenderEngine(Camera camera, Canvas canvas)
/*    */   {
/* 27 */     DisplayManager.setUpDisplay(canvas);
/* 28 */     this.renderer = new MasterRenderer(camera);
/* 29 */     this.processor = new RenderProcessor(this.renderer, camera);
/* 30 */     this.lightSorter = new LightSorter(4, camera);
/*    */   }
/*    */   
/*    */ 
/*    */   public void updateDisplay() {}
/*    */   
/*    */ 
/*    */   public static void goFullscreen() {}
/*    */   
/*    */ 
/*    */   public static void goWindowMode(int width, int height)
/*    */   {
/* 42 */     DisplayManager.goToWindowDisplay(width, height);
/*    */   }
/*    */   
/*    */   public static void goWireframe(boolean wireframe) {
/* 46 */     OpenglUtils.goWireframe(wireframe);
/*    */   }
/*    */   
/*    */   public static RawModel loadModelFile(int id, String modelFile) {
/* 50 */     return Loader.loadModelFile(id, modelFile);
/*    */   }
/*    */   
/*    */   public static int loadTexture(String texture) {
/* 54 */     return Loader.loadTexture(texture);
/*    */   }
/*    */   
/*    */   public static float getDeltaInSeconds() {
/* 58 */     return DisplayManager.getDeltaInSeconds();
/*    */   }
/*    */   
/*    */   public void processStaticEntity(StaticEntityInterface instance) {
/* 62 */     this.processor.processStaticInstance(instance);
/*    */   }
/*    */   
/*    */   public void processAnimatedEntity(AnimatedEntityInterface instance) {
/* 66 */     this.processor.processAnimatedInstance(instance);
/*    */   }
/*    */   
/*    */   public void processHumanEntity(HumanEntityInterface instance) {
/* 70 */     this.processor.processHumanInstance(instance);
/*    */   }
/*    */   
/*    */   public void processTerrainBlock(TerrainBlock terrainBlock) {
/* 74 */     this.processor.processTerrainBlock(terrainBlock);
/*    */   }
/*    */   
/*    */   public void render(Sky sky, List<Light> closeLights)
/*    */   {
/* 79 */     for (Light light : closeLights) {
/* 80 */       this.lightSorter.sortLight(light);
/*    */     }
/* 82 */     this.processor.render(sky, this.lightSorter.getClosestLights());
/* 83 */     this.lightSorter.reset();
/*    */   }
/*    */   
/*    */   public void updateView() {
/* 87 */     this.processor.updateFrustum();
/*    */   }
/*    */   
/*    */   public void closeDisplay() {
/* 91 */     this.processor.cleanUp();
/* 92 */     Loader.cleanUpModelMemory();
/* 93 */     DisplayManager.closeWindow();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\epicRenderEngine\RenderEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */