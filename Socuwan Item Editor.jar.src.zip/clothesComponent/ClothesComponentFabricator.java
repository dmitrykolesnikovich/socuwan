/*    */ package clothesComponent;
/*    */ 
/*    */ import backend.Item;
/*    */ import components.Component;
/*    */ import components.ComponentFabricator;
/*    */ 
/*    */ 
/*    */ public class ClothesComponentFabricator
/*    */   implements ComponentFabricator
/*    */ {
/*    */   public Component createNewComponent(Item item)
/*    */   {
/* 13 */     return new ClotheBlueprint(item);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\ClothesComponentFabricator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */