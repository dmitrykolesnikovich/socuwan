/*     */ package clothesComponent;
/*     */ 
/*     */ import frontend.FileInList;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.Configs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextureChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a texture!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   private TexturePanel panel;
/*     */   
/*     */   public TextureChooseScreen(TexturePanel panel, boolean diffuse)
/*     */   {
/*  39 */     this.panel = panel;
/*  40 */     setUpFrame();
/*  41 */     addLabel();
/*  42 */     addFileList(getAllIconFiles());
/*  43 */     addButton(diffuse);
/*  44 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  48 */     this.frame = new JDialog();
/*  49 */     this.frame.setAlwaysOnTop(true);
/*  50 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  51 */     this.frame.setSize(300, 500);
/*  52 */     this.frame.setResizable(false);
/*  53 */     this.frame.setLocationRelativeTo(null);
/*  54 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  58 */     GridBagConstraints gc = new GridBagConstraints();
/*  59 */     gc.gridx = 0;
/*  60 */     gc.gridy = 1;
/*  61 */     gc.weightx = 1.0D;
/*  62 */     gc.weighty = 1.0D;
/*     */     
/*  64 */     FileInList[] data = getAllFilesInList(files);
/*  65 */     this.list = new JList(data);
/*  66 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  67 */     this.list.setSelectionMode(1);
/*  68 */     this.list.setLayoutOrientation(0);
/*  69 */     this.list.setVisibleRowCount(-1);
/*  70 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  71 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  72 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  76 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  77 */     for (int i = 0; i < listedFiles.length; i++) {
/*  78 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  80 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  84 */     JLabel text = new JLabel("Choose a texture!");
/*  85 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  86 */     GridBagConstraints gc = new GridBagConstraints();
/*  87 */     gc.gridx = 0;
/*  88 */     gc.gridy = 0;
/*  89 */     gc.weightx = 1.0D;
/*  90 */     gc.weighty = 0.4D;
/*  91 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton(final boolean diffuse) {
/*  95 */     this.confirm = new JButton("Open");
/*  96 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/*  97 */     GridBagConstraints gc = new GridBagConstraints();
/*  98 */     gc.gridx = 0;
/*  99 */     gc.gridy = 2;
/* 100 */     gc.weightx = 1.0D;
/* 101 */     gc.weighty = 0.4D;
/* 102 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 106 */         if (!TextureChooseScreen.this.list.isSelectionEmpty()) {
/* 107 */           File chosen = ((FileInList)TextureChooseScreen.this.list.getSelectedValue()).getFile();
/* 108 */           TextureChooseScreen.this.panel.setNewIcon(chosen, diffuse);
/* 109 */           TextureChooseScreen.this.frame.setVisible(false);
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 114 */     });
/* 115 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllIconFiles() {
/* 119 */     File[] allFiles = Configs.TEXTURES_REPOS.listFiles();
/* 120 */     List<File> goodFiles = new ArrayList();
/* 121 */     for (File file : allFiles) {
/* 122 */       if (file.getName().endsWith(".png")) {
/* 123 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 126 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\TextureChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */