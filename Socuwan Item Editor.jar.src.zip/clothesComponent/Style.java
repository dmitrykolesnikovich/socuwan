/*    */ package clothesComponent;
/*    */ 
/*    */ public enum Style
/*    */ {
/*  5 */   HOLY("Holy"), 
/*  6 */   ANCIENT("Ancient"), 
/*  7 */   TRIBAL("Tribal"), 
/*  8 */   SHADOW("Shadow"), 
/*  9 */   SPIRIT("Spirit"), 
/* 10 */   NO_STYLE("No Style");
/*    */   
/*    */   private String name;
/*    */   
/*    */   private Style(String name) {
/* 15 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 19 */     return this.name;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 23 */     return this.name;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\Style.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */