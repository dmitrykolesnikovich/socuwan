/*    */ package clothesComponent;
/*    */ 
/*    */ public enum BodyPart
/*    */ {
/*  5 */   HIP("Hip"), 
/*  6 */   WAIST("Waist"), 
/*  7 */   CHEST("Chest"), 
/*  8 */   HEAD("Head"), 
/*  9 */   UPPER_RIGHT_ARM("Up. Right Arm"), 
/* 10 */   LOWER_RIGHT_ARM("Low. Right Arm"), 
/* 11 */   RIGHT_HAND("Right Hand"), 
/* 12 */   UPPER_LEFT_ARM("Up. Left Arm"), 
/* 13 */   LOWER_LEFT_ARM("Low. Left Arm"), 
/* 14 */   LEFT_HAND("Left Hand"), 
/* 15 */   UPPER_RIGHT_LEG("Up. Right Leg"), 
/* 16 */   LOWER_RIGHT_LEG("Low. Right Leg"), 
/* 17 */   RIGHT_FOOT("Right Foot"), 
/* 18 */   UPPER_LEFT_LEG("Up. Left Leg"), 
/* 19 */   LOWER_LEFT_LEG("Low. Left Leg"), 
/* 20 */   LEFT_FOOT("Left Foot");
/*    */   
/*    */   private String name;
/*    */   
/*    */   private BodyPart(String name)
/*    */   {
/* 26 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 30 */     return this.name;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\BodyPart.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */