/*    */ package clothesComponent;
/*    */ 
/*    */ import accessories.ClothesSection;
/*    */ import backend.Item;
/*    */ import components.ComponentPanel;
/*    */ import instances.HumanEntity;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Font;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import javax.swing.BorderFactory;
/*    */ import main.MainApp;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClothesPanel
/*    */   extends ComponentPanel
/*    */ {
/* 22 */   public static final Font FONT = new Font("Segoe UI", 1, 15);
/*    */   private ClotheBlueprint clothesData;
/*    */   
/*    */   public ClothesPanel(ClotheBlueprint component, Item item)
/*    */   {
/* 27 */     setPreferredSize(new Dimension(405, 630));
/* 28 */     setBorder(BorderFactory.createTitledBorder("Clothes Settings"));
/* 29 */     setLayout(new GridBagLayout());
/* 30 */     this.clothesData = component;
/* 31 */     GridBagConstraints gc = new GridBagConstraints();
/* 32 */     gc.fill = 1;
/* 33 */     gc.gridx = 0;
/* 34 */     gc.gridy = 0;
/* 35 */     gc.weightx = 1.0D;
/* 36 */     gc.weighty = 0.10000000149011612D;
/* 37 */     add(new ClothesInfoPanel(component), gc);
/* 38 */     gc.gridy = 1;
/* 39 */     gc.weighty = 1.5D;
/* 40 */     add(new ClothesSectionsPanel(component, item), gc);
/*    */   }
/*    */   
/*    */   public void destroy()
/*    */   {
/* 45 */     this.clothesData.getTextureAtlas().deleteFiles();
/* 46 */     for (ClothesSection section : this.clothesData.getSections()) {
/* 47 */       section.destroy();
/*    */     }
/* 49 */     MainApp.character.unequip();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\ClothesPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */