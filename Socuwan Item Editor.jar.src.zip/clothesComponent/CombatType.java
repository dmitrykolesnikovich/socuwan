/*    */ package clothesComponent;
/*    */ 
/*    */ import materials.Material;
/*    */ import materials.MaterialSet;
/*    */ import materials.Tier;
/*    */ 
/*    */ public enum CombatType
/*    */ {
/*  9 */   MAGE("Mage", MaterialSet.GEMS, MaterialSet.WOODS, MaterialSet.FLAXES), 
/* 10 */   RANGED("Ranged", MaterialSet.WOODS, MaterialSet.FLAXES, MaterialSet.FLAXES), 
/* 11 */   MELEE("Melee", MaterialSet.METALS, MaterialSet.GEMS, MaterialSet.METALS), 
/* 12 */   NON_COMBAT("Non-Combat", null, null, null);
/*    */   
/*    */   private MaterialSet primaryWeaponMatSet;
/*    */   private MaterialSet secondaryWeaponMatSet;
/*    */   private MaterialSet armourMatSet;
/*    */   private String name;
/*    */   
/*    */   private CombatType(String name, MaterialSet primaryWeaponMatSet, MaterialSet secondaryWeaponMatSet, MaterialSet armourMatSet) {
/* 20 */     this.primaryWeaponMatSet = primaryWeaponMatSet;
/* 21 */     this.secondaryWeaponMatSet = secondaryWeaponMatSet;
/* 22 */     this.armourMatSet = armourMatSet;
/* 23 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Material getPrimaryWeaponMaterial(Tier tier) {
/* 27 */     return this.primaryWeaponMatSet.getMaterial(tier);
/*    */   }
/*    */   
/*    */   public Material getSecondaryWeaponMaterial(Tier tier) {
/* 31 */     return this.secondaryWeaponMatSet.getMaterial(tier);
/*    */   }
/*    */   
/*    */   public Material getArmourMaterialSet(Tier tier) {
/* 35 */     return this.armourMatSet.getMaterial(tier);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 39 */     return this.name;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 43 */     return this.name;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\CombatType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */