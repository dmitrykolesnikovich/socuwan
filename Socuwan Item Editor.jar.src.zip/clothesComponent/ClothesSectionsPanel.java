/*    */ package clothesComponent;
/*    */ 
/*    */ import accessories.ClothesSection;
/*    */ import backend.Item;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClothesSectionsPanel
/*    */   extends JPanel
/*    */ {
/*    */   private static final int HEIGHT = 450;
/*    */   private ClotheBlueprint clothesComponent;
/*    */   
/*    */   public ClothesSectionsPanel(ClotheBlueprint clothesComp, final Item item)
/*    */   {
/* 23 */     this.clothesComponent = clothesComp;
/* 24 */     super.setPreferredSize(new Dimension(405, 450));
/* 25 */     JButton addButton = new JButton("Add Section");
/* 26 */     addButton.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent arg0)
/*    */       {
/* 30 */         ClothesSection section = new ClothesSection(item.getSuperFile());
/* 31 */         ClothesSectionsPanel.this.clothesComponent.addSection(section);
/* 32 */         ClothesSectionsPanel.this.add(new ClothesSectionPanel(section, ClothesSectionsPanel.this.clothesComponent, ClothesSectionsPanel.this));
/*    */         
/* 34 */         ClothesSectionsPanel.this.validate();
/* 35 */         ClothesSectionsPanel.this.repaint();
/*    */       }
/*    */       
/* 38 */     });
/* 39 */     add(addButton);
/* 40 */     ClothesSection[] sections = this.clothesComponent.getSections();
/* 41 */     for (ClothesSection section : sections) {
/* 42 */       add(new ClothesSectionPanel(section, this.clothesComponent, this));
/*    */     }
/*    */   }
/*    */   
/*    */   public void removePanel(ClothesSectionPanel panel) {
/* 47 */     remove(panel);
/* 48 */     validate();
/* 49 */     repaint();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\ClothesSectionsPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */