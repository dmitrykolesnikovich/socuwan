/*     */ package clothesComponent;
/*     */ 
/*     */ import frontend.JFloatSlider;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TexturePanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final int TEXTURE_PREVIEW_SIZE = 40;
/*     */   private ClotheBlueprint clothesComponent;
/*     */   private ModelTexture texture;
/*     */   private JLabel diffuseIcon;
/*     */   private JLabel extraIcon;
/*     */   private JCheckBox glows;
/*     */   
/*     */   public TexturePanel(ClotheBlueprint component)
/*     */   {
/*  46 */     this.clothesComponent = component;
/*  47 */     this.texture = this.clothesComponent.getTextureAtlas();
/*  48 */     setLayout(new GridBagLayout());
/*  49 */     GridBagConstraints gc = new GridBagConstraints();
/*  50 */     gc.fill = 1;
/*  51 */     gc.gridx = 0;
/*  52 */     gc.gridy = 0;
/*  53 */     gc.weightx = 1.0D;
/*  54 */     gc.weighty = 1.0D;
/*  55 */     boolean showGlow = setUpIconPanel(gc);
/*  56 */     gc.gridx = 1;
/*  57 */     gc.weightx = 4.0D;
/*  58 */     setUpSettingsPanel(gc, showGlow);
/*     */   }
/*     */   
/*     */   public void setNewIcon(File image, boolean diffuse)
/*     */   {
/*     */     try {
/*  64 */       BufferedImage myPicture = ImageIO.read(image);
/*  65 */       ImageIcon original = new ImageIcon(myPicture);
/*  66 */       ImageIcon resized = resizeImage(original);
/*  67 */       if (diffuse) {
/*  68 */         this.diffuseIcon.setIcon(resized);
/*  69 */         this.texture.setDiffuseFile(image);
/*     */       } else {
/*  71 */         this.glows.setVisible(true);
/*  72 */         this.extraIcon.setIcon(resized);
/*  73 */         this.texture.setSpecularFile(image);
/*     */       }
/*     */     } catch (Exception e) {
/*  76 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean setUpIconPanel(GridBagConstraints gc) {
/*  81 */     JPanel iconPanel = new JPanel();
/*  82 */     iconPanel.setLayout(new GridBagLayout());
/*  83 */     GridBagConstraints gc2 = new GridBagConstraints();
/*  84 */     gc2.fill = 1;
/*  85 */     gc2.gridx = 0;
/*  86 */     gc2.gridy = 0;
/*  87 */     gc2.weightx = 1.0D;
/*  88 */     gc2.weighty = 1.0D;
/*  89 */     File diffuseFile = this.texture.getDiffuseFile();
/*  90 */     if (diffuseFile != null) {
/*     */       try {
/*  92 */         this.diffuseIcon = createIcon(new FileInputStream(diffuseFile), true);
/*     */       } catch (FileNotFoundException e) {
/*  94 */         e.printStackTrace();
/*     */       }
/*     */     } else {
/*  97 */       this.diffuseIcon = createIcon(TexturePanel.class.getResourceAsStream("/res/defaultDiffuseTexture.png"), true);
/*     */     }
/*     */     
/* 100 */     iconPanel.add(this.diffuseIcon, gc2);
/* 101 */     gc2.gridy = 1;
/* 102 */     File specularFile = this.texture.getSpecularFile();
/* 103 */     if (specularFile != null) {
/*     */       try {
/* 105 */         this.extraIcon = createIcon(new FileInputStream(specularFile), false);
/*     */       } catch (FileNotFoundException e) {
/* 107 */         e.printStackTrace();
/*     */       }
/*     */     } else {
/* 110 */       this.extraIcon = createIcon(TexturePanel.class.getResourceAsStream("/res/defaultExtraTexture.png"), false);
/*     */     }
/*     */     
/* 113 */     iconPanel.add(this.extraIcon, gc2);
/*     */     
/* 115 */     add(iconPanel, gc);
/* 116 */     if (specularFile != null) {
/* 117 */       return true;
/*     */     }
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   private void setUpSettingsPanel(GridBagConstraints gc, boolean showGlow)
/*     */   {
/* 124 */     JPanel settingsPanel = new JPanel();
/* 125 */     settingsPanel.setLayout(new GridBagLayout());
/* 126 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 127 */     gc2.fill = 1;
/* 128 */     gc2.gridx = 0;
/* 129 */     gc2.gridy = 0;
/* 130 */     gc2.weightx = 1.0D;
/* 131 */     gc2.weighty = 1.0D;
/* 132 */     settingsPanel.add(createShineSlider(), gc2);
/* 133 */     gc2.gridy = 1;
/* 134 */     settingsPanel.add(createReflectivitySlider(), gc2);
/* 135 */     gc2.gridy = 2;
/* 136 */     final JCheckBox transparency = new JCheckBox("Has Transparency?");
/* 137 */     transparency.setFont(ClothesPanel.FONT);
/* 138 */     transparency.setSelected(this.texture.hasTransparency());
/* 139 */     transparency.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 143 */         TexturePanel.this.texture.setTransparent(transparency.isSelected());
/*     */       }
/* 145 */     });
/* 146 */     settingsPanel.add(transparency, gc2);
/* 147 */     gc2.gridy = 3;
/* 148 */     this.glows = new JCheckBox("Glows?");
/* 149 */     this.glows.setFont(ClothesPanel.FONT);
/* 150 */     this.glows.setSelected(this.texture.hasGlow());
/* 151 */     this.glows.setVisible(showGlow);
/* 152 */     this.glows.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 156 */         TexturePanel.this.texture.setGlows(TexturePanel.this.glows.isSelected());
/*     */       }
/* 158 */     });
/* 159 */     settingsPanel.add(this.glows, gc2);
/* 160 */     add(settingsPanel, gc);
/*     */   }
/*     */   
/*     */   private JPanel createReflectivitySlider()
/*     */   {
/* 165 */     return createSlider("Reflectivity:", 1.0F, reverseConvertReflectValue(this.texture.getReflectivity()[0]), false);
/*     */   }
/*     */   
/*     */   private JPanel createShineSlider()
/*     */   {
/* 170 */     return createSlider("Shinyness:", 1.0F, reverseConvertShineValue(this.texture.getShininess()), true);
/*     */   }
/*     */   
/*     */   private JPanel createSlider(String name, float maximum, float start, boolean shine) {
/* 174 */     JPanel panelSlider = new JPanel();
/* 175 */     panelSlider.setLayout(new GridBagLayout());
/* 176 */     GridBagConstraints gc = new GridBagConstraints();
/* 177 */     gc.fill = 1;
/* 178 */     gc.gridx = 0;
/* 179 */     gc.gridy = 0;
/* 180 */     gc.weightx = 1.0D;
/* 181 */     gc.weighty = 1.0D;
/*     */     
/* 183 */     JLabel nameLabel = new JLabel(name);
/* 184 */     nameLabel.setFont(ClothesPanel.FONT);
/* 185 */     nameLabel.setPreferredSize(new Dimension(90, 10));
/* 186 */     panelSlider.add(nameLabel, gc);
/* 187 */     gc.gridx = 1;
/* 188 */     final JLabel valueReading = new JLabel();
/* 189 */     valueReading.setPreferredSize(new Dimension(40, 10));
/* 190 */     valueReading.setFont(ClothesPanel.FONT);
/* 191 */     final JFloatSlider slider = new JFloatSlider(0, 0.0F, maximum, start);
/* 192 */     if (shine) {
/* 193 */       valueReading.setText(limitChars(Float.toString(slider.getActualValue()), 5));
/*     */     } else {
/* 195 */       valueReading.setText(limitChars(Float.toString(convertReflectValue(slider.getActualValue())), 5));
/*     */     }
/*     */     
/* 198 */     if (shine) {
/* 199 */       slider.addChangeListener(new ChangeListener()
/*     */       {
/*     */         public void stateChanged(ChangeEvent arg0)
/*     */         {
/* 203 */           valueReading.setText(TexturePanel.this.limitChars(Float.toString(slider.getActualValue()), 5));
/* 204 */           TexturePanel.this.texture.setShine(TexturePanel.this.convertShineValue(slider.getActualValue()));
/*     */         }
/*     */       });
/*     */     } else {
/* 208 */       slider.addChangeListener(new ChangeListener()
/*     */       {
/*     */         public void stateChanged(ChangeEvent arg0)
/*     */         {
/* 212 */           valueReading.setText(TexturePanel.this.limitChars(Float.toString(TexturePanel.access$400(TexturePanel.this, slider.getActualValue())), 5));
/*     */           
/* 214 */           TexturePanel.this.texture.setReflectivity(TexturePanel.this.convertReflectValue(slider.getActualValue()));
/*     */         }
/*     */       });
/*     */     }
/* 218 */     panelSlider.add(slider, gc);
/* 219 */     gc.gridx = 2;
/* 220 */     panelSlider.add(valueReading, gc);
/* 221 */     return panelSlider;
/*     */   }
/*     */   
/*     */   private String limitChars(String original, int limit)
/*     */   {
/* 226 */     if (original.length() <= limit) {
/* 227 */       return original;
/*     */     }
/* 229 */     return original.substring(0, 5);
/*     */   }
/*     */   
/*     */ 
/*     */   private JLabel createIcon(InputStream stream, final boolean diffuse)
/*     */   {
/* 235 */     BufferedImage myPicture = null;
/*     */     try {
/* 237 */       myPicture = ImageIO.read(stream);
/* 238 */       stream.close();
/*     */     } catch (IOException e) {
/* 240 */       e.printStackTrace();
/*     */     }
/* 242 */     ImageIcon original = new ImageIcon(myPicture);
/* 243 */     ImageIcon resized = resizeImage(original);
/* 244 */     JLabel icon = new JLabel(resized);
/* 245 */     icon.addMouseListener(new MouseListener()
/*     */     {
/*     */       public void mouseClicked(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseEntered(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseExited(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mousePressed(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void mouseReleased(MouseEvent arg0)
/*     */       {
/* 264 */         new TextureChooseScreen(TexturePanel.this, diffuse);
/*     */       }
/* 266 */     });
/* 267 */     icon.setPreferredSize(new Dimension(40, 40));
/* 268 */     return icon;
/*     */   }
/*     */   
/*     */   private ImageIcon resizeImage(ImageIcon original) {
/* 272 */     Image img = original.getImage();
/* 273 */     Image resized = getScaledImage(img, 40, 40);
/* 274 */     return new ImageIcon(resized);
/*     */   }
/*     */   
/*     */   private Image getScaledImage(Image srcImg, int w, int h) {
/* 278 */     BufferedImage resizedImg = new BufferedImage(w, h, 2);
/* 279 */     Graphics2D g2 = resizedImg.createGraphics();
/* 280 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     
/* 282 */     g2.drawImage(srcImg, 0, 0, w, h, null);
/* 283 */     g2.dispose();
/* 284 */     return resizedImg;
/*     */   }
/*     */   
/*     */   private float convertShineValue(float sliderValue) {
/* 288 */     float value = (float)(sliderValue * 1.5707963267948966D);
/* 289 */     value = (float)Math.sin(value);
/* 290 */     value = (float)Math.sin(value * 1.5707963267948966D);
/* 291 */     value *= 100.0F;
/* 292 */     return 100.0F - value;
/*     */   }
/*     */   
/*     */   private float reverseConvertShineValue(float shine)
/*     */   {
/* 297 */     float value = 100.0F - shine;
/* 298 */     value /= 100.0F;
/* 299 */     value = (float)Math.asin(value);
/* 300 */     value = (float)(value / 1.5707963267948966D);
/* 301 */     value = (float)Math.asin(value);
/* 302 */     value = (float)(value / 1.5707963267948966D);
/* 303 */     return value;
/*     */   }
/*     */   
/*     */   private float convertReflectValue(float sliderValue) {
/* 307 */     float value = sliderValue * sliderValue;
/* 308 */     value *= 5.0F;
/* 309 */     return value;
/*     */   }
/*     */   
/*     */   private float reverseConvertReflectValue(float reflectValue) {
/* 313 */     float value = reflectValue / 5.0F;
/* 314 */     return (float)Math.sqrt(value);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\TexturePanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */