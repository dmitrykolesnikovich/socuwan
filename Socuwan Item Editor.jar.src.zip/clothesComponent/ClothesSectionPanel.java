/*     */ package clothesComponent;
/*     */ 
/*     */ import accessories.ClothesSection;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClothesSectionPanel
/*     */   extends JPanel
/*     */ {
/*  25 */   public static final Color CHOSEN_COLOR = new Color(0, 155, 0);
/*  26 */   public static final Color UNCHOSEN_COLOR = new Color(155, 0, 0);
/*     */   
/*  28 */   public static final Font FONT = new Font("Segoe UI", 1, 11);
/*     */   
/*     */   private static final int HEIGHT = 48;
/*     */   
/*     */   private ClothesSection section;
/*     */   private ClotheBlueprint clothe;
/*     */   private ClothesSectionsPanel panel;
/*     */   
/*     */   public ClothesSectionPanel(ClothesSection section, ClotheBlueprint clothe, ClothesSectionsPanel panel)
/*     */   {
/*  38 */     this.panel = panel;
/*  39 */     this.section = section;
/*  40 */     this.clothe = clothe;
/*  41 */     setLayout(new GridBagLayout());
/*  42 */     setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  43 */     setPreferredSize(new Dimension(395, 48));
/*  44 */     GridBagConstraints gc = new GridBagConstraints();
/*  45 */     gc.fill = 1;
/*  46 */     gc.gridx = 0;
/*  47 */     gc.gridy = 0;
/*  48 */     gc.weightx = 1.0D;
/*  49 */     gc.weighty = 1.0D;
/*  50 */     addPartComboBox(gc);
/*  51 */     gc.weighty = 1.0D;
/*  52 */     gc.gridx = 1;
/*  53 */     addModelButton(gc);
/*  54 */     gc.weighty = 1.0D;
/*  55 */     gc.gridx = 2;
/*  56 */     addRemoveButton(gc);
/*  57 */     gc.weighty = 1.0D;
/*  58 */     gc.gridx = 0;
/*  59 */     gc.gridy = 1;
/*  60 */     addCoversSkinCheck(gc);
/*  61 */     gc.gridx = 1;
/*  62 */     addCoversAccessoryCheck(gc);
/*     */   }
/*     */   
/*     */   private void addPartComboBox(GridBagConstraints gc)
/*     */   {
/*  67 */     final JComboBox<BodyPart> bodyPart = new JComboBox(BodyPart.values());
/*  68 */     bodyPart.setFont(FONT);
/*  69 */     bodyPart.setSelectedItem(BodyPart.values()[this.section.getPartID()]);
/*  70 */     ((JLabel)bodyPart.getRenderer()).setHorizontalAlignment(0);
/*  71 */     add(bodyPart, gc);
/*  72 */     bodyPart.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  76 */         ClothesSectionPanel.this.section.setPartID(((BodyPart)bodyPart.getSelectedItem()).ordinal());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void addCoversSkinCheck(GridBagConstraints gc) {
/*  82 */     final JCheckBox covers = new JCheckBox("Covers skin?");
/*  83 */     covers.setFont(FONT);
/*  84 */     covers.setSelected(this.section.isFullyCoveringSkin());
/*  85 */     covers.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  89 */         ClothesSectionPanel.this.section.setFullyCoversSkin(covers.isSelected());
/*     */       }
/*  91 */     });
/*  92 */     add(covers, gc);
/*     */   }
/*     */   
/*     */   private void addCoversAccessoryCheck(GridBagConstraints gc) {
/*  96 */     final JCheckBox covers = new JCheckBox("Covers Accessory?");
/*  97 */     covers.setFont(FONT);
/*  98 */     covers.setSelected(this.section.isCoveringAccessory());
/*  99 */     covers.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 103 */         ClothesSectionPanel.this.section.setCoversAccessory(covers.isSelected());
/*     */       }
/* 105 */     });
/* 106 */     add(covers, gc);
/*     */   }
/*     */   
/*     */   private void addModelButton(GridBagConstraints gc) {
/* 110 */     String message = null;
/* 111 */     if (this.section.hasModel()) {
/* 112 */       message = "Change Model...";
/*     */     } else {
/* 114 */       message = "Choose Model...";
/*     */     }
/* 116 */     final JButton button = new JButton(message);
/* 117 */     if (this.section.hasModel()) {
/* 118 */       button.setForeground(CHOSEN_COLOR);
/*     */     } else {
/* 120 */       button.setForeground(UNCHOSEN_COLOR);
/*     */     }
/* 122 */     button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 126 */         new ModelChooseScreen(ClothesSectionPanel.this.section, button);
/*     */       }
/*     */       
/*     */ 
/* 130 */     });
/* 131 */     button.setFont(FONT);
/* 132 */     add(button, gc);
/*     */   }
/*     */   
/*     */   private void addRemoveButton(GridBagConstraints gc) {
/* 136 */     JButton button = new JButton("Remove");
/* 137 */     button.setFont(FONT);
/* 138 */     add(button, gc);
/* 139 */     button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 143 */         ClothesSectionPanel.this.clothe.removeSection(ClothesSectionPanel.this.section);
/* 144 */         ClothesSectionPanel.this.panel.removePanel(ClothesSectionPanel.this);
/* 145 */         ClothesSectionPanel.this.section.destroy();
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\ClothesSectionPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */