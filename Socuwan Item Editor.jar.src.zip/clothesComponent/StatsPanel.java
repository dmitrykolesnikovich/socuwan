/*     */ package clothesComponent;
/*     */ 
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.NumberFormatter;
/*     */ 
/*     */ public class StatsPanel
/*     */   extends JPanel
/*     */ {
/*     */   private ClotheBlueprint clothesComponent;
/*     */   private JFormattedTextField attackField;
/*     */   private JFormattedTextField defenceField;
/*     */   private JFormattedTextField volatilityField;
/*     */   
/*     */   public StatsPanel(ClotheBlueprint component)
/*     */   {
/*  24 */     this.clothesComponent = component;
/*  25 */     setLayout(new GridBagLayout());
/*  26 */     GridBagConstraints gc = new GridBagConstraints();
/*  27 */     gc.fill = 1;
/*  28 */     gc.gridx = 0;
/*  29 */     gc.gridy = 0;
/*  30 */     gc.weightx = 1.0D;
/*  31 */     gc.weighty = 1.0D;
/*  32 */     addLabels(gc);
/*  33 */     gc.gridy = 1;
/*  34 */     addTextFields(gc);
/*     */   }
/*     */   
/*     */   private void addLabels(GridBagConstraints gc) {
/*  38 */     JPanel topPanel = new JPanel();
/*  39 */     topPanel.setLayout(new GridBagLayout());
/*  40 */     GridBagConstraints gc2 = new GridBagConstraints();
/*  41 */     gc2.fill = 1;
/*  42 */     gc2.gridx = 0;
/*  43 */     gc2.gridy = 0;
/*  44 */     gc2.weightx = 1.0D;
/*  45 */     gc2.weighty = 1.0D;
/*  46 */     JLabel attackLabel = new JLabel("Attack:");
/*  47 */     attackLabel.setHorizontalAlignment(0);
/*  48 */     attackLabel.setFont(ClothesPanel.FONT);
/*  49 */     topPanel.add(attackLabel, gc2);
/*  50 */     gc2.gridx = 1;
/*  51 */     JLabel defenceLabel = new JLabel("Defence:");
/*  52 */     defenceLabel.setHorizontalAlignment(0);
/*  53 */     defenceLabel.setFont(ClothesPanel.FONT);
/*  54 */     topPanel.add(defenceLabel, gc2);
/*  55 */     gc2.gridx = 2;
/*  56 */     JLabel volatilityLabel = new JLabel("Volatility:");
/*  57 */     volatilityLabel.setHorizontalAlignment(0);
/*  58 */     volatilityLabel.setFont(ClothesPanel.FONT);
/*  59 */     topPanel.add(volatilityLabel, gc2);
/*  60 */     add(topPanel, gc);
/*     */   }
/*     */   
/*     */   private void addTextFields(GridBagConstraints gc) {
/*  64 */     JPanel bottomPanel = new JPanel();
/*  65 */     bottomPanel.setLayout(new GridBagLayout());
/*  66 */     GridBagConstraints gc2 = new GridBagConstraints();
/*  67 */     gc2.fill = 1;
/*  68 */     gc2.gridx = 0;
/*  69 */     gc2.gridy = 0;
/*  70 */     gc2.weightx = 1.0D;
/*  71 */     gc2.weighty = 1.0D;
/*  72 */     this.attackField = createTextField();
/*  73 */     this.attackField.setText(Float.toString(this.clothesComponent.getAttackBoost()));
/*  74 */     this.attackField.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/*  76 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/*  80 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/*  84 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/*  88 */         if (StatsPanel.this.attackField.getText().equals("")) {
/*  89 */           return;
/*     */         }
/*  91 */         StatsPanel.this.clothesComponent.setAttackBoost(Float.parseFloat(StatsPanel.this.attackField.getText().replaceAll(",", "")));
/*     */       }
/*     */       
/*  94 */     });
/*  95 */     bottomPanel.add(this.attackField, gc2);
/*  96 */     this.attackField.setFont(ClothesPanel.FONT);
/*  97 */     this.attackField.setHorizontalAlignment(0);
/*  98 */     gc2.gridx = 1;
/*  99 */     this.defenceField = createTextField();
/* 100 */     this.defenceField.setHorizontalAlignment(0);
/* 101 */     this.defenceField.setFont(ClothesPanel.FONT);
/* 102 */     this.defenceField.setText(Float.toString(this.clothesComponent.getDefenceDamping()));
/* 103 */     this.defenceField.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 105 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 109 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 113 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 117 */         if (StatsPanel.this.defenceField.getText().equals("")) {
/* 118 */           return;
/*     */         }
/* 120 */         StatsPanel.this.clothesComponent.setDefenceDamping(Float.parseFloat(StatsPanel.this.defenceField.getText().replaceAll(",", "")));
/*     */       }
/*     */       
/* 123 */     });
/* 124 */     bottomPanel.add(this.defenceField, gc2);
/* 125 */     gc2.gridx = 2;
/* 126 */     this.volatilityField = createTextField();
/* 127 */     this.volatilityField.setHorizontalAlignment(0);
/* 128 */     this.volatilityField.setFont(ClothesPanel.FONT);
/* 129 */     this.volatilityField.setText(Float.toString(this.clothesComponent.getVolatility()));
/* 130 */     this.volatilityField.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 132 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 136 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 140 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 144 */         if (StatsPanel.this.volatilityField.getText().equals("")) {
/* 145 */           return;
/*     */         }
/* 147 */         StatsPanel.this.clothesComponent.setVolatility(Float.parseFloat(StatsPanel.this.volatilityField.getText().replaceAll(",", "")));
/*     */       }
/*     */       
/* 150 */     });
/* 151 */     bottomPanel.add(this.volatilityField, gc2);
/* 152 */     add(bottomPanel, gc);
/*     */   }
/*     */   
/*     */   private JFormattedTextField createTextField() {
/* 156 */     NumberFormat floatFormat = NumberFormat.getNumberInstance();
/* 157 */     floatFormat.setMinimumFractionDigits(1);
/* 158 */     floatFormat.setMaximumFractionDigits(5);
/* 159 */     NumberFormatter numberFormatter = new NumberFormatter(floatFormat);
/* 160 */     numberFormatter.setValueClass(Float.class);
/* 161 */     numberFormatter.setAllowsInvalid(false);
/* 162 */     numberFormatter.setMinimum(Float.valueOf(0.0F));
/* 163 */     return new JFormattedTextField(numberFormatter);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\StatsPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */