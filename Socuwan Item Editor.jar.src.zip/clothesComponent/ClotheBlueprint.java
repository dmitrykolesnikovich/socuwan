/*     */ package clothesComponent;
/*     */ 
/*     */ import accessories.ClothesBlueprintInterface;
/*     */ import accessories.ClothesSection;
/*     */ import backend.Item;
/*     */ import categories.ClothesSubCategory;
/*     */ import categories.SubCategoryInterface;
/*     */ import clothes.Clothe;
/*     */ import components.Component;
/*     */ import components.ComponentPanel;
/*     */ import instances.HumanEntity;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import main.MainApp;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ public class ClotheBlueprint
/*     */   extends Component
/*     */   implements ClothesBlueprintInterface
/*     */ {
/*     */   private static final String SEPERATOR = ";";
/*     */   private static final String END_SECTIONS = "<END>";
/*     */   public static final String IDENTIFIER = "CLOTHES";
/*     */   private ModelTexture texture;
/*  29 */   private List<ClothesSection> sections = new ArrayList();
/*  30 */   private Style style = Style.NO_STYLE;
/*     */   private ClothesSubCategory type;
/*  32 */   private CombatType combatType = CombatType.NON_COMBAT;
/*  33 */   private float attack = 0.0F;
/*  34 */   private float defence = 0.0F;
/*  35 */   private float volatility = 0.0F;
/*     */   
/*     */   private Item item;
/*  38 */   private boolean cacheTextureDuringRender = false;
/*     */   
/*     */   public ClotheBlueprint(BufferedReader reader, Item item) throws Exception {
/*  41 */     this.texture = new ModelTexture(item.getSuperFile(), false);
/*  42 */     this.item = item;
/*  43 */     this.type = ((ClothesSubCategory)item.getSubCategory());
/*  44 */     String[] values = reader.readLine().split(";");
/*  45 */     int pointer = 0;
/*  46 */     this.combatType = CombatType.values()[Integer.parseInt(values[(pointer++)])];
/*  47 */     this.style = Style.values()[Integer.parseInt(values[(pointer++)])];
/*  48 */     this.attack = Float.parseFloat(values[(pointer++)]);
/*  49 */     this.defence = Float.parseFloat(values[(pointer++)]);
/*  50 */     this.volatility = Float.parseFloat(values[(pointer++)]);
/*     */     
/*  52 */     String line = null;
/*  53 */     while (!(line = reader.readLine()).equals("<END>")) {
/*  54 */       String[] sectionVals = line.split(";");
/*  55 */       int partID = Integer.parseInt(sectionVals[0]);
/*  56 */       boolean skin = readBoolean(sectionVals[1]);
/*  57 */       boolean coversAccessory = readBoolean(sectionVals[2]);
/*  58 */       ClothesSection section = new ClothesSection(partID, skin, coversAccessory, item.getSuperFile());
/*  59 */       this.sections.add(section);
/*     */     }
/*     */     
/*  62 */     if (this.sections.size() > 1) {
/*  63 */       this.cacheTextureDuringRender = true;
/*     */     } else {
/*  65 */       this.cacheTextureDuringRender = false;
/*     */     }
/*  67 */     MainApp.character.equip(new Clothe(this));
/*     */   }
/*     */   
/*     */   public ClotheBlueprint(Item item) {
/*  71 */     this.type = ((ClothesSubCategory)item.getSubCategory());
/*     */     try {
/*  73 */       this.texture = new ModelTexture(item.getSuperFile(), true);
/*     */     } catch (Exception e) {
/*  75 */       e.printStackTrace();
/*     */     }
/*  77 */     this.item = item;
/*  78 */     MainApp.character.equip(new Clothe(this));
/*     */   }
/*     */   
/*     */   public void exportInfo(PrintWriter infoFile)
/*     */   {
/*  83 */     infoFile.println("CLOTHES");
/*  84 */     infoFile.print(this.combatType.ordinal() + ";");
/*  85 */     infoFile.print(this.style.ordinal() + ";");
/*  86 */     infoFile.print(this.attack + ";");
/*  87 */     infoFile.print(this.defence + ";");
/*  88 */     infoFile.println(this.volatility);
/*  89 */     for (ClothesSection section : this.sections)
/*  90 */       if (section.hasModel())
/*     */       {
/*     */ 
/*  93 */         infoFile.print(section.getPartID() + ";");
/*  94 */         infoFile.print(booleanToInt(section.isFullyCoveringSkin()) + ";");
/*  95 */         infoFile.println(booleanToInt(section.isCoveringAccessory()) + ";");
/*     */       }
/*  97 */     infoFile.println("<END>");
/*  98 */     this.texture.saveToFile();
/*     */   }
/*     */   
/*     */   public ComponentPanel createComponentPanel()
/*     */   {
/* 103 */     return new ClothesPanel(this, this.item);
/*     */   }
/*     */   
/*     */   public void addSection(ClothesSection section) {
/* 107 */     this.sections.add(section);
/* 108 */     if (this.sections.size() > 1) {
/* 109 */       this.cacheTextureDuringRender = true;
/*     */     } else {
/* 111 */       this.cacheTextureDuringRender = false;
/*     */     }
/* 113 */     MainApp.character.updateClothes();
/*     */   }
/*     */   
/*     */   public void removeSection(ClothesSection section) {
/* 117 */     System.out.println();
/* 118 */     this.sections.remove(section);
/* 119 */     if (this.sections.size() > 1) {
/* 120 */       this.cacheTextureDuringRender = true;
/*     */     } else {
/* 122 */       this.cacheTextureDuringRender = false;
/*     */     }
/* 124 */     MainApp.character.updateClothes();
/*     */   }
/*     */   
/*     */   public ClothesSubCategory getType() {
/* 128 */     return this.type;
/*     */   }
/*     */   
/*     */   public ClothesSection[] getSections() {
/* 132 */     ClothesSection[] sectionsArray = new ClothesSection[this.sections.size()];
/* 133 */     for (int i = 0; i < sectionsArray.length; i++) {
/* 134 */       sectionsArray[i] = ((ClothesSection)this.sections.get(i));
/*     */     }
/* 136 */     return sectionsArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelTexture getTextureAtlas()
/*     */   {
/* 144 */     return this.texture;
/*     */   }
/*     */   
/*     */   public void setStyle(Style style) {
/* 148 */     this.style = style;
/*     */   }
/*     */   
/*     */   public Style getStyle() {
/* 152 */     return this.style;
/*     */   }
/*     */   
/*     */   public void setCombatType(CombatType type) {
/* 156 */     this.combatType = type;
/*     */   }
/*     */   
/*     */   public CombatType getCombatType() {
/* 160 */     return this.combatType;
/*     */   }
/*     */   
/*     */   public boolean needsCaching() {
/* 164 */     return this.cacheTextureDuringRender;
/*     */   }
/*     */   
/*     */   public float getAttackBoost() {
/* 168 */     return this.attack;
/*     */   }
/*     */   
/*     */   public float getDefenceDamping() {
/* 172 */     return this.defence;
/*     */   }
/*     */   
/*     */   public float getVolatility() {
/* 176 */     return this.volatility;
/*     */   }
/*     */   
/*     */   public void setAttackBoost(float attack) {
/* 180 */     this.attack = attack;
/*     */   }
/*     */   
/*     */   public void setDefenceDamping(float defenceDamping) {
/* 184 */     this.defence = defenceDamping;
/*     */   }
/*     */   
/*     */   public void setVolatility(float volatility) {
/* 188 */     this.volatility = volatility;
/*     */   }
/*     */   
/*     */   protected void setCombatInfo(CombatType combatType, float attack, float defence, float random) {
/* 192 */     this.combatType = combatType;
/* 193 */     this.attack = attack;
/* 194 */     this.defence = defence;
/* 195 */     this.volatility = random;
/*     */   }
/*     */   
/*     */   public void notifyNewItemFile(File itemFile)
/*     */   {
/* 200 */     this.texture.setItemFile(itemFile);
/* 201 */     for (ClothesSection section : this.sections) {
/* 202 */       section.setItemFile(itemFile);
/*     */     }
/*     */   }
/*     */   
/*     */   private int booleanToInt(boolean check) {
/* 207 */     if (check) {
/* 208 */       return 1;
/*     */     }
/* 210 */     return 0;
/*     */   }
/*     */   
/*     */   private boolean readBoolean(String bool)
/*     */   {
/* 215 */     int indicator = Integer.parseInt(bool);
/* 216 */     if (indicator == 0) {
/* 217 */       return false;
/*     */     }
/* 219 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void notifySecondaryCategoryChange(SubCategoryInterface sub)
/*     */   {
/* 225 */     this.type = ((ClothesSubCategory)sub);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\ClotheBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */