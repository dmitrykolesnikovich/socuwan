/*    */ package clothesComponent;
/*    */ 
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeStylePanel
/*    */   extends JPanel
/*    */ {
/*    */   private ClotheBlueprint clothesComponent;
/*    */   private JComboBox<CombatType> combatType;
/*    */   private JComboBox<Style> clothesStyle;
/*    */   
/*    */   public TypeStylePanel(ClotheBlueprint component)
/*    */   {
/* 24 */     this.clothesComponent = component;
/* 25 */     setLayout(new GridBagLayout());
/* 26 */     GridBagConstraints gc = new GridBagConstraints();
/* 27 */     gc.fill = 1;
/* 28 */     gc.gridx = 0;
/* 29 */     gc.gridy = 0;
/* 30 */     gc.weightx = 1.0D;
/* 31 */     gc.weighty = 1.0D;
/* 32 */     addTypeComboBox(gc);
/* 33 */     gc.gridx = 1;
/* 34 */     addStyleComboBox(gc);
/*    */   }
/*    */   
/*    */   private void addTypeComboBox(GridBagConstraints gc) {
/* 38 */     this.combatType = new JComboBox(CombatType.values());
/* 39 */     this.combatType.setFont(ClothesPanel.FONT);
/* 40 */     this.combatType.setSelectedItem(this.clothesComponent.getCombatType());
/* 41 */     ((JLabel)this.combatType.getRenderer()).setHorizontalAlignment(0);
/* 42 */     add(this.combatType, gc);
/* 43 */     this.combatType.addActionListener(new ActionListener()
/*    */     {
/*    */ 
/*    */       public void actionPerformed(ActionEvent arg0) {
/* 47 */         TypeStylePanel.this.clothesComponent.setCombatType((CombatType)TypeStylePanel.this.combatType.getSelectedItem()); }
/*    */     });
/*    */   }
/*    */   
/*    */   private void addStyleComboBox(GridBagConstraints gc) {
/* 52 */     this.clothesStyle = new JComboBox(Style.values());
/* 53 */     ((JLabel)this.clothesStyle.getRenderer()).setHorizontalAlignment(0);
/* 54 */     this.clothesStyle.setFont(ClothesPanel.FONT);
/* 55 */     this.clothesStyle.setSelectedItem(this.clothesComponent.getStyle());
/* 56 */     this.clothesStyle.addActionListener(new ActionListener()
/*    */     {
/*    */ 
/* 59 */       public void actionPerformed(ActionEvent e) { TypeStylePanel.this.clothesComponent.setStyle((Style)TypeStylePanel.this.clothesStyle.getSelectedItem()); }
/* 60 */     });
/* 61 */     add(this.clothesStyle, gc);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\TypeStylePanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */