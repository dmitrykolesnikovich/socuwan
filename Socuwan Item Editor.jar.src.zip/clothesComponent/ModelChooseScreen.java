/*     */ package clothesComponent;
/*     */ 
/*     */ import accessories.ClothesSection;
/*     */ import frontend.FileInList;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.Configs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a Model!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   private ClothesSection section;
/*     */   private JButton button;
/*     */   
/*     */   public ModelChooseScreen(ClothesSection section, JButton button)
/*     */   {
/*  42 */     this.section = section;
/*  43 */     this.button = button;
/*  44 */     setUpFrame();
/*  45 */     addLabel();
/*  46 */     addFileList(getAllModelFiles());
/*  47 */     addButton();
/*  48 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  52 */     this.frame = new JDialog();
/*  53 */     this.frame.setAlwaysOnTop(true);
/*  54 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  55 */     this.frame.setSize(300, 500);
/*  56 */     this.frame.setResizable(false);
/*  57 */     this.frame.setLocationRelativeTo(null);
/*  58 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  62 */     GridBagConstraints gc = new GridBagConstraints();
/*  63 */     gc.gridx = 0;
/*  64 */     gc.gridy = 1;
/*  65 */     gc.weightx = 1.0D;
/*  66 */     gc.weighty = 1.0D;
/*     */     
/*  68 */     FileInList[] data = getAllFilesInList(files);
/*  69 */     this.list = new JList(data);
/*  70 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  71 */     this.list.setSelectionMode(1);
/*  72 */     this.list.setLayoutOrientation(0);
/*  73 */     this.list.setVisibleRowCount(-1);
/*  74 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  75 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  76 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  80 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  81 */     for (int i = 0; i < listedFiles.length; i++) {
/*  82 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  84 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  88 */     JLabel text = new JLabel("Choose a Model!");
/*  89 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  90 */     GridBagConstraints gc = new GridBagConstraints();
/*  91 */     gc.gridx = 0;
/*  92 */     gc.gridy = 0;
/*  93 */     gc.weightx = 1.0D;
/*  94 */     gc.weighty = 0.4D;
/*  95 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/*  99 */     this.confirm = new JButton("Open");
/* 100 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/* 101 */     GridBagConstraints gc = new GridBagConstraints();
/* 102 */     gc.gridx = 0;
/* 103 */     gc.gridy = 2;
/* 104 */     gc.weightx = 1.0D;
/* 105 */     gc.weighty = 0.4D;
/* 106 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 110 */         if (!ModelChooseScreen.this.list.isSelectionEmpty()) {
/* 111 */           File chosen = ((FileInList)ModelChooseScreen.this.list.getSelectedValue()).getFile();
/* 112 */           ModelChooseScreen.this.section.setNewModelFile(chosen);
/* 113 */           ModelChooseScreen.this.button.setText("Change Model...");
/* 114 */           ModelChooseScreen.this.button.setForeground(new Color(0, 155, 0));
/* 115 */           ModelChooseScreen.this.frame.setVisible(false);
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 120 */     });
/* 121 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllModelFiles() {
/* 125 */     File[] allFiles = Configs.MODELS_REPOS.listFiles();
/* 126 */     List<File> goodFiles = new ArrayList();
/* 127 */     for (File file : allFiles) {
/* 128 */       if (file.getName().endsWith(".csv")) {
/* 129 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 132 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\ModelChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */