/*    */ package clothesComponent;
/*    */ 
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClothesInfoPanel
/*    */   extends JPanel
/*    */ {
/*    */   public ClothesInfoPanel(ClotheBlueprint clothesComponent)
/*    */   {
/* 14 */     setLayout(new GridBagLayout());
/* 15 */     GridBagConstraints gc = new GridBagConstraints();
/* 16 */     gc.fill = 1;
/* 17 */     gc.gridx = 0;
/* 18 */     gc.gridy = 0;
/* 19 */     gc.weightx = 1.0D;
/* 20 */     gc.weighty = 0.10000000149011612D;
/* 21 */     add(new TypeStylePanel(clothesComponent), gc);
/* 22 */     gc.weighty = 0.20000000298023224D;
/* 23 */     gc.gridy = 1;
/* 24 */     add(new StatsPanel(clothesComponent), gc);
/* 25 */     gc.gridy = 2;
/* 26 */     gc.weighty = 0.4000000059604645D;
/* 27 */     add(new TexturePanel(clothesComponent), gc);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Item Editor.jar!\clothesComponent\ClothesInfoPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */