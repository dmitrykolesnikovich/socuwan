/*    */ package lodListPanel;
/*    */ 
/*    */ import backend.LodModelVersion;
/*    */ import backend.MasterModel;
/*    */ import java.awt.Dimension;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.swing.JPanel;
/*    */ import lodSettingsPanel.LodSettingsPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListPanel
/*    */   extends JPanel
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   private MasterModel model;
/*    */   private LodSettingsPanel lodPanel;
/* 22 */   private List<LODListComponent> listComponents = new ArrayList();
/*    */   
/*    */   public ListPanel(int width, int height, LodSettingsPanel lodPanel) {
/* 25 */     this.lodPanel = lodPanel;
/* 26 */     this.width = width;
/* 27 */     this.height = height;
/* 28 */     setPreferredSize(new Dimension(width, height));
/*    */   }
/*    */   
/*    */   public void setNewMasterModel(MasterModel model) {
/* 32 */     for (LODListComponent listComponent : this.listComponents) {
/* 33 */       remove(listComponent);
/*    */     }
/* 35 */     this.listComponents.clear();
/* 36 */     this.model = model;
/* 37 */     for (LodModelVersion version : model.getSimplifiedVersions()) {
/* 38 */       LODListComponent listComponent = new LODListComponent(version, this.width - 20, this.lodPanel, this);
/* 39 */       add(listComponent);
/* 40 */       this.listComponents.add(listComponent);
/*    */     }
/*    */   }
/*    */   
/*    */   public void clear() {
/* 45 */     for (LODListComponent listComponent : this.listComponents) {
/* 46 */       remove(listComponent);
/*    */     }
/* 48 */     this.listComponents.clear();
/*    */   }
/*    */   
/*    */   public void removeLOD(LODListComponent listComponent) {
/* 52 */     remove(listComponent);
/* 53 */     this.listComponents.remove(listComponent);
/* 54 */     this.model.removeLodVersion(listComponent.getVersion());
/* 55 */     validate();
/* 56 */     repaint();
/*    */   }
/*    */   
/*    */   public void addNewLOD(LodModelVersion version) {
/* 60 */     LODListComponent listComponent = new LODListComponent(version, this.width - 20, this.lodPanel, this);
/* 61 */     add(listComponent);
/* 62 */     this.listComponents.add(listComponent);
/*    */   }
/*    */   
/*    */   public void reShuffleList() {
/* 66 */     for (LODListComponent listComponent : this.listComponents) {
/* 67 */       remove(listComponent);
/*    */     }
/* 69 */     List<LODListComponent> sorted = new ArrayList();
/* 70 */     for (LODListComponent listComponent : this.listComponents) {
/* 71 */       addUnsorted(listComponent, sorted);
/*    */     }
/* 73 */     for (LODListComponent component : sorted) {
/* 74 */       add(component);
/*    */     }
/* 76 */     validate();
/* 77 */     repaint();
/*    */   }
/*    */   
/*    */   private void addUnsorted(LODListComponent newComponent, List<LODListComponent> sorted) {
/* 81 */     int pointer = 0;
/* 82 */     for (LODListComponent component : sorted) {
/* 83 */       if (component.getVersion().getLod() > newComponent.getVersion().getLod()) {
/*    */         break;
/*    */       }
/* 86 */       pointer++;
/*    */     }
/* 88 */     sorted.add(pointer, newComponent);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\lodListPanel\ListPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */