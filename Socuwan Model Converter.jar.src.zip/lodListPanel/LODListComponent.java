/*     */ package lodListPanel;
/*     */ 
/*     */ import backend.LodModelVersion;
/*     */ import frontend.MainFrame;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import lodSettingsPanel.LodSettingsPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LODListComponent
/*     */   extends JPanel
/*     */ {
/*     */   private LodModelVersion lodVersion;
/*     */   private JLabel lodNumber;
/*     */   private JLabel triangleCount;
/*     */   private JLabel errorMargin;
/*     */   private LodSettingsPanel lodPanel;
/*     */   private ListPanel listPanel;
/*     */   
/*     */   public LODListComponent(LodModelVersion lodVersion, int width, LodSettingsPanel lodPanel, ListPanel listPanel)
/*     */   {
/*  32 */     this.lodVersion = lodVersion;
/*  33 */     this.lodPanel = lodPanel;
/*  34 */     this.listPanel = listPanel;
/*  35 */     setPreferredSize(new Dimension(width, 35));
/*  36 */     setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  37 */     setLayout(new GridBagLayout());
/*  38 */     createLODDisplay();
/*  39 */     createTriCount();
/*  40 */     createErrorMargin();
/*  41 */     createEditButton();
/*  42 */     createRemoveButton();
/*     */   }
/*     */   
/*     */   public LodModelVersion getVersion() {
/*  46 */     return this.lodVersion;
/*     */   }
/*     */   
/*     */   public void updateInfo() {
/*  50 */     this.lodNumber.setText(Integer.toString(this.lodVersion.getLod()));
/*  51 */     this.triangleCount.setText(Integer.toString(this.lodVersion.getTriangleCount()));
/*  52 */     this.errorMargin.setText(Float.toString(this.lodVersion.getErrorMargin()));
/*     */   }
/*     */   
/*     */   private void createLODDisplay() {
/*  56 */     JLabel label = new JLabel("LOD: ");
/*  57 */     label.setFont(MainFrame.SMALL_FONT);
/*  58 */     label.setHorizontalAlignment(4);
/*  59 */     add(label, getGC(0, 0, 1));
/*  60 */     this.lodNumber = new JLabel(Integer.toString(this.lodVersion.getLod()));
/*  61 */     this.lodNumber.setFont(MainFrame.SMALL_FONT);
/*  62 */     this.lodNumber.setHorizontalAlignment(2);
/*  63 */     add(this.lodNumber, getGC(1, 0, 1));
/*     */   }
/*     */   
/*     */   private void createTriCount() {
/*  67 */     JLabel label = new JLabel("Tris: ");
/*  68 */     label.setFont(MainFrame.SMALL_FONT);
/*  69 */     label.setHorizontalAlignment(4);
/*  70 */     add(label, getGC(2, 0, 1));
/*  71 */     this.triangleCount = new JLabel(Integer.toString(this.lodVersion.getTriangleCount()));
/*  72 */     this.triangleCount.setFont(MainFrame.SMALL_FONT);
/*  73 */     this.triangleCount.setHorizontalAlignment(2);
/*  74 */     add(this.triangleCount, getGC(3, 0, 1));
/*     */   }
/*     */   
/*     */   private void createErrorMargin() {
/*  78 */     JLabel label = new JLabel("Error: ");
/*  79 */     label.setFont(MainFrame.SMALL_FONT);
/*  80 */     label.setHorizontalAlignment(4);
/*  81 */     add(label, getGC(4, 0, 1));
/*  82 */     this.errorMargin = new JLabel(Float.toString(this.lodVersion.getErrorMargin()));
/*  83 */     this.errorMargin.setFont(MainFrame.SMALL_FONT);
/*  84 */     this.errorMargin.setHorizontalAlignment(2);
/*  85 */     add(this.errorMargin, getGC(5, 0, 1));
/*     */   }
/*     */   
/*     */   private void createEditButton() {
/*  89 */     JButton editButton = new JButton("Edit");
/*  90 */     editButton.setFont(MainFrame.SMALL_FONT);
/*  91 */     add(editButton, getGC(6, 0, 1));
/*  92 */     editButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  96 */         LODListComponent.this.lodPanel.showLOD(LODListComponent.this.lodVersion, LODListComponent.this);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void createRemoveButton()
/*     */   {
/* 103 */     JButton removeButton = new JButton("Remove");
/* 104 */     removeButton.setFont(MainFrame.SMALL_FONT);
/* 105 */     add(removeButton, getGC(7, 0, 1));
/* 106 */     removeButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 110 */         LODListComponent.this.listPanel.removeLOD(LODListComponent.this);
/* 111 */         LODListComponent.this.lodPanel.notifyChangedIndexCount();
/* 112 */         LODListComponent.this.lodPanel.notifyChangedLODCount();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y, int gridSizeX)
/*     */   {
/* 119 */     GridBagConstraints gc = new GridBagConstraints();
/* 120 */     gc.fill = 2;
/* 121 */     gc.gridx = x;
/* 122 */     gc.gridy = y;
/* 123 */     gc.weightx = 1.0D;
/* 124 */     gc.weighty = 1.0D;
/* 125 */     gc.gridwidth = gridSizeX;
/* 126 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\lodListPanel\LODListComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */