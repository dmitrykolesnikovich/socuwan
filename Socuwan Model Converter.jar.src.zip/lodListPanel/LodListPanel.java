/*     */ package lodListPanel;
/*     */ 
/*     */ import backend.LodModelVersion;
/*     */ import backend.MasterModel;
/*     */ import frontend.MainFrame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.text.NumberFormatter;
/*     */ import lodSettingsPanel.LodSettingsPanel;
/*     */ 
/*     */ public class LodListPanel extends javax.swing.JPanel
/*     */ {
/*     */   private int width;
/*     */   private int height;
/*     */   private JButton button;
/*     */   private ListPanel list;
/*  23 */   private boolean setUp = false;
/*     */   private MasterModel model;
/*     */   private MainFrame mainFrame;
/*     */   private LodSettingsPanel lodPanel;
/*     */   
/*     */   public LodListPanel(int width, int height, MainFrame mainFrame, LodSettingsPanel lodPanel)
/*     */   {
/*  30 */     this.width = width;
/*  31 */     this.height = height;
/*  32 */     this.mainFrame = mainFrame;
/*  33 */     this.lodPanel = lodPanel;
/*  34 */     setPreferredSize(new java.awt.Dimension(width, height));
/*  35 */     setBorder(javax.swing.BorderFactory.createTitledBorder("LOD List"));
/*  36 */     setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   public void addNewLOD(LodModelVersion version) {
/*  40 */     this.list.addNewLOD(version);
/*     */   }
/*     */   
/*     */   public void reSort() {
/*  44 */     this.list.reShuffleList();
/*     */   }
/*     */   
/*     */   public void setMasterModel(MasterModel model) {
/*  48 */     this.model = model;
/*  49 */     if (!this.setUp) {
/*  50 */       setUp();
/*  51 */       this.setUp = true;
/*     */     }
/*  53 */     update();
/*     */   }
/*     */   
/*     */   private void setUp() {
/*  57 */     this.button = new JButton("Add new Level of Detail");
/*  58 */     this.button.setFont(MainFrame.SMALL_FONT);
/*  59 */     this.button.setHorizontalAlignment(0);
/*  60 */     this.button.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent arg0) {
/*  64 */         LodListPanel.this.lodPanel.createNewLOD(LodListPanel.this.model); }
/*  65 */     });
/*  66 */     GridBagConstraints gc = getGC(0, 0, 6);
/*  67 */     gc.fill = 0;
/*  68 */     add(this.button, gc);
/*  69 */     this.list = new ListPanel(this.width - 20, this.height - 90, this.lodPanel);
/*  70 */     add(this.list, getGC(0, 1, 6));
/*  71 */     setUpAutoCalc();
/*     */   }
/*     */   
/*     */   private void removeAllLods() {
/*  75 */     this.model.getSimplifiedVersions().clear();
/*  76 */     this.list.clear();
/*     */   }
/*     */   
/*     */   private void addLOD(LodModelVersion version) {
/*  80 */     this.model.addLodVersion(version);
/*  81 */     this.list.addNewLOD(version);
/*     */   }
/*     */   
/*     */   private void updateEverything() {
/*  85 */     this.lodPanel.notifyChangedIndexCount();
/*  86 */     this.lodPanel.notifyChangedLODCount();
/*  87 */     this.list.reShuffleList();
/*  88 */     validate();
/*  89 */     repaint();
/*     */   }
/*     */   
/*     */   private void setUpAutoCalc() {
/*  93 */     JLabel label1 = new JLabel("Error: ");
/*  94 */     label1.setFont(MainFrame.SMALL_FONT);
/*  95 */     label1.setHorizontalAlignment(4);
/*  96 */     add(label1, getGC(0, 2, 1));
/*  97 */     final JFormattedTextField errorMargin = createTextField(4);
/*  98 */     errorMargin.setFont(MainFrame.SMALL_FONT);
/*  99 */     errorMargin.setText(Float.toString(0.0F));
/* 100 */     errorMargin.setHorizontalAlignment(4);
/* 101 */     add(errorMargin, getGC(1, 2, 1));
/*     */     
/* 103 */     JLabel label2 = new JLabel("Increase: ");
/* 104 */     label2.setFont(MainFrame.SMALL_FONT);
/* 105 */     add(label2, getGC(2, 2, 1));
/* 106 */     label2.setHorizontalAlignment(4);
/*     */     
/* 108 */     final JFormattedTextField increase = createTextField(4);
/* 109 */     increase.setFont(MainFrame.SMALL_FONT);
/* 110 */     increase.setText(Float.toString(0.0F));
/* 111 */     add(increase, getGC(3, 2, 1));
/* 112 */     increase.setHorizontalAlignment(4);
/*     */     
/* 114 */     JButton calculate = new JButton("Auto Calculate");
/* 115 */     calculate.setFont(MainFrame.SMALL_FONT);
/* 116 */     add(calculate, getGC(4, 2, 2));
/* 117 */     calculate.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 121 */         LodListPanel.this.removeAllLods();
/*     */         
/* 123 */         String value = errorMargin.getText().replaceAll(",", "");
/* 124 */         Float error = Float.valueOf(Float.parseFloat(value));
/* 125 */         String incValue = increase.getText().replaceAll(",", "");
/* 126 */         float increase = Float.parseFloat(incValue);
/*     */         
/* 128 */         for (int i = 1; i < 11; i++) {
/* 129 */           float versionErrorMargin = (float)(error.floatValue() * Math.pow(increase, i - 1.0F));
/* 130 */           LodModelVersion version = new LodModelVersion(i, LodListPanel.this.model.getOriginal());
/* 131 */           version.setErrorMargin(versionErrorMargin);
/* 132 */           version.calculateSimplifiedVersion();
/* 133 */           LodListPanel.this.addLOD(version);
/*     */         }
/*     */         
/* 136 */         LodListPanel.this.updateEverything();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/* 141 */   private void update() { this.list.setNewMasterModel(this.model); }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y, int gridSizeX)
/*     */   {
/* 145 */     GridBagConstraints gc = new GridBagConstraints();
/*     */     
/* 147 */     gc.gridx = x;
/* 148 */     gc.gridy = y;
/* 149 */     gc.weightx = 1.0D;
/* 150 */     gc.weighty = 1.0D;
/* 151 */     gc.gridwidth = gridSizeX;
/* 152 */     return gc;
/*     */   }
/*     */   
/*     */   private JFormattedTextField createTextField(int columns) {
/* 156 */     NumberFormat floatFormat = NumberFormat.getNumberInstance();
/* 157 */     floatFormat.setMinimumFractionDigits(1);
/* 158 */     floatFormat.setMaximumFractionDigits(5);
/* 159 */     NumberFormatter numberFormatter = new NumberFormatter(floatFormat);
/* 160 */     numberFormatter.setValueClass(Float.class);
/* 161 */     numberFormatter.setAllowsInvalid(false);
/* 162 */     JFormattedTextField text = new JFormattedTextField(numberFormatter);
/* 163 */     text.setColumns(columns);
/* 164 */     text.setFont(MainFrame.SMALL_FONT);
/* 165 */     text.setHorizontalAlignment(0);
/* 166 */     return text;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\lodListPanel\LodListPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */