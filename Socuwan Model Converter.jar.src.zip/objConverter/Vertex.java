/*    */ package objConverter;
/*    */ 
/*    */ import org.lwjgl.util.vector.Vector3f;
/*    */ 
/*    */ 
/*    */ public class Vertex
/*    */ {
/*    */   private static final int NO_INDEX = -1;
/*    */   private Vector3f position;
/* 10 */   private int textureIndex = -1;
/* 11 */   private int normalIndex = -1;
/* 12 */   private Vertex duplicateVertex = null;
/*    */   private int index;
/*    */   private float length;
/*    */   
/*    */   public Vertex(int index, Vector3f position) {
/* 17 */     this.index = index;
/* 18 */     this.position = position;
/* 19 */     this.length = position.length();
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 23 */     return this.index;
/*    */   }
/*    */   
/*    */   public float getLength() {
/* 27 */     return this.length;
/*    */   }
/*    */   
/*    */   public boolean isSet() {
/* 31 */     return (this.textureIndex != -1) && (this.normalIndex != -1);
/*    */   }
/*    */   
/*    */   public boolean hasSameTextureAndNormal(int textureIndexOther, int normalIndexOther) {
/* 35 */     return (textureIndexOther == this.textureIndex) && (normalIndexOther == this.normalIndex);
/*    */   }
/*    */   
/*    */   public void setTextureIndex(int textureIndex) {
/* 39 */     this.textureIndex = textureIndex;
/*    */   }
/*    */   
/*    */   public void setNormalIndex(int normalIndex) {
/* 43 */     this.normalIndex = normalIndex;
/*    */   }
/*    */   
/*    */   public Vector3f getPosition() {
/* 47 */     return this.position;
/*    */   }
/*    */   
/*    */   public int getTextureIndex() {
/* 51 */     return this.textureIndex;
/*    */   }
/*    */   
/*    */   public int getNormalIndex() {
/* 55 */     return this.normalIndex;
/*    */   }
/*    */   
/*    */   public Vertex getDuplicateVertex() {
/* 59 */     return this.duplicateVertex;
/*    */   }
/*    */   
/*    */   public void setDuplicateVertex(Vertex duplicateVertex) {
/* 63 */     this.duplicateVertex = duplicateVertex;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\objConverter\Vertex.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */