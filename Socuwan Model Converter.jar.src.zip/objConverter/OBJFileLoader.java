/*     */ package objConverter;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.util.vector.Vector2f;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import toolbox.ModelData;
/*     */ 
/*     */ public class OBJFileLoader
/*     */ {
/*     */   public static ModelData loadOBJ(java.io.File objFile)
/*     */   {
/*  14 */     java.io.FileReader isr = null;
/*     */     try {
/*  16 */       isr = new java.io.FileReader(objFile);
/*     */     } catch (java.io.FileNotFoundException e) {
/*  18 */       System.err.println("File not found in res; don't use any extention");
/*     */     }
/*  20 */     BufferedReader reader = new BufferedReader(isr);
/*     */     
/*  22 */     List<Vertex> vertices = new ArrayList();
/*  23 */     List<Vector2f> textures = new ArrayList();
/*  24 */     List<Vector3f> normals = new ArrayList();
/*  25 */     List<Integer> indices = new ArrayList();
/*     */     try {
/*     */       String line;
/*  28 */       for (;;) { line = reader.readLine();
/*  29 */         if (line.startsWith("v ")) {
/*  30 */           String[] currentLine = line.split(" ");
/*  31 */           Vector3f vertex = new Vector3f(Float.valueOf(currentLine[1]).floatValue(), Float.valueOf(currentLine[2]).floatValue(), Float.valueOf(currentLine[3]).floatValue());
/*     */           
/*     */ 
/*  34 */           Vertex newVertex = new Vertex(vertices.size(), vertex);
/*  35 */           vertices.add(newVertex);
/*     */         }
/*  37 */         else if (line.startsWith("vt ")) {
/*  38 */           String[] currentLine = line.split(" ");
/*  39 */           Vector2f texture = new Vector2f(Float.valueOf(currentLine[1]).floatValue(), Float.valueOf(currentLine[2]).floatValue());
/*     */           
/*  41 */           textures.add(texture);
/*  42 */         } else if (line.startsWith("vn ")) {
/*  43 */           String[] currentLine = line.split(" ");
/*  44 */           Vector3f normal = new Vector3f(Float.valueOf(currentLine[1]).floatValue(), Float.valueOf(currentLine[2]).floatValue(), Float.valueOf(currentLine[3]).floatValue());
/*     */           
/*     */ 
/*  47 */           normals.add(normal);
/*  48 */         } else if (line.startsWith("f ")) {
/*     */           break;
/*     */         }
/*     */       }
/*  52 */       while ((line != null) && (line.startsWith("f "))) {
/*  53 */         String[] currentLine = line.split(" ");
/*  54 */         String[] vertex1 = currentLine[1].split("/");
/*  55 */         String[] vertex2 = currentLine[2].split("/");
/*  56 */         String[] vertex3 = currentLine[3].split("/");
/*  57 */         processVertex(vertex1, vertices, indices);
/*  58 */         processVertex(vertex2, vertices, indices);
/*  59 */         processVertex(vertex3, vertices, indices);
/*  60 */         line = reader.readLine();
/*     */       }
/*  62 */       reader.close();
/*     */     } catch (java.io.IOException e) {
/*  64 */       System.err.println("Error reading the file");
/*     */     }
/*  66 */     removeUnusedVertices(vertices);
/*  67 */     float[] verticesArray = new float[vertices.size() * 3];
/*  68 */     float[] texturesArray = new float[vertices.size() * 2];
/*  69 */     float[] normalsArray = new float[vertices.size() * 3];
/*  70 */     float furthest = convertDataToArrays(vertices, textures, normals, verticesArray, texturesArray, normalsArray);
/*     */     
/*  72 */     int[] indicesArray = convertIndicesListToArray(indices);
/*  73 */     ModelData data = new ModelData(verticesArray, texturesArray, normalsArray, indicesArray, furthest);
/*     */     
/*  75 */     return data;
/*     */   }
/*     */   
/*     */   private static void processVertex(String[] vertex, List<Vertex> vertices, List<Integer> indices) {
/*  79 */     int index = Integer.parseInt(vertex[0]) - 1;
/*  80 */     Vertex currentVertex = (Vertex)vertices.get(index);
/*  81 */     int textureIndex = Integer.parseInt(vertex[1]) - 1;
/*  82 */     int normalIndex = Integer.parseInt(vertex[2]) - 1;
/*  83 */     if (!currentVertex.isSet()) {
/*  84 */       currentVertex.setTextureIndex(textureIndex);
/*  85 */       currentVertex.setNormalIndex(normalIndex);
/*  86 */       indices.add(Integer.valueOf(index));
/*     */     } else {
/*  88 */       dealWithAlreadyProcessedVertex(currentVertex, textureIndex, normalIndex, indices, vertices);
/*     */     }
/*     */   }
/*     */   
/*     */   private static int[] convertIndicesListToArray(List<Integer> indices)
/*     */   {
/*  94 */     int[] indicesArray = new int[indices.size()];
/*  95 */     for (int i = 0; i < indicesArray.length; i++) {
/*  96 */       indicesArray[i] = ((Integer)indices.get(i)).intValue();
/*     */     }
/*  98 */     return indicesArray;
/*     */   }
/*     */   
/*     */ 
/*     */   private static float convertDataToArrays(List<Vertex> vertices, List<Vector2f> textures, List<Vector3f> normals, float[] verticesArray, float[] texturesArray, float[] normalsArray)
/*     */   {
/* 104 */     float furthestPoint = 0.0F;
/* 105 */     for (int i = 0; i < vertices.size(); i++) {
/* 106 */       Vertex currentVertex = (Vertex)vertices.get(i);
/* 107 */       if (currentVertex.getLength() > furthestPoint) {
/* 108 */         furthestPoint = currentVertex.getLength();
/*     */       }
/* 110 */       Vector3f position = currentVertex.getPosition();
/* 111 */       Vector2f textureCoord = (Vector2f)textures.get(currentVertex.getTextureIndex());
/* 112 */       Vector3f normalVector = (Vector3f)normals.get(currentVertex.getNormalIndex());
/* 113 */       verticesArray[(i * 3)] = position.x;
/* 114 */       verticesArray[(i * 3 + 1)] = position.y;
/* 115 */       verticesArray[(i * 3 + 2)] = position.z;
/* 116 */       texturesArray[(i * 2)] = textureCoord.x;
/* 117 */       texturesArray[(i * 2 + 1)] = (1.0F - textureCoord.y);
/* 118 */       normalsArray[(i * 3)] = normalVector.x;
/* 119 */       normalsArray[(i * 3 + 1)] = normalVector.y;
/* 120 */       normalsArray[(i * 3 + 2)] = normalVector.z;
/*     */     }
/* 122 */     return furthestPoint;
/*     */   }
/*     */   
/*     */   private static void dealWithAlreadyProcessedVertex(Vertex previousVertex, int newTextureIndex, int newNormalIndex, List<Integer> indices, List<Vertex> vertices)
/*     */   {
/* 127 */     if (previousVertex.hasSameTextureAndNormal(newTextureIndex, newNormalIndex)) {
/* 128 */       indices.add(Integer.valueOf(previousVertex.getIndex()));
/*     */     } else {
/* 130 */       Vertex anotherVertex = previousVertex.getDuplicateVertex();
/* 131 */       if (anotherVertex != null) {
/* 132 */         dealWithAlreadyProcessedVertex(anotherVertex, newTextureIndex, newNormalIndex, indices, vertices);
/*     */       }
/*     */       else {
/* 135 */         Vertex duplicateVertex = new Vertex(vertices.size(), previousVertex.getPosition());
/* 136 */         duplicateVertex.setTextureIndex(newTextureIndex);
/* 137 */         duplicateVertex.setNormalIndex(newNormalIndex);
/* 138 */         previousVertex.setDuplicateVertex(duplicateVertex);
/* 139 */         vertices.add(duplicateVertex);
/* 140 */         indices.add(Integer.valueOf(duplicateVertex.getIndex()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void removeUnusedVertices(List<Vertex> vertices)
/*     */   {
/* 147 */     for (Vertex vertex : vertices) {
/* 148 */       if (!vertex.isSet()) {
/* 149 */         vertex.setTextureIndex(0);
/* 150 */         vertex.setNormalIndex(0);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\objConverter\OBJFileLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */