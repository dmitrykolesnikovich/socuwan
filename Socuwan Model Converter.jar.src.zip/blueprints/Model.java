/*    */ package blueprints;
/*    */ 
/*    */ 
/*    */ public class Model
/*    */ {
/*    */   public static final int NO_MODEL = -1;
/*    */   
/*    */   private int id;
/*    */   
/*    */   private String fileStemName;
/*    */   
/*    */   private int modelLoc;
/*    */   
/*    */   private int indicesLoc;
/*    */   private int[] levelOfDetailModels;
/*    */   private boolean solid;
/*    */   
/*    */   public Model(int id, String fileStem, int modelLoc, int indicesLoc, int[] lodModels)
/*    */   {
/* 20 */     this.id = id;
/* 21 */     this.modelLoc = modelLoc;
/* 22 */     this.indicesLoc = indicesLoc;
/* 23 */     this.levelOfDetailModels = lodModels;
/* 24 */     this.fileStemName = fileStem;
/* 25 */     this.solid = false;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 29 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getModelLoc() {
/* 33 */     return this.modelLoc;
/*    */   }
/*    */   
/*    */   public int getIndicesLoc() {
/* 37 */     return this.indicesLoc;
/*    */   }
/*    */   
/*    */   public String getFileStemName() {
/* 41 */     return this.fileStemName;
/*    */   }
/*    */   
/*    */   public int getIndicesLength(int levelOfDetail) {
/* 45 */     int length = 0;
/* 46 */     for (int i = levelOfDetail; i >= 0; i--) {
/* 47 */       length = this.levelOfDetailModels[i];
/* 48 */       if (length > 0) {
/*    */         break;
/*    */       }
/*    */     }
/* 52 */     return length;
/*    */   }
/*    */   
/*    */   public boolean isVisableAtLevel(int levelOfDetail) {
/* 56 */     if (this.levelOfDetailModels[levelOfDetail] >= 0) {
/* 57 */       return true;
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   public int getIndicesOffset(int levelOfDetail)
/*    */   {
/* 64 */     int offset = 0;
/* 65 */     while (this.levelOfDetailModels[levelOfDetail] == 0) {
/* 66 */       levelOfDetail--;
/*    */     }
/* 68 */     for (int i = levelOfDetail - 1; i >= 0; i--) {
/* 69 */       offset += this.levelOfDetailModels[i];
/*    */     }
/* 71 */     return offset;
/*    */   }
/*    */   
/*    */   public void limitVisibility(int level) {
/* 75 */     for (int i = level; i < this.levelOfDetailModels.length; i++) {
/* 76 */       this.levelOfDetailModels[i] = -1;
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isSolid() {
/* 81 */     return this.solid;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\blueprints\Model.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */