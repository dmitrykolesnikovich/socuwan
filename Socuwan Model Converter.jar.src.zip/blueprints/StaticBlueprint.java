/*    */ package blueprints;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import blueprintInterfaces.StaticBlueprintInterface;
/*    */ import epicRenderEngine.Loader;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ public class StaticBlueprint
/*    */   extends Blueprint implements StaticBlueprintInterface
/*    */ {
/*    */   private RawModel model;
/*    */   private boolean solid;
/* 13 */   private boolean fadeOut = false;
/*    */   private int instanceDataVBO;
/*    */   
/*    */   public StaticBlueprint(ModelTexture texture) {
/* 17 */     super(0, texture);
/*    */   }
/*    */   
/*    */   public void setRawModel(RawModel model) {
/* 21 */     this.model = model;
/*    */   }
/*    */   
/*    */   public StaticBlueprint(RawModel model, ModelTexture texture) {
/* 25 */     super(0, texture);
/* 26 */     this.model = model;
/* 27 */     if (model.isSolid()) {
/* 28 */       this.solid = true;
/*    */     } else {
/* 30 */       this.solid = false;
/*    */     }
/*    */   }
/*    */   
/*    */   public RawModel getModel() {
/* 35 */     return this.model;
/*    */   }
/*    */   
/*    */   public boolean fadesOut()
/*    */   {
/* 40 */     return this.fadeOut;
/*    */   }
/*    */   
/*    */   public void setToFadeOut()
/*    */   {
/* 45 */     this.fadeOut = true;
/* 46 */     this.instanceDataVBO = Loader.createInterleavedInstanceVBO(this.model.getVaoID(), 3, 200, new int[] { 4, 4, 4, 3, 1 });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isSolid()
/*    */   {
/* 53 */     return this.solid;
/*    */   }
/*    */   
/*    */   public int getInstanceDataVBO()
/*    */   {
/* 58 */     return this.instanceDataVBO;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\blueprints\StaticBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */