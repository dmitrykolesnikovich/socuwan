/*    */ package animations;
/*    */ 
/*    */ 
/*    */ public class Animation
/*    */ {
/*    */   private int id;
/*    */   
/*    */   private int length;
/*    */   
/*    */   private boolean loopAnimation;
/*    */   
/*    */   public final float MAX_POS_CHANGE_PER_MILLI;
/*    */   
/*    */   public final float MAX_ROT_CHANGE_PER_MILLI;
/*    */   public final float MAX_SCALE_CHANGE_PER_MILLI;
/*    */   private AnimationSection[] sections;
/*    */   
/*    */   public Animation(int id, int length, boolean loop, float maxPos, float maxRot, float maxScale)
/*    */   {
/* 20 */     this.id = id;
/* 21 */     this.MAX_POS_CHANGE_PER_MILLI = maxPos;
/* 22 */     this.MAX_ROT_CHANGE_PER_MILLI = maxRot;
/* 23 */     this.MAX_SCALE_CHANGE_PER_MILLI = maxScale;
/* 24 */     this.length = length;
/* 25 */     this.loopAnimation = loop;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 29 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setAnimationSections(AnimationSection[] sections) {
/* 33 */     this.sections = sections;
/*    */   }
/*    */   
/*    */ 
/*    */   public void animateEntitySectionsAtTime(AnimatablePart[] entityParts, float time, float deltaInSecs)
/*    */   {
/* 39 */     for (AnimationSection partAnimation : this.sections) {
/* 40 */       AnimatablePart entitySection = entityParts[partAnimation.getSectionID()];
/* 41 */       partAnimation.animateEntitySectionAtTime(entitySection, time, deltaInSecs);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public float increaseAnimationTime(float oldTime, float deltaInSeconds)
/*    */   {
/* 48 */     float newTime = oldTime + deltaInSeconds * 1000.0F;
/* 49 */     if (this.loopAnimation) {
/* 50 */       return newTime % this.length;
/*    */     }
/* 52 */     return newTime;
/*    */   }
/*    */   
/*    */   public boolean isOver(float time)
/*    */   {
/* 57 */     if (time >= this.length) {
/* 58 */       return true;
/*    */     }
/* 60 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\animations\Animation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */