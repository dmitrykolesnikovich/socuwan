/*     */ package mainApp;
/*     */ 
/*     */ import backend.MasterModel;
/*     */ import mainSettingsPanel.PreviewSettingsPanel;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import toolbox.MyMouse;
/*     */ import toolbox.Transformation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Camera
/*     */   implements epicRenderEngine.Camera
/*     */ {
/*  16 */   private final float FIELD_OF_VIEW = 70.0F;
/*  17 */   private final float NEAR_PLANE = 0.1F;
/*  18 */   private final float FAR_PLANE = 1040.0F;
/*     */   
/*     */   private MyMouse mouse;
/*     */   
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private float horizontalDistanceFromPlayer;
/*     */   private float verticalDistanceFromPlayer;
/*     */   private float pitch;
/*     */   private float yaw;
/*  29 */   private float actualDistanceFromPlayer = 17.0F;
/*  30 */   private float angleOfElevation = 0.25F;
/*  31 */   private float angleAroundPlayer = 190.0F;
/*  32 */   private boolean change = false;
/*     */   
/*     */   private static final float CAMERA_AIM_OFFSET = 2.5F;
/*     */   
/*     */   private static final int INFLUENCE_OF_MOUSEDY = 300;
/*     */   private static final int INFLUENCE_OF_MOUSEDX = 4;
/*     */   private static final int INFLUENCE_OF_MOUSE_WHEEL = 100;
/*     */   private static final float MAX_ANGLE_OF_ELEVATION = 1.5F;
/*     */   private static final float SPEED_OF_CAM_RETURN = 25.0F;
/*     */   private static final float CAM_RETURN_DISTANCE_EFFECT = 0.25F;
/*     */   private static final float PITCH_OFFSET = 1.8F;
/*     */   private static final float MINIMUM_ZOOM = 8.0F;
/*     */   private static final float MAX_HORIZONTAL_CHANGE = 500.0F;
/*     */   private static final float MAX_VERTICAL_CHANGE = 5.0F;
/*  46 */   private boolean rotate = false;
/*  47 */   Transformation transformation = new Transformation(400.0F, 0.0F, 400.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   
/*     */   private PreviewSettingsPanel previewDisplay;
/*     */   
/*     */   private MasterModel model;
/*  52 */   private int lod = 0;
/*     */   
/*  54 */   private boolean panOut = false;
/*  55 */   private boolean panIn = false;
/*     */   
/*     */   public Camera(MyMouse mouse)
/*     */   {
/*  59 */     this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */     
/*  61 */     this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*  62 */     this.mouse = mouse;
/*     */   }
/*     */   
/*     */   public float getDistance() {
/*  66 */     return this.actualDistanceFromPlayer;
/*     */   }
/*     */   
/*     */   public void setMasterModel(MasterModel model) {
/*  70 */     this.model = model;
/*     */   }
/*     */   
/*     */   public void setPreviewSettingsPanel(PreviewSettingsPanel previewDisplay) {
/*  74 */     this.previewDisplay = previewDisplay;
/*     */   }
/*     */   
/*     */   public void setRotate(boolean rotate) {
/*  78 */     this.rotate = rotate;
/*     */   }
/*     */   
/*     */   public void setDistanceFromPlayer(float distance) {
/*  82 */     this.actualDistanceFromPlayer = distance;
/*  83 */     this.change = true;
/*     */   }
/*     */   
/*     */   public void panOut() {
/*  87 */     this.actualDistanceFromPlayer = 17.0F;
/*  88 */     this.panOut = true;
/*  89 */     this.panIn = false;
/*     */   }
/*     */   
/*     */   public void panIn() {
/*  93 */     this.actualDistanceFromPlayer = 360.0F;
/*  94 */     this.panOut = false;
/*  95 */     this.panIn = true;
/*     */   }
/*     */   
/*     */   public void resetCamera() {
/*  99 */     this.actualDistanceFromPlayer = 17.0F;
/* 100 */     this.panOut = false;
/* 101 */     this.panIn = false;
/*     */   }
/*     */   
/*     */   public void moveCamera(float delta) {
/* 105 */     if (this.panOut) {
/* 106 */       this.actualDistanceFromPlayer += 0.4F;
/* 107 */       if (this.actualDistanceFromPlayer >= 360.0F) {
/* 108 */         resetCamera();
/*     */       }
/* 110 */     } else if (this.panIn) {
/* 111 */       this.actualDistanceFromPlayer -= 0.4F;
/* 112 */       if (this.actualDistanceFromPlayer <= 17.0F) {
/* 113 */         resetCamera();
/*     */       }
/*     */     }
/* 116 */     calculateHorizontalAngle(delta);
/* 117 */     calculateVerticalAngle(delta);
/* 118 */     calculateZoom();
/* 119 */     calculateDistances();
/* 120 */     calculatePosition();
/* 121 */     this.change = true;
/*     */     
/* 123 */     this.lod = TheLODCalculator.calculateLOD(this.actualDistanceFromPlayer);
/* 124 */     this.previewDisplay.updateDistance(this.actualDistanceFromPlayer);
/* 125 */     this.previewDisplay.updateLOD(this.lod);
/*     */   }
/*     */   
/*     */   public boolean isRotating() {
/* 129 */     return this.rotate;
/*     */   }
/*     */   
/*     */   public int getLOD() {
/* 133 */     return this.lod;
/*     */   }
/*     */   
/*     */   public float getX() {
/* 137 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/* 141 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/* 145 */     return this.z;
/*     */   }
/*     */   
/*     */   public float getPitch() {
/* 149 */     return this.pitch;
/*     */   }
/*     */   
/*     */   public float getYaw() {
/* 153 */     return this.yaw;
/*     */   }
/*     */   
/*     */   public float getFieldOfView() {
/* 157 */     return 70.0F;
/*     */   }
/*     */   
/*     */   public float getNearPlane() {
/* 161 */     return 0.1F;
/*     */   }
/*     */   
/*     */   public float getFarPlane() {
/* 165 */     return 1040.0F;
/*     */   }
/*     */   
/*     */   private void calculatePosition() {
/* 169 */     if (this.rotate) {
/* 170 */       this.transformation.increaseRotation(0.0F, 0.1F, 0.0F);
/*     */     }
/* 172 */     float playerRot = this.transformation.getRotY();
/* 173 */     this.x = (this.transformation.getX() - (float)(this.horizontalDistanceFromPlayer * Math.sin(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/* 176 */     this.z = (this.transformation.getZ() - (float)(this.horizontalDistanceFromPlayer * Math.cos(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/* 179 */     this.y = (this.verticalDistanceFromPlayer + 2.5F + 0.0F);
/*     */     
/* 181 */     if (this.transformation.getY() + 2.5F > this.y) {
/* 182 */       this.y = (this.transformation.getY() + 2.5F);
/*     */     }
/* 184 */     this.yaw = (playerRot + 180.0F + this.angleAroundPlayer);
/* 185 */     this.pitch = ((float)Math.toDegrees(this.angleOfElevation) - 1.8F);
/*     */   }
/*     */   
/*     */   private void calculateHorizontalAngle(float delta) {
/* 189 */     if ((this.mouse.isLeftButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 190 */       float angleChange = this.mouse.getDX() / 4.0F;
/* 191 */       if (angleChange > 500.0F * delta) {
/* 192 */         angleChange = 500.0F * delta;
/* 193 */       } else if (angleChange < -500.0F * delta) {
/* 194 */         angleChange = -500.0F * delta;
/*     */       }
/* 196 */       this.angleAroundPlayer -= angleChange;
/*     */       
/* 198 */       if (this.angleAroundPlayer >= 180.0F) {
/* 199 */         this.angleAroundPlayer -= 360.0F;
/* 200 */       } else if (this.angleAroundPlayer <= -180.0F) {
/* 201 */         this.angleAroundPlayer += 360.0F;
/*     */       }
/* 203 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void returnCamera(float delta) {
/* 208 */     float distanceRecoverySpeed = this.angleAroundPlayer / 0.25F * delta;
/* 209 */     float returningSpeed = 25.0F * delta;
/* 210 */     if (this.angleAroundPlayer > returningSpeed) {
/* 211 */       this.angleAroundPlayer -= returningSpeed + distanceRecoverySpeed;
/* 212 */       this.change = true;
/* 213 */     } else if (this.angleAroundPlayer < -returningSpeed) {
/* 214 */       this.angleAroundPlayer += returningSpeed - distanceRecoverySpeed;
/* 215 */       this.change = true;
/*     */     } else {
/* 217 */       this.angleAroundPlayer = 0.0F;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateVerticalAngle(float delta) {
/* 222 */     if ((this.mouse.isRightButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 223 */       float angleChange = this.mouse.getDY() / 300.0F;
/* 224 */       if (angleChange > 5.0F * delta) {
/* 225 */         angleChange = 5.0F * delta;
/* 226 */       } else if (angleChange < -5.0F * delta) {
/* 227 */         angleChange = -5.0F * delta;
/*     */       }
/* 229 */       this.angleOfElevation -= angleChange;
/* 230 */       if (this.angleOfElevation >= 1.5F) {
/* 231 */         this.angleOfElevation = 1.5F;
/* 232 */       } else if (this.angleOfElevation <= 0.0F) {
/* 233 */         this.angleOfElevation = 0.0F;
/*     */       }
/* 235 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateZoom() {
/* 240 */     if (Keyboard.isKeyDown(46)) {
/* 241 */       this.actualDistanceFromPlayer -= 1.0F;
/* 242 */       this.change = true;
/*     */     }
/* 244 */     float zoomLevel = this.mouse.getDWheel() / 100;
/* 245 */     if (zoomLevel != 0.0F) {
/* 246 */       this.actualDistanceFromPlayer -= zoomLevel;
/* 247 */       if (this.actualDistanceFromPlayer < 8.0F) {
/* 248 */         this.actualDistanceFromPlayer = 8.0F;
/*     */       }
/* 250 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateDistances() {
/* 255 */     if (this.change) {
/* 256 */       this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */       
/* 258 */       this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainApp\Camera.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */