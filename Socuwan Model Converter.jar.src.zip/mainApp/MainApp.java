/*     */ package mainApp;
/*     */ 
/*     */ import atmosphere.Sky;
/*     */ import atmosphere.SkyBox;
/*     */ import atmosphere.Sun;
/*     */ import backend.LodModelVersion;
/*     */ import backend.MasterModel;
/*     */ import backend.WorkSpace;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import frontend.MainFrame;
/*     */ import instances.HumanEntity;
/*     */ import instances.StaticEntity;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Locale;
/*     */ import javax.swing.JOptionPane;
/*     */ import terrains.Terrain;
/*     */ import texture.TerrainTexture;
/*     */ import texture.TerrainTexturePack;
/*     */ import toolbox.Colour;
/*     */ import toolbox.MyKeyboard;
/*     */ import toolbox.MyMouse;
/*     */ 
/*     */ public class MainApp
/*     */ {
/*     */   public static final float START_PLAYER_OFFSET = 10.0F;
/*     */   public static final float CENTER_X = 400.0F;
/*     */   public static final float CENTER_Z = 400.0F;
/*  30 */   public static boolean close = false;
/*     */   public static HumanEntity player;
/*     */   public static Camera camera;
/*     */   public static LodModelVersion overrideVersion;
/*     */   public static WorkSpace workspace;
/*  35 */   public static boolean WIRE_FRAME = false;
/*     */   
/*  37 */   public static boolean forceLOD = false;
/*  38 */   public static int forcedLOD = 0;
/*     */   
/*  40 */   public static boolean showTerrain = true;
/*     */   
/*     */   public static void init() {
/*  43 */     Locale.setDefault(Locale.US);
/*     */     
/*  45 */     System.out.println(new File("natives").getAbsolutePath());
/*     */     
/*  47 */     String osname = System.getProperty("os.name").toLowerCase();
/*  48 */     System.out.println("OS Name: " + osname);
/*  49 */     System.out.println("OS Arch: " + System.getProperty("os.arch"));
/*  50 */     String pathExtension = "";
/*     */     
/*  52 */     if (osname.contains("win")) {
/*  53 */       pathExtension = "win";
/*  54 */     } else if (osname.contains("lin")) {
/*  55 */       pathExtension = "lin";
/*  56 */     } else if (osname.contains("mac")) {
/*  57 */       pathExtension = "mac";
/*     */     } else {
/*  59 */       JOptionPane.showMessageDialog(null, "Sorry, but your system is not supported by LWJGL :(");
/*  60 */       System.exit(-1);
/*     */     }
/*     */     
/*     */ 
/*  64 */     System.setProperty("org.lwjgl.librarypath", new File("natives").getAbsolutePath() + "/" + pathExtension);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  71 */     init();
/*  72 */     MyMouse mouse = new MyMouse();
/*  73 */     MyKeyboard keyboard = new MyKeyboard();
/*  74 */     InputProcessor inputs = new InputProcessor(mouse, keyboard);
/*  75 */     camera = new Camera(mouse);
/*     */     
/*  77 */     workspace = new WorkSpace();
/*  78 */     MainFrame mainFrame = new MainFrame(workspace, camera);
/*     */     
/*  80 */     RenderEngine engine = new RenderEngine(camera, mainFrame.getCanvas());
/*  81 */     Configs.init();
/*     */     
/*  83 */     Sky sky = new Sky(camera, 500.0F);
/*  84 */     sky.getSun().setPosition(1000.0F, 500.0F, 1000.0F);
/*  85 */     sky.getSun().setColour(new Colour(245.0F, 204.0F, 126.0F, true));
/*  86 */     sky.setSkyColour(new Colour(1.0F, 0.7F, 0.8F));
/*  87 */     sky.getSkyBox().setTextures(RenderEngine.loadTexture("skybox/daySky"), RenderEngine.loadTexture("skybox/daySky"), 0.5F);
/*     */     
/*     */ 
/*     */ 
/*  91 */     TerrainTexture main = new TerrainTexture(0, "grassy256");
/*  92 */     TerrainTexture r = new TerrainTexture(0, "dirt256");
/*  93 */     TerrainTexture g = new TerrainTexture(0, "pinkFlowers256");
/*  94 */     TerrainTexture b = new TerrainTexture(0, "MarblePath512");
/*  95 */     TerrainTexturePack pack = new TerrainTexturePack(main, r, g, b, null);
/*  96 */     int alphaMap = RenderEngine.loadTexture("terrains/newAlpha");
/*  97 */     pack.setShiny();
/*  98 */     pack.setUseSpecularMap();
/*  99 */     Terrain terrain = new Terrain(0, 0, "flatty", pack, alphaMap);
/* 100 */     sky.setFogDensity(0.0023F);
/* 101 */     sky.setFogGradient(5.0F);
/* 102 */     player = new HumanEntity(410.0F, 0.0F, 400.0F, 0.0F, 0.0F, 0.0F, 0.5F);
/* 103 */     while (!close) {
/* 104 */       epicRenderEngine.Loader.dealWithRequests();
/* 105 */       sky.getSkyBox().update(new Colour(1.0F, 0.7F, 0.8F));
/* 106 */       sky.getSun().setPosition(camera.getX() + 500.0F, 200.0F, camera.getZ() + 500.0F);
/* 107 */       camera.moveCamera(RenderEngine.getDeltaInSeconds());
/* 108 */       engine.updateView();
/* 109 */       inputs.checkInput();
/*     */       
/* 111 */       player.animateForCurrentFrame(RenderEngine.getDeltaInSeconds());
/* 112 */       if (player.isShowing()) {
/* 113 */         engine.processHumanEntity(player);
/*     */       }
/* 115 */       MasterModel model = workspace.getCurrentMasterModel();
/* 116 */       if (model != null) {
/* 117 */         if (overrideVersion != null) {
/* 118 */           if (overrideVersion.getModel() != null) {
/* 119 */             model.getEntity().setBlueprint(overrideVersion.getModel().getBlueprint());
/* 120 */             engine.processStaticEntity(model.getEntity());
/*     */           }
/*     */         } else {
/* 123 */           if (!forceLOD) {
/* 124 */             model.setLOD(camera.getLOD());
/*     */           } else {
/* 126 */             model.setLOD(forcedLOD);
/*     */           }
/* 128 */           engine.processStaticEntity(model.getEntity());
/*     */         }
/*     */       }
/* 131 */       if (showTerrain) {
/* 132 */         for (terrains.TerrainBlock tile : terrain.getTerrainBlocks()) {
/* 133 */           engine.processTerrainBlock(tile);
/*     */         }
/*     */       }
/* 136 */       engine.render(sky, new ArrayList());
/* 137 */       engine.updateDisplay();
/*     */     }
/*     */     
/* 140 */     engine.closeDisplay();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainApp\MainApp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */