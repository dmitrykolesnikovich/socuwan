/*    */ package mainApp;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TheLODCalculator
/*    */ {
/*    */   public static final float MIN = 50.0F;
/*    */   
/*    */   public static final float INCREASE = 1.3F;
/*    */   
/* 11 */   private static final float LOG_MIN = (float)Math.log(50.0D);
/* 12 */   private static final float LOG_INCREASE = (float)Math.log(1.2999999523162842D);
/*    */   
/*    */   private static final float SCREEN_SIZE_FACTOR = 0.625F;
/*    */   
/*    */   public static int calculateLOD(float distanceFromCamera)
/*    */   {
/* 18 */     distanceFromCamera /= 0.625F;
/* 19 */     if (distanceFromCamera > 50.0F) {
/* 20 */       float lodFloat = (float)((Math.log(distanceFromCamera) - LOG_MIN) / LOG_INCREASE);
/* 21 */       return (int)(Math.floor(lodFloat) + 1.0D);
/*    */     }
/* 23 */     return 0;
/*    */   }
/*    */   
/*    */   public static int getDistanceOfLOD(int lod)
/*    */   {
/* 28 */     if (lod == 0) {
/* 29 */       return 0;
/*    */     }
/* 31 */     return (int)(50.0D * Math.pow(1.2999999523162842D, lod - 1) * 0.625D);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainApp\TheLODCalculator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */