/*    */ package mainApp;
/*    */ 
/*    */ import java.io.File;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Configs
/*    */ {
/*    */   public static final String FILE_SEPARATOR = "/";
/* 11 */   public static final File REPOSITORY = new File("repository");
/* 12 */   public static final File TEXTURE_REPOS = new File(REPOSITORY, "modelTextures");
/* 13 */   public static final File OBJ_REPOSITORY = new File(REPOSITORY, "objFiles");
/* 14 */   public static final File SAVES_FOLDER = new File(REPOSITORY, "models");
/*    */   public static final String NATIVES_FOLDER = "natives";
/*    */   
/* 17 */   static { if (!REPOSITORY.exists()) {
/* 18 */       REPOSITORY.mkdir();
/*    */     }
/* 20 */     if (!TEXTURE_REPOS.exists()) {
/* 21 */       TEXTURE_REPOS.mkdir();
/*    */     }
/* 23 */     if (!OBJ_REPOSITORY.exists()) {
/* 24 */       OBJ_REPOSITORY.mkdir();
/*    */     }
/* 26 */     if (!SAVES_FOLDER.exists()) {
/* 27 */       SAVES_FOLDER.mkdir();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public static final String RES_FOLDER = "/res/";
/*    */   
/*    */   public static final String TEXTURE_TYPE = ".png";
/*    */   
/*    */   public static final String MODEL_FILE_EXT = ".csv";
/*    */   
/*    */   public static final String PARTICLE_ATLAS_LOC = "particles/";
/*    */   public static final String DEFAULT_TEXTURE_NAME = "defaultTexture";
/*    */   public static final String OUTPUT_FILE_EXT = "_SCW.csv";
/*    */   public static final String ICON_NAME = "defaultIcon.png";
/*    */   public static final String ICON_FILE = "/res/defaultIcon.png";
/*    */   public static final String SKYBOX_FILE = "skybox";
/*    */   public static final String SKYBOX_TEXTURE = "skybox/daySky";
/*    */   public static final String TERRAIN_TEX_0 = "grassy256";
/*    */   public static final String TERRAIN_TEX_1 = "dirt256";
/*    */   public static final String TERRAIN_TEX_2 = "pinkFlowers256";
/*    */   public static final String TERRAIN_TEX_3 = "MarblePath512";
/*    */   public static final String BLEND_MAP = "terrains/newAlpha";
/*    */   public static final String TERRAIN_FILE = "flatty";
/*    */   public static final String TERRAIN_FILE_LOC = "/res/terrains/";
/*    */   public static final String TERRAIN_FILE_EXT = "TERRAIN.csv";
/*    */   public static final String HAIR_MODEL = "hair";
/*    */   public static final String HAIR_TEXTURE = "hair";
/*    */   public static final String SHADERS_LOC = "/renderPrograms/";
/*    */   public static final String CLUTTER_VERTEX_FILE = "/renderPrograms/clutterVertex.txt";
/*    */   public static final String CLUTTER_FRAGMENT_FILE = "/renderPrograms/clutterFragment.txt";
/*    */   public static final String PARTICLE_VERTEX_FILE = "/renderPrograms/particlesVertex.txt";
/*    */   public static final String PARTICLE_FRAGMENT_FILE = "/renderPrograms/particlesFragment.txt";
/*    */   public static final String HR_STATIC_VERTEX_FILE = "/renderPrograms/simpleVertex.txt";
/*    */   public static final String HR_STATIC_FRAGMENT_FILE = "/renderPrograms/simpleFragment.txt";
/*    */   public static final String HR_TERRAIN_VERTEX_FILE = "/renderPrograms/terrainVertex.txt";
/*    */   public static final String HR_TERRAIN_FRAGMENT_FILE = "/renderPrograms/terrainFragment.txt";
/*    */   public static final String LR_STATIC_VERTEX_FILE = "/renderPrograms/simpleLowResVertex.txt";
/*    */   public static final String LR_STATIC_FRAGMENT_FILE = "/renderPrograms/simpleLowResFragment.txt";
/*    */   public static final String LR_TERRAIN_VERTEX_FILE = "/renderPrograms/terrainLowResVertex.txt";
/*    */   public static final String LR_TERRAIN_FRAGMENT_FILE = "/renderPrograms/terrainLowResFragment.txt";
/*    */   public static final String SKYBOX_VERTEX_FILE = "/renderPrograms/skyboxVertex.txt";
/*    */   public static final String SKYBOX_FRAGMENT_FILE = "/renderPrograms/skyboxFragment.txt";
/*    */   public static ModelTexture DEFAULT_TEXTURE;
/*    */   public static void init()
/*    */   {
/* 73 */     DEFAULT_TEXTURE = new ModelTexture("defaultTexture");
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainApp\Configs.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */