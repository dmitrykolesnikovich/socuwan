/*     */ package errorMetricLOD;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ 
/*     */ 
/*     */ public class Vertex
/*     */ {
/*     */   private Vector3f vertex;
/*     */   private int index;
/*  15 */   private Set<Triangle> triangleFan = new HashSet();
/*  16 */   private List<Edge> edges = new ArrayList();
/*     */   private Matrix4f matrixQ;
/*     */   
/*     */   protected Vertex(Vector3f point, int index)
/*     */   {
/*  21 */     this.vertex = point;
/*  22 */     this.index = index;
/*     */   }
/*     */   
/*     */   protected void addTriangleToFan(Triangle triangle) {
/*  26 */     this.triangleFan.add(triangle);
/*  27 */     if (this.matrixQ == null) {
/*  28 */       this.matrixQ = new Matrix4f();
/*  29 */       this.matrixQ.load(triangle.getMatrixK());
/*     */     } else {
/*  31 */       Matrix4f.add(this.matrixQ, triangle.getMatrixK(), this.matrixQ);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isEdgeVertex() {
/*  36 */     List<Vertex> nonMatchedVertices = new ArrayList();
/*  37 */     for (Triangle triangle : this.triangleFan) {
/*  38 */       List<Vertex> otherVerts = triangle.getOtherVertices(this);
/*  39 */       for (Vertex otherVert : otherVerts) {
/*  40 */         if (!nonMatchedVertices.contains(otherVert)) {
/*  41 */           nonMatchedVertices.add(otherVert);
/*     */         } else {
/*  43 */           nonMatchedVertices.remove(otherVert);
/*     */         }
/*     */       }
/*     */     }
/*  47 */     return !nonMatchedVertices.isEmpty();
/*     */   }
/*     */   
/*     */   protected int getIndex() {
/*  51 */     return this.index;
/*     */   }
/*     */   
/*     */   protected Matrix4f getMatrixQ() {
/*  55 */     return this.matrixQ;
/*     */   }
/*     */   
/*     */   protected List<Edge> remove(Vertex replacement) {
/*  59 */     List<Triangle> toRemove = new ArrayList();
/*  60 */     for (Triangle triangle : this.triangleFan) {
/*  61 */       boolean collapsed = triangle.replace(this, replacement);
/*  62 */       if (collapsed) {
/*  63 */         toRemove.add(triangle);
/*     */       }
/*     */     }
/*  66 */     for (Triangle triangle : toRemove) {
/*  67 */       triangle.remove();
/*     */     }
/*  69 */     for (Edge edge : this.edges) {
/*  70 */       edge.replaceVertex(this, replacement);
/*     */     }
/*  72 */     return replacement.takeOverFrom(this);
/*     */   }
/*     */   
/*     */   protected Vector3f getPoint() {
/*  76 */     return this.vertex;
/*     */   }
/*     */   
/*     */   protected Set<Triangle> getTriangleFan() {
/*  80 */     return this.triangleFan;
/*     */   }
/*     */   
/*     */   protected void notifyTriangleRemoved(Triangle triangle) {
/*  84 */     this.triangleFan.remove(triangle);
/*     */   }
/*     */   
/*     */   protected void notifyEdgeRemoved(Edge edge) {
/*  88 */     this.edges.remove(edge);
/*     */   }
/*     */   
/*     */   private List<Edge> takeOverFrom(Vertex removed) {
/*  92 */     Matrix4f.add(this.matrixQ, removed.matrixQ, this.matrixQ);
/*  93 */     this.triangleFan.addAll(removed.triangleFan);
/*  94 */     List<Edge> dupes = new ArrayList();
/*  95 */     for (Edge newEdge : removed.edges) {
/*  96 */       if (!addNewEdge(newEdge)) {
/*  97 */         dupes.add(newEdge);
/*     */       }
/*     */     }
/* 100 */     for (Edge edge : this.edges) {
/* 101 */       edge.evaluateCost();
/*     */     }
/* 103 */     for (Edge dupe : dupes) {
/* 104 */       dupe.delete();
/*     */     }
/* 106 */     return dupes;
/*     */   }
/*     */   
/*     */   protected boolean addNewEdge(Edge edge) {
/* 110 */     for (Edge currentEdge : this.edges) {
/* 111 */       if (Edge.areDuplicates(edge, currentEdge)) {
/* 112 */         return false;
/*     */       }
/*     */     }
/* 115 */     this.edges.add(edge);
/* 116 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\errorMetricLOD\Vertex.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */