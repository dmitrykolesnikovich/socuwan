/*     */ package errorMetricLOD;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ 
/*     */ public class Triangle
/*     */ {
/*     */   private Vertex vertex1;
/*     */   private Vertex vertex2;
/*     */   private Vertex vertex3;
/*     */   private Matrix4f matrixK;
/*     */   
/*     */   protected Triangle(Vertex vertex1, Vertex vertex2, Vertex vertex3)
/*     */   {
/*  18 */     this.vertex1 = vertex1;
/*  19 */     this.vertex2 = vertex2;
/*  20 */     this.vertex3 = vertex3;
/*  21 */     calculateMatrix();
/*     */   }
/*     */   
/*     */   protected boolean contains(Vertex vertex) {
/*  25 */     if ((this.vertex1 == vertex) || (this.vertex2 == vertex) || (this.vertex3 == vertex)) {
/*  26 */       return true;
/*     */     }
/*  28 */     return false;
/*     */   }
/*     */   
/*     */   protected Vertex getAnotherVertex(Vertex original)
/*     */   {
/*  33 */     if (this.vertex1 != original) {
/*  34 */       return this.vertex1;
/*     */     }
/*  36 */     return this.vertex2;
/*     */   }
/*     */   
/*     */   protected List<Vertex> getOtherVertices(Vertex original)
/*     */   {
/*  41 */     List<Vertex> vertices = new ArrayList();
/*  42 */     if (this.vertex1 != original) {
/*  43 */       vertices.add(this.vertex1);
/*     */     }
/*  45 */     if (this.vertex2 != original) {
/*  46 */       vertices.add(this.vertex2);
/*     */     }
/*  48 */     if (this.vertex3 != original) {
/*  49 */       vertices.add(this.vertex3);
/*     */     }
/*  51 */     return vertices;
/*     */   }
/*     */   
/*     */   protected boolean replace(Vertex replaceThis, Vertex withThis) {
/*  55 */     if (contains(withThis)) {
/*  56 */       return true;
/*     */     }
/*  58 */     if (this.vertex1 == replaceThis) {
/*  59 */       this.vertex1 = withThis;
/*  60 */     } else if (this.vertex2 == replaceThis) {
/*  61 */       this.vertex2 = withThis;
/*  62 */     } else if (this.vertex3 == replaceThis) {
/*  63 */       this.vertex3 = withThis;
/*     */     } else {
/*  65 */       System.err.println("BIG ERROR@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
/*     */     }
/*  67 */     return false;
/*     */   }
/*     */   
/*     */   protected void remove()
/*     */   {
/*  72 */     this.vertex1.notifyTriangleRemoved(this);
/*  73 */     this.vertex2.notifyTriangleRemoved(this);
/*  74 */     this.vertex3.notifyTriangleRemoved(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Vertex getVertex1()
/*     */   {
/*  97 */     return this.vertex1;
/*     */   }
/*     */   
/*     */   protected Vertex getVertex2() {
/* 101 */     return this.vertex2;
/*     */   }
/*     */   
/*     */   protected Vertex getVertex3() {
/* 105 */     return this.vertex3;
/*     */   }
/*     */   
/*     */   protected Matrix4f getMatrixK() {
/* 109 */     return this.matrixK;
/*     */   }
/*     */   
/*     */   private Vector3f getNormal() {
/* 113 */     Vector3f first = Vector3f.sub(this.vertex2.getPoint(), this.vertex1.getPoint(), null);
/* 114 */     Vector3f second = Vector3f.sub(this.vertex3.getPoint(), this.vertex1.getPoint(), null);
/* 115 */     Vector3f cross = Vector3f.cross(first, second, null);
/* 116 */     return cross.normalise(null);
/*     */   }
/*     */   
/*     */   private void calculateMatrix() {
/* 120 */     Vector3f normal = getNormal();
/* 121 */     Vector3f vertex = this.vertex1.getPoint();
/* 122 */     float d = -(normal.x * vertex.x + normal.y * vertex.y + normal.z * vertex.z);
/* 123 */     float a = normal.x;
/* 124 */     float b = normal.y;
/* 125 */     float c = normal.z;
/* 126 */     this.matrixK = new Matrix4f();
/* 127 */     this.matrixK.m00 = (a * a);
/* 128 */     this.matrixK.m10 = (a * b);
/* 129 */     this.matrixK.m20 = (a * c);
/* 130 */     this.matrixK.m30 = (a * d);
/*     */     
/* 132 */     this.matrixK.m01 = (a * b);
/* 133 */     this.matrixK.m11 = (b * b);
/* 134 */     this.matrixK.m21 = (b * c);
/* 135 */     this.matrixK.m31 = (b * d);
/*     */     
/* 137 */     this.matrixK.m02 = (a * c);
/* 138 */     this.matrixK.m12 = (b * c);
/* 139 */     this.matrixK.m22 = (c * c);
/* 140 */     this.matrixK.m32 = (c * d);
/*     */     
/* 142 */     this.matrixK.m03 = (a * d);
/* 143 */     this.matrixK.m13 = (b * d);
/* 144 */     this.matrixK.m23 = (c * d);
/* 145 */     this.matrixK.m33 = (d * d);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\errorMetricLOD\Triangle.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */