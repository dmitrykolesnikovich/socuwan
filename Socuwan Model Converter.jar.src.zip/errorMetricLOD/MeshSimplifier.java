/*     */ package errorMetricLOD;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import toolbox.ModelData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MeshSimplifier
/*     */ {
/*  16 */   private static List<Vertex> vertices = new ArrayList();
/*  17 */   private static List<Edge> edges = new ArrayList();
/*     */   
/*     */   public static ModelData simplifyModelData(ModelData data, float errorMargin) {
/*  20 */     extractVertices(data);
/*  21 */     createMesh(data);
/*  22 */     calculateAllCosts();
/*  23 */     simplifyMesh(errorMargin);
/*  24 */     int[] newIndices = getSimplifiedIndices();
/*  25 */     vertices.clear();
/*  26 */     edges.clear();
/*  27 */     return new ModelData(data.getVertices(), data.getTextureCoords(), data.getNormals(), newIndices, data.getFurthestPoint());
/*     */   }
/*     */   
/*     */   private static void extractVertices(ModelData data)
/*     */   {
/*  32 */     int pointer = 0;
/*  33 */     for (int i = 0; i < data.getVertices().length; i += 3) {
/*  34 */       float x = data.getVertices()[i];
/*  35 */       float y = data.getVertices()[(i + 1)];
/*  36 */       float z = data.getVertices()[(i + 2)];
/*  37 */       vertices.add(new Vertex(new Vector3f(x, y, z), pointer));
/*  38 */       pointer++;
/*     */     }
/*     */   }
/*     */   
/*     */   private static void createMesh(ModelData data) {
/*  43 */     int[] indices = data.getIndices();
/*  44 */     for (int i = 0; i < indices.length; i += 3) {
/*  45 */       int index1 = indices[i];
/*  46 */       int index2 = indices[(i + 1)];
/*  47 */       int index3 = indices[(i + 2)];
/*  48 */       linkMesh(index1, index2, index3);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void linkMesh(int index1, int index2, int index3) {
/*  53 */     Vertex vertex1 = (Vertex)vertices.get(index1);
/*  54 */     Vertex vertex2 = (Vertex)vertices.get(index2);
/*  55 */     Vertex vertex3 = (Vertex)vertices.get(index3);
/*  56 */     Triangle triangle = new Triangle(vertex1, vertex2, vertex3);
/*  57 */     vertex1.addTriangleToFan(triangle);
/*  58 */     vertex2.addTriangleToFan(triangle);
/*  59 */     vertex3.addTriangleToFan(triangle);
/*  60 */     Edge edge1 = new Edge(vertex1, vertex2);
/*  61 */     Edge edge2 = new Edge(vertex2, vertex3);
/*  62 */     Edge edge3 = new Edge(vertex3, vertex1);
/*  63 */     if (vertex1.addNewEdge(edge1)) {
/*  64 */       vertex2.addNewEdge(edge1);
/*  65 */       edges.add(edge1);
/*     */     }
/*  67 */     if (vertex2.addNewEdge(edge2)) {
/*  68 */       vertex3.addNewEdge(edge2);
/*  69 */       edges.add(edge2);
/*     */     }
/*  71 */     if (vertex3.addNewEdge(edge3)) {
/*  72 */       vertex1.addNewEdge(edge3);
/*  73 */       edges.add(edge3);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void calculateAllCosts() {
/*  78 */     for (Edge edge : edges) {
/*  79 */       edge.evaluateCost();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void simplifyMesh(float errorMargin) {
/*  84 */     Edge lowest = null;
/*  85 */     while ((lowest = getLowestCostEdge()).getCost() < errorMargin) {
/*  86 */       if (vertices.size() < 9) {
/*  87 */         return;
/*     */       }
/*  89 */       edges.remove(lowest);
/*  90 */       vertices.remove(lowest.getRemovedVertex());
/*  91 */       List<Edge> dupes = lowest.collapse();
/*  92 */       edges.removeAll(dupes);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Edge getLowestCostEdge() {
/*  97 */     Edge lowest = null;
/*  98 */     for (Edge edge : edges) {
/*  99 */       if (lowest == null) {
/* 100 */         lowest = edge;
/*     */       }
/* 102 */       else if (edge.getCost() <= lowest.getCost()) {
/* 103 */         lowest = edge;
/*     */       }
/*     */     }
/*     */     
/* 107 */     return lowest;
/*     */   }
/*     */   
/*     */   private static int[] getSimplifiedIndices() {
/* 111 */     Set<Triangle> triangles = new HashSet();
/* 112 */     for (Vertex vertex : vertices) {
/* 113 */       triangles.addAll(vertex.getTriangleFan());
/*     */     }
/* 115 */     int[] newIndices = new int[triangles.size() * 3];
/* 116 */     int pointer = 0;
/* 117 */     for (Triangle triangle : triangles) {
/* 118 */       newIndices[(pointer++)] = triangle.getVertex1().getIndex();
/* 119 */       newIndices[(pointer++)] = triangle.getVertex2().getIndex();
/* 120 */       newIndices[(pointer++)] = triangle.getVertex3().getIndex();
/*     */     }
/* 122 */     return newIndices;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\errorMetricLOD\MeshSimplifier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */