/*    */ package errorMetricLOD;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import org.lwjgl.util.vector.Matrix4f;
/*    */ import org.lwjgl.util.vector.Vector3f;
/*    */ 
/*    */ public class Edge
/*    */ {
/*    */   private Vertex vertex1;
/*    */   private Vertex vertex2;
/*    */   private float cost;
/*    */   
/*    */   protected Edge(Vertex vertex1, Vertex vertex2)
/*    */   {
/* 16 */     this.vertex1 = vertex1;
/* 17 */     this.vertex2 = vertex2;
/*    */   }
/*    */   
/*    */   protected void evaluateCost() {
/* 21 */     Matrix4f matrix = new Matrix4f();
/* 22 */     Matrix4f.add(this.vertex1.getMatrixQ(), this.vertex2.getMatrixQ(), matrix);
/* 23 */     Vector3f newPos = this.vertex2.getPoint();
/* 24 */     this.cost = (matrix.m00 * newPos.x * newPos.x + 2.0F * matrix.m01 * newPos.x * newPos.y + 2.0F * matrix.m02 * newPos.x * newPos.z + 2.0F * matrix.m03 * newPos.x + matrix.m11 * newPos.y * newPos.y + 2.0F * matrix.m12 * newPos.y * newPos.z + 2.0F * matrix.m13 * newPos.y + matrix.m22 * newPos.z * newPos.z + 2.0F * matrix.m23 * newPos.z + matrix.m33);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 29 */     if (isConnectedToSeam()) {
/* 30 */       this.cost = 1.0E8F;
/*    */     }
/*    */   }
/*    */   
/*    */   protected boolean isAlongSeam() {
/* 35 */     return (this.vertex1.isEdgeVertex()) && (this.vertex2.isEdgeVertex());
/*    */   }
/*    */   
/*    */   protected boolean isConnectedToSeam() {
/* 39 */     return (this.vertex1.isEdgeVertex()) || (this.vertex2.isEdgeVertex());
/*    */   }
/*    */   
/*    */   protected float getCost() {
/* 43 */     return this.cost;
/*    */   }
/*    */   
/*    */   protected List<Edge> collapse() {
/* 47 */     this.vertex1.notifyEdgeRemoved(this);
/* 48 */     this.vertex2.notifyEdgeRemoved(this);
/* 49 */     return this.vertex1.remove(this.vertex2);
/*    */   }
/*    */   
/*    */   protected void replaceVertex(Vertex replaceThis, Vertex withThis) {
/* 53 */     if (this.vertex1 == replaceThis) {
/* 54 */       this.vertex1 = withThis;
/* 55 */     } else if (this.vertex2 == replaceThis) {
/* 56 */       this.vertex2 = withThis;
/*    */     } else {
/* 58 */       System.err.println("No edge vertex changed!");
/*    */     }
/*    */   }
/*    */   
/*    */   protected void delete() {
/* 63 */     this.vertex1.notifyEdgeRemoved(this);
/* 64 */     this.vertex2.notifyEdgeRemoved(this);
/*    */   }
/*    */   
/*    */   protected Vertex getRemovedVertex() {
/* 68 */     return this.vertex1;
/*    */   }
/*    */   
/*    */   private boolean contains(Vertex v) {
/* 72 */     if ((this.vertex1 == v) || (this.vertex2 == v)) {
/* 73 */       return true;
/*    */     }
/* 75 */     return false;
/*    */   }
/*    */   
/*    */   protected static boolean areDuplicates(Edge e1, Edge e2)
/*    */   {
/* 80 */     if ((e1.contains(e2.vertex1)) && (e1.contains(e2.vertex2))) {
/* 81 */       return true;
/*    */     }
/* 83 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\errorMetricLOD\Edge.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */