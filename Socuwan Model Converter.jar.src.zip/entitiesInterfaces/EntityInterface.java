package entitiesInterfaces;

import blueprintInterfaces.BlueprintInterface;
import toolbox.Colour;

public abstract interface EntityInterface
{
  public abstract BlueprintInterface getBlueprint();
  
  public abstract float getX();
  
  public abstract float getY();
  
  public abstract float getZ();
  
  public abstract float getRotX();
  
  public abstract float getRotY();
  
  public abstract float getRotZ();
  
  public abstract float getScale();
  
  public abstract void setDistance(float paramFloat);
  
  public abstract float getDistance();
  
  public abstract void setLOD(int paramInt);
  
  public abstract boolean isVisible();
  
  public abstract float getVisibleDistance();
  
  public abstract int getLOD();
  
  public abstract float getFurthestPoint();
  
  public abstract float[] getInstanceTextureCoords();
  
  public abstract Colour getMaterial1Colour();
  
  public abstract Colour getMaterial2Colour();
  
  public abstract void setReflectionFlag();
  
  public abstract boolean hasReflection();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\entitiesInterfaces\EntityInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */