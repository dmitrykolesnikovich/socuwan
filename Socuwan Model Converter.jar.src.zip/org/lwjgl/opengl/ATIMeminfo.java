package org.lwjgl.opengl;

public final class ATIMeminfo
{
  public static final int GL_VBO_FREE_MEMORY_ATI = 34811;
  public static final int GL_TEXTURE_FREE_MEMORY_ATI = 34812;
  public static final int GL_RENDERBUFFER_FREE_MEMORY_ATI = 34813;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ATIMeminfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */