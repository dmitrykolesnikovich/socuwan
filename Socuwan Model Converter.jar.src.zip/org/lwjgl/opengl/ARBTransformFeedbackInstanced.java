/*    */ package org.lwjgl.opengl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ARBTransformFeedbackInstanced
/*    */ {
/*    */   public static void glDrawTransformFeedbackInstanced(int mode, int id, int primcount)
/*    */   {
/* 13 */     GL42.glDrawTransformFeedbackInstanced(mode, id, primcount);
/*    */   }
/*    */   
/*    */   public static void glDrawTransformFeedbackStreamInstanced(int mode, int id, int stream, int primcount) {
/* 17 */     GL42.glDrawTransformFeedbackStreamInstanced(mode, id, stream, primcount);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBTransformFeedbackInstanced.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */