package org.lwjgl.opengl;

public final class EXTBgra
{
  public static final int GL_BGR_EXT = 32992;
  public static final int GL_BGRA_EXT = 32993;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTBgra.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */