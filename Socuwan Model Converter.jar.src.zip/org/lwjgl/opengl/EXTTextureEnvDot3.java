package org.lwjgl.opengl;

public final class EXTTextureEnvDot3
{
  public static final int GL_DOT3_RGB_EXT = 34624;
  public static final int GL_DOT3_RGBA_EXT = 34625;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTTextureEnvDot3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */