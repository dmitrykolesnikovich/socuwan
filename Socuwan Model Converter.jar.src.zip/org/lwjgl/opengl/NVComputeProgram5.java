package org.lwjgl.opengl;

public final class NVComputeProgram5
{
  public static final int GL_COMPUTE_PROGRAM_NV = 37115;
  public static final int GL_COMPUTE_PROGRAM_PARAMETER_BUFFER_NV = 37116;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\NVComputeProgram5.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */