package org.lwjgl.opengl;

public final class ARBMapBufferAlignment
{
  public static final int GL_MIN_MAP_BUFFER_ALIGNMENT = 37052;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBMapBufferAlignment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */