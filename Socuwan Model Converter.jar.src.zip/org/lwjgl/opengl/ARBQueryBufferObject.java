package org.lwjgl.opengl;

public final class ARBQueryBufferObject
{
  public static final int GL_QUERY_RESULT_NO_WAIT = 37268;
  public static final int GL_QUERY_BUFFER = 37266;
  public static final int GL_QUERY_BUFFER_BINDING = 37267;
  public static final int GL_QUERY_BUFFER_BARRIER_BIT = 32768;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBQueryBufferObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */