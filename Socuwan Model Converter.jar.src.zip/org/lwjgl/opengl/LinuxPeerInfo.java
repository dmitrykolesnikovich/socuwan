/*    */ package org.lwjgl.opengl;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class LinuxPeerInfo
/*    */   extends PeerInfo
/*    */ {
/*    */   LinuxPeerInfo()
/*    */   {
/* 44 */     super(createHandle());
/*    */   }
/*    */   
/*    */   private static native ByteBuffer createHandle();
/*    */   
/* 49 */   public final long getDisplay() { return nGetDisplay(getHandle()); }
/*    */   
/*    */   private static native long nGetDisplay(ByteBuffer paramByteBuffer);
/*    */   
/*    */   public final long getDrawable() {
/* 54 */     return nGetDrawable(getHandle());
/*    */   }
/*    */   
/*    */   private static native long nGetDrawable(ByteBuffer paramByteBuffer);
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\LinuxPeerInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */