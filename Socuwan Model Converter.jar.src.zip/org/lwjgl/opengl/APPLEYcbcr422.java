package org.lwjgl.opengl;

public final class APPLEYcbcr422
{
  public static final int GL_YCBCR_422_APPLE = 34233;
  public static final int GL_UNSIGNED_SHORT_8_8_APPLE = 34234;
  public static final int GL_UNSIGNED_SHORT_8_8_REV_APPLE = 34235;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\APPLEYcbcr422.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */