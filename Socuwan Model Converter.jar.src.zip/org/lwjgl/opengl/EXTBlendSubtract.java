package org.lwjgl.opengl;

public final class EXTBlendSubtract
{
  public static final int GL_FUNC_SUBTRACT_EXT = 32778;
  public static final int GL_FUNC_REVERSE_SUBTRACT_EXT = 32779;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTBlendSubtract.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */