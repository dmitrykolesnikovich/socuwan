package org.lwjgl.opengl;

public final class EXTRescaleNormal
{
  public static final int GL_RESCALE_NORMAL_EXT = 32826;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTRescaleNormal.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */