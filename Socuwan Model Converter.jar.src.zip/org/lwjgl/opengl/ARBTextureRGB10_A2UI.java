package org.lwjgl.opengl;

public final class ARBTextureRGB10_A2UI
{
  public static final int GL_RGB10_A2UI = 36975;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBTextureRGB10_A2UI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */