/*    */ package org.lwjgl.opengl;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.IntBuffer;
/*    */ import java.nio.ShortBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ARBDrawElementsBaseVertex
/*    */ {
/*    */   public static void glDrawElementsBaseVertex(int mode, ByteBuffer indices, int basevertex)
/*    */   {
/* 13 */     GL32.glDrawElementsBaseVertex(mode, indices, basevertex);
/*    */   }
/*    */   
/* 16 */   public static void glDrawElementsBaseVertex(int mode, IntBuffer indices, int basevertex) { GL32.glDrawElementsBaseVertex(mode, indices, basevertex); }
/*    */   
/*    */   public static void glDrawElementsBaseVertex(int mode, ShortBuffer indices, int basevertex) {
/* 19 */     GL32.glDrawElementsBaseVertex(mode, indices, basevertex);
/*    */   }
/*    */   
/* 22 */   public static void glDrawElementsBaseVertex(int mode, int indices_count, int type, long indices_buffer_offset, int basevertex) { GL32.glDrawElementsBaseVertex(mode, indices_count, type, indices_buffer_offset, basevertex); }
/*    */   
/*    */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ByteBuffer indices, int basevertex)
/*    */   {
/* 26 */     GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices, basevertex);
/*    */   }
/*    */   
/* 29 */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, IntBuffer indices, int basevertex) { GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices, basevertex); }
/*    */   
/*    */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ShortBuffer indices, int basevertex) {
/* 32 */     GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices, basevertex);
/*    */   }
/*    */   
/* 35 */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, int indices_count, int type, long indices_buffer_offset, int basevertex) { GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices_count, type, indices_buffer_offset, basevertex); }
/*    */   
/*    */   public static void glDrawElementsInstancedBaseVertex(int mode, ByteBuffer indices, int primcount, int basevertex)
/*    */   {
/* 39 */     GL32.glDrawElementsInstancedBaseVertex(mode, indices, primcount, basevertex);
/*    */   }
/*    */   
/* 42 */   public static void glDrawElementsInstancedBaseVertex(int mode, IntBuffer indices, int primcount, int basevertex) { GL32.glDrawElementsInstancedBaseVertex(mode, indices, primcount, basevertex); }
/*    */   
/*    */   public static void glDrawElementsInstancedBaseVertex(int mode, ShortBuffer indices, int primcount, int basevertex) {
/* 45 */     GL32.glDrawElementsInstancedBaseVertex(mode, indices, primcount, basevertex);
/*    */   }
/*    */   
/* 48 */   public static void glDrawElementsInstancedBaseVertex(int mode, int indices_count, int type, long indices_buffer_offset, int primcount, int basevertex) { GL32.glDrawElementsInstancedBaseVertex(mode, indices_count, type, indices_buffer_offset, primcount, basevertex); }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBDrawElementsBaseVertex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */