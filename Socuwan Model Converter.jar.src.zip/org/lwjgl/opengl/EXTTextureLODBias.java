package org.lwjgl.opengl;

public final class EXTTextureLODBias
{
  public static final int GL_TEXTURE_FILTER_CONTROL_EXT = 34048;
  public static final int GL_TEXTURE_LOD_BIAS_EXT = 34049;
  public static final int GL_MAX_TEXTURE_LOD_BIAS_EXT = 34045;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTTextureLODBias.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */