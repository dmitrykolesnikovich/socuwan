package org.lwjgl.opengl;

public final class EXTTextureCompressionS3TC
{
  public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 33776;
  public static final int GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 33777;
  public static final int GL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 33778;
  public static final int GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTTextureCompressionS3TC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */