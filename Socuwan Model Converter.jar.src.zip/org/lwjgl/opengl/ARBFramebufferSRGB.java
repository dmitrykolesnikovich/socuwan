package org.lwjgl.opengl;

public final class ARBFramebufferSRGB
{
  public static final int GLX_FRAMEBUFFER_SRGB_CAPABLE_ARB = 8370;
  public static final int WGL_FRAMEBUFFER_SRGB_CAPABLE_ARB = 8361;
  public static final int GL_FRAMEBUFFER_SRGB_ARB = 36281;
  public static final int GL_FRAMEBUFFER_SRGB_CAPABLE_ARB = 36282;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBFramebufferSRGB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */