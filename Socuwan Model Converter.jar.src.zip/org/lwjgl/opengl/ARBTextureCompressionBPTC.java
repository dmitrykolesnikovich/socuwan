package org.lwjgl.opengl;

public final class ARBTextureCompressionBPTC
{
  public static final int GL_COMPRESSED_RGBA_BPTC_UNORM_ARB = 36492;
  public static final int GL_COMPRESSED_SRGB_ALPHA_BPTC_UNORM_ARB = 36493;
  public static final int GL_COMPRESSED_RGB_BPTC_SIGNED_FLOAT_ARB = 36494;
  public static final int GL_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_ARB = 36495;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBTextureCompressionBPTC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */