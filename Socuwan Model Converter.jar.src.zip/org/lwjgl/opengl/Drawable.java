package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.PointerBuffer;

public abstract interface Drawable
{
  public abstract boolean isCurrent()
    throws LWJGLException;
  
  public abstract void makeCurrent()
    throws LWJGLException;
  
  public abstract void releaseContext()
    throws LWJGLException;
  
  public abstract void destroy();
  
  public abstract void setCLSharingProperties(PointerBuffer paramPointerBuffer)
    throws LWJGLException;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\Drawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */