package org.lwjgl.opengl;

public final class EXTTextureRectangle
{
  public static final int GL_TEXTURE_RECTANGLE_EXT = 34037;
  public static final int GL_TEXTURE_BINDING_RECTANGLE_EXT = 34038;
  public static final int GL_PROXY_TEXTURE_RECTANGLE_EXT = 34039;
  public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_EXT = 34040;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTTextureRectangle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */