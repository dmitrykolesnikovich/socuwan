package org.lwjgl.opengl;

public final class NVDepthClamp
{
  public static final int GL_DEPTH_CLAMP_NV = 34383;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\NVDepthClamp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */