package org.lwjgl.opengl;

public final class ARBEnhancedLayouts
{
  public static final int GL_LOCATION_COMPONENT = 37706;
  public static final int GL_TRANSFORM_FEEDBACK_BUFFER_INDEX = 37707;
  public static final int GL_TRANSFORM_FEEDBACK_BUFFER_STRIDE = 37708;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBEnhancedLayouts.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */