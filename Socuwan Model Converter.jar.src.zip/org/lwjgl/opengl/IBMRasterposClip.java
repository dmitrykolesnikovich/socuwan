package org.lwjgl.opengl;

public final class IBMRasterposClip
{
  public static final int GL_RASTER_POSITION_UNCLIPPED_IBM = 103010;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\IBMRasterposClip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */