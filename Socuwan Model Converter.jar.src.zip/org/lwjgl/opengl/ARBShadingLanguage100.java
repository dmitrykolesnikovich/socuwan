package org.lwjgl.opengl;

public final class ARBShadingLanguage100
{
  public static final int GL_SHADING_LANGUAGE_VERSION_ARB = 35724;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBShadingLanguage100.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */