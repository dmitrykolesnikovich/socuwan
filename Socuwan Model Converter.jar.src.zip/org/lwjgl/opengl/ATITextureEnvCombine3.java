package org.lwjgl.opengl;

public final class ATITextureEnvCombine3
{
  public static final int GL_MODULATE_ADD_ATI = 34628;
  public static final int GL_MODULATE_SIGNED_ADD_ATI = 34629;
  public static final int GL_MODULATE_SUBTRACT_ATI = 34630;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ATITextureEnvCombine3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */