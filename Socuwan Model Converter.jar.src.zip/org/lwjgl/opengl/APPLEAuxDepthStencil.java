package org.lwjgl.opengl;

public final class APPLEAuxDepthStencil
{
  public static final int GL_AUX_DEPTH_STENCIL_APPLE = 35348;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\APPLEAuxDepthStencil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */