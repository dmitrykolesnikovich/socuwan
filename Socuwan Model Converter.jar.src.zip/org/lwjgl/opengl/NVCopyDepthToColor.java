package org.lwjgl.opengl;

public final class NVCopyDepthToColor
{
  public static final int GL_DEPTH_STENCIL_TO_RGBA_NV = 34926;
  public static final int GL_DEPTH_STENCIL_TO_BGRA_NV = 34927;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\NVCopyDepthToColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */