package org.lwjgl.opengl;

public final class EXTFramebufferSRGB
{
  public static final int GLX_FRAMEBUFFER_SRGB_CAPABLE_EXT = 8370;
  public static final int WGL_FRAMEBUFFER_SRGB_CAPABLE_EXT = 8361;
  public static final int GL_FRAMEBUFFER_SRGB_EXT = 36281;
  public static final int GL_FRAMEBUFFER_SRGB_CAPABLE_EXT = 36282;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTFramebufferSRGB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */