/*     */ package org.lwjgl.opengl;
/*     */ 
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.LWJGLException;
/*     */ import org.lwjgl.LWJGLUtil;
/*     */ import org.lwjgl.PointerBuffer;
/*     */ import org.lwjgl.opengles.ContextAttribs;
/*     */ import org.lwjgl.opengles.EGL;
/*     */ import org.lwjgl.opengles.EGLConfig;
/*     */ import org.lwjgl.opengles.EGLContext;
/*     */ import org.lwjgl.opengles.EGLDisplay;
/*     */ import org.lwjgl.opengles.EGLSurface;
/*     */ import org.lwjgl.opengles.GLES20;
/*     */ import org.lwjgl.opengles.PixelFormat;
/*     */ import org.lwjgl.opengles.PowerManagementEventException;
/*     */ import org.lwjgl.opengles.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DrawableGLES
/*     */   implements DrawableLWJGL
/*     */ {
/*     */   protected PixelFormat pixel_format;
/*     */   protected EGLDisplay eglDisplay;
/*     */   protected EGLConfig eglConfig;
/*     */   protected EGLSurface eglSurface;
/*     */   protected ContextGLES context;
/*     */   protected Drawable shared_drawable;
/*     */   
/*     */   public void setPixelFormat(PixelFormatLWJGL pf)
/*     */     throws LWJGLException
/*     */   {
/*  68 */     synchronized (GlobalLock.lock) {
/*  69 */       this.pixel_format = ((PixelFormat)pf);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public PixelFormatLWJGL getPixelFormat()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 2	org/lwjgl/opengl/GlobalLock:lock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 4	org/lwjgl/opengl/DrawableGLES:pixel_format	Lorg/lwjgl/opengles/PixelFormat;
/*     */     //   10: aload_1
/*     */     //   11: monitorexit
/*     */     //   12: areturn
/*     */     //   13: astore_2
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: aload_2
/*     */     //   17: athrow
/*     */     // Line number table:
/*     */     //   Java source line #74	-> byte code offset #0
/*     */     //   Java source line #75	-> byte code offset #6
/*     */     //   Java source line #76	-> byte code offset #13
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	18	0	this	DrawableGLES
/*     */     //   4	11	1	Ljava/lang/Object;	Object
/*     */     //   13	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	12	13	finally
/*     */     //   13	16	13	finally
/*     */   }
/*     */   
/*     */   public void initialize(long window, long display_id, int eglSurfaceType, PixelFormat pf)
/*     */     throws LWJGLException
/*     */   {
/*  80 */     synchronized (GlobalLock.lock) {
/*  81 */       if (this.eglSurface != null) {
/*  82 */         this.eglSurface.destroy();
/*  83 */         this.eglSurface = null;
/*     */       }
/*     */       
/*  86 */       if (this.eglDisplay != null) {
/*  87 */         this.eglDisplay.terminate();
/*  88 */         this.eglDisplay = null;
/*     */       }
/*     */       
/*  91 */       EGLDisplay eglDisplay = EGL.eglGetDisplay((int)display_id);
/*     */       
/*  93 */       int[] attribs = { 12329, 0, 12352, 4, 12333, 0 };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */       EGLConfig[] configs = eglDisplay.chooseConfig(pf.getAttribBuffer(eglDisplay, eglSurfaceType, attribs), null, BufferUtils.createIntBuffer(1));
/* 100 */       if (configs.length == 0) {
/* 101 */         throw new LWJGLException("No EGLConfigs found for the specified PixelFormat.");
/*     */       }
/* 103 */       EGLConfig eglConfig = pf.getBestMatch(configs);
/* 104 */       EGLSurface eglSurface = eglDisplay.createWindowSurface(eglConfig, window, null);
/* 105 */       pf.setSurfaceAttribs(eglSurface);
/*     */       
/* 107 */       this.eglDisplay = eglDisplay;
/* 108 */       this.eglConfig = eglConfig;
/* 109 */       this.eglSurface = eglSurface;
/*     */       
/*     */ 
/* 112 */       if (this.context != null)
/* 113 */         this.context.getEGLContext().setDisplay(eglDisplay);
/*     */     }
/*     */   }
/*     */   
/*     */   public void createContext(ContextAttribs attribs, Drawable shared_drawable) throws LWJGLException {
/* 118 */     synchronized (GlobalLock.lock) {
/* 119 */       this.context = new ContextGLES(this, attribs, shared_drawable != null ? ((DrawableGLES)shared_drawable).getContext() : null);
/* 120 */       this.shared_drawable = shared_drawable;
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   Drawable getSharedDrawable()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 2	org/lwjgl/opengl/GlobalLock:lock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 27	org/lwjgl/opengl/DrawableGLES:shared_drawable	Lorg/lwjgl/opengl/Drawable;
/*     */     //   10: aload_1
/*     */     //   11: monitorexit
/*     */     //   12: areturn
/*     */     //   13: astore_2
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: aload_2
/*     */     //   17: athrow
/*     */     // Line number table:
/*     */     //   Java source line #125	-> byte code offset #0
/*     */     //   Java source line #126	-> byte code offset #6
/*     */     //   Java source line #127	-> byte code offset #13
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	18	0	this	DrawableGLES
/*     */     //   4	11	1	Ljava/lang/Object;	Object
/*     */     //   13	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	12	13	finally
/*     */     //   13	16	13	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public EGLDisplay getEGLDisplay()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 2	org/lwjgl/opengl/GlobalLock:lock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 7	org/lwjgl/opengl/DrawableGLES:eglDisplay	Lorg/lwjgl/opengles/EGLDisplay;
/*     */     //   10: aload_1
/*     */     //   11: monitorexit
/*     */     //   12: areturn
/*     */     //   13: astore_2
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: aload_2
/*     */     //   17: athrow
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #132	-> byte code offset #6
/*     */     //   Java source line #133	-> byte code offset #13
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	18	0	this	DrawableGLES
/*     */     //   4	11	1	Ljava/lang/Object;	Object
/*     */     //   13	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	12	13	finally
/*     */     //   13	16	13	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public EGLConfig getEGLConfig()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 2	org/lwjgl/opengl/GlobalLock:lock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 19	org/lwjgl/opengl/DrawableGLES:eglConfig	Lorg/lwjgl/opengles/EGLConfig;
/*     */     //   10: aload_1
/*     */     //   11: monitorexit
/*     */     //   12: areturn
/*     */     //   13: astore_2
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: aload_2
/*     */     //   17: athrow
/*     */     // Line number table:
/*     */     //   Java source line #137	-> byte code offset #0
/*     */     //   Java source line #138	-> byte code offset #6
/*     */     //   Java source line #139	-> byte code offset #13
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	18	0	this	DrawableGLES
/*     */     //   4	11	1	Ljava/lang/Object;	Object
/*     */     //   13	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	12	13	finally
/*     */     //   13	16	13	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public EGLSurface getEGLSurface()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 2	org/lwjgl/opengl/GlobalLock:lock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 5	org/lwjgl/opengl/DrawableGLES:eglSurface	Lorg/lwjgl/opengles/EGLSurface;
/*     */     //   10: aload_1
/*     */     //   11: monitorexit
/*     */     //   12: areturn
/*     */     //   13: astore_2
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: aload_2
/*     */     //   17: athrow
/*     */     // Line number table:
/*     */     //   Java source line #143	-> byte code offset #0
/*     */     //   Java source line #144	-> byte code offset #6
/*     */     //   Java source line #145	-> byte code offset #13
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	18	0	this	DrawableGLES
/*     */     //   4	11	1	Ljava/lang/Object;	Object
/*     */     //   13	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	12	13	finally
/*     */     //   13	16	13	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public ContextGLES getContext()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 2	org/lwjgl/opengl/GlobalLock:lock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 20	org/lwjgl/opengl/DrawableGLES:context	Lorg/lwjgl/opengl/ContextGLES;
/*     */     //   10: aload_1
/*     */     //   11: monitorexit
/*     */     //   12: areturn
/*     */     //   13: astore_2
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: aload_2
/*     */     //   17: athrow
/*     */     // Line number table:
/*     */     //   Java source line #149	-> byte code offset #0
/*     */     //   Java source line #150	-> byte code offset #6
/*     */     //   Java source line #151	-> byte code offset #13
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	18	0	this	DrawableGLES
/*     */     //   4	11	1	Ljava/lang/Object;	Object
/*     */     //   13	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	12	13	finally
/*     */     //   13	16	13	finally
/*     */   }
/*     */   
/*     */   public Context createSharedContext()
/*     */     throws LWJGLException
/*     */   {
/* 155 */     synchronized (GlobalLock.lock) {
/* 156 */       checkDestroyed();
/* 157 */       return new ContextGLES(this, this.context.getContextAttribs(), this.context);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void checkGLError() {}
/*     */   
/*     */   public void setSwapInterval(int swap_interval)
/*     */   {
/* 166 */     ContextGLES.setSwapInterval(swap_interval);
/*     */   }
/*     */   
/*     */   public void swapBuffers()
/*     */     throws LWJGLException
/*     */   {}
/*     */   
/*     */   public void initContext(float r, float g, float b)
/*     */   {
/* 175 */     GLES20.glClearColor(r, g, b, 0.0F);
/*     */     
/* 177 */     GLES20.glClear(16384);
/*     */   }
/*     */   
/*     */   public boolean isCurrent() throws LWJGLException {
/* 181 */     synchronized (GlobalLock.lock) {
/* 182 */       checkDestroyed();
/* 183 */       return this.context.isCurrent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void makeCurrent() throws LWJGLException, PowerManagementEventException {
/* 188 */     synchronized (GlobalLock.lock) {
/* 189 */       checkDestroyed();
/* 190 */       this.context.makeCurrent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void releaseContext() throws LWJGLException, PowerManagementEventException {
/* 195 */     synchronized (GlobalLock.lock) {
/* 196 */       checkDestroyed();
/* 197 */       if (this.context.isCurrent())
/* 198 */         this.context.releaseCurrent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 203 */     synchronized (GlobalLock.lock) {
/*     */       try {
/* 205 */         if (this.context != null) {
/*     */           try {
/* 207 */             releaseContext();
/*     */           }
/*     */           catch (PowerManagementEventException e) {}
/*     */           
/*     */ 
/* 212 */           this.context.forceDestroy();
/* 213 */           this.context = null;
/*     */         }
/*     */         
/* 216 */         if (this.eglSurface != null) {
/* 217 */           this.eglSurface.destroy();
/* 218 */           this.eglSurface = null;
/*     */         }
/*     */         
/* 221 */         if (this.eglDisplay != null) {
/* 222 */           this.eglDisplay.terminate();
/* 223 */           this.eglDisplay = null;
/*     */         }
/*     */         
/* 226 */         this.pixel_format = null;
/* 227 */         this.shared_drawable = null;
/*     */       } catch (LWJGLException e) {
/* 229 */         LWJGLUtil.log("Exception occurred while destroying Drawable: " + e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void checkDestroyed() {
/* 235 */     if (this.context == null)
/* 236 */       throw new IllegalStateException("The Drawable has no context available.");
/*     */   }
/*     */   
/*     */   public void setCLSharingProperties(PointerBuffer properties) throws LWJGLException {
/* 240 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\DrawableGLES.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */