package org.lwjgl.opengl;

public final class ARBHalfFloatVertex
{
  public static final int GL_HALF_FLOAT = 5131;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ARBHalfFloatVertex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */