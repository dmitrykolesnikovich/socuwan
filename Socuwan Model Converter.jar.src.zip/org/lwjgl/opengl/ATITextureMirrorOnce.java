package org.lwjgl.opengl;

public final class ATITextureMirrorOnce
{
  public static final int GL_MIRROR_CLAMP_ATI = 34626;
  public static final int GL_MIRROR_CLAMP_TO_EDGE_ATI = 34627;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\ATITextureMirrorOnce.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */