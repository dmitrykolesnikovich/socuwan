package org.lwjgl.opengl;

public final class EXTSeparateSpecularColor
{
  public static final int GL_SINGLE_COLOR_EXT = 33273;
  public static final int GL_SEPARATE_SPECULAR_COLOR_EXT = 33274;
  public static final int GL_LIGHT_MODEL_COLOR_CONTROL_EXT = 33272;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opengl\EXTSeparateSpecularColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */