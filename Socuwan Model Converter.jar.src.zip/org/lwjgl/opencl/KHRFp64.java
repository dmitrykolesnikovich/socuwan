package org.lwjgl.opencl;

public final class KHRFp64
{
  public static final int CL_DEVICE_DOUBLE_FP_CONFIG = 4146;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opencl\KHRFp64.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */