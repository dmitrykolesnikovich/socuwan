package org.lwjgl.opencl;

public final class KHRGLDepthImages
{
  public static final int CL_DEPTH_STENCIL = 4286;
  public static final int CL_UNORM_INT24 = 4319;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\org\lwjgl\opencl\KHRGLDepthImages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */