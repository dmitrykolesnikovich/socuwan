/*     */ package lodSettingsPanel;
/*     */ 
/*     */ import backend.LodModelVersion;
/*     */ import backend.MasterModel;
/*     */ import frontend.MainFrame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.text.NumberFormatter;
/*     */ import lodListPanel.LODListComponent;
/*     */ import mainApp.TheLODCalculator;
/*     */ 
/*     */ public class LODPanel extends javax.swing.JPanel
/*     */ {
/*     */   private MasterModel model;
/*     */   private LodModelVersion version;
/*     */   private JLabel triangleCount;
/*     */   private JLabel lodDistance;
/*     */   private JFormattedTextField errorMargin;
/*     */   private LodSettingsPanel panel;
/*     */   private JButton confirm;
/*     */   private LODListComponent possibleLODPanel;
/*     */   
/*     */   public LODPanel(int width, int height, LodModelVersion simplifiedModel, MasterModel model, boolean isNew, LodSettingsPanel panel, LODListComponent possibleLODPanel)
/*     */   {
/*  31 */     this.possibleLODPanel = possibleLODPanel;
/*  32 */     this.model = model;
/*  33 */     this.panel = panel;
/*  34 */     this.version = simplifiedModel;
/*  35 */     setPreferredSize(new java.awt.Dimension(width, height));
/*  36 */     setLayout(new java.awt.GridBagLayout());
/*  37 */     addLODChoice(isNew);
/*  38 */     addDistance();
/*  39 */     addTriangleCount();
/*  40 */     addShowButton();
/*  41 */     addErrorMargin();
/*  42 */     addCalculateButton(isNew);
/*  43 */     addSetButton(isNew);
/*  44 */     addCancelButton(isNew);
/*  45 */     mainApp.MainApp.overrideVersion = this.version;
/*     */   }
/*     */   
/*     */   public void destroy() {
/*  49 */     mainApp.MainApp.overrideVersion = null;
/*     */   }
/*     */   
/*     */   private void addLODChoice(final boolean isNew) {
/*  53 */     JLabel label = new JLabel("LOD:");
/*  54 */     label.setFont(MainFrame.SMALL_FONT);
/*  55 */     label.setHorizontalAlignment(0);
/*  56 */     add(label, getGC(0, 0, 1));
/*     */     
/*  58 */     Integer[] possibleLODs = null;
/*  59 */     if (isNew) {
/*  60 */       possibleLODs = this.model.getPossibleLODS();
/*     */     } else {
/*  62 */       possibleLODs = new Integer[this.model.getPossibleLODS().length + 1];
/*  63 */       possibleLODs[0] = Integer.valueOf(this.version.getLod());
/*  64 */       for (int i = 1; i < possibleLODs.length; i++) {
/*  65 */         possibleLODs[i] = this.model.getPossibleLODS()[(i - 1)];
/*     */       }
/*     */     }
/*  68 */     final JComboBox<Integer> lods = new JComboBox(possibleLODs);
/*  69 */     lods.setFont(MainFrame.SMALL_FONT);
/*  70 */     lods.setSelectedItem(Integer.valueOf(this.version.getLod()));
/*  71 */     lods.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*  75 */         LODPanel.this.version.setLod(((Integer)lods.getSelectedItem()).intValue());
/*  76 */         LODPanel.this.lodDistance.setText(Integer.toString(TheLODCalculator.getDistanceOfLOD(((Integer)lods.getSelectedItem()).intValue())));
/*  77 */         if (!isNew) {
/*  78 */           LODPanel.this.model.resortList();
/*  79 */           LODPanel.this.panel.notifyChangedListOrder();
/*  80 */           LODPanel.this.possibleLODPanel.updateInfo();
/*     */         }
/*     */         
/*     */       }
/*  84 */     });
/*  85 */     add(lods, getGC(1, 0, 1));
/*     */   }
/*     */   
/*     */   private void addTriangleCount() {
/*  89 */     JLabel label = new JLabel("Triangle Count:");
/*  90 */     label.setFont(MainFrame.SMALL_FONT);
/*  91 */     label.setHorizontalAlignment(0);
/*  92 */     add(label, getGC(2, 0, 1));
/*  93 */     this.triangleCount = new JLabel(Integer.toString(this.version.getTriangleCount()));
/*  94 */     this.triangleCount.setFont(MainFrame.SMALL_FONT);
/*  95 */     this.triangleCount.setHorizontalAlignment(2);
/*  96 */     add(this.triangleCount, getGC(3, 0, 1));
/*     */   }
/*     */   
/*     */   private void addDistance() {
/* 100 */     JLabel label = new JLabel("LOD start distance:");
/* 101 */     label.setFont(MainFrame.SMALL_FONT);
/* 102 */     label.setHorizontalAlignment(0);
/* 103 */     add(label, getGC(0, 1, 1));
/* 104 */     this.lodDistance = new JLabel(Integer.toString(TheLODCalculator.getDistanceOfLOD(this.version.getLod())));
/*     */     
/* 106 */     this.lodDistance.setFont(MainFrame.SMALL_FONT);
/* 107 */     this.lodDistance.setHorizontalAlignment(2);
/* 108 */     add(this.lodDistance, getGC(1, 1, 1));
/*     */   }
/*     */   
/*     */   private void addShowButton() {
/* 112 */     JButton button = new JButton("Preview Distance");
/* 113 */     button.setFont(MainFrame.SMALL_FONT);
/* 114 */     button.setHorizontalAlignment(0);
/* 115 */     button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 119 */         mainApp.MainApp.camera.setDistanceFromPlayer(Float.parseFloat(LODPanel.this.lodDistance.getText()));
/*     */       }
/*     */       
/* 122 */     });
/* 123 */     add(button, getGC(2, 1, 2));
/*     */   }
/*     */   
/*     */   private void addErrorMargin() {
/* 127 */     JLabel label = new JLabel("Error Margin:");
/* 128 */     label.setFont(MainFrame.SMALL_FONT);
/* 129 */     label.setHorizontalAlignment(0);
/* 130 */     add(label, getGC(0, 2, 1));
/*     */     
/* 132 */     this.errorMargin = createTextField(6);
/* 133 */     this.errorMargin.setFont(MainFrame.SMALL_FONT);
/* 134 */     this.errorMargin.setText(Float.toString(this.version.getErrorMargin()));
/* 135 */     add(this.errorMargin, getGC(1, 2, 1));
/*     */   }
/*     */   
/*     */   private void addCalculateButton(final boolean isNew)
/*     */   {
/* 140 */     JButton button = new JButton("Calculate");
/* 141 */     button.setFont(MainFrame.SMALL_FONT);
/* 142 */     button.setHorizontalAlignment(0);
/* 143 */     button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 147 */         String value = LODPanel.this.errorMargin.getText().replaceAll(",", "");
/* 148 */         LODPanel.this.version.setErrorMargin(Float.parseFloat(value));
/* 149 */         LODPanel.this.version.calculateSimplifiedVersion();
/* 150 */         LODPanel.this.triangleCount.setText(Integer.toString(LODPanel.this.version.getTriangleCount()));
/* 151 */         if (!isNew) {
/* 152 */           LODPanel.this.panel.notifyChangedIndexCount();
/*     */         }
/* 154 */         LODPanel.this.confirm.setVisible(true);
/* 155 */         if (LODPanel.this.possibleLODPanel != null) {
/* 156 */           LODPanel.this.possibleLODPanel.updateInfo();
/*     */         }
/*     */       }
/* 159 */     });
/* 160 */     add(button, getGC(2, 2, 2));
/*     */   }
/*     */   
/*     */   private void addSetButton(final boolean isNew) {
/* 164 */     this.confirm = new JButton("Confirm");
/* 165 */     this.confirm.setFont(MainFrame.SMALL_FONT);
/* 166 */     this.confirm.setHorizontalAlignment(0);
/* 167 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 171 */         if (isNew) {
/* 172 */           LODPanel.this.model.addLodVersion(LODPanel.this.version);
/* 173 */           LODPanel.this.panel.notifyChangedIndexCount();
/* 174 */           LODPanel.this.panel.notifyChangedLODCount();
/* 175 */           LODPanel.this.panel.notifyAddLOD(LODPanel.this.version);
/* 176 */           LODPanel.this.panel.notifyChangedListOrder();
/*     */         } else {
/* 178 */           LODPanel.this.possibleLODPanel.updateInfo();
/*     */         }
/* 180 */         LODPanel.this.panel.notifyChangedIndexCount();
/* 181 */         LODPanel.this.panel.clear();
/*     */       }
/* 183 */     });
/* 184 */     add(this.confirm, getGC(0, 3, 2));
/* 185 */     this.confirm.setVisible(!isNew);
/*     */   }
/*     */   
/*     */   private void addCancelButton(boolean isNew) {
/* 189 */     JButton button = new JButton("Cancel");
/* 190 */     button.setFont(MainFrame.SMALL_FONT);
/* 191 */     button.setVisible(isNew);
/* 192 */     button.setHorizontalAlignment(0);
/* 193 */     button.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 198 */         LODPanel.this.panel.clear();
/*     */       }
/*     */       
/* 201 */     });
/* 202 */     add(button, getGC(2, 3, 2));
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y, int gridSizeX) {
/* 206 */     GridBagConstraints gc = new GridBagConstraints();
/* 207 */     gc.fill = 2;
/* 208 */     gc.gridx = x;
/* 209 */     gc.gridy = y;
/* 210 */     gc.weightx = 1.0D;
/* 211 */     gc.weighty = 1.0D;
/* 212 */     gc.gridwidth = gridSizeX;
/* 213 */     return gc;
/*     */   }
/*     */   
/*     */   private JFormattedTextField createTextField(int columns) {
/* 217 */     NumberFormat floatFormat = NumberFormat.getNumberInstance();
/* 218 */     floatFormat.setMinimumFractionDigits(1);
/* 219 */     floatFormat.setMaximumFractionDigits(5);
/* 220 */     NumberFormatter numberFormatter = new NumberFormatter(floatFormat);
/* 221 */     numberFormatter.setValueClass(Float.class);
/* 222 */     numberFormatter.setAllowsInvalid(false);
/* 223 */     JFormattedTextField text = new JFormattedTextField(numberFormatter);
/* 224 */     text.setColumns(columns);
/* 225 */     text.setFont(MainFrame.SMALL_FONT);
/* 226 */     text.setHorizontalAlignment(0);
/* 227 */     return text;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\lodSettingsPanel\LODPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */