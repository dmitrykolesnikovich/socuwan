/*    */ package lodSettingsPanel;
/*    */ 
/*    */ import backend.LodModelVersion;
/*    */ import backend.MasterModel;
/*    */ import frontend.MainFrame;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JPanel;
/*    */ import lodListPanel.LODListComponent;
/*    */ 
/*    */ 
/*    */ public class LodSettingsPanel
/*    */   extends JPanel
/*    */ {
/*    */   private MainFrame mainFrame;
/*    */   private LODPanel currentLODPanel;
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public LodSettingsPanel(int width, int height, MainFrame mainFrame)
/*    */   {
/* 22 */     this.mainFrame = mainFrame;
/* 23 */     this.width = width;
/* 24 */     this.height = height;
/* 25 */     setPreferredSize(new Dimension(width, height));
/* 26 */     setBorder(BorderFactory.createTitledBorder("LOD Settings"));
/*    */   }
/*    */   
/*    */   public void notifyChangedIndexCount() {
/* 30 */     this.mainFrame.updateIndexCount();
/*    */   }
/*    */   
/*    */   public void notifyAddLOD(LodModelVersion version) {
/* 34 */     this.mainFrame.notifyAddLOD(version);
/*    */   }
/*    */   
/*    */   public void notifyChangedLODCount() {
/* 38 */     this.mainFrame.updateLODCount();
/*    */   }
/*    */   
/*    */   public void createNewLOD(MasterModel model) {
/* 42 */     clear();
/* 43 */     if (model.getPossibleLODS().length > 0) {
/* 44 */       this.currentLODPanel = new LODPanel(this.width - 20, this.height - 30, new LodModelVersion(model.getPossibleLODS()[0].intValue(), model.getOriginal()), this.mainFrame.getMasterModel(), true, this, null);
/*    */       
/*    */ 
/* 47 */       add(this.currentLODPanel);
/*    */     }
/* 49 */     validate();
/* 50 */     repaint();
/*    */   }
/*    */   
/*    */   public void notifyChangedListOrder() {
/* 54 */     this.mainFrame.notifyLODOrderChange();
/*    */   }
/*    */   
/*    */   public void showLOD(LodModelVersion version, LODListComponent componentPanel) {
/* 58 */     clear();
/* 59 */     this.currentLODPanel = new LODPanel(this.width - 20, this.height - 30, version, this.mainFrame.getMasterModel(), false, this, componentPanel);
/*    */     
/* 61 */     add(this.currentLODPanel);
/* 62 */     validate();
/* 63 */     repaint();
/*    */   }
/*    */   
/*    */   public void clear() {
/* 67 */     if (this.currentLODPanel != null) {
/* 68 */       this.currentLODPanel.destroy();
/* 69 */       remove(this.currentLODPanel);
/* 70 */       this.currentLODPanel = null;
/* 71 */       validate();
/* 72 */       repaint();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\lodSettingsPanel\LodSettingsPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */