/*     */ package epicRenderEngine;
/*     */ 
/*     */ import backend.Model;
/*     */ import blueprintInterfaces.RawModel;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL15;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ import org.lwjgl.opengl.GL33;
/*     */ import org.newdawn.slick.opengl.Texture;
/*     */ import org.newdawn.slick.opengl.TextureLoader;
/*     */ import texture.ModelTexture;
/*     */ import toolbox.ModelData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Loader
/*     */ {
/*     */   private static final float MIPMAP_BIAS = -0.5F;
/*  41 */   private static Map<Integer, Integer> vaoCache = new HashMap();
/*  42 */   private static List<Integer> vboCache = new ArrayList();
/*  43 */   private static List<Integer> textureCache = new ArrayList();
/*  44 */   private static List<Model> waitingModels = new ArrayList();
/*  45 */   private static List<ModelTexture> waitingTextures = new ArrayList();
/*     */   
/*     */   public static synchronized void requestRawModelLoad(Model model) {
/*  48 */     waitingModels.add(model);
/*     */   }
/*     */   
/*     */   public static synchronized void requestTextureLoad(ModelTexture texture) {
/*  52 */     waitingTextures.add(texture);
/*     */   }
/*     */   
/*     */   public static synchronized void dealWithRequests() {
/*  56 */     if (!waitingModels.isEmpty()) {
/*  57 */       for (Model waitingModel : waitingModels) {
/*  58 */         ModelData data = waitingModel.getModelData();
/*  59 */         RawModel model = new RawModel(0, loadModelToVAO(data.getVertices(), data.getNormals(), data.getTextureCoords(), data.getIndices()), new int[] { data.getIndices().length });
/*     */         
/*     */ 
/*  62 */         waitingModel.setRawModel(model);
/*     */       }
/*     */     }
/*  65 */     waitingModels.clear();
/*     */     
/*  67 */     if (!waitingTextures.isEmpty()) {
/*  68 */       for (ModelTexture waitingTexture : waitingTextures) {
/*  69 */         if (waitingTexture.getTextureFile() != null) {
/*  70 */           int diffuse = loadTexture(waitingTexture.getTextureFile());
/*  71 */           waitingTexture.setDiffuseTexture(diffuse);
/*     */         }
/*     */       }
/*     */     }
/*  75 */     waitingTextures.clear();
/*     */   }
/*     */   
/*     */   public static int loadMipmappedTexture(String fileName) {
/*  79 */     return loadTexture(fileName, true);
/*     */   }
/*     */   
/*     */   public static int loadTexture(String fileName) {
/*  83 */     return loadTexture(fileName, false);
/*     */   }
/*     */   
/*     */   public static void clearVaoFromMemory(Integer vao) {
/*  87 */     Integer vbo = (Integer)vaoCache.remove(vao);
/*  88 */     if (vbo != null) {
/*  89 */       GL15.glDeleteBuffers(vbo.intValue());
/*  90 */       GL30.glDeleteVertexArrays(vao.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] normals, float[] textureCoords) {
/*  95 */     int vertexArrayID = createVAO();
/*  96 */     storeInterleavedDataInVAO(vertexArrayID, vertices, normals, textureCoords);
/*  97 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] textureCoords) {
/* 101 */     int vertexArrayID = createVAO();
/* 102 */     storeInterleavedDataInVAO(vertexArrayID, vertices, textureCoords);
/* 103 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] textureCoords, int[] indices) {
/* 107 */     int vertexArrayID = createVAO();
/* 108 */     createIndicesVBO(indices);
/* 109 */     storeInterleavedDataInVAO(vertexArrayID, vertices, textureCoords);
/* 110 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] normals, float[] textureCoords, int[] indices)
/*     */   {
/* 115 */     int vertexArrayID = createVAO();
/* 116 */     createIndicesVBO(indices);
/* 117 */     storeInterleavedDataInVAO(vertexArrayID, vertices, normals, textureCoords);
/* 118 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices) {
/* 122 */     int vertexArrayID = createVAO();
/* 123 */     storePositionDataInVAO(vertexArrayID, vertices);
/* 124 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int createIndicesVBO(int[] indices) {
/* 128 */     IntBuffer indicesBuffer = BufferUtils.createIntBuffer(indices.length);
/* 129 */     indicesBuffer.put(indices);
/* 130 */     indicesBuffer.flip();
/* 131 */     int indicesBufferId = GL15.glGenBuffers();
/* 132 */     vboCache.add(Integer.valueOf(indicesBufferId));
/* 133 */     GL15.glBindBuffer(34963, indicesBufferId);
/* 134 */     GL15.glBufferData(34963, indicesBuffer, 35044);
/* 135 */     return indicesBufferId;
/*     */   }
/*     */   
/*     */   protected static void cleanUpModelMemory() {
/* 139 */     GL20.glDisableVertexAttribArray(0);
/* 140 */     GL15.glBindBuffer(34962, 0);
/* 141 */     GL30.glBindVertexArray(0);
/*     */     
/* 143 */     for (Iterator i$ = textureCache.iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 144 */       GL11.glDeleteTextures(id);
/*     */     }
/* 146 */     for (Iterator i$ = vboCache.iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 147 */       GL15.glDeleteBuffers(id);
/*     */     }
/* 149 */     for (Iterator i$ = vaoCache.keySet().iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 150 */       GL30.glDeleteVertexArrays(id);
/* 151 */       GL15.glDeleteBuffers(((Integer)vaoCache.get(Integer.valueOf(id))).intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   protected static RawModel loadModelFile(int id, String modelFile) {
/* 156 */     BufferedReader reader = openModelFile(modelFile);
/* 157 */     float[] vertices = readIntoArray(reader);
/* 158 */     float[] textureCoords = readIntoArray(reader);
/* 159 */     float[] normals = readIntoArray(reader);
/* 160 */     int[][] indicesData = readInAllIndices(reader);
/* 161 */     int vertexArrayID = loadModelToVAO(vertices, normals, textureCoords, indicesData[0]);
/* 162 */     RawModel model = new RawModel(id, vertexArrayID, indicesData[1]);
/*     */     
/* 164 */     addAditionalModelSettings(model, reader);
/*     */     try {
/* 166 */       reader.close();
/*     */     }
/*     */     catch (IOException e) {}
/* 169 */     return model;
/*     */   }
/*     */   
/*     */   protected static RawModel loadModelFile(File modelFile) {
/* 173 */     BufferedReader reader = openFile(modelFile);
/* 174 */     float[] vertices = readIntoArray(reader);
/* 175 */     float[] textureCoords = readIntoArray(reader);
/* 176 */     float[] normals = readIntoArray(reader);
/* 177 */     int[][] indicesData = readInAllIndices(reader);
/* 178 */     int vertexArrayID = loadModelToVAO(vertices, normals, textureCoords, indicesData[0]);
/* 179 */     RawModel model = new RawModel(0, vertexArrayID, indicesData[1]);
/*     */     
/* 181 */     addAditionalModelSettings(model, reader);
/*     */     try {
/* 183 */       reader.close();
/*     */     }
/*     */     catch (IOException e) {}
/* 186 */     return model;
/*     */   }
/*     */   
/*     */   private static BufferedReader openFile(File file) {
/* 190 */     BufferedReader reader = null;
/*     */     try {
/* 192 */       FileReader isr = new FileReader(file);
/* 193 */       reader = new BufferedReader(isr);
/*     */     } catch (FileNotFoundException e) {
/* 195 */       System.err.println("File not found!");
/* 196 */       e.printStackTrace();
/* 197 */       System.exit(-1);
/*     */     }
/* 199 */     return reader;
/*     */   }
/*     */   
/*     */   private static void storeInterleavedDataInVAO(int vaoID, float[] vertices, float[] normals, float[] textureCoords)
/*     */   {
/* 204 */     FloatBuffer interleavedData = interleaveDataInBuffer(vertices, normals, textureCoords);
/* 205 */     int bufferObjectID = GL15.glGenBuffers();
/* 206 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 207 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 208 */     GL15.glBufferData(34962, interleavedData, 35044);
/*     */     
/* 210 */     int vertexByteCount = 32;
/* 211 */     GL20.glVertexAttribPointer(0, 3, 5126, false, vertexByteCount, 0L);
/* 212 */     GL20.glVertexAttribPointer(1, 3, 5126, false, vertexByteCount, 12L);
/*     */     
/* 214 */     GL20.glVertexAttribPointer(2, 2, 5126, false, vertexByteCount, 24L);
/*     */     
/*     */ 
/* 217 */     GL15.glBindBuffer(34962, 0);
/* 218 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   private static void storePositionDataInVAO(int vaoID, float[] vertices) {
/* 222 */     FloatBuffer buffer = BufferUtils.createFloatBuffer(vertices.length);
/* 223 */     buffer.put(vertices);
/* 224 */     buffer.flip();
/* 225 */     int bufferObjectID = GL15.glGenBuffers();
/* 226 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 227 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 228 */     GL15.glBufferData(34962, buffer, 35044);
/* 229 */     GL20.glVertexAttribPointer(0, 3, 5126, false, 0, 0L);
/* 230 */     GL15.glBindBuffer(34962, 0);
/* 231 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   public static void updateInstanceVBO(int vbo, float[] data, int elementMaxCount, int elementSize, FloatBuffer buffer)
/*     */   {
/* 236 */     if (data.length >= elementMaxCount * elementSize) {
/* 237 */       System.err.println("TOO MUCH DATA UPDATED IN VBO!");
/* 238 */       return;
/*     */     }
/* 240 */     buffer.clear();
/* 241 */     buffer.put(data);
/* 242 */     buffer.flip();
/* 243 */     GL15.glBindBuffer(34962, vbo);
/* 244 */     GL15.glBufferData(34962, elementMaxCount * elementSize * 4, 35040);
/*     */     
/* 246 */     GL15.glBufferSubData(34962, 0L, buffer);
/* 247 */     GL15.glBindBuffer(34962, 0);
/*     */   }
/*     */   
/*     */   public static int createEmptyInstanceVBO(int vaoID, int attribute, int maxElementCount, int elementSize)
/*     */   {
/* 252 */     GL30.glBindVertexArray(vaoID);
/* 253 */     int vboID = GL15.glGenBuffers();
/* 254 */     vboCache.add(Integer.valueOf(vboID));
/* 255 */     GL15.glBindBuffer(34962, vboID);
/* 256 */     GL15.glBufferData(34962, maxElementCount * elementSize * 4, 35040);
/*     */     
/* 258 */     GL20.glVertexAttribPointer(attribute, elementSize, 5126, false, 0, 0L);
/* 259 */     GL33.glVertexAttribDivisor(attribute, 1);
/* 260 */     GL15.glBindBuffer(34962, 0);
/* 261 */     GL30.glBindVertexArray(0);
/* 262 */     return vboID;
/*     */   }
/*     */   
/*     */   public static int createInterleavedInstanceVBO(int vaoID, int startingAttribute, int maxElementCount, int... sizes)
/*     */   {
/* 267 */     GL30.glBindVertexArray(vaoID);
/* 268 */     int vboID = GL15.glGenBuffers();
/* 269 */     vboCache.add(Integer.valueOf(vboID));
/* 270 */     int totalElementSize = 0;
/* 271 */     for (int size : sizes) {
/* 272 */       totalElementSize += size;
/*     */     }
/* 274 */     totalElementSize *= 4;
/* 275 */     GL15.glBindBuffer(34962, vboID);
/* 276 */     GL15.glBufferData(34962, maxElementCount * totalElementSize, 35040);
/*     */     
/*     */ 
/* 279 */     int offset = 0;
/* 280 */     for (int i = 0; i < sizes.length; i++) {
/* 281 */       GL20.glVertexAttribPointer(i + startingAttribute, sizes[i], 5126, false, totalElementSize, offset);
/*     */       
/* 283 */       GL33.glVertexAttribDivisor(i + startingAttribute, 1);
/* 284 */       offset += sizes[i] * 4;
/*     */     }
/*     */     
/* 287 */     GL15.glBindBuffer(34962, 0);
/* 288 */     GL30.glBindVertexArray(0);
/* 289 */     return vboID;
/*     */   }
/*     */   
/*     */   private static void storeInterleavedDataInVAO(int vaoID, float[] vertices, float[] textureCoords) {
/* 293 */     FloatBuffer interleavedData = interleaveDataInBuffer(vertices, textureCoords);
/* 294 */     int bufferObjectID = GL15.glGenBuffers();
/* 295 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 296 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 297 */     GL15.glBufferData(34962, interleavedData, 35044);
/*     */     
/* 299 */     int vertexByteCount = 20;
/* 300 */     GL20.glVertexAttribPointer(0, 3, 5126, false, vertexByteCount, 0L);
/* 301 */     GL20.glVertexAttribPointer(1, 2, 5126, false, vertexByteCount, 12L);
/*     */     
/*     */ 
/* 304 */     GL15.glBindBuffer(34962, 0);
/* 305 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   private static FloatBuffer interleaveDataInBuffer(float[] vertices, float[] normals, float[] textureCoords)
/*     */   {
/* 310 */     FloatBuffer interleavedBuffer = BufferUtils.createFloatBuffer(vertices.length + normals.length + textureCoords.length);
/*     */     
/* 312 */     int veticesPointer = 0;
/* 313 */     int normalsPointer = 0;
/* 314 */     int texturePointer = 0;
/* 315 */     for (int i = 0; i < vertices.length / 3; i++) {
/* 316 */       interleavedBuffer.put(new float[] { vertices[(veticesPointer++)], vertices[(veticesPointer++)], vertices[(veticesPointer++)] });
/*     */       
/* 318 */       interleavedBuffer.put(new float[] { normals[(normalsPointer++)], normals[(normalsPointer++)], normals[(normalsPointer++)] });
/*     */       
/* 320 */       interleavedBuffer.put(new float[] { textureCoords[(texturePointer++)], textureCoords[(texturePointer++)] });
/*     */     }
/*     */     
/* 323 */     interleavedBuffer.flip();
/* 324 */     return interleavedBuffer;
/*     */   }
/*     */   
/*     */   private static FloatBuffer interleaveDataInBuffer(float[] vertices, float[] textureCoords) {
/* 328 */     FloatBuffer interleavedBuffer = BufferUtils.createFloatBuffer(vertices.length + textureCoords.length);
/*     */     
/* 330 */     int veticesPointer = 0;
/* 331 */     int texturePointer = 0;
/* 332 */     for (int i = 0; i < vertices.length / 3; i++) {
/* 333 */       interleavedBuffer.put(new float[] { vertices[(veticesPointer++)], vertices[(veticesPointer++)], vertices[(veticesPointer++)] });
/*     */       
/* 335 */       interleavedBuffer.put(new float[] { textureCoords[(texturePointer++)], textureCoords[(texturePointer++)] });
/*     */     }
/*     */     
/* 338 */     interleavedBuffer.flip();
/* 339 */     return interleavedBuffer;
/*     */   }
/*     */   
/*     */   private static int createVAO() {
/* 343 */     int vertexArrayID = GL30.glGenVertexArrays();
/* 344 */     GL30.glBindVertexArray(vertexArrayID);
/* 345 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   private static BufferedReader openModelFile(String fileStem) {
/* 349 */     BufferedReader reader = null;
/*     */     try {
/* 351 */       InputStream in = Class.class.getResourceAsStream("/res/" + fileStem + ".csv");
/*     */       
/* 353 */       InputStreamReader isr = new InputStreamReader(in);
/* 354 */       reader = new BufferedReader(isr);
/*     */     } catch (Exception e) {
/* 356 */       e.printStackTrace();
/* 357 */       System.out.println();
/* 358 */       System.err.println("Unable to find model file: " + fileStem);
/* 359 */       System.exit(-1);
/*     */     }
/* 361 */     return reader;
/*     */   }
/*     */   
/*     */   private static float[] readIntoArray(BufferedReader reader) {
/* 365 */     float[] theArray = null;
/*     */     try {
/* 367 */       theArray = new float[Integer.valueOf(reader.readLine()).intValue()];
/* 368 */       String[] line = reader.readLine().split(",");
/* 369 */       for (int i = 0; i < theArray.length; i++) {
/* 370 */         theArray[i] = Float.valueOf(line[i]).floatValue();
/*     */       }
/*     */     } catch (Exception e) {
/* 373 */       e.printStackTrace();
/* 374 */       System.err.println("Problem loading file data!");
/* 375 */       System.exit(-1);
/*     */     }
/* 377 */     return theArray;
/*     */   }
/*     */   
/*     */   private static int[][] readInAllIndices(BufferedReader reader) {
/*     */     try {
/* 382 */       List<Integer> listOfIndices = new ArrayList();
/* 383 */       List<Integer> listOfLengths = new ArrayList();
/* 384 */       listOfLengths.add(Integer.valueOf(reader.readLine()));
/* 385 */       String[] line = reader.readLine().split(",");
/* 386 */       for (int i = 0; i < line.length; i++) {
/* 387 */         listOfIndices.add(Integer.valueOf(line[i]));
/*     */       }
/*     */       
/*     */       String fullLine;
/* 391 */       while (((fullLine = reader.readLine()) != null) && (!fullLine.equals("NEWSECTION"))) {
/* 392 */         line = fullLine.split(",");
/* 393 */         int lod = Integer.valueOf(line[0]).intValue();
/* 394 */         while (listOfLengths.size() < lod) {
/* 395 */           listOfLengths.add(Integer.valueOf(0));
/*     */         }
/* 397 */         listOfLengths.add(Integer.valueOf(Integer.valueOf(line[1]).intValue()));
/* 398 */         line = reader.readLine().split(",");
/* 399 */         for (int i = 0; i < line.length; i++) {
/* 400 */           listOfIndices.add(Integer.valueOf(line[i]));
/*     */         }
/*     */       }
/* 403 */       int[] indicesArray = new int[listOfIndices.size()];
/* 404 */       for (int i = 0; i < indicesArray.length; i++) {
/* 405 */         indicesArray[i] = ((Integer)listOfIndices.get(i)).intValue();
/*     */       }
/* 407 */       int[] lengthsArray = new int[listOfLengths.size()];
/* 408 */       for (int i = 0; i < lengthsArray.length; i++) {
/* 409 */         lengthsArray[i] = ((Integer)listOfLengths.get(i)).intValue();
/*     */       }
/* 411 */       return new int[][] { indicesArray, lengthsArray };
/*     */     }
/*     */     catch (Exception e) {
/* 414 */       e.printStackTrace();
/* 415 */       System.err.println("Problem loading indices data!");
/* 416 */       System.exit(-1); }
/* 417 */     return (int[][])null;
/*     */   }
/*     */   
/*     */   private static int loadTexture(String fileName, boolean mipmap)
/*     */   {
/* 422 */     Texture texture = null;
/*     */     try {
/* 424 */       texture = TextureLoader.getTexture("PNG", Class.class.getResourceAsStream("/res/" + fileName + ".png"));
/*     */     }
/*     */     catch (Exception e) {
/* 427 */       e.printStackTrace();
/* 428 */       System.err.println("Tried to load texture /res/" + fileName + ".png" + " , didn't work");
/* 429 */       System.exit(-1);
/*     */     }
/* 431 */     if (mipmap) {
/* 432 */       GL30.glGenerateMipmap(3553);
/* 433 */       GL11.glTexParameteri(3553, 10240, 9729);
/* 434 */       GL11.glTexParameteri(3553, 10241, 9987);
/*     */       
/* 436 */       GL11.glTexParameterf(3553, 34049, -0.5F);
/*     */     }
/* 438 */     textureCache.add(Integer.valueOf(texture.getTextureID()));
/* 439 */     return texture.getTextureID();
/*     */   }
/*     */   
/*     */   private static void addAditionalModelSettings(RawModel model, BufferedReader reader) {
/* 443 */     String sectionHeader = null;
/*     */     for (;;) {
/*     */       try {
/* 446 */         sectionHeader = reader.readLine();
/*     */       } catch (IOException e) {
/* 448 */         e.printStackTrace();
/* 449 */         System.exit(-1);
/*     */       }
/* 451 */       if (sectionHeader == null)
/* 452 */         return;
/* 453 */       if (!sectionHeader.equals("<CDOS>")) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static int loadTexture(File file)
/*     */   {
/* 460 */     Texture texture = null;
/*     */     try {
/* 462 */       texture = TextureLoader.getTexture("PNG", new FileInputStream(file));
/*     */     } catch (Exception e) {
/* 464 */       e.printStackTrace();
/* 465 */       System.err.println("Tried to load texture " + file.getName() + ", didn't work");
/* 466 */       System.exit(-1);
/*     */     }
/* 468 */     GL30.glGenerateMipmap(3553);
/* 469 */     GL11.glTexParameteri(3553, 10240, 9729);
/* 470 */     GL11.glTexParameteri(3553, 10241, 9987);
/*     */     
/* 472 */     GL11.glTexParameterf(3553, 34049, -0.5F);
/* 473 */     textureCache.add(Integer.valueOf(texture.getTextureID()));
/* 474 */     return texture.getTextureID();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\epicRenderEngine\Loader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */