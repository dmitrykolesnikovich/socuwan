/*     */ package epicRenderEngine;
/*     */ 
/*     */ import java.awt.Canvas;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import org.lwjgl.LWJGLException;
/*     */ import org.lwjgl.Sys;
/*     */ import org.lwjgl.opengl.ContextAttribs;
/*     */ import org.lwjgl.opengl.Display;
/*     */ import org.lwjgl.opengl.DisplayMode;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.PixelFormat;
/*     */ 
/*     */ public class DisplayManager
/*     */ {
/*  16 */   private static String title = "Version0_0_4_2";
/*     */   
/*     */   private static final int FRAME_TIME_CAP = 120;
/*     */   
/*     */   private static final boolean vSync = false;
/*     */   
/*     */   private static final boolean START_FULLSCREEN = false;
/*     */   
/*     */   private static final int ROLLING_AVERAGE_LENGTH = 10;
/*     */   
/*     */   private static final float FULLSCREEN_ASPECT_MARGIN = 0.05F;
/*     */   private static final float FULLSCREEN_RESOLUTION = 0.75F;
/*     */   private static final float DELTA_FACTOR = 1000.0F;
/*     */   private static final boolean showAlert = false;
/*  30 */   private static float delta = 0.0F;
/*  31 */   private static long lastFrame = 0L;
/*  32 */   private static List<Float> previousTimes = new java.util.ArrayList();
/*     */   
/*     */   protected static void setUpDisplay(Canvas canvas) {
/*  35 */     PixelFormat format = new PixelFormat();
/*  36 */     ContextAttribs attributes = new ContextAttribs(3, 2).withForwardCompatible(true).withProfileCore(true);
/*     */     
/*     */     try
/*     */     {
/*  40 */       Display.setTitle(title);
/*  41 */       goToWindowDisplay(canvas.getWidth(), canvas.getHeight());
/*     */       
/*     */ 
/*     */ 
/*  45 */       Display.setParent(canvas);
/*  46 */       Display.create(format, attributes);
/*     */     } catch (LWJGLException e) {
/*  48 */       e.printStackTrace();
/*  49 */       System.err.println("Failed to create a display.");
/*  50 */       System.exit(-1);
/*     */     }
/*  52 */     GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
/*  53 */     lastFrame = getTime();
/*     */   }
/*     */   
/*     */   protected static void updateScreen() {
/*  57 */     Display.update();
/*  58 */     Display.sync(120);
/*  59 */     calculateDelta();
/*     */   }
/*     */   
/*     */   public static float getDeltaInSeconds() {
/*  63 */     return delta;
/*     */   }
/*     */   
/*     */   protected static void closeWindow() {}
/*     */   
/*     */   protected static void goToFullScreenDisplay()
/*     */   {
/*     */     try
/*     */     {
/*  72 */       DisplayMode mode = getBestCompatableDisplayMode();
/*  73 */       if (mode == null) {
/*  74 */         System.err.println("Couldn't go fullscreen!");
/*  75 */         return;
/*     */       }
/*  77 */       System.out.println("Going fullscreen with resolution: " + mode.getWidth() + " x " + mode.getHeight() + " x " + mode.getBitsPerPixel() + ", aspect: " + mode.getWidth() / mode.getHeight());
/*     */       
/*     */ 
/*  80 */       Display.setDisplayMode(mode);
/*  81 */       Display.setFullscreen(true);
/*  82 */       if (Display.isCreated()) {
/*  83 */         GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
/*     */       }
/*  85 */       Display.setVSyncEnabled(false);
/*     */     } catch (LWJGLException e) {
/*  87 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void goToWindowDisplay(int width, int height) {
/*     */     try {
/*  93 */       Display.setDisplayMode(new DisplayMode(width, height));
/*  94 */       if (Display.isCreated()) {
/*  95 */         GL11.glViewport(0, 0, width, height);
/*     */       }
/*     */     } catch (LWJGLException e) {
/*  98 */       e.printStackTrace();
/*  99 */       System.err.println("Error changing window size!");
/*     */     }
/*     */   }
/*     */   
/*     */   private static long getTime() {
/* 104 */     return Sys.getTime() * 1000L / Sys.getTimerResolution();
/*     */   }
/*     */   
/*     */   private static void calculateDelta() {
/* 108 */     long time = getTime();
/* 109 */     long difference = time - lastFrame;
/* 110 */     float value = (float)difference / 1000.0F;
/* 111 */     delta = updateRollingAverage(value);
/* 112 */     lastFrame = time;
/*     */   }
/*     */   
/*     */   private static float updateRollingAverage(float value)
/*     */   {
/* 117 */     previousTimes.add(0, Float.valueOf(value));
/* 118 */     if (previousTimes.size() > 10) {
/* 119 */       previousTimes.remove(10);
/*     */     }
/* 121 */     if (previousTimes.size() < 10) {
/* 122 */       return value;
/*     */     }
/* 124 */     return toolbox.Maths.getAverageOfList(previousTimes);
/*     */   }
/*     */   
/*     */   private static DisplayMode getBestCompatableDisplayMode() {
/* 128 */     DisplayMode bestMode = null;
/* 129 */     DisplayMode desktop = Display.getDesktopDisplayMode();
/* 130 */     float perfectAspect = desktop.getWidth() / desktop.getHeight();
/* 131 */     float perfectWidth = desktop.getWidth() * 0.75F;
/*     */     try {
/* 133 */       DisplayMode[] modes = Display.getAvailableDisplayModes();
/* 134 */       for (DisplayMode mode : modes) {
/* 135 */         float testAspect = mode.getWidth() / mode.getHeight();
/* 136 */         if ((testAspect < perfectAspect + 0.05F) && (testAspect > perfectAspect - 0.05F))
/*     */         {
/* 138 */           if (mode.getBitsPerPixel() == desktop.getBitsPerPixel()) {
/* 139 */             if (bestMode == null) {
/* 140 */               bestMode = mode;
/*     */             }
/*     */             else {
/* 143 */               float bestWidthDiff = Math.abs(perfectWidth - bestMode.getWidth());
/* 144 */               float testWidthDiff = Math.abs(perfectWidth - mode.getWidth());
/* 145 */               if (testWidthDiff < bestWidthDiff) {
/* 146 */                 bestMode = mode;
/* 147 */               } else if ((testWidthDiff == bestWidthDiff) && 
/* 148 */                 (mode.getFrequency() > bestMode.getFrequency())) {
/* 149 */                 bestMode = mode;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 157 */       e.printStackTrace();
/*     */     }
/* 159 */     return bestMode;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\epicRenderEngine\DisplayManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */