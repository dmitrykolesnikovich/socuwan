/*    */ package epicRenderEngine;
/*    */ 
/*    */ public class RawOBJData
/*    */ {
/*    */   private float[] vertices;
/*    */   private float[] textureCoords;
/*    */   private float[] normals;
/*    */   private int[] indices;
/*    */   private int[] lengths;
/*    */   
/*    */   public RawOBJData(float[] vertices, float[] normals, float[] texCoords, int[] indices, int[] lengths) {
/* 12 */     this.vertices = vertices;
/* 13 */     this.normals = normals;
/* 14 */     this.textureCoords = texCoords;
/* 15 */     this.indices = indices;
/* 16 */     this.lengths = lengths;
/*    */   }
/*    */   
/*    */   public float[] getVertices() {
/* 20 */     return this.vertices;
/*    */   }
/*    */   
/*    */   public float[] getTextureCoords() {
/* 24 */     return this.textureCoords;
/*    */   }
/*    */   
/*    */   public float[] getNormals() {
/* 28 */     return this.normals;
/*    */   }
/*    */   
/*    */   public int[] getIndices() {
/* 32 */     return this.indices;
/*    */   }
/*    */   
/*    */   public int[] getLengths() {
/* 36 */     return this.lengths;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\epicRenderEngine\RawOBJData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */