package epicRenderEngine;

public abstract interface Camera
{
  public abstract float getFarPlane();
  
  public abstract float getNearPlane();
  
  public abstract float getFieldOfView();
  
  public abstract float getX();
  
  public abstract float getY();
  
  public abstract float getZ();
  
  public abstract float getPitch();
  
  public abstract float getYaw();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\epicRenderEngine\Camera.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */