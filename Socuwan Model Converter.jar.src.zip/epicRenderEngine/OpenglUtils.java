/*     */ package epicRenderEngine;
/*     */ 
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL13;
/*     */ import org.lwjgl.opengl.GL15;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import org.lwjgl.util.vector.Vector4f;
/*     */ import toolbox.Colour;
/*     */ import toolbox.Maths;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenglUtils
/*     */ {
/*  21 */   private static boolean cullingBackFace = false;
/*  22 */   private static boolean inWireframe = false;
/*  23 */   private static boolean isBlending = false;
/*     */   
/*     */   public static void prepareNewRenderParse(Colour skyColour) {
/*  26 */     GL11.glClear(16640);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  31 */     GL11.glClearColor(skyColour.getR(), skyColour.getG(), skyColour.getB(), 1.0F);
/*  32 */     disableBlending();
/*  33 */     enableDepthTesting();
/*     */   }
/*     */   
/*     */   public static void enableBlending() {
/*  37 */     if (!isBlending) {
/*  38 */       GL11.glEnable(3042);
/*  39 */       GL11.glBlendFunc(770, 771);
/*  40 */       isBlending = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void enableAdditiveBlending() {
/*  45 */     GL11.glEnable(3042);
/*  46 */     GL11.glBlendFunc(770, 1);
/*     */   }
/*     */   
/*     */   public static void disableBlending() {
/*  50 */     if (isBlending) {
/*  51 */       GL11.glDisable(3042);
/*  52 */       isBlending = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void disableDepthTesting() {
/*  57 */     GL11.glDisable(2929);
/*     */   }
/*     */   
/*     */   public static void enableDepthTesting() {
/*  61 */     GL11.glEnable(2929);
/*     */   }
/*     */   
/*     */   public static void bindGuiVAO(int vaoID) {
/*  65 */     GL30.glBindVertexArray(vaoID);
/*  66 */     GL20.glEnableVertexAttribArray(0);
/*  67 */     GL20.glEnableVertexAttribArray(1);
/*     */   }
/*     */   
/*     */   public static void bindJustPositionVAO(int vaoID) {
/*  71 */     GL30.glBindVertexArray(vaoID);
/*  72 */     GL20.glEnableVertexAttribArray(0);
/*     */   }
/*     */   
/*     */   public static void bindVAO(int vaoID, int... attributes) {
/*  76 */     GL30.glBindVertexArray(vaoID);
/*  77 */     for (int i : attributes) {
/*  78 */       GL20.glEnableVertexAttribArray(i);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unbindVAO(int vaoID, int... attributes) {
/*  83 */     for (int i : attributes) {
/*  84 */       GL20.glDisableVertexAttribArray(i);
/*     */     }
/*  86 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   public static void bindVAO(int vaoID) {
/*  90 */     GL30.glBindVertexArray(vaoID);
/*  91 */     GL20.glEnableVertexAttribArray(0);
/*  92 */     GL20.glEnableVertexAttribArray(1);
/*  93 */     GL20.glEnableVertexAttribArray(2);
/*     */   }
/*     */   
/*     */   public static void bindIndicesVBO(int vboID) {
/*  97 */     GL15.glBindBuffer(34963, vboID);
/*     */   }
/*     */   
/*     */   public static void bindTextureToBank(int textureID, int bankID) {
/* 101 */     GL13.glActiveTexture(33984 + bankID);
/* 102 */     GL11.glBindTexture(3553, textureID);
/* 103 */     GL11.glTexParameteri(3553, 33084, 0);
/*     */   }
/*     */   
/*     */   public static void bindTextureToBank(int textureID, int bankID, int lodBias) {
/* 107 */     GL13.glActiveTexture(33984 + bankID);
/* 108 */     GL11.glBindTexture(3553, textureID);
/* 109 */     GL11.glTexParameteri(3553, 33084, lodBias);
/*     */   }
/*     */   
/*     */   public static void cullBackFaces(boolean cull) {
/* 113 */     if ((cull) && (!cullingBackFace)) {
/* 114 */       GL11.glEnable(2884);
/* 115 */       GL11.glCullFace(1029);
/* 116 */       cullingBackFace = true;
/* 117 */     } else if ((!cull) && (cullingBackFace)) {
/* 118 */       GL11.glDisable(2884);
/* 119 */       cullingBackFace = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void goWireframe(boolean goWireframe) {
/* 124 */     if ((goWireframe) && (!inWireframe)) {
/* 125 */       GL11.glPolygonMode(1032, 6913);
/* 126 */       inWireframe = true;
/* 127 */     } else if ((!goWireframe) && (inWireframe)) {
/* 128 */       GL11.glPolygonMode(1032, 6914);
/* 129 */       inWireframe = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void unbindIndicesVBO() {
/* 134 */     GL15.glBindBuffer(34963, 0);
/*     */   }
/*     */   
/*     */   public static void unbindVAO() {
/* 138 */     GL20.glDisableVertexAttribArray(2);
/* 139 */     GL20.glDisableVertexAttribArray(1);
/* 140 */     GL20.glDisableVertexAttribArray(0);
/* 141 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   public static void resetModelMatrix(Matrix4f matrix, float x, float y, float z, float rX, float rY, float rZ, float scale)
/*     */   {
/* 146 */     matrix.setIdentity();
/* 147 */     translateMatrix(matrix, x, y, z);
/* 148 */     rotateMatrix(matrix, rX, 1.0F, 0.0F, 0.0F);
/* 149 */     rotateMatrix(matrix, rY, 0.0F, 1.0F, 0.0F);
/* 150 */     rotateMatrix(matrix, rZ, 0.0F, 0.0F, 1.0F);
/* 151 */     scaleMatrix(matrix, scale);
/*     */   }
/*     */   
/*     */   public static Vector4f toEyeCoords(Matrix4f view, float posX, float posY, float posZ) {
/* 155 */     Vector3f lightPos = new Vector3f(posX, posY, posZ);
/* 156 */     Vector4f eyeCoords = new Vector4f();
/* 157 */     Matrix4f.transform(view, new Vector4f(lightPos.x, lightPos.y, lightPos.z, 1.0F), eyeCoords);
/* 158 */     return eyeCoords;
/*     */   }
/*     */   
/*     */   public static void translateMatrix(Matrix4f matrix, float x, float y, float z) {
/* 162 */     Vector3f position = new Vector3f(x, y, z);
/* 163 */     Matrix4f.translate(position, matrix, matrix);
/*     */   }
/*     */   
/*     */   public static void rotateMatrix(Matrix4f matrix, float value, float x, float y, float z) {
/* 167 */     Matrix4f.rotate(Maths.degreesToRadians(value), new Vector3f(x, y, z), matrix, matrix);
/*     */   }
/*     */   
/*     */   public static void rotateMatrixWithQuaternion(Matrix4f modelMatrix, double w, double x, double y, double z)
/*     */   {
/* 172 */     Matrix4f rotation = Maths.quaternionToMatrix(w, x, y, z);
/* 173 */     Matrix4f.mul(modelMatrix, rotation, modelMatrix);
/*     */   }
/*     */   
/*     */   public static void scaleMatrix(Matrix4f matrix, float value) {
/* 177 */     Vector3f scale = new Vector3f(value, value, value);
/* 178 */     Matrix4f.scale(scale, matrix, matrix);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\epicRenderEngine\OpenglUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */