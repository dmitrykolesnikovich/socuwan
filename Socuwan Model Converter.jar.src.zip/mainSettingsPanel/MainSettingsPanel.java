/*    */ package mainSettingsPanel;
/*    */ 
/*    */ import backend.MasterModel;
/*    */ import frontend.MainFrame;
/*    */ import java.awt.Canvas;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JPanel;
/*    */ import mainApp.Camera;
/*    */ 
/*    */ 
/*    */ public class MainSettingsPanel
/*    */   extends JPanel
/*    */ {
/*    */   private ModelDataPanel dataPanel;
/*    */   private PreviewSettingsPanel previewSettingsPanel;
/*    */   private Canvas preview;
/*    */   
/*    */   public MainSettingsPanel(int width, int height, MainFrame mainFrame, Camera camera)
/*    */   {
/* 23 */     setPreferredSize(new Dimension(width, height));
/* 24 */     setBorder(BorderFactory.createTitledBorder("Main Settings"));
/* 25 */     setLayout(new GridBagLayout());
/* 26 */     initPanels(width, height, camera);
/*    */   }
/*    */   
/*    */   public Canvas getCanvas() {
/* 30 */     return this.preview;
/*    */   }
/*    */   
/*    */   public void setMasterModel(MasterModel model) {
/* 34 */     this.dataPanel.setMasterModel(model);
/*    */   }
/*    */   
/*    */   public void updateIndexCount() {
/* 38 */     this.dataPanel.updateIndexCount();
/*    */   }
/*    */   
/*    */   public void updateLODCount() {
/* 42 */     this.dataPanel.updateLODCount();
/*    */   }
/*    */   
/*    */   private void initPanels(int width, int height, Camera camera) {
/* 46 */     int panelWidths = width - 10;
/* 47 */     int panelHeight = height - 10;
/* 48 */     int previewHeight = (int)((panelWidths - 10) * 0.5625F);
/* 49 */     int topPanelsHeight = panelHeight - previewHeight - 20;
/* 50 */     int dataPanelWidth = 400;
/* 51 */     int settingsPanelWidth = panelWidths - dataPanelWidth - 20;
/*    */     
/* 53 */     this.dataPanel = new ModelDataPanel(dataPanelWidth, topPanelsHeight, this);
/* 54 */     add(this.dataPanel, getGC(0, 0, 1));
/* 55 */     this.previewSettingsPanel = new PreviewSettingsPanel(settingsPanelWidth, topPanelsHeight, this, camera);
/* 56 */     add(this.previewSettingsPanel, getGC(1, 0, 1));
/* 57 */     this.preview = new Canvas();
/* 58 */     this.preview.setPreferredSize(new Dimension(panelWidths - 10, previewHeight));
/* 59 */     add(this.preview, getGC(0, 1, 2));
/*    */   }
/*    */   
/*    */   private GridBagConstraints getGC(int x, int y, int gridSizeX) {
/* 63 */     GridBagConstraints gc = new GridBagConstraints();
/* 64 */     gc.gridx = x;
/* 65 */     gc.gridy = y;
/* 66 */     gc.weightx = 1.0D;
/* 67 */     gc.weighty = 1.0D;
/* 68 */     gc.gridwidth = gridSizeX;
/* 69 */     return gc;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainSettingsPanel\MainSettingsPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */