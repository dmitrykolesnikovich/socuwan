/*     */ package mainSettingsPanel;
/*     */ 
/*     */ import backend.MasterModel;
/*     */ import backend.WorkSpace;
/*     */ import frontend.FileInList;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import mainApp.Configs;
/*     */ import mainApp.MainApp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextureChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a texture!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JFrame frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   
/*     */   public TextureChooseScreen()
/*     */   {
/*  37 */     setUpFrame();
/*  38 */     addLabel();
/*  39 */     addFileList(getAllIconFiles());
/*  40 */     addButton();
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  44 */     this.frame = new JFrame();
/*  45 */     this.frame.setVisible(true);
/*  46 */     this.frame.setSize(300, 500);
/*  47 */     this.frame.setResizable(false);
/*  48 */     this.frame.setLocationRelativeTo(null);
/*  49 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  53 */     GridBagConstraints gc = new GridBagConstraints();
/*  54 */     gc.gridx = 0;
/*  55 */     gc.gridy = 1;
/*  56 */     gc.weightx = 1.0D;
/*  57 */     gc.weighty = 1.0D;
/*     */     
/*  59 */     FileInList[] data = getAllFilesInList(files);
/*  60 */     this.list = new JList(data);
/*  61 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  62 */     this.list.setSelectionMode(1);
/*  63 */     this.list.setLayoutOrientation(0);
/*  64 */     this.list.setVisibleRowCount(-1);
/*  65 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  66 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  67 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  71 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  72 */     for (int i = 0; i < listedFiles.length; i++) {
/*  73 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  75 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  79 */     JLabel text = new JLabel("Choose a texture!");
/*  80 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  81 */     GridBagConstraints gc = new GridBagConstraints();
/*  82 */     gc.gridx = 0;
/*  83 */     gc.gridy = 0;
/*  84 */     gc.weightx = 1.0D;
/*  85 */     gc.weighty = 0.4D;
/*  86 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/*  90 */     this.confirm = new JButton("Open");
/*  91 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/*  92 */     GridBagConstraints gc = new GridBagConstraints();
/*  93 */     gc.gridx = 0;
/*  94 */     gc.gridy = 2;
/*  95 */     gc.weightx = 1.0D;
/*  96 */     gc.weighty = 0.4D;
/*  97 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 101 */         if (!TextureChooseScreen.this.list.isSelectionEmpty()) {
/* 102 */           File chosen = ((FileInList)TextureChooseScreen.this.list.getSelectedValue()).getFile();
/* 103 */           if (MainApp.workspace.getCurrentMasterModel() != null) {
/* 104 */             MainApp.workspace.getCurrentMasterModel().setTextureFile(chosen);
/*     */           }
/* 106 */           TextureChooseScreen.this.frame.setVisible(false);
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 111 */     });
/* 112 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllIconFiles() {
/* 116 */     File[] allFiles = Configs.TEXTURE_REPOS.listFiles();
/* 117 */     List<File> goodFiles = new ArrayList();
/* 118 */     for (File file : allFiles) {
/* 119 */       if (file.getName().endsWith(".png")) {
/* 120 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 123 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainSettingsPanel\TextureChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */