/*     */ package mainSettingsPanel;
/*     */ 
/*     */ import backend.MasterModel;
/*     */ import frontend.MainFrame;
/*     */ import frontend.Slider;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.io.File;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelDataPanel
/*     */   extends JPanel
/*     */ {
/*     */   private MainSettingsPanel mainPanel;
/*  23 */   private boolean created = false;
/*     */   private MasterModel model;
/*     */   private JLabel title;
/*     */   private JLabel triangleCount;
/*     */   private JLabel vertexCount;
/*     */   private JLabel indexCount;
/*     */   private JLabel lodCount;
/*     */   private Slider slider;
/*     */   
/*     */   public ModelDataPanel(int width, int height, MainSettingsPanel mainPanel)
/*     */   {
/*  34 */     this.mainPanel = mainPanel;
/*  35 */     setPreferredSize(new Dimension(width, height));
/*  36 */     setBorder(BorderFactory.createLineBorder(new Color(126, 160, 194)));
/*  37 */     setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   public void setMasterModel(MasterModel model) {
/*  41 */     this.model = model;
/*  42 */     if (!this.created) {
/*  43 */       this.created = true;
/*  44 */       setUp();
/*     */     }
/*  46 */     update();
/*     */   }
/*     */   
/*     */   public void updateIndexCount() {
/*  50 */     this.indexCount.setText(Integer.toString(this.model.getTotalIndicesCount()));
/*     */   }
/*     */   
/*     */   public void updateLODCount() {
/*  54 */     this.lodCount.setText(Integer.toString(this.model.getNumberOfLods()));
/*     */   }
/*     */   
/*     */   private void setUp() {
/*  58 */     createTitle();
/*  59 */     createOriginalModelCounts();
/*  60 */     createFullModelCounts();
/*  61 */     setSlider();
/*     */   }
/*     */   
/*     */   private void createTitle() {
/*  65 */     this.title = new JLabel(this.model.getOutputFile().getName());
/*  66 */     this.title.setFont(MainFrame.MEDIUM_FONT);
/*  67 */     this.title.setHorizontalAlignment(0);
/*  68 */     add(this.title, getGC(0, 0, 4));
/*     */   }
/*     */   
/*     */   private void createFullModelCounts() {
/*  72 */     JLabel indexLabel = new JLabel("Indices Count:");
/*  73 */     indexLabel.setFont(MainFrame.SMALL_FONT);
/*  74 */     indexLabel.setHorizontalAlignment(0);
/*  75 */     add(indexLabel, getGC(0, 2, 1));
/*  76 */     this.indexCount = new JLabel(Integer.toString(this.model.getTotalIndicesCount()));
/*  77 */     this.indexCount.setFont(MainFrame.SMALL_FONT);
/*  78 */     this.indexCount.setHorizontalAlignment(2);
/*  79 */     add(this.indexCount, getGC(1, 2, 1));
/*     */     
/*  81 */     JLabel lodLabel = new JLabel("No. of LODs:");
/*  82 */     lodLabel.setFont(MainFrame.SMALL_FONT);
/*  83 */     lodLabel.setHorizontalAlignment(0);
/*  84 */     add(lodLabel, getGC(2, 2, 1));
/*  85 */     this.lodCount = new JLabel(Integer.toString(this.model.getNumberOfLods()));
/*  86 */     this.lodCount.setFont(MainFrame.SMALL_FONT);
/*  87 */     this.lodCount.setHorizontalAlignment(2);
/*  88 */     add(this.lodCount, getGC(3, 2, 1));
/*     */   }
/*     */   
/*     */   private void createOriginalModelCounts() {
/*  92 */     JLabel triangleLabel = new JLabel("Triangle Count:");
/*  93 */     triangleLabel.setFont(MainFrame.SMALL_FONT);
/*  94 */     triangleLabel.setHorizontalAlignment(0);
/*  95 */     add(triangleLabel, getGC(0, 1, 1));
/*  96 */     this.triangleCount = new JLabel(Integer.toString(this.model.getTriangleCount()));
/*  97 */     this.triangleCount.setFont(MainFrame.SMALL_FONT);
/*  98 */     this.triangleCount.setHorizontalAlignment(2);
/*  99 */     add(this.triangleCount, getGC(1, 1, 1));
/*     */     
/* 101 */     JLabel vertexLabel = new JLabel("Vertices Count:");
/* 102 */     vertexLabel.setFont(MainFrame.SMALL_FONT);
/* 103 */     vertexLabel.setHorizontalAlignment(0);
/* 104 */     add(vertexLabel, getGC(2, 1, 1));
/* 105 */     this.vertexCount = new JLabel(Integer.toString(this.model.getVertexCount()));
/* 106 */     this.vertexCount.setFont(MainFrame.SMALL_FONT);
/* 107 */     this.vertexCount.setHorizontalAlignment(2);
/* 108 */     add(this.vertexCount, getGC(3, 1, 1));
/*     */   }
/*     */   
/*     */   private void update() {
/* 112 */     this.title.setText(this.model.getOutputFile().getName());
/* 113 */     this.triangleCount.setText(Integer.toString(this.model.getTriangleCount()));
/* 114 */     this.vertexCount.setText(Integer.toString(this.model.getVertexCount()));
/* 115 */     this.indexCount.setText(Integer.toString(this.model.getTotalIndicesCount()));
/* 116 */     this.lodCount.setText(Integer.toString(this.model.getNumberOfLods()));
/* 117 */     remove(this.slider);
/* 118 */     setSlider();
/*     */   }
/*     */   
/*     */   private void setSlider() {
/* 122 */     this.slider = new Slider("Scale:", this.model.getScale(), 0.0F, 8.0F, false);
/* 123 */     add(this.slider, getGC(0, 3, 4));
/* 124 */     this.slider.addSliderListener(new ChangeListener()
/*     */     {
/*     */ 
/*     */       public void stateChanged(ChangeEvent arg0) {
/* 128 */         ModelDataPanel.this.model.setScale(ModelDataPanel.this.slider.getSliderReading()); }
/*     */     });
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y, int gridSizeX) {
/* 133 */     GridBagConstraints gc = new GridBagConstraints();
/* 134 */     gc.fill = 2;
/* 135 */     gc.gridx = x;
/* 136 */     gc.gridy = y;
/* 137 */     gc.weightx = 1.0D;
/* 138 */     gc.weighty = 1.0D;
/* 139 */     gc.gridwidth = gridSizeX;
/* 140 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainSettingsPanel\ModelDataPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */