/*     */ package mainSettingsPanel;
/*     */ 
/*     */ import frontend.MainFrame;
/*     */ import frontend.Slider;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JSpinner.DefaultEditor;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import mainApp.Camera;
/*     */ import mainApp.MainApp;
/*     */ 
/*     */ public class PreviewSettingsPanel extends javax.swing.JPanel
/*     */ {
/*     */   private MainSettingsPanel mainPanel;
/*     */   private Camera camera;
/*     */   private JLabel cameraDistance;
/*     */   private JLabel distanceLOD;
/*     */   
/*     */   public PreviewSettingsPanel(int width, int height, MainSettingsPanel mainPanel, Camera camera)
/*     */   {
/*  26 */     this.mainPanel = mainPanel;
/*  27 */     this.camera = camera;
/*  28 */     setPreferredSize(new java.awt.Dimension(width, height));
/*  29 */     setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(126, 160, 194)));
/*  30 */     setLayout(new java.awt.GridBagLayout());
/*  31 */     addDisanceDisplay();
/*  32 */     addLODDisplay();
/*  33 */     camera.setPreviewSettingsPanel(this);
/*  34 */     addShowPlayerChoice();
/*  35 */     addShowTerrainChoice();
/*  36 */     addForceLODChoice();
/*  37 */     addCameraOptions();
/*  38 */     addWireframeChoice();
/*  39 */     addRotateCamera();
/*  40 */     addTextureButton();
/*  41 */     addAtlasOrderChoices();
/*  42 */     addSlider();
/*     */   }
/*     */   
/*     */   public void updateDistance(float distance) {
/*  46 */     this.cameraDistance.setText(Float.toString(distance));
/*     */   }
/*     */   
/*     */   public void updateLOD(int lod) {
/*  50 */     this.distanceLOD.setText(Integer.toString(lod));
/*     */   }
/*     */   
/*     */   private void addDisanceDisplay() {
/*  54 */     JLabel label = new JLabel("Distance:");
/*  55 */     label.setFont(MainFrame.SMALL_FONT);
/*  56 */     label.setHorizontalAlignment(2);
/*  57 */     add(label, getGC(0, 0, 1));
/*  58 */     this.cameraDistance = new JLabel(Float.toString(this.camera.getDistance()));
/*  59 */     this.cameraDistance.setFont(MainFrame.SMALL_FONT);
/*  60 */     this.cameraDistance.setHorizontalAlignment(2);
/*  61 */     add(this.cameraDistance, getGC(1, 0, 1));
/*     */   }
/*     */   
/*     */   private void addLODDisplay() {
/*  65 */     JLabel label = new JLabel("LOD:");
/*  66 */     label.setFont(MainFrame.SMALL_FONT);
/*  67 */     label.setHorizontalAlignment(2);
/*  68 */     add(label, getGC(2, 0, 1));
/*  69 */     this.distanceLOD = new JLabel(Float.toString(this.camera.getLOD()));
/*  70 */     this.distanceLOD.setFont(MainFrame.SMALL_FONT);
/*  71 */     this.distanceLOD.setHorizontalAlignment(2);
/*  72 */     add(this.distanceLOD, getGC(3, 0, 1));
/*     */   }
/*     */   
/*     */   private void addShowPlayerChoice() {
/*  76 */     final JCheckBox showPlayer = new JCheckBox("Show Player");
/*  77 */     showPlayer.setFont(MainFrame.SMALL_FONT);
/*  78 */     showPlayer.setHorizontalAlignment(2);
/*  79 */     add(showPlayer, getGC(0, 1, 2));
/*  80 */     showPlayer.setSelected(true);
/*  81 */     showPlayer.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  85 */         MainApp.player.setShowing(showPlayer.isSelected());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void addShowTerrainChoice()
/*     */   {
/*  92 */     final JCheckBox showTerrain = new JCheckBox("Show Terrain");
/*  93 */     showTerrain.setFont(MainFrame.SMALL_FONT);
/*  94 */     showTerrain.setHorizontalAlignment(2);
/*  95 */     add(showTerrain, getGC(2, 1, 2));
/*  96 */     showTerrain.setSelected(MainApp.showTerrain);
/*  97 */     showTerrain.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 101 */         MainApp.showTerrain = showTerrain.isSelected();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   private void addForceLODChoice()
/*     */   {
/* 109 */     final JCheckBox forceLOD = new JCheckBox("Force LOD");
/* 110 */     forceLOD.setFont(MainFrame.SMALL_FONT);
/* 111 */     forceLOD.setHorizontalAlignment(2);
/* 112 */     add(forceLOD, getGC(0, 2, 2));
/* 113 */     forceLOD.setSelected(MainApp.forceLOD);
/* 114 */     forceLOD.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 118 */         MainApp.forceLOD = forceLOD.isSelected();
/*     */       }
/*     */       
/* 121 */     });
/* 122 */     JLabel label = new JLabel("LOD: ");
/* 123 */     label.setFont(MainFrame.SMALL_FONT);
/* 124 */     label.setHorizontalAlignment(2);
/* 125 */     add(label, getGC(2, 2, 1));
/*     */     
/* 127 */     final JSpinner spinner = getJSpinner();
/* 128 */     add(spinner, getGC(3, 2, 1));
/* 129 */     spinner.addChangeListener(new javax.swing.event.ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/* 133 */         MainApp.forcedLOD = ((Integer)spinner.getValue()).intValue();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private JSpinner getJSpinner()
/*     */   {
/* 140 */     SpinnerNumberModel model = new SpinnerNumberModel(MainApp.forcedLOD, 0, 10, 1);
/* 141 */     JSpinner spinner = new JSpinner(model);
/* 142 */     spinner.setFont(MainFrame.SMALL_FONT);
/* 143 */     ((JSpinner.DefaultEditor)spinner.getEditor()).getTextField().setEditable(false);
/* 144 */     return spinner;
/*     */   }
/*     */   
/*     */   private JSpinner getJSpinnerOrder() {
/* 148 */     SpinnerNumberModel model = new SpinnerNumberModel(1, 1, 10, 1);
/* 149 */     JSpinner spinner = new JSpinner(model);
/* 150 */     spinner.setFont(MainFrame.SMALL_FONT);
/* 151 */     ((JSpinner.DefaultEditor)spinner.getEditor()).getTextField().setEditable(false);
/* 152 */     return spinner;
/*     */   }
/*     */   
/*     */   private void addCameraOptions() {
/* 156 */     JButton pan = new JButton("Pan Out");
/* 157 */     pan.setFont(MainFrame.SMALL_FONT);
/* 158 */     pan.setHorizontalAlignment(0);
/* 159 */     add(pan, getGC(0, 4, 1));
/* 160 */     pan.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 164 */         MainApp.camera.panOut();
/*     */       }
/*     */       
/*     */ 
/* 168 */     });
/* 169 */     JButton panin = new JButton("Pan In");
/* 170 */     panin.setFont(MainFrame.SMALL_FONT);
/* 171 */     panin.setHorizontalAlignment(0);
/* 172 */     add(panin, getGC(1, 4, 1));
/* 173 */     panin.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 177 */         MainApp.camera.panIn();
/*     */       }
/*     */       
/*     */ 
/* 181 */     });
/* 182 */     JButton reset = new JButton("Reset Camera");
/* 183 */     reset.setFont(MainFrame.SMALL_FONT);
/* 184 */     reset.setHorizontalAlignment(0);
/* 185 */     add(reset, getGC(2, 4, 2));
/* 186 */     reset.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 190 */         MainApp.camera.resetCamera();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void addWireframeChoice()
/*     */   {
/* 197 */     final JCheckBox wireframe = new JCheckBox("Wireframe Mode");
/* 198 */     wireframe.setFont(MainFrame.SMALL_FONT);
/* 199 */     wireframe.setHorizontalAlignment(2);
/* 200 */     add(wireframe, getGC(2, 3, 2));
/* 201 */     wireframe.setSelected(MainApp.WIRE_FRAME);
/* 202 */     wireframe.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 206 */         MainApp.WIRE_FRAME = wireframe.isSelected();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   private void addRotateCamera()
/*     */   {
/* 214 */     final JCheckBox rotate = new JCheckBox("Rotate Object");
/* 215 */     rotate.setFont(MainFrame.SMALL_FONT);
/* 216 */     rotate.setHorizontalAlignment(2);
/* 217 */     add(rotate, getGC(0, 3, 2));
/* 218 */     rotate.setSelected(renderPrograms.StaticRenderer.ROTATE);
/* 219 */     rotate.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 223 */         renderPrograms.StaticRenderer.ROTATE = rotate.isSelected();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void addTextureButton() {
/* 229 */     JButton chooseTexture = new JButton("Choose Texture");
/* 230 */     chooseTexture.setFont(MainFrame.SMALL_FONT);
/* 231 */     chooseTexture.setHorizontalAlignment(0);
/* 232 */     add(chooseTexture, getGC(0, 5, 2));
/* 233 */     chooseTexture.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 237 */         new TextureChooseScreen();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void addAtlasOrderChoices()
/*     */   {
/* 244 */     JLabel label = new JLabel("Atlas Order: ");
/* 245 */     label.setFont(MainFrame.SMALL_FONT);
/* 246 */     label.setHorizontalAlignment(2);
/* 247 */     add(label, getGC(2, 5, 1));
/*     */     
/* 249 */     final JSpinner spinner = getJSpinnerOrder();
/* 250 */     spinner.addChangeListener(new javax.swing.event.ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/* 254 */         if (MainApp.workspace.getCurrentMasterModel().getEntity() != null) {
/* 255 */           MainApp.workspace.getCurrentMasterModel().getEntity().setTextureCoords(((Integer)spinner.getValue()).intValue());
/*     */         }
/*     */         
/*     */       }
/* 259 */     });
/* 260 */     add(spinner, getGC(3, 5, 1));
/*     */   }
/*     */   
/*     */   private void addSlider() {
/* 264 */     final Slider slider = new Slider("Distance:", 10.0F, 0.0F, 200.0F, false);
/* 265 */     add(slider, getGC(0, 6, 4));
/* 266 */     slider.addSliderListener(new javax.swing.event.ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/* 270 */         MainApp.player.setX(400.0F + slider.getSliderReading());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private java.awt.GridBagConstraints getGC(int x, int y, int gridSizeX)
/*     */   {
/* 277 */     java.awt.GridBagConstraints gc = new java.awt.GridBagConstraints();
/* 278 */     gc.fill = 2;
/* 279 */     gc.gridx = x;
/* 280 */     gc.gridy = y;
/* 281 */     gc.weightx = 1.0D;
/* 282 */     gc.weighty = 1.0D;
/* 283 */     gc.gridwidth = gridSizeX;
/* 284 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\mainSettingsPanel\PreviewSettingsPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */