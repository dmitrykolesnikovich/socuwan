/*    */ package csvLoader;
/*    */ 
/*    */ import backend.LodModelVersion;
/*    */ import backend.MasterModel;
/*    */ import backend.Model;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import toolbox.FileUtils;
/*    */ import toolbox.ModelData;
/*    */ 
/*    */ public class CSVFileLoader
/*    */ {
/*    */   private static final String SEPARATOR = ",";
/*    */   
/*    */   public static MasterModel loadModelCSV(File csvFile)
/*    */     throws Exception
/*    */   {
/* 20 */     BufferedReader reader = FileUtils.openTextFile(csvFile);
/* 21 */     float furthestPoint = 10.0F;
/* 22 */     String line = reader.readLine();
/* 23 */     if (line.contains("FP")) {
/* 24 */       String[] parts = line.split(",");
/* 25 */       furthestPoint = Float.parseFloat(parts[1]);
/* 26 */       line = reader.readLine();
/*    */     }
/* 28 */     int vertexCount = Integer.parseInt(line);
/* 29 */     float[] vertices = new float[vertexCount];
/* 30 */     String[] values = reader.readLine().split(",");
/* 31 */     for (int i = 0; i < vertices.length; i++) {
/* 32 */       vertices[i] = Float.parseFloat(values[i]);
/*    */     }
/*    */     
/* 35 */     int textureCoordCount = Integer.parseInt(reader.readLine());
/* 36 */     values = reader.readLine().split(",");
/* 37 */     float[] textureCoords = new float[textureCoordCount];
/* 38 */     for (int i = 0; i < textureCoords.length; i++) {
/* 39 */       textureCoords[i] = Float.parseFloat(values[i]);
/*    */     }
/*    */     
/* 42 */     int normalsCount = Integer.parseInt(reader.readLine());
/* 43 */     values = reader.readLine().split(",");
/* 44 */     float[] normals = new float[normalsCount];
/* 45 */     for (int i = 0; i < normals.length; i++) {
/* 46 */       normals[i] = Float.parseFloat(values[i]);
/*    */     }
/*    */     
/* 49 */     int indicesCount = Integer.parseInt(reader.readLine());
/* 50 */     values = reader.readLine().split(",");
/* 51 */     int[] indices = new int[indicesCount];
/* 52 */     for (int i = 0; i < indices.length; i++) {
/* 53 */       indices[i] = Integer.parseInt(values[i]);
/*    */     }
/* 55 */     ModelData data = new ModelData(vertices, textureCoords, normals, indices, furthestPoint);
/* 56 */     Model original = new Model(data);
/* 57 */     String nextLine = null;
/* 58 */     List<LodModelVersion> versions = new ArrayList();
/* 59 */     while (((nextLine = reader.readLine()) != null) && (!nextLine.equals("NEWSECTION"))) {
/* 60 */       LodModelVersion version = loadSimplifiedVersion(vertices, textureCoords, normals, furthestPoint, reader, nextLine, original);
/*    */       
/* 62 */       versions.add(version);
/*    */     }
/* 64 */     reader.close();
/* 65 */     return new MasterModel(csvFile, original, versions);
/*    */   }
/*    */   
/*    */   private static LodModelVersion loadSimplifiedVersion(float[] vertices, float[] textures, float[] normals, float furthest, BufferedReader reader, String line, Model original)
/*    */     throws Exception
/*    */   {
/* 71 */     String[] values = line.split(",");
/* 72 */     int lod = Integer.parseInt(values[0]);
/* 73 */     int indicesCount = Integer.parseInt(values[1]);
/* 74 */     float error = 0.0F;
/* 75 */     if (values.length == 3) {
/* 76 */       error = Float.parseFloat(values[2]);
/*    */     }
/* 78 */     int[] indices = new int[indicesCount];
/* 79 */     values = reader.readLine().split(",");
/* 80 */     for (int i = 0; i < indices.length; i++) {
/* 81 */       indices[i] = Integer.parseInt(values[i]);
/*    */     }
/* 83 */     ModelData data = new ModelData(vertices, textures, normals, indices, furthest);
/* 84 */     return new LodModelVersion(lod, original, data, error);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\csvLoader\CSVFileLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */