/*    */ package accessories;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ 
/*    */ public class AccessoryBlueprint
/*    */ {
/*    */   private RawModel model;
/*    */   private texture.ModelTexture texture;
/*    */   private int sectionID;
/*    */   
/*    */   public AccessoryBlueprint(int sectionID, RawModel model, texture.ModelTexture texture)
/*    */   {
/* 13 */     this.sectionID = sectionID;
/* 14 */     this.model = model;
/* 15 */     this.texture = texture;
/*    */   }
/*    */   
/*    */   public int getSectionID() {
/* 19 */     return this.sectionID;
/*    */   }
/*    */   
/*    */   public RawModel getModel() {
/* 23 */     return this.model;
/*    */   }
/*    */   
/*    */   public texture.ModelTexture getTexture() {
/* 27 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\accessories\AccessoryBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */