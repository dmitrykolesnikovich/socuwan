/*     */ package instances;
/*     */ 
/*     */ import blueprints.Blueprint;
/*     */ import entitiesInterfaces.EntityInterface;
/*     */ import toolbox.Colour;
/*     */ 
/*     */ 
/*     */ public abstract class Entity
/*     */   implements EntityInterface
/*     */ {
/*     */   private Blueprint blueprint;
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private float rotX;
/*     */   private float rotY;
/*     */   private float rotZ;
/*     */   private float scale;
/*     */   private float disFromCamera;
/*     */   private int currentLevelOfDetail;
/*     */   private float textureOffsetX;
/*     */   private float textureOffsetY;
/*     */   private float textureSize;
/*  24 */   private Colour material1Colour = null;
/*  25 */   private Colour material2Colour = null;
/*     */   
/*  27 */   private boolean solid = false;
/*     */   
/*     */   private boolean hasReflection;
/*  30 */   private boolean wireframe = false;
/*     */   
/*     */   public Entity(Blueprint blueprint, int textureIndex, float x, float y, float z, float rotX, float rotY, float rotZ, float scale) {
/*  33 */     this.blueprint = blueprint;
/*  34 */     setTextureCoords(1);
/*  35 */     this.x = x;
/*  36 */     this.y = y;
/*  37 */     this.z = z;
/*  38 */     this.rotX = rotX;
/*  39 */     this.rotY = rotY;
/*  40 */     this.rotZ = rotZ;
/*  41 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public void setWireframe(boolean wire) {
/*  45 */     this.wireframe = wire;
/*     */   }
/*     */   
/*     */   public void setScale(float scale) {
/*  49 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  53 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  57 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  61 */     return this.z;
/*     */   }
/*     */   
/*     */   public void translatePosition(float dX, float dY, float dZ)
/*     */   {
/*  66 */     this.x += dX;
/*  67 */     this.y += dY;
/*  68 */     this.z += dZ;
/*     */   }
/*     */   
/*     */   public void setX(float x) {
/*  72 */     this.x = x;
/*     */   }
/*     */   
/*     */   public void setY(float y) {
/*  76 */     this.y = y;
/*     */   }
/*     */   
/*     */   public void setZ(float z) {
/*  80 */     this.z = z;
/*     */   }
/*     */   
/*     */   public float getRotX() {
/*  84 */     return this.rotX;
/*     */   }
/*     */   
/*     */   public float getRotY() {
/*  88 */     return this.rotY;
/*     */   }
/*     */   
/*     */   public float getRotZ() {
/*  92 */     return this.rotZ;
/*     */   }
/*     */   
/*     */   public void setRotY(float rotY) {
/*  96 */     this.rotY = rotY;
/*     */   }
/*     */   
/*     */   public void setRotZ(float rotZ) {
/* 100 */     this.rotZ = rotZ;
/*     */   }
/*     */   
/*     */   public void increaseRotationValue(float dX, float dY, float dZ) {
/* 104 */     this.rotX += dX;
/* 105 */     this.rotY += dY;
/* 106 */     this.rotZ += dZ;
/*     */   }
/*     */   
/*     */   public float getScale() {
/* 110 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void increaseScale(float dScale) {
/* 114 */     this.scale += dScale;
/*     */   }
/*     */   
/*     */   public boolean isSolid()
/*     */   {
/* 119 */     return this.solid;
/*     */   }
/*     */   
/*     */   public float getFurthestPoint() {
/* 123 */     return this.blueprint.getFurthestPoint() * this.scale;
/*     */   }
/*     */   
/*     */   public Blueprint getBlueprint()
/*     */   {
/* 128 */     return this.blueprint;
/*     */   }
/*     */   
/*     */   public void setDistance(float distance)
/*     */   {
/* 133 */     this.disFromCamera = distance;
/*     */   }
/*     */   
/*     */   public float getDistance()
/*     */   {
/* 138 */     return this.disFromCamera;
/*     */   }
/*     */   
/*     */   public void setLOD(int lod)
/*     */   {
/* 143 */     this.currentLevelOfDetail = lod;
/*     */   }
/*     */   
/*     */   public boolean isVisible()
/*     */   {
/* 148 */     return true;
/*     */   }
/*     */   
/*     */   public float getVisibleDistance()
/*     */   {
/* 153 */     return this.blueprint.getVisibleRange() * this.scale;
/*     */   }
/*     */   
/*     */   public void setReflectionFlag()
/*     */   {
/* 158 */     if (this.blueprint.hasReflection()) {
/* 159 */       if (this.blueprint.hasLimitedReflection()) {
/* 160 */         if (this.disFromCamera < this.blueprint.getReflectionLimit() * this.scale) {
/* 161 */           this.hasReflection = true;
/*     */         } else {
/* 163 */           this.hasReflection = false;
/*     */         }
/*     */       } else {
/* 166 */         this.hasReflection = true;
/*     */       }
/*     */     } else {
/* 169 */       this.hasReflection = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasReflection()
/*     */   {
/* 175 */     return this.hasReflection;
/*     */   }
/*     */   
/*     */   public int getLOD()
/*     */   {
/* 180 */     return this.currentLevelOfDetail;
/*     */   }
/*     */   
/*     */   public float[] getInstanceTextureCoords()
/*     */   {
/* 185 */     return new float[] { this.textureSize, this.textureOffsetX, this.textureOffsetY };
/*     */   }
/*     */   
/*     */   public Colour getMaterial1Colour()
/*     */   {
/* 190 */     return this.material1Colour;
/*     */   }
/*     */   
/*     */   public Colour getMaterial2Colour()
/*     */   {
/* 195 */     return this.material2Colour;
/*     */   }
/*     */   
/*     */   public void setBlueprint(Blueprint blueprint) {
/* 199 */     this.blueprint = blueprint;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setOrder(int order) {}
/*     */   
/*     */   public void setTextureCoords(int order)
/*     */   {
/* 207 */     this.textureOffsetX = getXOffset(0, order);
/* 208 */     this.textureOffsetY = getYOffset(0, order);
/* 209 */     this.textureSize = getSize(order);
/*     */   }
/*     */   
/*     */   private float getSize(int order) {
/* 213 */     return 1.0F / order;
/*     */   }
/*     */   
/*     */   private float getXOffset(int index, int order) {
/* 217 */     float check = index / order;
/* 218 */     return check % 1.0F;
/*     */   }
/*     */   
/*     */   private float getYOffset(int index, int order) {
/* 222 */     return (float)(Math.floor(index / order) * getSize(order));
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\instances\Entity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */