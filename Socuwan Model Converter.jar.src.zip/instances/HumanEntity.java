/*     */ package instances;
/*     */ 
/*     */ import accessories.AccessoryBlueprint;
/*     */ import accessories.AccessoryInterface;
/*     */ import accessories.ClothesInstanceInterface;
/*     */ import accessories.ClothesSection;
/*     */ import accessories.Hair;
/*     */ import accessories.HairColour;
/*     */ import accessories.HairStyle;
/*     */ import animations.Animation;
/*     */ import animations.AnimationLoader;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import blueprints.AnimatedBlueprint;
/*     */ import entitiesInterfaces.HumanEntityInterface;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ public class HumanEntity extends AnimatedEntity implements HumanEntityInterface
/*     */ {
/*  24 */   private static final AnimatedBlueprint HUMAN_BLUEPRINT = ;
/*  25 */   private static final Animation standing = AnimationLoader.loadAnimationFile("standing");
/*     */   
/*  27 */   private Hair hair = null;
/*     */   
/*  29 */   private boolean show = true;
/*     */   
/*     */   public HumanEntity(float x, float y, float z, float rotX, float rotY, float rotZ, float scale) {
/*  32 */     super(HUMAN_BLUEPRINT, 0, x, y, z, rotX, rotY, rotZ, scale);
/*  33 */     super.suggestAnimation(standing);
/*  34 */     setHair(HairStyle.SIMPLE_HAIR, HairColour.BROWN);
/*     */   }
/*     */   
/*     */   public void setShowing(boolean show) {
/*  38 */     this.show = show;
/*     */   }
/*     */   
/*     */   public boolean isShowing() {
/*  42 */     return this.show;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setHair(HairStyle hairstyle, HairColour hairColour)
/*     */   {
/*  48 */     this.hair = new Hair(hairstyle, hairColour);
/*     */   }
/*     */   
/*     */   public List<AccessoryInterface> getAccessoriesOnNode(int sectionID) {
/*  52 */     List<AccessoryInterface> accessories = new ArrayList();
/*  53 */     if ((this.hair != null) && 
/*  54 */       (sectionID == this.hair.getBlueprint().getSectionID())) {
/*  55 */       accessories.add(this.hair);
/*     */     }
/*     */     
/*  58 */     return accessories;
/*     */   }
/*     */   
/*     */   public Map<ClothesInstanceInterface, ClothesSection> getClothesSectionsOnNode(int sectionID) {
/*  62 */     return new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static AnimatedBlueprint createBlueprint()
/*     */   {
/*  69 */     BoneBlueprint hip = new BoneBlueprint(0, RenderEngine.loadModelFile(33, "hip"), 0.0F, 0.0F, 0.0F);
/*  70 */     BoneBlueprint waist = new BoneBlueprint(1, RenderEngine.loadModelFile(32, "waist"), 0.0F, 4.05F, 0.0F);
/*     */     
/*  72 */     BoneBlueprint chest = new BoneBlueprint(2, RenderEngine.loadModelFile(31, "chest"), 0.0F, 4.85F, 0.0F);
/*     */     
/*  74 */     BoneBlueprint head = new BoneBlueprint(3, RenderEngine.loadModelFile(30, "head"), 0.0F, 5.9F, 0.0F);
/*  75 */     BoneBlueprint upperRightArm = new BoneBlueprint(4, RenderEngine.loadModelFile(40, "upperRightArm"), -1.15F, 5.5F, 0.0F);
/*     */     
/*  77 */     BoneBlueprint lowerRightArm = new BoneBlueprint(5, RenderEngine.loadModelFile(41, "lowerRightArm"), -1.15F, 4.4F, 0.0F);
/*     */     
/*  79 */     BoneBlueprint rightHand = new BoneBlueprint(6, RenderEngine.loadModelFile(42, "rightHand"), -1.15F, 3.3F, 0.0F);
/*     */     
/*  81 */     BoneBlueprint upperLeftArm = new BoneBlueprint(7, RenderEngine.loadModelFile(43, "upperLeftArm"), 1.15F, 5.5F, 0.0F);
/*     */     
/*  83 */     BoneBlueprint lowerLeftArm = new BoneBlueprint(8, RenderEngine.loadModelFile(44, "lowerLeftArm"), 1.15F, 4.4F, 0.0F);
/*     */     
/*  85 */     BoneBlueprint leftHand = new BoneBlueprint(9, RenderEngine.loadModelFile(45, "leftHand"), 1.15F, 3.3F, 0.0F);
/*     */     
/*  87 */     BoneBlueprint upperRightLeg = new BoneBlueprint(10, RenderEngine.loadModelFile(34, "upperRightLeg"), -0.45F, 3.2F, 0.0F);
/*     */     
/*  89 */     BoneBlueprint lowerRightLeg = new BoneBlueprint(11, RenderEngine.loadModelFile(35, "lowerRightLeg"), -0.45F, 1.7F, 0.0F);
/*     */     
/*  91 */     BoneBlueprint rightFoot = new BoneBlueprint(12, RenderEngine.loadModelFile(36, "rightFoot"), -0.45F, 0.37F, 0.0F);
/*     */     
/*  93 */     BoneBlueprint upperLeftLeg = new BoneBlueprint(13, RenderEngine.loadModelFile(37, "upperLeftLeg"), 0.45F, 3.2F, 0.0F);
/*     */     
/*  95 */     BoneBlueprint lowerLeftLeg = new BoneBlueprint(14, RenderEngine.loadModelFile(38, "lowerLeftLeg"), 0.45F, 1.7F, 0.0F);
/*     */     
/*  97 */     BoneBlueprint leftFoot = new BoneBlueprint(15, RenderEngine.loadModelFile(39, "leftFoot"), 0.45F, 0.37F, 0.0F);
/*     */     
/*     */ 
/* 100 */     hip.addChildren(new BoneBlueprint[] { waist, upperRightLeg, upperLeftLeg });
/* 101 */     waist.addChildren(new BoneBlueprint[] { chest });
/* 102 */     chest.addChildren(new BoneBlueprint[] { head, upperLeftArm, upperRightArm });
/* 103 */     upperLeftArm.addChildren(new BoneBlueprint[] { lowerLeftArm });
/* 104 */     lowerLeftArm.addChildren(new BoneBlueprint[] { leftHand });
/* 105 */     upperRightArm.addChildren(new BoneBlueprint[] { lowerRightArm });
/* 106 */     lowerRightArm.addChildren(new BoneBlueprint[] { rightHand });
/* 107 */     upperLeftLeg.addChildren(new BoneBlueprint[] { lowerLeftLeg });
/* 108 */     upperRightLeg.addChildren(new BoneBlueprint[] { lowerRightLeg });
/* 109 */     lowerLeftLeg.addChildren(new BoneBlueprint[] { leftFoot });
/* 110 */     lowerRightLeg.addChildren(new BoneBlueprint[] { rightFoot });
/*     */     
/* 112 */     return new AnimatedBlueprint(0, new BoneBlueprint[] { hip }, 16, new ModelTexture("test"));
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\instances\HumanEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */