/*     */ package instances;
/*     */ 
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import toolbox.MyMouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Camera
/*     */   implements epicRenderEngine.Camera
/*     */ {
/*  12 */   private final float FIELD_OF_VIEW = 70.0F;
/*  13 */   private final float NEAR_PLANE = 0.1F;
/*  14 */   private final float FAR_PLANE = 1040.0F;
/*     */   
/*     */   private Entity parentEntity;
/*     */   
/*     */   private MyMouse mouse;
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private float horizontalDistanceFromPlayer;
/*     */   private float verticalDistanceFromPlayer;
/*     */   private float pitch;
/*     */   private float yaw;
/*  26 */   private float actualDistanceFromPlayer = 120.0F;
/*  27 */   private float angleOfElevation = 0.37F;
/*  28 */   private float angleAroundPlayer = 150.0F;
/*  29 */   private boolean change = false;
/*  30 */   private boolean panOut = false;
/*     */   
/*     */   private static final float CAMERA_AIM_OFFSET = 2.5F;
/*     */   private static final int INFLUENCE_OF_MOUSEDY = 50;
/*     */   private static final int INFLUENCE_OF_MOUSEDX = 1;
/*     */   private static final int INFLUENCE_OF_MOUSE_WHEEL = 100;
/*     */   private static final float MAX_ANGLE_OF_ELEVATION = 1.5F;
/*     */   private static final float PITCH_OFFSET = 8.0F;
/*     */   private static final float MINIMUM_ZOOM = 8.0F;
/*     */   private static final float MAX_HORIZONTAL_CHANGE = 2000.0F;
/*     */   private static final float MAX_VERTICAL_CHANGE = 20.0F;
/*     */   
/*     */   public Camera(MyMouse mouse)
/*     */   {
/*  44 */     this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */     
/*  46 */     this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*  47 */     this.mouse = mouse;
/*     */   }
/*     */   
/*     */   public void setParentEntity(Entity entity) {
/*  51 */     this.parentEntity = entity;
/*     */   }
/*     */   
/*     */   public void panOut() {
/*  55 */     this.actualDistanceFromPlayer = 12.0F;
/*  56 */     this.panOut = true;
/*     */   }
/*     */   
/*     */   public void resetCamera() {
/*  60 */     this.actualDistanceFromPlayer = 12.0F;
/*  61 */     this.panOut = false;
/*     */   }
/*     */   
/*     */   public void moveCamera(float delta) {
/*  65 */     if (this.panOut) {
/*  66 */       this.actualDistanceFromPlayer += 0.5F;
/*  67 */       if (this.actualDistanceFromPlayer >= 300.0F) {
/*  68 */         resetCamera();
/*     */       }
/*     */     }
/*  71 */     this.change = true;
/*  72 */     calculateHorizontalAngle(delta);
/*  73 */     calculateVerticalAngle(delta);
/*  74 */     calculateZoom();
/*  75 */     calculateDistances();
/*  76 */     calculatePosition();
/*     */   }
/*     */   
/*     */   public float getX() {
/*  80 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  84 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  88 */     return this.z;
/*     */   }
/*     */   
/*     */   public float getPitch() {
/*  92 */     return this.pitch;
/*     */   }
/*     */   
/*     */   public float getYaw() {
/*  96 */     return this.yaw;
/*     */   }
/*     */   
/*     */   public float getFieldOfView() {
/* 100 */     return 70.0F;
/*     */   }
/*     */   
/*     */   public float getNearPlane() {
/* 104 */     return 0.1F;
/*     */   }
/*     */   
/*     */   public float getFarPlane() {
/* 108 */     return 1040.0F;
/*     */   }
/*     */   
/*     */   private void calculatePosition() {
/* 112 */     float playerRot = 0.0F;
/* 113 */     this.x = (this.parentEntity.getX() - (float)(this.horizontalDistanceFromPlayer * Math.sin(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/* 116 */     this.z = (this.parentEntity.getZ() - (float)(this.horizontalDistanceFromPlayer * Math.cos(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/*     */ 
/* 120 */     float height = 0.0F;
/* 121 */     this.y = (this.verticalDistanceFromPlayer + 2.5F + height);
/*     */     
/* 123 */     if (this.parentEntity.getY() + 2.5F > this.y) {
/* 124 */       this.y = (this.parentEntity.getY() + 2.5F);
/*     */     }
/* 126 */     this.yaw = (playerRot + 180.0F + this.angleAroundPlayer);
/* 127 */     this.pitch = ((float)Math.toDegrees(this.angleOfElevation) - 8.0F);
/*     */   }
/*     */   
/*     */   private void calculateHorizontalAngle(float delta) {
/* 131 */     if ((this.mouse.isLeftButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 132 */       float angleChange = this.mouse.getDX() / 1.0F;
/* 133 */       if (angleChange > 2000.0F * delta) {
/* 134 */         angleChange = 2000.0F * delta;
/* 135 */       } else if (angleChange < -2000.0F * delta) {
/* 136 */         angleChange = -2000.0F * delta;
/*     */       }
/* 138 */       this.angleAroundPlayer -= angleChange;
/*     */       
/* 140 */       if (this.angleAroundPlayer >= 180.0F) {
/* 141 */         this.angleAroundPlayer -= 360.0F;
/* 142 */       } else if (this.angleAroundPlayer <= -180.0F) {
/* 143 */         this.angleAroundPlayer += 360.0F;
/*     */       }
/* 145 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateVerticalAngle(float delta)
/*     */   {
/* 151 */     if ((this.mouse.isRightButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 152 */       float angleChange = this.mouse.getDY() / 50.0F;
/* 153 */       if (angleChange > 20.0F * delta) {
/* 154 */         angleChange = 20.0F * delta;
/* 155 */       } else if (angleChange < -20.0F * delta) {
/* 156 */         angleChange = -20.0F * delta;
/*     */       }
/* 158 */       this.angleOfElevation -= angleChange;
/* 159 */       if (this.angleOfElevation >= 1.5F) {
/* 160 */         this.angleOfElevation = 1.5F;
/* 161 */       } else if (this.angleOfElevation <= 0.0F) {
/* 162 */         this.angleOfElevation = 0.0F;
/*     */       }
/* 164 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateZoom() {
/* 169 */     if (Keyboard.isKeyDown(46)) {
/* 170 */       this.actualDistanceFromPlayer -= 1.0F;
/* 171 */       this.change = true;
/*     */     }
/* 173 */     float zoomLevel = this.mouse.getDWheel() / 100;
/* 174 */     if (zoomLevel != 0.0F) {
/* 175 */       this.actualDistanceFromPlayer -= zoomLevel;
/* 176 */       if (this.actualDistanceFromPlayer < 8.0F) {
/* 177 */         this.actualDistanceFromPlayer = 8.0F;
/*     */       }
/* 179 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateDistances() {
/* 184 */     if (this.change) {
/* 185 */       this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */       
/* 187 */       this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\instances\Camera.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */