package blueprintInterfaces;

import texture.ModelTexture;

public abstract interface BlueprintInterface
{
  public abstract ModelTexture getTexture();
  
  public abstract void limitVisibility(float paramFloat);
  
  public abstract float getVisibleRange();
  
  public abstract void setFurthestPoint(float paramFloat);
  
  public abstract float getFurthestPoint();
  
  public abstract boolean hasReflection();
  
  public abstract boolean isVisibleUnderWater();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\blueprintInterfaces\BlueprintInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */