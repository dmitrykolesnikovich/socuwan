/*    */ package blueprintInterfaces;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ public class RawModel
/*    */ {
/*    */   private int id;
/*    */   private int vaoID;
/*    */   private int[] indexVBOLengths;
/*    */   private boolean solid;
/*    */   
/*    */   public RawModel(int id, int vaoID, int[] indicesLengths)
/*    */   {
/* 15 */     this.id = id;
/* 16 */     this.vaoID = vaoID;
/* 17 */     this.indexVBOLengths = indicesLengths;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 21 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getVaoID() {
/* 25 */     return this.vaoID;
/*    */   }
/*    */   
/*    */   public int getIndexVBOLength(int lOD) {
/* 29 */     int start = lOD;
/* 30 */     if (lOD >= this.indexVBOLengths.length) {
/* 31 */       start = this.indexVBOLengths.length - 1;
/*    */     }
/* 33 */     for (int i = start; i >= 0; i--) {
/* 34 */       int length = this.indexVBOLengths[i];
/* 35 */       if (length >= 0) {
/* 36 */         return length;
/*    */       }
/*    */     }
/* 39 */     System.err.println("Index VBO length of 0? Shouldn't be possible.");
/* 40 */     return 0;
/*    */   }
/*    */   
/*    */   public int getIndicesVBOOffset(int lOD) {
/* 44 */     int offset = 0;
/* 45 */     if (lOD >= this.indexVBOLengths.length) {
/* 46 */       lOD = this.indexVBOLengths.length - 1;
/*    */     }
/* 48 */     while (this.indexVBOLengths[lOD] == 0) {
/* 49 */       lOD--;
/*    */     }
/* 51 */     for (int i = lOD - 1; i >= 0; i--) {
/* 52 */       offset += this.indexVBOLengths[i];
/*    */     }
/* 54 */     return offset;
/*    */   }
/*    */   
/*    */   public boolean isSolid()
/*    */   {
/* 59 */     return this.solid;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\blueprintInterfaces\RawModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */