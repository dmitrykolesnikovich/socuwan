/*    */ package blueprintInterfaces;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class BoneBlueprint
/*    */ {
/*    */   private int partID;
/*    */   private RawModel model;
/*    */   private float centerX;
/*    */   private float centerY;
/*    */   private float centerZ;
/*    */   private List<BoneBlueprint> childrenNodes;
/*    */   
/*    */   public BoneBlueprint(int partID, RawModel model, float centerX, float centerY, float centerZ) {
/* 15 */     this.model = model;
/* 16 */     this.partID = partID;
/* 17 */     this.centerX = centerX;
/* 18 */     this.centerY = centerY;
/* 19 */     this.centerZ = centerZ;
/* 20 */     this.childrenNodes = new java.util.ArrayList();
/*    */   }
/*    */   
/*    */   public int getPartID() {
/* 24 */     return this.partID;
/*    */   }
/*    */   
/*    */   public RawModel getModel() {
/* 28 */     return this.model;
/*    */   }
/*    */   
/*    */   public void addChildren(BoneBlueprint... children) {
/* 32 */     for (BoneBlueprint child : children) {
/* 33 */       this.childrenNodes.add(child);
/*    */     }
/*    */   }
/*    */   
/*    */   public List<BoneBlueprint> getChildren() {
/* 38 */     return this.childrenNodes;
/*    */   }
/*    */   
/*    */   public float getCenterX() {
/* 42 */     return this.centerX;
/*    */   }
/*    */   
/*    */   public float getCenterY() {
/* 46 */     return this.centerY;
/*    */   }
/*    */   
/*    */   public float getCenterZ() {
/* 50 */     return this.centerZ;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\blueprintInterfaces\BoneBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */