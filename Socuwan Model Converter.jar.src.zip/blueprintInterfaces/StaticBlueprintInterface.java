package blueprintInterfaces;

public abstract interface StaticBlueprintInterface
  extends BlueprintInterface
{
  public abstract RawModel getModel();
  
  public abstract boolean fadesOut();
  
  public abstract int getInstanceDataVBO();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\blueprintInterfaces\StaticBlueprintInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */