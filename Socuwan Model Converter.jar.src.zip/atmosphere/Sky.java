/*    */ package atmosphere;
/*    */ 
/*    */ import epicRenderEngine.Camera;
/*    */ import toolbox.Colour;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sky
/*    */ {
/*    */   private static final float SKY_BOX_EXTENSION = 1.05F;
/*    */   private SkyBox skybox;
/*    */   private Sun sun;
/* 13 */   private Colour skyColour = new Colour(0.3137255F, 1.0F, 0.61960787F);
/* 14 */   private float fogDensity = 0.0F;
/* 15 */   private float fogGradient = 2.0F;
/*    */   
/*    */   public Sky(Camera camera, float generalVisibility) {
/* 18 */     this.skybox = new SkyBox(camera, generalVisibility * 1.05F);
/* 19 */     this.sun = new Sun(camera, generalVisibility);
/*    */   }
/*    */   
/*    */   public SkyBox getSkyBox() {
/* 23 */     return this.skybox;
/*    */   }
/*    */   
/*    */   public Sun getSun() {
/* 27 */     return this.sun;
/*    */   }
/*    */   
/*    */   public Colour getSkyColour() {
/* 31 */     return this.skyColour;
/*    */   }
/*    */   
/*    */   public void setSkyColour(Colour skyColour) {
/* 35 */     this.skyColour = skyColour;
/*    */   }
/*    */   
/*    */   public float getFogDensity() {
/* 39 */     return this.fogDensity;
/*    */   }
/*    */   
/*    */   public void setFogDensity(float fogDensity) {
/* 43 */     this.fogDensity = fogDensity;
/*    */   }
/*    */   
/*    */   public float getFogGradient() {
/* 47 */     return this.fogGradient;
/*    */   }
/*    */   
/*    */   public void setFogGradient(float fogGradient) {
/* 51 */     this.fogGradient = fogGradient;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\atmosphere\Sky.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */