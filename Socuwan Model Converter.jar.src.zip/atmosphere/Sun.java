/*    */ package atmosphere;
/*    */ 
/*    */ import epicRenderEngine.Camera;
/*    */ import org.lwjgl.util.vector.Vector3f;
/*    */ import toolbox.Colour;
/*    */ 
/*    */ public class Sun
/*    */ {
/*    */   private entitiesInterfaces.Light sunlight;
/*    */   private final float renderDistance;
/*    */   private float x;
/*    */   private float y;
/*    */   private float z;
/*    */   private float yaw;
/*    */   private float pitch;
/*    */   private Camera camera;
/* 17 */   private float scale = 1.0F;
/* 18 */   private Colour colour = new Colour(1.0F, 1.0F, 1.0F);
/*    */   
/*    */   public Sun(Camera camera, float renderDistance) {
/* 21 */     this.camera = camera;
/* 22 */     this.renderDistance = renderDistance;
/* 23 */     this.sunlight = new entitiesInterfaces.Light(0.0F, 0.0F, 0.0F);
/*    */   }
/*    */   
/*    */   public entitiesInterfaces.Light getLight() {
/* 27 */     return this.sunlight;
/*    */   }
/*    */   
/*    */   public void setPosition(float x, float y, float z) {
/* 31 */     this.sunlight.setPosition(x, y, z);
/* 32 */     Vector3f toSunFromCamera = new Vector3f(x - this.camera.getX(), y - this.camera.getY(), z - this.camera.getZ());
/* 33 */     toSunFromCamera.normalise();
/* 34 */     this.pitch = (360.0F - (float)Math.toDegrees(Math.asin(toSunFromCamera.y)));
/*    */     
/* 36 */     toSunFromCamera.scale(this.renderDistance);
/* 37 */     this.x = (this.camera.getX() + toSunFromCamera.x);
/* 38 */     this.y = (this.camera.getY() + toSunFromCamera.y);
/* 39 */     this.z = (this.camera.getZ() + toSunFromCamera.z);
/*    */     
/* 41 */     float dX = this.camera.getX() - x;
/* 42 */     float dZ = this.camera.getZ() - z;
/* 43 */     this.yaw = ((float)Math.toDegrees(Math.atan2(dX, dZ)));
/*    */   }
/*    */   
/*    */   public void setScale(float scale)
/*    */   {
/* 48 */     this.scale = scale;
/*    */   }
/*    */   
/*    */   public float getScale() {
/* 52 */     return this.scale;
/*    */   }
/*    */   
/*    */   public float getX() {
/* 56 */     return this.x;
/*    */   }
/*    */   
/*    */   public float getY() {
/* 60 */     return this.y;
/*    */   }
/*    */   
/*    */   public float getZ() {
/* 64 */     return this.z;
/*    */   }
/*    */   
/*    */   public float getPitch() {
/* 68 */     return this.pitch;
/*    */   }
/*    */   
/*    */   public float getYaw() {
/* 72 */     return this.yaw;
/*    */   }
/*    */   
/*    */   public Colour getColour() {
/* 76 */     return this.colour;
/*    */   }
/*    */   
/*    */   public void setColour(Colour colour) {
/* 80 */     this.colour = colour;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\atmosphere\Sun.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */