package atmosphere;

public abstract interface SkyTextureInterface
{
  public abstract int getTexture();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\atmosphere\SkyTextureInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */