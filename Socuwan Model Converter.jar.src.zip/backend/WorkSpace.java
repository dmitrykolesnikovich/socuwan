/*    */ package backend;
/*    */ 
/*    */ import csvLoader.CSVFileLoader;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import mainApp.Configs;
/*    */ import objConverter.OBJFileLoader;
/*    */ import toolbox.ModelData;
/*    */ 
/*    */ public class WorkSpace
/*    */ {
/*    */   private MasterModel masterModel;
/*    */   
/*    */   public void open(File masterModelFile)
/*    */   {
/* 18 */     save();
/*    */     try {
/* 20 */       this.masterModel = CSVFileLoader.loadModelCSV(masterModelFile);
/*    */     } catch (Exception e) {
/* 22 */       e.printStackTrace();
/* 23 */       System.out.println();
/* 24 */       System.err.println("Couldn't load Master Model file: " + masterModelFile.getPath());
/*    */     }
/*    */   }
/*    */   
/*    */   public void createNewMasterModel(File objFile) {
/* 29 */     save();
/*    */     try {
/* 31 */       ModelData modelData = OBJFileLoader.loadOBJ(objFile);
/* 32 */       File outputFile = new File(Configs.SAVES_FOLDER, objFile.getName().split("\\.")[0] + "_SCW.csv");
/*    */       
/* 34 */       outputFile.createNewFile();
/* 35 */       this.masterModel = new MasterModel(outputFile, new Model(modelData), new ArrayList());
/*    */     }
/*    */     catch (Exception e) {
/* 38 */       e.printStackTrace();
/* 39 */       System.err.println("Couldn't create new file!");
/*    */     }
/*    */   }
/*    */   
/*    */   public void save() {
/* 44 */     if (this.masterModel != null) {
/* 45 */       this.masterModel.export();
/*    */     }
/*    */   }
/*    */   
/*    */   public List<File> listOBJs() {
/* 50 */     File[] files = Configs.OBJ_REPOSITORY.listFiles();
/* 51 */     List<File> fileList = new ArrayList();
/* 52 */     for (File file : files) {
/* 53 */       fileList.add(file);
/*    */     }
/* 55 */     return fileList;
/*    */   }
/*    */   
/*    */   public List<File> listMasterModelFiles() {
/* 59 */     File[] files = Configs.SAVES_FOLDER.listFiles();
/* 60 */     List<File> fileList = new ArrayList();
/* 61 */     for (File file : files) {
/* 62 */       fileList.add(file);
/*    */     }
/* 64 */     return fileList;
/*    */   }
/*    */   
/*    */   public MasterModel getCurrentMasterModel() {
/* 68 */     return this.masterModel;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\backend\WorkSpace.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */