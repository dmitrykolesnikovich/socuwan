/*    */ package backend;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.PrintWriter;
/*    */ import toolbox.ModelData;
/*    */ 
/*    */ public class ModelFileExporter
/*    */ {
/*    */   public static final String FAR_POINT = "FP";
/*    */   public static final String SEPARATOR = ",";
/*    */   
/*    */   public static void exportModel(MasterModel masterModel)
/*    */   {
/* 16 */     ModelData originalData = masterModel.getOriginal().getModelData();
/* 17 */     float[] vertices = originalData.getVertices();
/* 18 */     float[] textureCoords = originalData.getTextureCoords();
/* 19 */     float[] normals = originalData.getNormals();
/* 20 */     int[] indices = originalData.getIndices();
/*    */     
/* 22 */     PrintWriter writer = openSaveFile(masterModel.getOutputFile());
/* 23 */     writer.println("FP," + originalData.getFurthestPoint() * masterModel.getScale());
/* 24 */     printFloatList(vertices, writer, masterModel.getScale());
/* 25 */     printFloatList(textureCoords, writer, 1.0F);
/* 26 */     printFloatList(normals, writer, 1.0F);
/* 27 */     printIndices(indices, writer);
/* 28 */     for (LodModelVersion version : masterModel.getSimplifiedVersions()) {
/* 29 */       printLodVersion(version, writer);
/*    */     }
/* 31 */     closeFile(writer);
/*    */   }
/*    */   
/*    */   private static void printFloatList(float[] data, PrintWriter writer, float scale) {
/* 35 */     writer.println(data.length);
/* 36 */     writer.print(data[0] * scale);
/* 37 */     for (int i = 1; i < data.length; i++) {
/* 38 */       writer.print("," + data[i] * scale);
/*    */     }
/* 40 */     writer.println();
/*    */   }
/*    */   
/*    */   private static void printLodVersion(LodModelVersion version, PrintWriter writer) {
/* 44 */     int[] indices = version.getModel().getModelData().getIndices();
/* 45 */     writer.println(version.getLod() + "," + indices.length + "," + version.getErrorMargin());
/*    */     
/* 47 */     writer.print(indices[0]);
/* 48 */     for (int i = 1; i < indices.length; i++) {
/* 49 */       writer.print("," + indices[i]);
/*    */     }
/* 51 */     writer.println();
/*    */   }
/*    */   
/*    */   private static void printIndices(int[] data, PrintWriter writer) {
/* 55 */     writer.println(data.length);
/* 56 */     writer.print(data[0]);
/* 57 */     for (int i = 1; i < data.length; i++) {
/* 58 */       writer.print("," + data[i]);
/*    */     }
/* 60 */     writer.println();
/*    */   }
/*    */   
/*    */   private static PrintWriter openSaveFile(File file) {
/* 64 */     FileWriter fileWriter = null;
/*    */     try {
/* 66 */       fileWriter = new FileWriter(file, false);
/*    */     } catch (Exception e) {
/* 68 */       e.printStackTrace();
/* 69 */       System.err.println("Problem opening file to write!");
/* 70 */       System.exit(-1);
/*    */     }
/* 72 */     BufferedWriter bWriter = new BufferedWriter(fileWriter);
/* 73 */     return new PrintWriter(bWriter);
/*    */   }
/*    */   
/*    */   private static void closeFile(PrintWriter file) {
/* 77 */     file.close();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\backend\ModelFileExporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */