/*    */ package backend;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import blueprints.StaticBlueprint;
/*    */ import epicRenderEngine.Loader;
/*    */ import mainApp.Configs;
/*    */ import texture.ModelTexture;
/*    */ import toolbox.ModelData;
/*    */ 
/*    */ public class Model
/*    */ {
/*    */   private ModelData modelData;
/*    */   private StaticBlueprint blueprint;
/*    */   
/*    */   public Model(ModelData model)
/*    */   {
/* 17 */     if (MasterModel.textureFile == null) {
/* 18 */       this.blueprint = new StaticBlueprint(Configs.DEFAULT_TEXTURE);
/*    */     } else {
/* 20 */       this.blueprint = new StaticBlueprint(new ModelTexture(MasterModel.textureFile));
/*    */     }
/* 22 */     this.modelData = model;
/* 23 */     Loader.requestRawModelLoad(this);
/*    */   }
/*    */   
/*    */   public void setModelData(ModelData model) {
/* 27 */     this.modelData = model;
/* 28 */     Loader.requestRawModelLoad(this);
/*    */   }
/*    */   
/*    */   public void setRawModel(RawModel model) {
/* 32 */     this.blueprint.setRawModel(model);
/*    */   }
/*    */   
/*    */   public StaticBlueprint getBlueprint() {
/* 36 */     return this.blueprint;
/*    */   }
/*    */   
/*    */   public ModelData getModelData() {
/* 40 */     return this.modelData;
/*    */   }
/*    */   
/*    */   public int getTriangleCount() {
/* 44 */     return this.modelData.getIndices().length / 3;
/*    */   }
/*    */   
/*    */   public int getIndexCount() {
/* 48 */     return this.modelData.getIndices().length;
/*    */   }
/*    */   
/*    */   public int getVertexCount() {
/* 52 */     return this.modelData.getVertices().length / 3;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\backend\Model.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */