/*    */ package backend;
/*    */ 
/*    */ import errorMetricLOD.MeshSimplifier;
/*    */ import toolbox.ModelData;
/*    */ 
/*    */ 
/*    */ public class LodModelVersion
/*    */ {
/*    */   private Model original;
/*    */   private int lod;
/* 11 */   private float errorMargin = 0.2F;
/*    */   private Model model;
/*    */   
/*    */   public LodModelVersion(int lod, Model original) {
/* 15 */     this.lod = lod;
/* 16 */     this.original = original;
/*    */   }
/*    */   
/*    */   public LodModelVersion(int lod, Model original, ModelData modelData, float errorMargin) {
/* 20 */     this.lod = lod;
/* 21 */     this.original = original;
/* 22 */     this.model = new Model(modelData);
/* 23 */     this.errorMargin = errorMargin;
/*    */   }
/*    */   
/*    */   public int getLod() {
/* 27 */     return this.lod;
/*    */   }
/*    */   
/*    */   public void calculateSimplifiedVersion() {
/* 31 */     ModelData data = MeshSimplifier.simplifyModelData(this.original.getModelData(), this.errorMargin);
/* 32 */     if (this.model != null) {
/* 33 */       this.model.setModelData(data);
/*    */     } else {
/* 35 */       this.model = new Model(data);
/*    */     }
/*    */   }
/*    */   
/*    */   public float getDistance() {
/* 40 */     return (float)(50.0D * Math.pow(1.2999999523162842D, this.lod - 1));
/*    */   }
/*    */   
/*    */   public void setLod(int lod) {
/* 44 */     this.lod = lod;
/*    */   }
/*    */   
/*    */   public float getErrorMargin() {
/* 48 */     return this.errorMargin;
/*    */   }
/*    */   
/*    */   public void setErrorMargin(float errorMargin) {
/* 52 */     this.errorMargin = errorMargin;
/*    */   }
/*    */   
/*    */   public int getTriangleCount() {
/* 56 */     if (this.model != null) {
/* 57 */       return this.model.getTriangleCount();
/*    */     }
/* 59 */     return 0;
/*    */   }
/*    */   
/*    */   public Model getModel()
/*    */   {
/* 64 */     return this.model;
/*    */   }
/*    */   
/*    */   public void setModel(Model model) {
/* 68 */     this.model = model;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\backend\LodModelVersion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */