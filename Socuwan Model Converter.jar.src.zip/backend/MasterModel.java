/*     */ package backend;
/*     */ 
/*     */ import blueprints.StaticBlueprint;
/*     */ import instances.StaticEntity;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ public class MasterModel
/*     */ {
/*     */   private static final int MAX_LOD = 10;
/*     */   private Model originalModel;
/*     */   private File outputFile;
/*  15 */   private List<LodModelVersion> simplifiedModels = new ArrayList();
/*  16 */   private float scale = 1.0F;
/*     */   public static File textureFile;
/*     */   private StaticEntity entity;
/*     */   
/*     */   public MasterModel(File output, Model original, List<LodModelVersion> versions)
/*     */   {
/*  22 */     this.originalModel = original;
/*  23 */     textureFile = null;
/*  24 */     this.simplifiedModels = versions;
/*  25 */     this.outputFile = output;
/*  26 */     this.entity = new StaticEntity(this.originalModel.getBlueprint(), 0, 400.0F, 0.0F, 400.0F, 0.0F, 0.0F, 0.0F, this.scale);
/*     */   }
/*     */   
/*     */   public void setTextureFile(File texture) {
/*  30 */     textureFile = texture;
/*  31 */     this.originalModel.getBlueprint().getTexture().setNewTextureFile(texture);
/*  32 */     for (LodModelVersion version : this.simplifiedModels) {
/*  33 */       version.getModel().getBlueprint().getTexture().setNewTextureFile(texture);
/*     */     }
/*     */   }
/*     */   
/*     */   public File getOutputFile() {
/*  38 */     return this.outputFile;
/*     */   }
/*     */   
/*     */   public Integer[] getPossibleLODS() {
/*  42 */     List<Integer> currentLods = new ArrayList();
/*  43 */     for (LodModelVersion version : this.simplifiedModels) {
/*  44 */       currentLods.add(Integer.valueOf(version.getLod()));
/*     */     }
/*  46 */     Integer[] possibleValues = new Integer[10 - currentLods.size()];
/*  47 */     int pointer = 0;
/*  48 */     for (int i = 1; i <= 10; i++) {
/*  49 */       if (!currentLods.contains(Integer.valueOf(i))) {
/*  50 */         possibleValues[(pointer++)] = Integer.valueOf(i);
/*     */       }
/*     */     }
/*  53 */     return possibleValues;
/*     */   }
/*     */   
/*     */   public Model getOriginal() {
/*  57 */     return this.originalModel;
/*     */   }
/*     */   
/*     */   public StaticEntity getEntity() {
/*  61 */     return this.entity;
/*     */   }
/*     */   
/*     */   public void setLOD(int lod) {
/*  65 */     Model modelToUse = this.originalModel;
/*  66 */     int selectedModelLOD = 0;
/*  67 */     for (LodModelVersion version : this.simplifiedModels) {
/*  68 */       if ((version.getLod() <= lod) && 
/*  69 */         (version.getLod() > selectedModelLOD)) {
/*  70 */         modelToUse = version.getModel();
/*  71 */         selectedModelLOD = version.getLod();
/*     */       }
/*     */     }
/*     */     
/*  75 */     this.entity.setBlueprint(modelToUse.getBlueprint());
/*     */   }
/*     */   
/*     */   public void addLodVersion(LodModelVersion lodVersion) {
/*  79 */     int pointer = 0;
/*  80 */     for (LodModelVersion version : this.simplifiedModels) {
/*  81 */       if (version.getLod() > lodVersion.getLod()) {
/*     */         break;
/*     */       }
/*  84 */       pointer++;
/*     */     }
/*  86 */     this.simplifiedModels.add(pointer, lodVersion);
/*     */   }
/*     */   
/*     */   public void resortList() {
/*  90 */     List<LodModelVersion> oldList = this.simplifiedModels;
/*  91 */     this.simplifiedModels = new ArrayList();
/*  92 */     for (LodModelVersion version : oldList) {
/*  93 */       addLodVersion(version);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getScale() {
/*  98 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setScale(float scale) {
/* 102 */     this.scale = scale;
/* 103 */     this.entity.setScale(scale);
/*     */   }
/*     */   
/*     */   public void removeLodVersion(LodModelVersion lodVersion) {
/* 107 */     this.simplifiedModels.remove(lodVersion);
/*     */   }
/*     */   
/*     */   public int getTriangleCount() {
/* 111 */     return this.originalModel.getTriangleCount();
/*     */   }
/*     */   
/*     */   public int getVertexCount() {
/* 115 */     return this.originalModel.getVertexCount();
/*     */   }
/*     */   
/*     */   public int getNumberOfLods() {
/* 119 */     return this.simplifiedModels.size();
/*     */   }
/*     */   
/*     */   public List<LodModelVersion> getSimplifiedVersions() {
/* 123 */     return this.simplifiedModels;
/*     */   }
/*     */   
/*     */   public void export() {
/* 127 */     ModelFileExporter.exportModel(this);
/*     */   }
/*     */   
/*     */   public int getTotalIndicesCount() {
/* 131 */     int total = this.originalModel.getIndexCount();
/* 132 */     for (LodModelVersion version : this.simplifiedModels) {
/* 133 */       total += version.getModel().getIndexCount();
/*     */     }
/* 135 */     return total;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\backend\MasterModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */