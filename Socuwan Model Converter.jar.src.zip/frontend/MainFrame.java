/*     */ package frontend;
/*     */ 
/*     */ import backend.LodModelVersion;
/*     */ import backend.MasterModel;
/*     */ import backend.WorkSpace;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import lodListPanel.LodListPanel;
/*     */ import lodSettingsPanel.LodSettingsPanel;
/*     */ import mainApp.Camera;
/*     */ import mainSettingsPanel.MainSettingsPanel;
/*     */ 
/*     */ public class MainFrame
/*     */ {
/*     */   private static final String TITLE = "Socuwan Model Converter";
/*     */   private static final int WIDTH = 1280;
/*     */   private static final int HEIGHT = 720;
/*     */   public static final String FONT_NAME = "Segoe UI";
/*  27 */   public static final Font VSMALL_FONT = new Font("Segoe UI", 0, 11);
/*  28 */   public static final Font SMALL_FONT = new Font("Segoe UI", 1, 13);
/*  29 */   public static final Font MEDIUM_FONT = new Font("Segoe UI", 1, 20);
/*     */   
/*     */   private static final int PANELS_HEIGHT = 660;
/*     */   
/*     */   private static final int LIST_PANEL_HEIGHT = 500;
/*     */   private static final int LOD_PANEL_HEIGHT = 150;
/*     */   private static final int MAIN_PANEL_WIDTH = 810;
/*     */   private static final int LIST_PANEL_WIDTH = 450;
/*     */   private static final int LOD_PANEL_WIDTH = 450;
/*     */   private JFrame frame;
/*     */   private MainSettingsPanel mainSettingsPanel;
/*     */   private LodListPanel lodListPanel;
/*     */   private LodSettingsPanel lodSettingsPanel;
/*     */   private Camera camera;
/*     */   private MasterModel masterModel;
/*     */   
/*     */   public MainFrame(final WorkSpace workspace, Camera camera)
/*     */   {
/*  47 */     this.camera = camera;
/*  48 */     initFrame();
/*  49 */     setIcon();
/*  50 */     initMenuBar(workspace);
/*  51 */     initPanels(camera);
/*  52 */     this.frame.setVisible(true);
/*  53 */     this.frame.addWindowListener(new java.awt.event.WindowListener()
/*     */     {
/*     */       public void windowActivated(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowClosed(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowClosing(WindowEvent arg0)
/*     */       {
/*  65 */         workspace.save();
/*  66 */         mainApp.MainApp.close = true;
/*     */         try {
/*  68 */           Thread.sleep(300L);
/*     */         } catch (InterruptedException e) {
/*  70 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowDeactivated(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowDeiconified(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void windowIconified(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void windowOpened(WindowEvent arg0) {}
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   public Canvas getCanvas()
/*     */   {
/*  93 */     return this.mainSettingsPanel.getCanvas();
/*     */   }
/*     */   
/*     */   public void setNewMasterModel(MasterModel model) {
/*  97 */     this.masterModel = model;
/*  98 */     this.camera.setMasterModel(model);
/*  99 */     this.mainSettingsPanel.setMasterModel(model);
/* 100 */     this.lodListPanel.setMasterModel(model);
/* 101 */     this.lodSettingsPanel.clear();
/* 102 */     this.frame.validate();
/* 103 */     this.frame.repaint();
/*     */   }
/*     */   
/*     */   public MasterModel getMasterModel() {
/* 107 */     return this.masterModel;
/*     */   }
/*     */   
/*     */   public void updateLODCount() {
/* 111 */     this.mainSettingsPanel.updateLODCount();
/*     */   }
/*     */   
/*     */   public void notifyLODOrderChange() {
/* 115 */     this.lodListPanel.reSort();
/*     */   }
/*     */   
/*     */   public void updateIndexCount() {
/* 119 */     this.mainSettingsPanel.updateIndexCount();
/*     */   }
/*     */   
/*     */   public void notifyAddLOD(LodModelVersion version) {
/* 123 */     this.lodListPanel.addNewLOD(version);
/*     */   }
/*     */   
/*     */   private void initFrame() {
/* 127 */     this.frame = new JFrame("Socuwan Model Converter");
/* 128 */     this.frame.setDefaultCloseOperation(3);
/* 129 */     this.frame.setSize(1280, 720);
/* 130 */     this.frame.setResizable(false);
/* 131 */     this.frame.setLocationRelativeTo(null);
/* 132 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void initPanels(Camera camera) {
/* 136 */     this.mainSettingsPanel = new MainSettingsPanel(810, 660, this, camera);
/* 137 */     this.frame.add(this.mainSettingsPanel, getGC(0, 0, 2));
/* 138 */     this.lodSettingsPanel = new LodSettingsPanel(450, 150, this);
/* 139 */     this.frame.add(this.lodSettingsPanel, getGC(1, 1, 1));
/* 140 */     this.lodListPanel = new LodListPanel(450, 500, this, this.lodSettingsPanel);
/* 141 */     this.frame.add(this.lodListPanel, getGC(1, 0, 1));
/*     */   }
/*     */   
/*     */   private void setIcon()
/*     */   {
/* 146 */     BufferedImage myPicture = null;
/*     */     try {
/* 148 */       myPicture = javax.imageio.ImageIO.read(MainFrame.class.getResourceAsStream("/res/defaultIcon.png"));
/* 149 */       ImageIcon original = new ImageIcon(myPicture);
/* 150 */       this.frame.setIconImage(original.getImage());
/*     */     } catch (IOException e) {
/* 152 */       System.err.println("Couldn't change app icon!");
/*     */     }
/*     */   }
/*     */   
/*     */   private void initMenuBar(WorkSpace workspace) {
/* 157 */     MenuBar menuBar = new MenuBar(workspace, this);
/* 158 */     this.frame.setJMenuBar(menuBar);
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y, int gridSizeY) {
/* 162 */     GridBagConstraints gc = new GridBagConstraints();
/* 163 */     gc.gridx = x;
/* 164 */     gc.gridy = y;
/* 165 */     gc.weightx = 1.0D;
/* 166 */     gc.weighty = 1.0D;
/* 167 */     gc.gridheight = gridSizeY;
/* 168 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\frontend\MainFrame.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */