/*     */ package frontend;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ public class Slider extends JPanel
/*     */ {
/*     */   private float max;
/*     */   private float start;
/*     */   private boolean linear;
/*     */   private JFloatSlider slider;
/*     */   
/*     */   public Slider(String name, float current, float start, float max, boolean linear)
/*     */   {
/*  20 */     this.max = max;
/*  21 */     this.start = start;
/*  22 */     this.linear = linear;
/*  23 */     add(createSlider(name, current));
/*     */   }
/*     */   
/*     */   public void addSliderListener(ChangeListener listener) {
/*  27 */     this.slider.addChangeListener(listener);
/*     */   }
/*     */   
/*     */   private JPanel createSlider(String name, float start) {
/*  31 */     JPanel panelSlider = new JPanel();
/*  32 */     panelSlider.setLayout(new GridBagLayout());
/*  33 */     GridBagConstraints gc = new GridBagConstraints();
/*  34 */     gc.fill = 1;
/*  35 */     gc.gridx = 0;
/*  36 */     gc.gridy = 0;
/*  37 */     gc.weightx = 1.0D;
/*  38 */     gc.weighty = 1.0D;
/*     */     
/*  40 */     JLabel nameLabel = new JLabel(name);
/*  41 */     nameLabel.setFont(MainFrame.SMALL_FONT);
/*  42 */     nameLabel.setPreferredSize(new Dimension(60, 20));
/*  43 */     panelSlider.add(nameLabel, gc);
/*  44 */     gc.weightx = 1.0D;
/*  45 */     gc.gridx = 1;
/*  46 */     final JLabel valueReading = new JLabel();
/*  47 */     valueReading.setPreferredSize(new Dimension(50, 20));
/*  48 */     valueReading.setFont(MainFrame.SMALL_FONT);
/*  49 */     this.slider = new JFloatSlider(0, 0.0F, 1.0F, reverseConvertValue(start));
/*  50 */     valueReading.setText(limitChars(Float.toString(convertScaleValue(this.slider.getActualValue())), 5));
/*     */     
/*     */ 
/*  53 */     this.slider.addChangeListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  57 */         valueReading.setText(Slider.this.limitChars(Float.toString(Slider.access$100(Slider.this, Slider.this.slider.getActualValue())), 5));
/*     */       }
/*     */       
/*  60 */     });
/*  61 */     panelSlider.add(this.slider, gc);
/*     */     
/*  63 */     this.slider.setPreferredSize(new Dimension(250, 20));
/*     */     
/*  65 */     gc.gridx = 2;
/*  66 */     gc.weightx = 1.0D;
/*  67 */     panelSlider.add(valueReading, gc);
/*  68 */     return panelSlider;
/*     */   }
/*     */   
/*     */   private String limitChars(String original, int limit)
/*     */   {
/*  73 */     if (original.length() <= limit) {
/*  74 */       return original;
/*     */     }
/*  76 */     return original.substring(0, 5);
/*     */   }
/*     */   
/*     */ 
/*     */   public float getSliderReading()
/*     */   {
/*  82 */     return convertScaleValue(this.slider.getActualValue());
/*     */   }
/*     */   
/*     */   private float convertScaleValue(float sliderValue) {
/*  86 */     float value = sliderValue;
/*  87 */     if (!this.linear) {
/*  88 */       value *= sliderValue;
/*  89 */       value *= sliderValue;
/*     */     }
/*  91 */     value *= (this.max - this.start);
/*  92 */     return value + this.start;
/*     */   }
/*     */   
/*     */   private float reverseConvertValue(float reflectValue) {
/*  96 */     reflectValue -= this.start;
/*  97 */     float value = reflectValue / (this.max - this.start);
/*  98 */     if (this.linear) {
/*  99 */       return value;
/*     */     }
/* 101 */     return (float)Math.cbrt(value);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\frontend\Slider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */