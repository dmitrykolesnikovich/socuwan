/*     */ package frontend;
/*     */ 
/*     */ import backend.WorkSpace;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelChooseScreen
/*     */ {
/*     */   private static final int MAIN_FONT_SIZE = 15;
/*     */   private static final int LIST_FONT_SIZE = 13;
/*     */   private static final String MESSAGE = "Choose a model file!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JFrame frame;
/*     */   private WorkSpace workspace;
/*     */   private MainFrame mainFrame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   
/*     */   public ModelChooseScreen(List<File> files, WorkSpace workspace, MainFrame mainFrame)
/*     */   {
/*  35 */     this.workspace = workspace;
/*  36 */     this.mainFrame = mainFrame;
/*  37 */     setUpFrame();
/*  38 */     addLabel();
/*  39 */     addFileList(files);
/*  40 */     addButton();
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  44 */     this.frame = new JFrame();
/*  45 */     this.frame.setVisible(true);
/*  46 */     this.frame.setSize(300, 300);
/*  47 */     this.frame.setResizable(false);
/*  48 */     this.frame.setLocationRelativeTo(null);
/*  49 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  53 */     GridBagConstraints gc = new GridBagConstraints();
/*  54 */     gc.gridx = 0;
/*  55 */     gc.gridy = 1;
/*  56 */     gc.weightx = 1.0D;
/*  57 */     gc.weighty = 1.0D;
/*     */     
/*  59 */     FileInList[] data = getAllFilesInList(files);
/*  60 */     this.list = new JList(data);
/*  61 */     this.list.setFont(new Font("Segoe UI", 1, 13));
/*  62 */     this.list.setSelectionMode(1);
/*  63 */     this.list.setLayoutOrientation(0);
/*  64 */     this.list.setVisibleRowCount(-1);
/*  65 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  66 */     listScroller.setPreferredSize(new Dimension(250, 180));
/*  67 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  71 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  72 */     for (int i = 0; i < listedFiles.length; i++) {
/*  73 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  75 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  79 */     JLabel text = new JLabel("Choose a model file!");
/*  80 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  81 */     GridBagConstraints gc = new GridBagConstraints();
/*  82 */     gc.gridx = 0;
/*  83 */     gc.gridy = 0;
/*  84 */     gc.weightx = 1.0D;
/*  85 */     gc.weighty = 0.4D;
/*  86 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/*  90 */     this.confirm = new JButton("Open");
/*  91 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/*  92 */     GridBagConstraints gc = new GridBagConstraints();
/*  93 */     gc.gridx = 0;
/*  94 */     gc.gridy = 2;
/*  95 */     gc.weightx = 1.0D;
/*  96 */     gc.weighty = 0.4D;
/*  97 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 101 */         if (!ModelChooseScreen.this.list.isSelectionEmpty()) {
/* 102 */           File chosen = ((FileInList)ModelChooseScreen.this.list.getSelectedValue()).getFile();
/*     */           try {
/* 104 */             ModelChooseScreen.this.workspace.open(chosen);
/* 105 */             ModelChooseScreen.this.frame.setVisible(false);
/* 106 */             ModelChooseScreen.this.mainFrame.setNewMasterModel(ModelChooseScreen.this.workspace.getCurrentMasterModel());
/*     */           } catch (Exception e) {
/* 108 */             ModelChooseScreen.this.frame.setVisible(false);
/* 109 */             e.printStackTrace();
/* 110 */             System.err.println("INVALID FILE FORMAT!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 116 */     });
/* 117 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\frontend\ModelChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */