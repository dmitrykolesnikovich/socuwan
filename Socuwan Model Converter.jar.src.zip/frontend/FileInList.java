/*    */ package frontend;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ public class FileInList
/*    */ {
/*    */   private File file;
/*    */   private String fileName;
/*    */   
/*    */   public FileInList(File file) {
/* 11 */     this.file = file;
/* 12 */     this.fileName = file.getName().split("\\.")[0];
/*    */   }
/*    */   
/*    */   public String toString() {
/* 16 */     return this.fileName;
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 20 */     return this.file;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\frontend\FileInList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */