/*    */ package frontend;
/*    */ 
/*    */ import backend.WorkSpace;
/*    */ import java.awt.Font;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JMenuBar;
/*    */ import javax.swing.JMenuItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuBar
/*    */   extends JMenuBar
/*    */ {
/*    */   private WorkSpace workspace;
/*    */   private MainFrame mainFrame;
/*    */   
/*    */   public MenuBar(WorkSpace workspace, MainFrame mainFrame)
/*    */   {
/* 21 */     this.workspace = workspace;
/* 22 */     this.mainFrame = mainFrame;
/* 23 */     createMenu(mainFrame);
/*    */   }
/*    */   
/*    */   private void createMenu(MainFrame mainFrame) {
/* 27 */     JMenu file = new JMenu("File");
/* 28 */     add(file);
/* 29 */     JMenuItem newModel = new JMenuItem("New Model File");
/* 30 */     JMenuItem openFile = new JMenuItem("Edit Model File");
/* 31 */     JMenuItem save = new JMenuItem("Save");
/* 32 */     file.add(newModel);
/* 33 */     file.add(openFile);
/* 34 */     file.add(save);
/* 35 */     addOpenFileFunction(openFile, mainFrame);
/* 36 */     addNewFileFunction(newModel);
/* 37 */     addSaveFunction(save);
/* 38 */     file.setFont(new Font("Segoe UI", 1, 12));
/* 39 */     newModel.setFont(new Font("Segoe UI", 1, 12));
/* 40 */     openFile.setFont(new Font("Segoe UI", 1, 12));
/* 41 */     save.setFont(new Font("Segoe UI", 1, 12));
/*    */   }
/*    */   
/*    */ 
/*    */   private void addOpenFileFunction(JMenuItem open, final MainFrame mainFrame)
/*    */   {
/* 47 */     open.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/* 51 */         new ModelChooseScreen(MenuBar.this.workspace.listMasterModelFiles(), MenuBar.this.workspace, mainFrame);
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */ 
/*    */   private void addNewFileFunction(JMenuItem newFileOption)
/*    */   {
/* 59 */     newFileOption.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e) {
/* 62 */         new OBJFileChooseScreen(MenuBar.this.workspace.listOBJs(), MenuBar.this.workspace, MenuBar.this.mainFrame);
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   private void addSaveFunction(JMenuItem saveOption)
/*    */   {
/* 69 */     saveOption.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e) {
/* 72 */         MenuBar.this.workspace.save();
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\frontend\MenuBar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */