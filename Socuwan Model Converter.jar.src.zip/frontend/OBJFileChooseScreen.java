/*     */ package frontend;
/*     */ 
/*     */ import backend.WorkSpace;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OBJFileChooseScreen
/*     */ {
/*     */   private static final int MAIN_FONT_SIZE = 15;
/*     */   private static final int LIST_FONT_SIZE = 13;
/*     */   private static final String MESSAGE = "Choose an OBJ file!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JFrame frame;
/*     */   private WorkSpace workspace;
/*     */   private MainFrame mainFrame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   
/*     */   public OBJFileChooseScreen(List<File> files, WorkSpace workspace, MainFrame mainFrame)
/*     */   {
/*  36 */     this.workspace = workspace;
/*  37 */     this.mainFrame = mainFrame;
/*  38 */     setUpFrame();
/*  39 */     addLabel();
/*  40 */     addFileList(files);
/*  41 */     addButton();
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  45 */     this.frame = new JFrame();
/*  46 */     this.frame.setVisible(true);
/*  47 */     this.frame.setSize(300, 300);
/*  48 */     this.frame.setResizable(false);
/*  49 */     this.frame.setLocationRelativeTo(null);
/*  50 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  54 */     GridBagConstraints gc = new GridBagConstraints();
/*  55 */     gc.gridx = 0;
/*  56 */     gc.gridy = 1;
/*  57 */     gc.weightx = 1.0D;
/*  58 */     gc.weighty = 1.0D;
/*     */     
/*  60 */     FileInList[] data = getAllFilesInList(files);
/*  61 */     this.list = new JList(data);
/*  62 */     this.list.setFont(new Font("Segoe UI", 1, 13));
/*  63 */     this.list.setSelectionMode(1);
/*  64 */     this.list.setLayoutOrientation(0);
/*  65 */     this.list.setVisibleRowCount(-1);
/*  66 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  67 */     listScroller.setPreferredSize(new Dimension(250, 180));
/*  68 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  72 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  73 */     for (int i = 0; i < listedFiles.length; i++) {
/*  74 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  76 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  80 */     JLabel text = new JLabel("Choose an OBJ file!");
/*  81 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  82 */     GridBagConstraints gc = new GridBagConstraints();
/*  83 */     gc.gridx = 0;
/*  84 */     gc.gridy = 0;
/*  85 */     gc.weightx = 1.0D;
/*  86 */     gc.weighty = 0.4D;
/*  87 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/*  91 */     this.confirm = new JButton("Open");
/*  92 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/*  93 */     GridBagConstraints gc = new GridBagConstraints();
/*  94 */     gc.gridx = 0;
/*  95 */     gc.gridy = 2;
/*  96 */     gc.weightx = 1.0D;
/*  97 */     gc.weighty = 0.4D;
/*  98 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 102 */         if (!OBJFileChooseScreen.this.list.isSelectionEmpty()) {
/* 103 */           File chosen = ((FileInList)OBJFileChooseScreen.this.list.getSelectedValue()).getFile();
/*     */           try {
/* 105 */             OBJFileChooseScreen.this.workspace.createNewMasterModel(chosen);
/* 106 */             OBJFileChooseScreen.this.frame.setVisible(false);
/* 107 */             OBJFileChooseScreen.this.mainFrame.setNewMasterModel(OBJFileChooseScreen.this.workspace.getCurrentMasterModel());
/*     */           } catch (Exception e) {
/* 109 */             OBJFileChooseScreen.this.frame.setVisible(false);
/* 110 */             e.printStackTrace();
/* 111 */             System.err.println("INVALID FILE FORMAT!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 117 */     });
/* 118 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\frontend\OBJFileChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */