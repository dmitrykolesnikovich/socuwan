/*    */ package materials;
/*    */ 
/*    */ import toolbox.Colour;
/*    */ 
/*    */ public enum Metal
/*    */   implements Material
/*    */ {
/*  8 */   BRASS("Brass", Tier.TIER_1, new Colour(0.643F, 0.486F, 0.275F)), 
/*  9 */   BRONZE("Bronze", Tier.TIER_2, new Colour(0.553F, 0.247F, 0.094F)), 
/* 10 */   IRON("Iron", Tier.TIER_3, new Colour(0.305F, 0.208F, 0.137F)), 
/* 11 */   STEEL("Steel", Tier.TIER_4, new Colour(0.5F, 0.5F, 0.5F)), 
/* 12 */   ORKIUM("Orkium", Tier.TIER_5, new Colour(0.302F, 0.412F, 0.247F)), 
/* 13 */   SILVER("Silver", Tier.TIER_6, new Colour(0.7F, 0.7F, 0.7F)), 
/* 14 */   GOLD("Gold", Tier.TIER_7, new Colour(0.875F, 0.592F, 0.008F)), 
/* 15 */   DAEMONITE("Daemonite", Tier.TIER_8, new Colour(79.0F, 6.0F, 40.0F, true)), 
/* 16 */   SOULITE("Soulite", Tier.TIER_9, new Colour(0.06F, 0.06F, 0.06F)), 
/* 17 */   MOLTEN_SPIRIT("Spirite", Tier.TIER_10, new Colour(1.0F, 1.0F, 1.0F));
/*    */   
/*    */   private String name;
/*    */   private Tier tier;
/*    */   private Colour colour;
/*    */   
/*    */   private Metal(String name, Tier tier, Colour colour)
/*    */   {
/* 25 */     this.tier = tier;
/* 26 */     this.name = name;
/* 27 */     this.colour = colour;
/*    */   }
/*    */   
/*    */   public Tier getTier()
/*    */   {
/* 32 */     return this.tier;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */   public Colour getColour() {
/* 41 */     return this.colour;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\materials\Metal.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */