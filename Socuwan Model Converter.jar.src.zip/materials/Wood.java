/*    */ package materials;
/*    */ 
/*    */ import toolbox.Colour;
/*    */ 
/*    */ public enum Wood implements Material
/*    */ {
/*  7 */   OAK("Oak", Tier.TIER_1, new Colour(0.419F, 0.227F, 0.039F)), 
/*  8 */   WILLOW("Willow", Tier.TIER_2, new Colour(0.769F, 0.722F, 0.541F)), 
/*  9 */   YEW("Yew", Tier.TIER_3, new Colour(0.302F, 0.094F, 0.008F)), 
/* 10 */   MAPLE("Maple", Tier.TIER_4, new Colour(0.588F, 0.216F, 0.039F)), 
/* 11 */   CEDAR("Cedar", Tier.TIER_5, new Colour(0.839F, 0.486F, 0.255F)), 
/* 12 */   SPRUCE("Spruce", Tier.TIER_6, new Colour(0.663F, 0.42F, 0.204F)), 
/* 13 */   BAUXWOOD("Bauxwood", Tier.TIER_7, new Colour(0.369F, 0.42F, 0.247F)), 
/* 14 */   MAHOGANY("Mahogany", Tier.TIER_8, new Colour(0.337F, 0.122F, 0.212F)), 
/* 15 */   BLACKWOOD("Blackwood", Tier.TIER_9, new Colour(0.161F, 0.161F, 0.161F)), 
/* 16 */   SPIRITWOOD("Spiritwood", Tier.TIER_10, new Colour(1.0F, 1.0F, 1.0F));
/*    */   
/*    */   private String name;
/*    */   private Tier tier;
/*    */   private Colour colour;
/*    */   
/*    */   private Wood(String name, Tier tier, Colour colour) {
/* 23 */     this.tier = tier;
/* 24 */     this.name = name;
/* 25 */     this.colour = colour;
/*    */   }
/*    */   
/*    */   public Tier getTier()
/*    */   {
/* 30 */     return this.tier;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 35 */     return this.name;
/*    */   }
/*    */   
/*    */   public Colour getColour() {
/* 39 */     return this.colour;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\materials\Wood.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */