/*    */ package materials;
/*    */ 
/*    */ public enum Tier
/*    */ {
/*  5 */   NO_TIER(0, "General", new float[] { 1.0F, 1.0F, 1.0F }), 
/*  6 */   TIER_1(1, "Basic", new float[] { 0.737F, 0.553F, 0.42F }), 
/*  7 */   TIER_2(2, "Beginner", new float[] { 0.694F, 0.667F, 0.322F }), 
/*  8 */   TIER_3(3, "Regular", new float[] { 0.894F, 0.78F, 0.122F }), 
/*  9 */   TIER_4(4, "Amatuer", new float[] { 0.894F, 0.451F, 0.122F }), 
/* 10 */   TIER_5(5, "Pro", new float[] { 0.886F, 0.29F, 0.039F }), 
/* 11 */   TIER_6(6, "Expert", new float[] { 0.976F, 0.043F, 0.043F }), 
/* 12 */   TIER_7(7, "Master", new float[] { 0.694F, 0.003F, 0.02F }), 
/* 13 */   TIER_8(8, "Legendary", new float[] { 0.588F, 0.003F, 0.576F }), 
/* 14 */   TIER_9(9, "Epic", new float[] { 0.094F, 0.063F, 0.737F }), 
/* 15 */   TIER_10(10, "Spirit", new float[] { 0.11F, 0.984F, 0.855F });
/*    */   
/*    */   private int tierNumber;
/*    */   private String name;
/*    */   private float[] colour;
/*    */   
/*    */   private Tier(int tierNumber, String name, float[] colour) {
/* 22 */     this.name = name;
/* 23 */     this.colour = colour;
/* 24 */     this.tierNumber = tierNumber;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 28 */     return this.name;
/*    */   }
/*    */   
/*    */   public float[] getColour() {
/* 32 */     return this.colour;
/*    */   }
/*    */   
/*    */   public int getTierNumber() {
/* 36 */     return this.tierNumber;
/*    */   }
/*    */   
/*    */   public static Tier getTier(byte tierNumber) throws Exception {
/* 40 */     if (tierNumber > 0) {
/* 41 */       return valueOf("TIER_" + tierNumber);
/*    */     }
/* 43 */     return NO_TIER;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\materials\Tier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */