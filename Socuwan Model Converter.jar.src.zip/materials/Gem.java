/*    */ package materials;
/*    */ 
/*    */ import toolbox.Colour;
/*    */ 
/*    */ public enum Gem implements Material
/*    */ {
/*  7 */   QUARTZ("Quartz", Tier.TIER_1, new Colour(0.886F, 0.796F, 0.278F)), 
/*  8 */   AMETHYST("Amethyst", Tier.TIER_2, new Colour(0.53F, 0.4157F, 0.643F)), 
/*  9 */   JADE("Jade", Tier.TIER_3, new Colour(0.341F, 0.718F, 0.569F)), 
/* 10 */   SAPPHIRE("Sapphire", Tier.TIER_4, new Colour(0.149F, 0.26F, 0.73F)), 
/* 11 */   EMERALD("Emerald", Tier.TIER_5, new Colour(0.137F, 0.745F, 0.122F)), 
/* 12 */   RUBY("Ruby", Tier.TIER_6, new Colour(0.616F, 0.008F, 0.024F)), 
/* 13 */   DIAMOND("Diamond", Tier.TIER_7, new Colour(0.063F, 0.863F, 0.929F)), 
/* 14 */   BLOOD_DIAMOND("Blood Diamond", Tier.TIER_8, new Colour(0.51F, 0.008F, 0.373F)), 
/* 15 */   SOUL_STONE("Soul Stone", Tier.TIER_9, new Colour(0.106F, 0.106F, 0.106F)), 
/* 16 */   SPIRIT_STONE("Spirit Stone", Tier.TIER_10, new Colour(1.0F, 1.0F, 1.0F));
/*    */   
/*    */   private Tier tier;
/*    */   private String name;
/*    */   private Colour colour;
/*    */   
/*    */   private Gem(String name, Tier tier, Colour colour) {
/* 23 */     this.tier = tier;
/* 24 */     this.name = name;
/* 25 */     this.colour = colour;
/*    */   }
/*    */   
/*    */   public Tier getTier()
/*    */   {
/* 30 */     return this.tier;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getName()
/*    */   {
/* 36 */     return this.name;
/*    */   }
/*    */   
/*    */   public Colour getColour() {
/* 40 */     return this.colour;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Model Converter.jar!\materials\Gem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */