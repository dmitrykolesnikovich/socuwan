/*     */ package lightComponent;
/*     */ 
/*     */ import componentArchitecture.ComponentListPanel;
/*     */ import componentArchitecture.ComponentPanel;
/*     */ import entitiesInterfaces.Light;
/*     */ import frontend.Slider;
/*     */ import frontend.VectorPanel;
/*     */ import frontend.VectorPanelListener;
/*     */ import instances.StaticInstance;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import main.MainApp;
/*     */ 
/*     */ public class LightComponentPanel
/*     */   extends ComponentPanel
/*     */ {
/*     */   private JPanel settingsPanel;
/*     */   private LightComponent component;
/*     */   
/*     */   public LightComponentPanel(LightComponent component, ComponentListPanel list)
/*     */   {
/*  25 */     super(component, list);
/*  26 */     this.component = component;
/*  27 */     this.settingsPanel = super.getSettingsPanel();
/*  28 */     this.settingsPanel.setLayout(new GridBagLayout());
/*  29 */     MainApp.lightSphere.showEntity(true);
/*  30 */     setUpColourSliders();
/*  31 */     setUpAttenuationSliders();
/*  32 */     setUpOffset();
/*     */   }
/*     */   
/*     */   private void setUpColourSliders() {
/*  36 */     final Slider redSlider = new Slider("Red", this.component.getLight().getR(), 0.0F, 5.0F, true);
/*  37 */     redSlider.addSliderListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  41 */         LightComponentPanel.this.component.getLight().setR(redSlider.getSliderReading());
/*     */       }
/*  43 */     });
/*  44 */     this.settingsPanel.add(redSlider, getGC(0, 0));
/*  45 */     final Slider greenSlider = new Slider("Green", this.component.getLight().getG(), 0.0F, 5.0F, true);
/*  46 */     greenSlider.addSliderListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  50 */         LightComponentPanel.this.component.getLight().setG(greenSlider.getSliderReading());
/*     */       }
/*  52 */     });
/*  53 */     this.settingsPanel.add(greenSlider, getGC(0, 1));
/*  54 */     final Slider blueSlider = new Slider("Blue", this.component.getLight().getB(), 0.0F, 5.0F, true);
/*  55 */     blueSlider.addSliderListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  59 */         LightComponentPanel.this.component.getLight().setB(blueSlider.getSliderReading());
/*     */       }
/*  61 */     });
/*  62 */     this.settingsPanel.add(blueSlider, getGC(0, 2));
/*     */   }
/*     */   
/*     */   private void setUpAttenuationSliders() {
/*  66 */     final Slider att1Slider = new Slider("Att 1", this.component.getLight().getAttenuation1(), 0.0F, 1.0F, true);
/*     */     
/*  68 */     att1Slider.addSliderListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  72 */         LightComponentPanel.this.component.getLight().setAttenuation1(att1Slider.getSliderReading());
/*     */       }
/*  74 */     });
/*  75 */     this.settingsPanel.add(att1Slider, getGC(0, 3));
/*  76 */     final Slider att2Slider = new Slider("Att 2", this.component.getLight().getAttenuation2(), 0.0F, 0.1F, false);
/*     */     
/*  78 */     att2Slider.addSliderListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  82 */         LightComponentPanel.this.component.getLight().setAttenuation2(att2Slider.getSliderReading());
/*     */       }
/*  84 */     });
/*  85 */     this.settingsPanel.add(att2Slider, getGC(0, 4));
/*  86 */     final Slider att3Slider = new Slider("Att 3", this.component.getLight().getAttenuation3(), 0.0F, 0.1F, false);
/*     */     
/*  88 */     att3Slider.addSliderListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  92 */         LightComponentPanel.this.component.getLight().setAttenuation3(att3Slider.getSliderReading());
/*     */       }
/*  94 */     });
/*  95 */     this.settingsPanel.add(att3Slider, getGC(0, 5));
/*     */   }
/*     */   
/*     */   private void setUpOffset() {
/*  99 */     final VectorPanel vectorPanel = new VectorPanel(this.settingsPanel.getWidth() - 50, 25, "Offset: ", this.component.getOffsetX(), this.component.getOffsetY(), this.component.getOffsetZ());
/*     */     
/* 101 */     vectorPanel.addVectorPanelListener(new VectorPanelListener()
/*     */     {
/*     */       public void doAction() {
/* 104 */         LightComponentPanel.this.component.setOffsetX(vectorPanel.getXValue());
/* 105 */         LightComponentPanel.this.component.setOffsetY(vectorPanel.getYValue());
/* 106 */         LightComponentPanel.this.component.setOffsetZ(vectorPanel.getZValue());
/* 107 */       } });
/* 108 */     this.settingsPanel.add(vectorPanel, getGC(0, 6));
/*     */   }
/*     */   
/*     */   public void cleanUp()
/*     */   {
/* 113 */     MainApp.lightSphere.showEntity(false);
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y) {
/* 117 */     GridBagConstraints gc = new GridBagConstraints();
/* 118 */     gc.fill = 2;
/* 119 */     gc.gridx = x;
/* 120 */     gc.gridy = y;
/* 121 */     gc.weightx = 1.0D;
/* 122 */     gc.weighty = 1.0D;
/* 123 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\lightComponent\LightComponentPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */