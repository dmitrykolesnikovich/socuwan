/*     */ package lightComponent;
/*     */ 
/*     */ import componentArchitecture.Component;
/*     */ import componentArchitecture.ComponentFabricator;
/*     */ import componentArchitecture.ComponentListPanel;
/*     */ import componentArchitecture.ComponentPanel;
/*     */ import componentArchitecture.ComponentType;
/*     */ import entitiesInterfaces.Light;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import instances.StaticInstance;
/*     */ import java.io.PrintWriter;
/*     */ import main.MainApp;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import toolbox.Maths;
/*     */ import toolbox.Transformation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LightComponent
/*     */   extends Component
/*     */ {
/*     */   private Transformation transform;
/*     */   private float offsetX;
/*  27 */   private float offsetY = 19.0F;
/*     */   private float offsetZ;
/*     */   private Light light;
/*     */   
/*     */   public LightComponent(Transformation transform) {
/*  32 */     super(ComponentType.LIGHT_COMPONENT);
/*  33 */     this.light = new Light(transform.getX(), transform.getY(), transform.getZ());
/*  34 */     this.transform = transform;
/*     */   }
/*     */   
/*     */   public LightComponent(Transformation transform, Vector3f offset, Vector3f colour, Vector3f attenuation)
/*     */   {
/*  39 */     super(ComponentType.LIGHT_COMPONENT);
/*     */     
/*  41 */     this.light = new Light(transform.getX(), transform.getY(), transform.getZ(), colour.x, colour.y, colour.z, attenuation.x, attenuation.y, attenuation.z);
/*     */     
/*  43 */     this.transform = transform;
/*  44 */     this.offsetX = offset.x;
/*  45 */     this.offsetY = offset.y;
/*  46 */     this.offsetZ = offset.z;
/*     */   }
/*     */   
/*     */   public void export(PrintWriter writer)
/*     */   {
/*  51 */     writer.println(this.offsetX + ";" + this.offsetY + ";" + this.offsetZ + ";" + this.light.getR() + ";" + this.light.getG() + ";" + this.light.getB() + ";" + this.light.getAttenuation1() + ";" + this.light.getAttenuation2() + ";" + this.light.getAttenuation3());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void update(RenderEngine engine)
/*     */   {
/*  58 */     Vector3f offset = new Vector3f(this.offsetX, this.offsetY, this.offsetZ);
/*  59 */     float scale = this.transform.getScale();
/*  60 */     Vector3f theOffset = Maths.rotateVector(new Vector3f(offset.x * scale, offset.y * scale, offset.z * scale), this.transform.getRotX(), this.transform.getRotY(), this.transform.getRotZ());
/*     */     
/*  62 */     float actualX = this.transform.getX() + theOffset.x;
/*  63 */     float actualY = this.transform.getY() + theOffset.y;
/*  64 */     float actualZ = this.transform.getZ() + theOffset.z;
/*  65 */     this.light.setPosition(actualX, actualY, actualZ);
/*  66 */     MainApp.lightSphere.getTransformation().setPosition(actualX, actualY, actualZ);
/*  67 */     engine.addLocalLight(this.light);
/*     */   }
/*     */   
/*     */   public float getOffsetX() {
/*  71 */     return this.offsetX;
/*     */   }
/*     */   
/*     */   public void setOffsetX(float offsetX) {
/*  75 */     this.offsetX = offsetX;
/*     */   }
/*     */   
/*     */   public float getOffsetY() {
/*  79 */     return this.offsetY;
/*     */   }
/*     */   
/*     */   public void setOffsetY(float offsetY) {
/*  83 */     this.offsetY = offsetY;
/*     */   }
/*     */   
/*     */   public float getOffsetZ() {
/*  87 */     return this.offsetZ;
/*     */   }
/*     */   
/*     */   public void setOffsetZ(float offsetZ) {
/*  91 */     this.offsetZ = offsetZ;
/*     */   }
/*     */   
/*     */   public Light getLight() {
/*  95 */     return this.light;
/*     */   }
/*     */   
/*     */   public void setInFabricator(ComponentFabricator fabricator)
/*     */   {
/* 100 */     fabricator.addUnNeededComponent(this);
/*     */   }
/*     */   
/*     */   public ComponentPanel getComponentPanel(ComponentListPanel listPanel)
/*     */   {
/* 105 */     return new LightComponentPanel(this, listPanel);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\lightComponent\LightComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */