/*    */ package lightComponent;
/*    */ 
/*    */ import backend.Entity;
/*    */ import componentArchitecture.Component;
/*    */ import componentArchitecture.ComponentCreator;
/*    */ import instances.EntityInstance;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.PrintStream;
/*    */ import org.lwjgl.util.vector.Vector3f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LightComponentCreator
/*    */   implements ComponentCreator
/*    */ {
/*    */   public Component createComponent(Entity entity)
/*    */   {
/* 19 */     return new LightComponent(entity.getEntityInstance().getTransformation());
/*    */   }
/*    */   
/*    */   public Component loadComponent(BufferedReader reader, Entity entity)
/*    */   {
/*    */     try {
/* 25 */       String[] values = reader.readLine().split(";");
/* 26 */       int pointer = 0;
/* 27 */       float x = Float.parseFloat(values[(pointer++)]);
/* 28 */       float y = Float.parseFloat(values[(pointer++)]);
/* 29 */       float z = Float.parseFloat(values[(pointer++)]);
/* 30 */       float r = Float.parseFloat(values[(pointer++)]);
/* 31 */       float g = Float.parseFloat(values[(pointer++)]);
/* 32 */       float b = Float.parseFloat(values[(pointer++)]);
/* 33 */       float att1 = Float.parseFloat(values[(pointer++)]);
/* 34 */       float att2 = Float.parseFloat(values[(pointer++)]);
/* 35 */       float att3 = Float.parseFloat(values[(pointer++)]);
/* 36 */       return new LightComponent(entity.getEntityInstance().getTransformation(), new Vector3f(x, y, z), new Vector3f(r, g, b), new Vector3f(att1, att2, att3));
/*    */     }
/*    */     catch (Exception e) {
/* 39 */       e.printStackTrace();
/* 40 */       System.err.println("Couldn't load light component!"); }
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\lightComponent\LightComponentCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */