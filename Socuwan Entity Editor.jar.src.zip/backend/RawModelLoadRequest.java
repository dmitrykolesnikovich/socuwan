/*    */ package backend;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import epicRenderEngine.GlRequest;
/*    */ import epicRenderEngine.ModelData;
/*    */ 
/*    */ public class RawModelLoadRequest implements GlRequest
/*    */ {
/*    */   private ModelData data;
/*    */   private StaticEntity entity;
/*    */   
/*    */   public RawModelLoadRequest(StaticEntity entity, ModelData data)
/*    */   {
/* 14 */     this.entity = entity;
/* 15 */     this.data = data;
/*    */   }
/*    */   
/*    */   public void excecute()
/*    */   {
/* 20 */     RawModel model = epicRenderEngine.Loader.loadRawModel(this.data);
/* 21 */     this.entity.setRawModel(model);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\RawModelLoadRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */