/*    */ package backend;
/*    */ 
/*    */ import instances.AnimatedInstance;
/*    */ import instances.StaticInstance;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import main.Configs;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Workspace
/*    */ {
/*    */   private Entity currentEntity;
/*    */   
/*    */   public void save()
/*    */   {
/* 22 */     if (this.currentEntity != null) {
/* 23 */       this.currentEntity.save();
/* 24 */       System.out.println("SAVED!");
/*    */     }
/*    */   }
/*    */   
/*    */   public void createNewEntity(EntityType type) {
/*    */     try {
/* 30 */       if (type == EntityType.STATIC) {
/* 31 */         this.currentEntity = new StaticEntity(Configs.SAVES_FILE, new Random().nextInt(1000000000));
/* 32 */         main.MainApp.currentEntity = new StaticInstance((StaticEntity)this.currentEntity);
/*    */       } else {
/* 34 */         this.currentEntity = new AnimatedEntity(Configs.SAVES_FILE, new Random().nextInt(1000000000));
/* 35 */         main.MainApp.currentEntity = new AnimatedInstance((AnimatedEntity)this.currentEntity);
/*    */       }
/*    */     } catch (Exception e) {
/* 38 */       System.err.println("Couldn't create new file!");
/* 39 */       e.printStackTrace();
/* 40 */       System.exit(-1);
/*    */     }
/*    */   }
/*    */   
/*    */   public List<File> getAvailableItems() {
/* 45 */     File[] files = Configs.SAVES_FILE.listFiles();
/* 46 */     List<File> entityFiles = new ArrayList();
/* 47 */     for (File file : files) {
/* 48 */       entityFiles.add(file);
/*    */     }
/* 50 */     return entityFiles;
/*    */   }
/*    */   
/*    */   public Entity getCurrentEntity() {
/* 54 */     return this.currentEntity;
/*    */   }
/*    */   
/*    */   public boolean open(File entityFile) {
/*    */     try {
/* 59 */       Entity entity = EntityImporter.importEntity(entityFile);
/* 60 */       this.currentEntity = entity;
/* 61 */       main.MainApp.currentEntity = this.currentEntity.getEntityInstance();
/* 62 */       return true;
/*    */     } catch (Exception e) {
/* 64 */       e.printStackTrace();
/* 65 */       System.err.println("Couldn't open invalid entity file: " + entityFile.getName()); }
/* 66 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\Workspace.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */