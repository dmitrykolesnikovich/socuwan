/*    */ package backend;
/*    */ 
/*    */ import blueprintInterfaces.BoneBlueprint;
/*    */ import blueprintInterfaces.RawModel;
/*    */ import epicRenderEngine.GlRequest;
/*    */ import epicRenderEngine.ModelData;
/*    */ 
/*    */ public class BoneLoadRequest implements GlRequest
/*    */ {
/*    */   private BoneBlueprint bone;
/*    */   private ModelData data;
/*    */   
/*    */   public BoneLoadRequest(BoneBlueprint bone, ModelData data)
/*    */   {
/* 15 */     this.bone = bone;
/* 16 */     this.data = data;
/*    */   }
/*    */   
/*    */   public void excecute()
/*    */   {
/* 21 */     RawModel model = epicRenderEngine.Loader.loadRawModel(this.data);
/* 22 */     this.bone.setRawModel(model);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\BoneLoadRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */