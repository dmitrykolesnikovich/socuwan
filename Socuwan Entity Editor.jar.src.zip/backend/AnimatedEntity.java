/*     */ package backend;
/*     */ 
/*     */ import animations.AnimationComponentBlueprint;
/*     */ import blueprintInterfaces.AnimatedBlueprintInterface;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import frontend.MainFrame;
/*     */ import instances.AnimatedInstance;
/*     */ import instances.EntityInstance;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.file.Files;
/*     */ import main.MainApp;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimatedEntity
/*     */   extends Entity
/*     */   implements AnimatedBlueprintInterface
/*     */ {
/*     */   private static final String BONE_SECTION_START = "<BONES>";
/*     */   private static final String BONE_SECTION_END = "</BONES>";
/*     */   private AnimationComponentBlueprint bones;
/*     */   private BoneBlueprint rootNode;
/*  27 */   private int numberOfBones = 0;
/*  28 */   private boolean newModel = false;
/*     */   
/*  30 */   private AnimatedInstance currentInstance = null;
/*     */   
/*     */   public AnimatedEntity(File entityFile) {
/*  33 */     super(entityFile);
/*     */   }
/*     */   
/*     */   public AnimatedEntity(File savesFile, int id) throws Exception {
/*  37 */     super(savesFile, id);
/*     */   }
/*     */   
/*     */   public AnimatedEntity(BoneBlueprint headBone, int numberOfBones, ModelTexture texture) {
/*  41 */     super(texture);
/*  42 */     this.bones = new AnimationComponentBlueprint(headBone, numberOfBones);
/*  43 */     super.setHasModel();
/*     */   }
/*     */   
/*     */   public AnimationComponentBlueprint getAnimationBlueprint() {
/*  47 */     return this.bones;
/*     */   }
/*     */   
/*     */   public boolean setAnimationComponent(AnimationComponentBlueprint bones) {
/*  51 */     File entityFile = getSuperFile();
/*     */     try {
/*  53 */       for (File file : entityFile.listFiles()) {
/*  54 */         if (file.getName().contains("bone_")) {
/*  55 */           Files.deleteIfExists(file.toPath());
/*     */         }
/*     */       }
/*  58 */       for (BoneBlueprint bone : bones.getAllBones()) {
/*  59 */         bone.loadRawModel();
/*     */       }
/*  61 */       this.newModel = true;
/*  62 */       super.setHasModel();
/*  63 */       this.bones = bones;
/*  64 */       return true;
/*     */     } catch (Exception e) {
/*  66 */       e.printStackTrace();
/*  67 */       System.err.println("Couldn't load bone models!"); }
/*  68 */     return false;
/*     */   }
/*     */   
/*     */   public void updateFurthestPoint(float far)
/*     */   {
/*  73 */     if (far > super.getFurthestPoint()) {
/*  74 */       super.setFurthestPoint(far);
/*  75 */       MainApp.mainFrame.updateRadius();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasNewModel() {
/*  80 */     boolean hasGot = this.newModel;
/*  81 */     this.newModel = false;
/*  82 */     return hasGot;
/*     */   }
/*     */   
/*     */   public EntityType getType()
/*     */   {
/*  87 */     return EntityType.ANIMATED;
/*     */   }
/*     */   
/*     */   public BoneBlueprint[] getHeadBones()
/*     */   {
/*  92 */     return this.bones.getHeadBones();
/*     */   }
/*     */   
/*     */   public int getNumberOfBones()
/*     */   {
/*  97 */     return this.bones.getNumberOfBones();
/*     */   }
/*     */   
/*     */ 
/*     */   public EntityInstance createInstance()
/*     */   {
/* 103 */     return null;
/*     */   }
/*     */   
/*     */   public void saveExtraInfo(PrintWriter writer)
/*     */   {
/* 108 */     if (this.bones != null) {
/* 109 */       writer.println("<BONES>");
/* 110 */       this.bones.getHeadBones()[0].exportToFile(writer);
/*     */     }
/* 112 */     writer.println("</BONES>");
/*     */   }
/*     */   
/*     */   public void loadExtraInfo(BufferedReader reader) throws Exception
/*     */   {
/* 117 */     this.numberOfBones = 0;
/* 118 */     String line = reader.readLine();
/* 119 */     if (line.equals("<BONES>")) {
/* 120 */       readInNode(reader, null);
/* 121 */       super.setHasModel();
/* 122 */       this.bones = new AnimationComponentBlueprint(this.rootNode, this.numberOfBones);
/*     */     }
/* 124 */     reader.readLine();
/*     */   }
/*     */   
/*     */   private boolean readInNode(BufferedReader reader, BoneBlueprint parent) throws Exception {
/* 128 */     String line = reader.readLine();
/* 129 */     if (line.equals("}")) {
/* 130 */       return false;
/*     */     }
/* 132 */     this.numberOfBones += 1;
/* 133 */     String[] settings = line.split(";");
/* 134 */     int partID = Integer.parseInt(settings[0]);
/* 135 */     float centerX = Float.parseFloat(settings[1]);
/* 136 */     float centerY = Float.parseFloat(settings[2]);
/* 137 */     float centerZ = Float.parseFloat(settings[3]);
/* 138 */     BoneBlueprint bone = new BoneBlueprint(partID, centerX, centerY, centerZ, this);
/* 139 */     if (parent != null) {
/* 140 */       parent.addChildren(new BoneBlueprint[] { bone });
/*     */     } else {
/* 142 */       this.rootNode = bone;
/*     */     }
/*     */     
/* 145 */     while (readInNode(reader, bone)) {}
/*     */     
/*     */ 
/* 148 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public EntityInstance getEntityInstance()
/*     */   {
/* 154 */     if (this.currentInstance == null) {
/* 155 */       this.currentInstance = new AnimatedInstance(this);
/*     */     }
/* 157 */     return this.currentInstance;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\AnimatedEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */