/*     */ package backend;
/*     */ 
/*     */ import componentArchitecture.Component;
/*     */ import componentArchitecture.ComponentType;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityImporter
/*     */ {
/*     */   protected static Entity importEntity(File superFile)
/*     */     throws Exception
/*     */   {
/*  22 */     BufferedReader reader = openFile(getInfoFile(superFile));
/*  23 */     int id = Integer.parseInt(superFile.getName());
/*  24 */     Entity entity = readEntitySettings(reader, superFile);
/*  25 */     entity.setID(id);
/*  26 */     readComponents(reader, entity);
/*  27 */     closeFile(reader);
/*  28 */     return entity;
/*     */   }
/*     */   
/*     */   private static Entity readEntitySettings(BufferedReader reader, File superFile) throws Exception
/*     */   {
/*  33 */     String[] values = reader.readLine().split(";");
/*  34 */     int pointer = 0;
/*  35 */     EntityType type = EntityType.values()[Integer.parseInt(values[(pointer++)])];
/*  36 */     Entity entity = null;
/*  37 */     if (type == EntityType.STATIC) {
/*  38 */       entity = new StaticEntity(superFile);
/*  39 */     } else if (type == EntityType.ANIMATED) {
/*  40 */       entity = new AnimatedEntity(superFile);
/*     */     }
/*  42 */     entity.setFurthestPoint(Float.parseFloat(values[(pointer++)]));
/*  43 */     entity.setVisibleRange(Float.parseFloat(values[(pointer++)]));
/*  44 */     entity.setVisibleUnderWater(readBoolean(values[(pointer++)]));
/*  45 */     entity.setHasReflection(readBoolean(values[(pointer++)]));
/*  46 */     entity.setHasLimitedReflection(readBoolean(values[(pointer++)]));
/*  47 */     entity.setLimitedReflection(Float.parseFloat(values[(pointer++)]));
/*  48 */     entity.setRenderOption(RenderOption.values()[Integer.parseInt(values[(pointer++)])]);
/*  49 */     entity.loadExtraInfo(reader);
/*  50 */     return entity;
/*     */   }
/*     */   
/*     */   private static void readComponents(BufferedReader reader, Entity entity) throws IOException {
/*     */     for (;;) {
/*  55 */       String identifier = reader.readLine();
/*  56 */       ComponentType type = null;
/*  57 */       if (identifier.equals("<END>")) {
/*  58 */         return;
/*     */       }
/*  60 */       type = ComponentType.valueOf(identifier);
/*     */       
/*  62 */       Component component = type.loadComponent(reader, entity);
/*  63 */       entity.addLoadedComponent(component);
/*     */     }
/*     */   }
/*     */   
/*     */   private static BufferedReader openFile(File file) {
/*  68 */     BufferedReader reader = null;
/*     */     try {
/*  70 */       FileReader isr = new FileReader(file);
/*  71 */       reader = new BufferedReader(isr);
/*     */     } catch (FileNotFoundException e) {
/*  73 */       System.err.println("File not found!");
/*  74 */       e.printStackTrace();
/*  75 */       System.exit(-1);
/*     */     }
/*  77 */     return reader;
/*     */   }
/*     */   
/*     */   private static void closeFile(BufferedReader file) {
/*     */     try {
/*  82 */       file.close();
/*     */     } catch (IOException e) {
/*  84 */       e.printStackTrace();
/*  85 */       System.exit(-1);
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean readBoolean(String bool) {
/*  90 */     int indicator = Integer.parseInt(bool);
/*  91 */     if (indicator == 0) {
/*  92 */       return false;
/*     */     }
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   private static File getInfoFile(File superFile)
/*     */   {
/*  99 */     File[] files = superFile.listFiles();
/* 100 */     for (File file : files) {
/* 101 */       if (file.getName().equals("info.txt")) {
/* 102 */         return file;
/*     */       }
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\EntityImporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */