/*    */ package backend;
/*    */ 
/*    */ public enum RenderOption
/*    */ {
/*  5 */   NORMAL("Standard Render"), 
/*  6 */   CLUTTER("Clutter Render"), 
/*  7 */   LOW_RES("Low Res Render");
/*    */   
/*    */   private String name;
/*    */   
/*    */   private RenderOption(String name) {
/* 12 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 16 */     return this.name;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\RenderOption.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */