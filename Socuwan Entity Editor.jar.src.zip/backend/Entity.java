/*     */ package backend;
/*     */ 
/*     */ import blueprintInterfaces.BlueprintInterface;
/*     */ import componentArchitecture.Component;
/*     */ import componentArchitecture.ComponentFabricator;
/*     */ import instances.EntityInstance;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Entity
/*     */   implements BlueprintInterface
/*     */ {
/*     */   private File superFile;
/*     */   private ModelTexture texture;
/*     */   private int id;
/*  25 */   private float furthestPoint = 10.0F;
/*  26 */   private float visibleRange = 1000.0F;
/*     */   
/*  28 */   private boolean visibleUnderWater = false;
/*  29 */   private boolean reflection = true;
/*  30 */   private boolean limitedReflection = false;
/*  31 */   private float reflectionLimit = 0.0F;
/*     */   
/*  33 */   private boolean wireframe = false;
/*  34 */   private RenderOption renderMethod = RenderOption.NORMAL;
/*     */   
/*  36 */   private boolean hasModel = false;
/*     */   
/*  38 */   private List<Component> loadedComponents = new ArrayList();
/*     */   
/*     */ 
/*  41 */   private ComponentFabricator fabricator = new ComponentFabricator();
/*     */   
/*     */   public Entity(File savesFile, int id) throws Exception {
/*  44 */     this.id = id;
/*  45 */     this.superFile = new File(savesFile, Integer.toString(id));
/*  46 */     this.superFile.mkdirs();
/*  47 */     File info = new File(this.superFile, "info.txt");
/*  48 */     info.createNewFile();
/*  49 */     this.texture = new ModelTexture(this);
/*  50 */     save();
/*     */   }
/*     */   
/*     */   public Entity(File entityFile) {
/*  54 */     this.superFile = entityFile;
/*     */     try {
/*  56 */       this.texture = new ModelTexture(this);
/*     */     } catch (Exception e) {
/*  58 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public Entity(ModelTexture texture) {
/*  63 */     this.texture = texture;
/*     */   }
/*     */   
/*     */   public void addLoadedComponent(Component component) {
/*  67 */     this.loadedComponents.add(component);
/*     */   }
/*     */   
/*     */   public List<Component> getLoadedComponents()
/*     */   {
/*  72 */     return this.loadedComponents;
/*     */   }
/*     */   
/*  75 */   public ComponentFabricator getFabricator() { return this.fabricator; }
/*     */   
/*     */   public void setRenderOption(RenderOption option)
/*     */   {
/*  79 */     this.renderMethod = option;
/*     */   }
/*     */   
/*     */   public RenderOption getRenderMethod() {
/*  83 */     return this.renderMethod;
/*     */   }
/*     */   
/*     */   public abstract EntityInstance createInstance();
/*     */   
/*     */   public void setFurthestPoint(float furthest) {
/*  89 */     this.furthestPoint = furthest;
/*     */   }
/*     */   
/*     */   public void setWireframe(boolean wire) {
/*  93 */     this.wireframe = wire;
/*     */   }
/*     */   
/*     */   public boolean isWireframe() {
/*  97 */     return this.wireframe;
/*     */   }
/*     */   
/*     */   public boolean hasModel() {
/* 101 */     return this.hasModel;
/*     */   }
/*     */   
/*     */   public void setHasModel() {
/* 105 */     this.hasModel = true;
/*     */   }
/*     */   
/*     */   public void setVisibleRange(float visibleUntil) {
/* 109 */     this.visibleRange = visibleUntil;
/*     */   }
/*     */   
/*     */   public abstract EntityType getType();
/*     */   
/*     */   public ModelTexture getTexture()
/*     */   {
/* 116 */     return this.texture;
/*     */   }
/*     */   
/*     */   public void save() {
/* 120 */     EntityExporter.exportEntity(this);
/* 121 */     this.texture.saveToFile();
/*     */   }
/*     */   
/*     */   public abstract void saveExtraInfo(PrintWriter paramPrintWriter);
/*     */   
/*     */   public abstract void loadExtraInfo(BufferedReader paramBufferedReader) throws Exception;
/*     */   
/*     */   public abstract EntityInstance getEntityInstance();
/*     */   
/*     */   public void setVisibleUnderWater(boolean visible) {
/* 131 */     this.visibleUnderWater = visible;
/*     */   }
/*     */   
/*     */   public void setHasReflection(boolean hasReflection) {
/* 135 */     this.reflection = hasReflection;
/*     */   }
/*     */   
/*     */   public void setLimitedReflection(float distance) {
/* 139 */     this.reflectionLimit = distance;
/*     */   }
/*     */   
/*     */   public void setHasLimitedReflection(boolean limited) {
/* 143 */     this.limitedReflection = limited;
/*     */   }
/*     */   
/*     */   public void unlimitReflection() {
/* 147 */     this.limitedReflection = false;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 151 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setID(int id) {
/* 155 */     this.id = id;
/*     */   }
/*     */   
/*     */   public float getFurthestPoint() {
/* 159 */     return this.furthestPoint;
/*     */   }
/*     */   
/*     */   public float getVisibleRange() {
/* 163 */     return this.visibleRange;
/*     */   }
/*     */   
/*     */   public boolean isVisibleUnderWater() {
/* 167 */     return this.visibleUnderWater;
/*     */   }
/*     */   
/*     */   public boolean hasReflection() {
/* 171 */     return this.reflection;
/*     */   }
/*     */   
/*     */   public boolean hasLimitedReflection() {
/* 175 */     return this.limitedReflection;
/*     */   }
/*     */   
/*     */   public float getReflectionLimit() {
/* 179 */     return this.reflectionLimit;
/*     */   }
/*     */   
/*     */   public void setSuperFile(File superFile) {
/* 183 */     this.superFile = superFile;
/*     */   }
/*     */   
/*     */   public File getSuperFile() {
/* 187 */     return this.superFile;
/*     */   }
/*     */   
/*     */   public File getInfoFile() {
/* 191 */     File[] files = this.superFile.listFiles();
/* 192 */     for (File file : files) {
/* 193 */       if (file.getName().equals("info.txt")) {
/* 194 */         return file;
/*     */       }
/*     */     }
/* 197 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\Entity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */