/*    */ package backend;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ import epicRenderEngine.GlRequest;
/*    */ 
/*    */ public class InstanceVBOLoad implements GlRequest
/*    */ {
/*    */   private StaticEntity entity;
/*    */   
/*    */   public InstanceVBOLoad(StaticEntity entity)
/*    */   {
/* 12 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public void excecute()
/*    */   {
/* 17 */     int instanceDataVBO = epicRenderEngine.Loader.createInterleavedInstanceVBO(this.entity.getModel().getVaoID(), 3, 200, new int[] { 4, 4, 4, 3, 1 });
/*    */     
/*    */ 
/*    */ 
/* 21 */     this.entity.setInstancedData(instanceDataVBO);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\InstanceVBOLoad.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */