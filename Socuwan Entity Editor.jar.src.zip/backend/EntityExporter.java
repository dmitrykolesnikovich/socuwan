/*    */ package backend;
/*    */ 
/*    */ import componentArchitecture.Component;
/*    */ import componentArchitecture.ComponentFabricator;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.List;
/*    */ import main.Configs;
/*    */ 
/*    */ public class EntityExporter
/*    */ {
/*    */   protected static final String END_TAG = "<END>";
/*    */   
/*    */   protected static boolean exportEntity(Entity entity)
/*    */   {
/* 19 */     File entityFile = entity.getSuperFile();
/* 20 */     PrintWriter writer = openSaveFile(entity.getInfoFile());
/* 21 */     printData(writer, entity);
/* 22 */     entity.saveExtraInfo(writer);
/* 23 */     printComponents(writer, entity.getFabricator().getComponents());
/* 24 */     closeFile(writer);
/* 25 */     File newSuperfile = null;
/*    */     
/* 27 */     newSuperfile = new File(Configs.SAVES_FILE, Integer.toString(entity.getId()));
/*    */     
/* 29 */     if (entityFile.renameTo(newSuperfile)) {
/* 30 */       entity.setSuperFile(newSuperfile);
/* 31 */       return true;
/*    */     }
/* 33 */     return false;
/*    */   }
/*    */   
/*    */   private static void printData(PrintWriter writer, Entity entity)
/*    */   {
/* 38 */     writer.print(Integer.toString(entity.getType().ordinal()));
/* 39 */     writer.print(";");
/* 40 */     writer.print(entity.getFurthestPoint());
/* 41 */     writer.print(";");
/* 42 */     writer.print(entity.getVisibleRange());
/* 43 */     writer.print(";");
/* 44 */     writer.print(booleanToInt(entity.isVisibleUnderWater()));
/* 45 */     writer.print(";");
/* 46 */     writer.print(booleanToInt(entity.hasReflection()));
/* 47 */     writer.print(";");
/* 48 */     writer.print(booleanToInt(entity.hasLimitedReflection()));
/* 49 */     writer.print(";");
/* 50 */     writer.print(entity.getReflectionLimit());
/* 51 */     writer.print(";");
/* 52 */     writer.println(entity.getRenderMethod().ordinal());
/*    */   }
/*    */   
/*    */   private static void printComponents(PrintWriter writer, List<Component> components) {
/* 56 */     for (Component component : components) {
/* 57 */       writer.println(component.getType().getActualName());
/* 58 */       component.export(writer);
/*    */     }
/* 60 */     writer.println("<END>");
/*    */   }
/*    */   
/*    */   private static PrintWriter openSaveFile(File file) {
/* 64 */     FileWriter fileWriter = null;
/*    */     try {
/* 66 */       fileWriter = new FileWriter(file, false);
/*    */     } catch (Exception e) {
/* 68 */       e.printStackTrace();
/* 69 */       System.err.println("Problem opening file to write!");
/* 70 */       System.exit(-1);
/*    */     }
/* 72 */     BufferedWriter bWriter = new BufferedWriter(fileWriter);
/* 73 */     return new PrintWriter(bWriter);
/*    */   }
/*    */   
/*    */   private static void closeFile(PrintWriter file) {
/* 77 */     file.close();
/*    */   }
/*    */   
/*    */   private static int booleanToInt(boolean check) {
/* 81 */     if (check) {
/* 82 */       return 1;
/*    */     }
/* 84 */     return 0;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\EntityExporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */