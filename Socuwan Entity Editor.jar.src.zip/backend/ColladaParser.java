/*     */ package backend;
/*     */ 
/*     */ import animations.AnimationComponentBlueprint;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColladaParser
/*     */ {
/*  18 */   private static BoneBlueprint currentParent = null;
/*  19 */   private static BoneBlueprint rootNode = null;
/*  20 */   private static int numberOfBones = 0;
/*     */   
/*     */   public static AnimationComponentBlueprint loadBones(File colladaFile, AnimatedEntity entity) throws Exception
/*     */   {
/*  24 */     currentParent = null;
/*  25 */     rootNode = null;
/*  26 */     numberOfBones = 0;
/*     */     
/*  28 */     BufferedReader reader = openFile(colladaFile);
/*  29 */     readInBones(entity, reader);
/*     */     
/*  31 */     return new AnimationComponentBlueprint(rootNode, numberOfBones);
/*     */   }
/*     */   
/*     */   private static BufferedReader openFile(File file) throws Exception {
/*  35 */     FileReader isr = new FileReader(file);
/*  36 */     BufferedReader reader = new BufferedReader(isr);
/*  37 */     return reader;
/*     */   }
/*     */   
/*     */   private static void readInBones(AnimatedEntity entity, BufferedReader reader) throws Exception {
/*     */     String check;
/*  42 */     while ((check = reader.readLine()) != null) {
/*  43 */       if (check.contains("<node id=\"Armature\"")) {
/*  44 */         processHeirarchy(reader, entity);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void processHeirarchy(BufferedReader reader, AnimatedEntity entity) throws Exception
/*     */   {
/*     */     String line;
/*  52 */     while (!(line = reader.readLine()).contains("</visual_scene>")) {
/*  53 */       if (line.contains("JOINT")) {
/*  54 */         processNode(line, entity, reader);
/*  55 */       } else if (line.contains("NODE")) {
/*  56 */         skip(reader);
/*  57 */       } else if (line.contains("</node>")) {
/*  58 */         if (currentParent == null) break;
/*  59 */         currentParent = currentParent.getParent();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void processNode(String nodeHeader, AnimatedEntity entity, BufferedReader reader)
/*     */     throws Exception
/*     */   {
/*  69 */     numberOfBones += 1;
/*  70 */     String sectionName = nodeHeader.split("\"")[1];
/*  71 */     int sectionID = Integer.parseInt(sectionName.split("_")[1]);
/*  72 */     BoneBlueprint blueprint = new BoneBlueprint(sectionID, sectionName, entity);
/*  73 */     if (currentParent != null) {
/*  74 */       currentParent.addChildren(new BoneBlueprint[] { blueprint });
/*  75 */       blueprint.setParent(currentParent);
/*     */     } else {
/*  77 */       rootNode = blueprint;
/*     */     }
/*  79 */     currentParent = blueprint;
/*  80 */     readTransformForSection(blueprint, reader);
/*     */   }
/*     */   
/*     */   private static void skip(BufferedReader reader) throws Exception {
/*  84 */     while (!reader.readLine().contains("</node>")) {}
/*     */   }
/*     */   
/*     */   private static void readTransformForSection(BoneBlueprint bone, BufferedReader reader)
/*     */     throws Exception
/*     */   {
/*  90 */     String matrix = reader.readLine().split("[<>]")[2];
/*  91 */     String[] indieValues = matrix.split(" ");
/*  92 */     float[] matrixArray = new float[16];
/*  93 */     for (int i = 0; i < matrixArray.length; i++) {
/*  94 */       matrixArray[i] = Float.parseFloat(indieValues[i]);
/*     */     }
/*  96 */     Matrix4f rotation = loadMatrix(matrixArray);
/*  97 */     bone.setModelMatrix(rotation);
/*     */   }
/*     */   
/*     */   private static Matrix4f loadMatrix(float[] matrix) {
/* 101 */     Matrix4f startMatrix = new Matrix4f();
/* 102 */     int pointer = 0;
/* 103 */     startMatrix.m00 = matrix[(pointer++)];
/* 104 */     startMatrix.m10 = matrix[(pointer++)];
/* 105 */     startMatrix.m20 = matrix[(pointer++)];
/* 106 */     startMatrix.m30 = matrix[(pointer++)];
/* 107 */     startMatrix.m01 = matrix[(pointer++)];
/* 108 */     startMatrix.m11 = matrix[(pointer++)];
/* 109 */     startMatrix.m21 = matrix[(pointer++)];
/* 110 */     startMatrix.m31 = matrix[(pointer++)];
/* 111 */     startMatrix.m02 = matrix[(pointer++)];
/* 112 */     startMatrix.m12 = matrix[(pointer++)];
/* 113 */     startMatrix.m22 = matrix[(pointer++)];
/* 114 */     startMatrix.m32 = matrix[(pointer++)];
/* 115 */     startMatrix.m03 = matrix[(pointer++)];
/* 116 */     startMatrix.m13 = matrix[(pointer++)];
/* 117 */     startMatrix.m23 = matrix[(pointer++)];
/* 118 */     startMatrix.m33 = matrix[(pointer++)];
/* 119 */     return startMatrix;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\ColladaParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */