/*     */ package backend;
/*     */ 
/*     */ import blueprintInterfaces.RawModel;
/*     */ import blueprintInterfaces.StaticBlueprintInterface;
/*     */ import epicRenderEngine.Loader;
/*     */ import epicRenderEngine.ModelData;
/*     */ import frontend.MainFrame;
/*     */ import instances.EntityInstance;
/*     */ import instances.StaticInstance;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import main.MainApp;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ public class StaticEntity
/*     */   extends Entity
/*     */   implements StaticBlueprintInterface
/*     */ {
/*     */   private RawModel model;
/*     */   private StaticInstance currentInstance;
/*  25 */   private int instanceVBO = -1;
/*  26 */   private boolean fades = false;
/*     */   
/*     */   public StaticEntity(RawModel model, ModelTexture texture) {
/*  29 */     super(texture);
/*  30 */     this.model = model;
/*     */   }
/*     */   
/*     */   public StaticEntity(File entityFile) {
/*  34 */     super(entityFile);
/*  35 */     File[] files = entityFile.listFiles();
/*  36 */     for (File file : files) {
/*  37 */       if (file.getName().equals("MODEL.csv")) {
/*  38 */         super.setHasModel();
/*  39 */         Loader.requestRawModelLoading(this);
/*  40 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public StaticEntity(File savesFile, int id) throws Exception {
/*  46 */     super(savesFile, id);
/*     */   }
/*     */   
/*     */   public EntityType getType()
/*     */   {
/*  51 */     return EntityType.STATIC;
/*     */   }
/*     */   
/*     */   public void setModelFile(File modelFile) throws Exception {
/*  55 */     ModelData data = Loader.loadModelData(modelFile);
/*  56 */     File file = new File(getSuperFile(), "MODEL.csv");
/*  57 */     Files.copy(modelFile.toPath(), file.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*  58 */     super.setHasModel();
/*  59 */     Loader.sendRequest(new RawModelLoadRequest(this, data));
/*     */   }
/*     */   
/*     */   public File getModelFile() {
/*  63 */     return new File(getSuperFile(), "MODEL.csv");
/*     */   }
/*     */   
/*     */   public RawModel getModel()
/*     */   {
/*  68 */     return this.model;
/*     */   }
/*     */   
/*     */   public void setRenderOption(RenderOption option)
/*     */   {
/*  73 */     super.setRenderOption(option);
/*  74 */     if (option == RenderOption.CLUTTER) {
/*  75 */       if (this.instanceVBO == -1) {
/*  76 */         setToFadeOut();
/*     */       } else {
/*  78 */         this.fades = true;
/*     */       }
/*     */     } else {
/*  81 */       this.fades = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setToFadeOut() {
/*  86 */     Loader.sendRequest(new InstanceVBOLoad(this));
/*     */   }
/*     */   
/*     */   public boolean fadesOut()
/*     */   {
/*  91 */     return this.fades;
/*     */   }
/*     */   
/*     */   public int getInstanceDataVBO()
/*     */   {
/*  96 */     return this.instanceVBO;
/*     */   }
/*     */   
/*     */   public void setInstancedData(int vbo) {
/* 100 */     this.instanceVBO = vbo;
/* 101 */     this.fades = true;
/*     */   }
/*     */   
/*     */   public void setModelFromLoader(RawModel model) {
/* 105 */     this.model = model;
/*     */   }
/*     */   
/*     */   public void setRawModel(RawModel model) {
/* 109 */     this.model = model;
/* 110 */     super.setFurthestPoint(model.getFurthestPoint());
/* 111 */     MainApp.mainFrame.updateRadius();
/*     */   }
/*     */   
/*     */   public EntityInstance createInstance()
/*     */   {
/* 116 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void saveExtraInfo(PrintWriter writer) {}
/*     */   
/*     */ 
/*     */   public void loadExtraInfo(BufferedReader reader)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */   public EntityInstance getEntityInstance()
/*     */   {
/* 131 */     if (this.currentInstance == null) {
/* 132 */       this.currentInstance = new StaticInstance(this);
/*     */     }
/* 134 */     return this.currentInstance;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\backend\StaticEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */