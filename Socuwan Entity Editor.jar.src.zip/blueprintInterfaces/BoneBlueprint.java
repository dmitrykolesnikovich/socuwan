/*     */ package blueprintInterfaces;
/*     */ 
/*     */ import backend.AnimatedEntity;
/*     */ import backend.BoneLoadRequest;
/*     */ import epicRenderEngine.Loader;
/*     */ import epicRenderEngine.ModelData;
/*     */ import frontend.ErrorPopUp;
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoneBlueprint
/*     */ {
/*     */   public static final String BONE_FILE_PREFIX = "bone_";
/*     */   private static final String BONE_FILE_EXT = ".csv";
/*     */   private static final String START_CHILD_LIST = "{";
/*     */   public static final String END_CHILD_LIST = "}";
/*     */   private int partID;
/*     */   private String name;
/*     */   private AnimatedEntity entity;
/*     */   private RawModel model;
/*     */   private float centerX;
/*     */   private float centerY;
/*     */   private float centerZ;
/*  33 */   private List<BoneBlueprint> childrenNodes = new ArrayList();
/*     */   private BoneBlueprint parent;
/*     */   private Matrix4f modelMatrix;
/*  36 */   private boolean modelSet = false;
/*     */   private File nextModelFile;
/*     */   
/*     */   public BoneBlueprint(int partID, String name, AnimatedEntity entity)
/*     */   {
/*  41 */     this.partID = partID;
/*  42 */     this.name = name;
/*  43 */     this.entity = entity;
/*     */   }
/*     */   
/*     */   public BoneBlueprint(int partID, float centerX, float centerY, float centerZ, AnimatedEntity entity)
/*     */   {
/*  48 */     this.partID = partID;
/*  49 */     this.centerX = centerX;
/*  50 */     this.centerY = centerY;
/*  51 */     this.centerZ = centerZ;
/*  52 */     this.entity = entity;
/*  53 */     Loader.requestBoneModelLoading(this);
/*     */   }
/*     */   
/*     */   public BoneBlueprint(int partID, RawModel model, float centerX, float centerY, float centerZ) {
/*  57 */     this.model = model;
/*  58 */     this.partID = partID;
/*  59 */     this.centerX = centerX;
/*  60 */     this.centerY = centerY;
/*  61 */     this.centerZ = centerZ;
/*  62 */     this.childrenNodes = new ArrayList();
/*     */   }
/*     */   
/*     */   public File getModelFile() {
/*  66 */     return new File(this.entity.getSuperFile(), "bone_" + this.partID + ".csv");
/*     */   }
/*     */   
/*     */   public void setModelMatrix(Matrix4f matrix) {
/*  70 */     if (this.parent == null) {
/*  71 */       this.modelMatrix = matrix;
/*     */     } else {
/*  73 */       this.modelMatrix = Matrix4f.mul(this.parent.modelMatrix, matrix, null);
/*     */     }
/*  75 */     this.centerX = this.modelMatrix.m30;
/*  76 */     this.centerY = this.modelMatrix.m32;
/*  77 */     this.centerZ = (-this.modelMatrix.m31);
/*     */   }
/*     */   
/*     */   public void exportToFile(PrintWriter writer) {
/*  81 */     writer.print(this.partID + ";");
/*  82 */     writer.println(this.centerX + ";" + this.centerY + ";" + this.centerZ);
/*  83 */     writer.println("{");
/*  84 */     for (BoneBlueprint child : this.childrenNodes) {
/*  85 */       child.exportToFile(writer);
/*     */     }
/*  87 */     writer.println("}");
/*     */   }
/*     */   
/*     */   public Matrix4f getModelMatrix() {
/*  91 */     return this.modelMatrix;
/*     */   }
/*     */   
/*     */   public void setNextModelFile(File modelFile) {
/*  95 */     this.modelSet = true;
/*  96 */     this.nextModelFile = modelFile;
/*     */   }
/*     */   
/*     */   public void loadRawModel() throws Exception {
/*     */     try {
/* 101 */       ModelData data = Loader.loadModelData(this.nextModelFile);
/* 102 */       File file = new File(this.entity.getSuperFile(), "bone_" + this.partID + ".csv");
/* 103 */       Files.copy(this.nextModelFile.toPath(), file.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/* 104 */       Loader.sendRequest(new BoneLoadRequest(this, data));
/*     */     } catch (Exception e) {
/* 106 */       new ErrorPopUp(this.nextModelFile.getName() + " couldn't be loaded!");
/* 107 */       throw new Exception();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isModelSet() {
/* 112 */     return this.modelSet;
/*     */   }
/*     */   
/*     */   public void setRawModel(RawModel model) {
/* 116 */     this.model = model;
/* 117 */     this.entity.updateFurthestPoint(model.getFurthestPoint());
/*     */   }
/*     */   
/*     */   public void setParent(BoneBlueprint parent) {
/* 121 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public BoneBlueprint getParent() {
/* 125 */     return this.parent;
/*     */   }
/*     */   
/*     */   public int getPartID() {
/* 129 */     return this.partID;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 133 */     return this.name;
/*     */   }
/*     */   
/*     */   public RawModel getModel() {
/* 137 */     return this.model;
/*     */   }
/*     */   
/*     */   public void addChildren(BoneBlueprint... children) {
/* 141 */     for (BoneBlueprint child : children) {
/* 142 */       this.childrenNodes.add(child);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<BoneBlueprint> getChildren() {
/* 147 */     return this.childrenNodes;
/*     */   }
/*     */   
/*     */   public float getCenterX() {
/* 151 */     return this.centerX;
/*     */   }
/*     */   
/*     */   public float getCenterY() {
/* 155 */     return this.centerY;
/*     */   }
/*     */   
/*     */   public float getCenterZ() {
/* 159 */     return this.centerZ;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\blueprintInterfaces\BoneBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */