/*    */ package blueprintInterfaces;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class RawModel { private int id;
/*    */   private int vaoID;
/*    */   private int[] indexVBOLengths;
/*  8 */   private float furthestPoint = 10.0F;
/*    */   
/*    */   private boolean solid;
/*    */   
/*    */   public RawModel(int id, int vaoID, int[] indicesLengths)
/*    */   {
/* 14 */     this.id = id;
/* 15 */     this.vaoID = vaoID;
/* 16 */     this.indexVBOLengths = indicesLengths;
/*    */   }
/*    */   
/*    */   public float getFurthestPoint() {
/* 20 */     return this.furthestPoint;
/*    */   }
/*    */   
/*    */   public void setFurthestPoint(float furthest) {
/* 24 */     this.furthestPoint = furthest;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 28 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getVaoID() {
/* 32 */     return this.vaoID;
/*    */   }
/*    */   
/*    */   public int getIndexVBOLength(int lOD) {
/* 36 */     int start = lOD;
/* 37 */     if (lOD >= this.indexVBOLengths.length) {
/* 38 */       start = this.indexVBOLengths.length - 1;
/*    */     }
/* 40 */     for (int i = start; i >= 0; i--) {
/* 41 */       int length = this.indexVBOLengths[i];
/* 42 */       if (length >= 0) {
/* 43 */         return length;
/*    */       }
/*    */     }
/* 46 */     System.err.println("Index VBO length of 0? Shouldn't be possible.");
/* 47 */     return 0;
/*    */   }
/*    */   
/*    */   public int getIndicesVBOOffset(int lOD) {
/* 51 */     int offset = 0;
/* 52 */     if (lOD >= this.indexVBOLengths.length) {
/* 53 */       lOD = this.indexVBOLengths.length - 1;
/*    */     }
/* 55 */     while (this.indexVBOLengths[lOD] == 0) {
/* 56 */       lOD--;
/*    */     }
/* 58 */     for (int i = lOD - 1; i >= 0; i--) {
/* 59 */       offset += this.indexVBOLengths[i];
/*    */     }
/* 61 */     return offset;
/*    */   }
/*    */   
/*    */   public boolean isSolid()
/*    */   {
/* 66 */     return this.solid;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\blueprintInterfaces\RawModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */