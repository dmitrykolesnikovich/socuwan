/*    */ package animations;
/*    */ 
/*    */ import blueprintInterfaces.BoneBlueprint;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AnimationComponentBlueprint
/*    */ {
/*    */   private int numberOfBones;
/*    */   private BoneBlueprint headBone;
/*    */   
/*    */   public AnimationComponentBlueprint(BoneBlueprint headBone, int numberOfBones)
/*    */   {
/* 14 */     this.headBone = headBone;
/* 15 */     this.numberOfBones = numberOfBones;
/*    */   }
/*    */   
/*    */   public BoneBlueprint[] getHeadBones() {
/* 19 */     return new BoneBlueprint[] { this.headBone };
/*    */   }
/*    */   
/*    */   public BoneBlueprint getRoot() {
/* 23 */     return this.headBone;
/*    */   }
/*    */   
/*    */   public int getNumberOfBones() {
/* 27 */     return this.numberOfBones;
/*    */   }
/*    */   
/*    */   public List<BoneBlueprint> getAllBones() {
/* 31 */     List<BoneBlueprint> bones = new ArrayList();
/* 32 */     addBoneToList(this.headBone, bones);
/* 33 */     return bones;
/*    */   }
/*    */   
/*    */   private void addBoneToList(BoneBlueprint bone, List<BoneBlueprint> list) {
/* 37 */     list.add(bone);
/* 38 */     for (BoneBlueprint child : bone.getChildren()) {
/* 39 */       addBoneToList(child, list);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\animations\AnimationComponentBlueprint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */