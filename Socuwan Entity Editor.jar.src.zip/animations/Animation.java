/*    */ package animations;
/*    */ 
/*    */ 
/*    */ public class Animation
/*    */ {
/*    */   private int id;
/*    */   
/*    */   private int length;
/*    */   private boolean loopAnimation;
/*    */   public final float MAX_POS_CHANGE_PER_MILLI;
/*    */   public final float MAX_ROT_CHANGE_PER_MILLI;
/*    */   public final float MAX_SCALE_CHANGE_PER_MILLI;
/*    */   private AnimationSection[] sections;
/*    */   
/*    */   public Animation(int id, int length, boolean loop, float maxPos, float maxRot, float maxScale)
/*    */   {
/* 17 */     this.id = id;
/* 18 */     this.MAX_POS_CHANGE_PER_MILLI = maxPos;
/* 19 */     this.MAX_ROT_CHANGE_PER_MILLI = maxRot;
/* 20 */     this.MAX_SCALE_CHANGE_PER_MILLI = maxScale;
/* 21 */     this.length = length;
/* 22 */     this.loopAnimation = loop;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 26 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setAnimationSections(AnimationSection[] sections) {
/* 30 */     this.sections = sections;
/*    */   }
/*    */   
/*    */ 
/*    */   public void animateEntitySectionsAtTime(AnimatablePart[] entityParts, float time, float deltaInSecs)
/*    */   {
/* 36 */     for (AnimationSection partAnimation : this.sections) {
/* 37 */       AnimatablePart entitySection = entityParts[partAnimation.getSectionID()];
/* 38 */       partAnimation.animateEntitySectionAtTime(entitySection, time, deltaInSecs);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public float increaseAnimationTime(float oldTime, float deltaInSeconds)
/*    */   {
/* 45 */     float newTime = oldTime + deltaInSeconds * 1000.0F;
/* 46 */     if (this.loopAnimation) {
/* 47 */       return newTime % this.length;
/*    */     }
/* 49 */     return newTime;
/*    */   }
/*    */   
/*    */   public boolean isOver(float time)
/*    */   {
/* 54 */     if (time >= this.length) {
/* 55 */       return true;
/*    */     }
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\animations\Animation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */