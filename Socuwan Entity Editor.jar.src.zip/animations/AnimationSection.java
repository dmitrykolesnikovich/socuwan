/*     */ package animations;
/*     */ 
/*     */ import toolbox.Maths;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimationSection
/*     */ {
/*     */   private int sectionID;
/*     */   private Frame[] frames;
/*     */   private boolean hasPositionChange;
/*     */   private boolean hasRotationChange;
/*     */   private boolean hasScaleChange;
/*     */   private Animation animation;
/*     */   
/*     */   public AnimationSection(int id, Animation parent, boolean pos, boolean rot, boolean scale)
/*     */   {
/*  20 */     this.sectionID = id;
/*  21 */     this.hasPositionChange = pos;
/*  22 */     this.hasRotationChange = rot;
/*  23 */     this.hasScaleChange = scale;
/*  24 */     this.animation = parent;
/*     */   }
/*     */   
/*     */   public void setFrames(Frame[] frames) {
/*  28 */     this.frames = frames;
/*     */   }
/*     */   
/*     */   public int getSectionID() {
/*  32 */     return this.sectionID;
/*     */   }
/*     */   
/*     */   public void animateEntitySectionAtTime(AnimatablePart entitySection, float time, float deltaSeconds) {
/*  36 */     float deltaMillis = deltaSeconds * 1000.0F;
/*  37 */     if (!this.hasPositionChange) {
/*  38 */       smoothlySetPosition(entitySection, new float[] { 0.0F, 0.0F, 0.0F }, deltaMillis);
/*     */     }
/*  40 */     if (!this.hasRotationChange) {
/*  41 */       smoothlySetRotation(entitySection, new double[] { 1.0D, 0.0D, 0.0D, 0.0D }, deltaMillis);
/*     */     }
/*  43 */     if (!this.hasScaleChange) {
/*  44 */       smoothlySetScale(entitySection, 1.0F, deltaMillis);
/*     */     }
/*  46 */     int nextFrameIndex = findNextFrameIndex(time, 0, this.frames.length - 1);
/*  47 */     Frame previousFrame = this.frames[(nextFrameIndex - 1)];
/*     */     Frame nextFrame;
/*  49 */     Frame nextFrame; if (nextFrameIndex != this.frames.length) {
/*  50 */       nextFrame = this.frames[nextFrameIndex];
/*     */     } else {
/*  52 */       nextFrame = previousFrame;
/*     */     }
/*  54 */     animateForMidpointOfFrames(entitySection, time, previousFrame, nextFrame, deltaMillis);
/*     */   }
/*     */   
/*     */   private int findNextFrameIndex(float time, int firstIndex, int lastIndex) {
/*  58 */     if (firstIndex == lastIndex) {
/*  59 */       return lastIndex + 1;
/*     */     }
/*  61 */     float length = 1 + (lastIndex - firstIndex);
/*  62 */     int check = (int)Math.floor(length / 2.0F) + firstIndex - 1;
/*  63 */     int number1 = this.frames[check].getTime();
/*  64 */     int number2 = this.frames[(check + 1)].getTime();
/*  65 */     if (number1 > time) {
/*  66 */       return findNextFrameIndex(time, firstIndex, check);
/*     */     }
/*  68 */     if (number2 > time) {
/*  69 */       return check + 1;
/*     */     }
/*  71 */     return findNextFrameIndex(time, check + 1, lastIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void animateForMidpointOfFrames(AnimatablePart entitySection, float time, Frame before, Frame after, float delta)
/*     */   {
/*  79 */     if (this.hasPositionChange) {
/*  80 */       float[] inter = interpolatePosition(entitySection, time, before, after, delta);
/*  81 */       smoothlySetPosition(entitySection, inter, delta);
/*     */     }
/*  83 */     if (this.hasRotationChange) {
/*  84 */       double[] inter = interpolateRotation(entitySection, time, before, after, delta);
/*  85 */       smoothlySetRotation(entitySection, inter, delta);
/*     */     }
/*  87 */     if (this.hasScaleChange) {
/*  88 */       float inter = interpolateScale(entitySection, time, before, after, delta);
/*  89 */       smoothlySetScale(entitySection, inter, delta);
/*     */     }
/*     */   }
/*     */   
/*     */   private float[] interpolatePosition(AnimatablePart entitySection, float time, Frame before, Frame after, float delta)
/*     */   {
/*  95 */     int firstTime = before.getTime();
/*  96 */     int nextTime = after.getTime();
/*  97 */     float[] target = new float[3];
/*  98 */     if (firstTime == nextTime) {
/*  99 */       target[0] = before.getX();
/* 100 */       target[1] = before.getY();
/* 101 */       target[2] = before.getZ();
/*     */     } else {
/* 103 */       target[0] = calcMidValue(firstTime, nextTime, before.getX(), after.getX(), time);
/* 104 */       target[1] = calcMidValue(firstTime, nextTime, before.getY(), after.getY(), time);
/* 105 */       target[2] = calcMidValue(firstTime, nextTime, before.getZ(), after.getZ(), time);
/*     */     }
/* 107 */     return target;
/*     */   }
/*     */   
/*     */ 
/*     */   private double[] interpolateRotation(AnimatablePart section, float time, Frame before, Frame after, float delta)
/*     */   {
/* 113 */     int firstTime = before.getTime();
/* 114 */     int nextTime = after.getTime();
/* 115 */     double[] target = new double[4];
/* 116 */     if (firstTime == nextTime) {
/* 117 */       target[0] = before.getRotW();
/* 118 */       target[1] = before.getRotX();
/* 119 */       target[2] = before.getRotY();
/* 120 */       target[3] = before.getRotZ();
/*     */     } else {
/* 122 */       double[] qA = { before.getRotW(), before.getRotX(), before.getRotY(), before.getRotZ() };
/* 123 */       double[] qB = { after.getRotW(), after.getRotX(), after.getRotY(), after.getRotZ() };
/* 124 */       double unitTime = (time - firstTime) / (nextTime - firstTime);
/* 125 */       target = slerp(qA, qB, unitTime);
/*     */     }
/* 127 */     return target;
/*     */   }
/*     */   
/*     */   private float interpolateScale(AnimatablePart entitySection, float time, Frame before, Frame after, float delta)
/*     */   {
/* 132 */     int firstTime = before.getTime();
/* 133 */     int nextTime = after.getTime();
/*     */     float target;
/* 135 */     float target; if (firstTime == nextTime) {
/* 136 */       target = before.getScale();
/*     */     } else {
/* 138 */       target = calcMidValue(before.getTime(), after.getTime(), before.getScale(), after.getScale(), time);
/*     */     }
/*     */     
/* 141 */     return target;
/*     */   }
/*     */   
/*     */   private void smoothlySetPosition(AnimatablePart entitySection, float[] target, float delta) {
/* 145 */     float finalX = getSmoothedResult(entitySection.getX(), target[0], this.animation.MAX_POS_CHANGE_PER_MILLI * delta);
/*     */     
/* 147 */     float finalY = getSmoothedResult(entitySection.getY(), target[1], this.animation.MAX_POS_CHANGE_PER_MILLI * delta);
/*     */     
/* 149 */     float finalZ = getSmoothedResult(entitySection.getZ(), target[2], this.animation.MAX_POS_CHANGE_PER_MILLI * delta);
/*     */     
/* 151 */     entitySection.setPosition(finalX, finalY, finalZ);
/*     */   }
/*     */   
/*     */   private void smoothlySetRotation(AnimatablePart section, double[] target, float delta) {
/* 155 */     double[] original = { section.getRotW(), section.getRotX(), section.getRotY(), section.getRotZ() };
/*     */     
/* 157 */     double theta = Math.acos(Maths.dotProductOfQuaternions(original, target));
/* 158 */     if (theta < this.animation.MAX_ROT_CHANGE_PER_MILLI * delta) {
/* 159 */       section.setRotation(target[0], target[1], target[2], target[3]);
/* 160 */       return;
/*     */     }
/* 162 */     double scalar = this.animation.MAX_ROT_CHANGE_PER_MILLI * delta / theta;
/* 163 */     double[] smoothed = slerp(original, target, scalar);
/* 164 */     section.setRotation(smoothed[0], smoothed[1], smoothed[2], smoothed[3]);
/*     */   }
/*     */   
/*     */   private void smoothlySetScale(AnimatablePart entitySection, float target, float delta) {
/* 168 */     float scale = getSmoothedResult(entitySection.getScale(), target, this.animation.MAX_SCALE_CHANGE_PER_MILLI * delta);
/*     */     
/* 170 */     entitySection.setScale(scale);
/*     */   }
/*     */   
/*     */   private double[] slerp(double[] qA, double[] qB, double time) {
/* 174 */     double[] result = new double[4];
/* 175 */     double cosHalfTheta = Maths.dotProductOfQuaternions(qA, qB);
/* 176 */     if (Math.abs(cosHalfTheta) >= 1.0D) {
/* 177 */       result[0] = qA[0];
/* 178 */       result[1] = qA[1];
/* 179 */       result[2] = qA[2];
/* 180 */       result[3] = qA[3];
/* 181 */       return result;
/*     */     }
/* 183 */     double halfTheta = Math.acos(cosHalfTheta);
/* 184 */     double sinHalfTheta = Math.sqrt(1.0D - cosHalfTheta * cosHalfTheta);
/* 185 */     if (Math.abs((float)sinHalfTheta) < 0.001D) {
/* 186 */       result[0] = ((float)(qA[0] * 0.5D + qB[0] * 0.5D));
/* 187 */       result[1] = ((float)(qA[1] * 0.5D + qB[1] * 0.5D));
/* 188 */       result[2] = ((float)(qA[2] * 0.5D + qB[2] * 0.5D));
/* 189 */       result[3] = ((float)(qA[3] * 0.5D + qB[3] * 0.5D));
/* 190 */       return result;
/*     */     }
/* 192 */     double ratioA = Math.sin((1.0D - time) * halfTheta) / sinHalfTheta;
/* 193 */     double ratioB = Math.sin(time * halfTheta) / sinHalfTheta;
/* 194 */     result[0] = ((float)(qA[0] * ratioA + qB[0] * ratioB));
/* 195 */     result[1] = ((float)(qA[1] * ratioA + qB[1] * ratioB));
/* 196 */     result[2] = ((float)(qA[2] * ratioA + qB[2] * ratioB));
/* 197 */     result[3] = ((float)(qA[3] * ratioA + qB[3] * ratioB));
/* 198 */     return result;
/*     */   }
/*     */   
/*     */   private float getSmoothedResult(float before, float after, float max) {
/* 202 */     if (after - before > max)
/* 203 */       return before + max;
/* 204 */     if (after - before < -max) {
/* 205 */       return before - max;
/*     */     }
/* 207 */     return after;
/*     */   }
/*     */   
/*     */   private float calcMidValue(int first, int last, float firstValue, float lastValue, float time)
/*     */   {
/* 212 */     return firstValue + (lastValue - firstValue) / (last - first) * (time - first);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\animations\AnimationSection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */