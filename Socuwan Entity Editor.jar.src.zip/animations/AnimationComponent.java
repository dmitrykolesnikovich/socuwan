/*     */ package animations;
/*     */ 
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import entitiesInterfaces.AnimatedSection;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimationComponent
/*     */ {
/*     */   private AnimatedSection[] sections;
/*     */   private AnimatedSection[] headNodes;
/*     */   private Animation currentAnimation;
/*     */   private float currentAnimationTime;
/*     */   private Animation nextAnimation;
/*     */   
/*     */   public AnimationComponent(AnimationComponentBlueprint blueprint)
/*     */   {
/*  22 */     createInstancesOfBones(blueprint);
/*     */   }
/*     */   
/*     */   public AnimatedSection[] getHeadNodes() {
/*  26 */     return this.headNodes;
/*     */   }
/*     */   
/*     */   public AnimatedSection[] getSections() {
/*  30 */     return this.sections;
/*     */   }
/*     */   
/*     */   public void update()
/*     */   {
/*  35 */     animateForCurrentFrame(RenderEngine.getDeltaInSeconds());
/*     */   }
/*     */   
/*     */   public void suggestAnimation(Animation anim)
/*     */   {
/*  40 */     this.nextAnimation = anim;
/*     */   }
/*     */   
/*     */   protected float getCurrentAnimationTime() {
/*  44 */     return this.currentAnimationTime;
/*     */   }
/*     */   
/*     */   protected Animation getCurrentAnimation() {
/*  48 */     return this.currentAnimation;
/*     */   }
/*     */   
/*     */   public void animateForCurrentFrame(float deltaInSeconds) {
/*  52 */     if (this.nextAnimation == null) {
/*  53 */       return;
/*     */     }
/*  55 */     if (this.nextAnimation == this.currentAnimation) {
/*  56 */       this.currentAnimationTime = this.currentAnimation.increaseAnimationTime(this.currentAnimationTime, deltaInSeconds);
/*     */     }
/*     */     else {
/*  59 */       this.currentAnimation = this.nextAnimation;
/*  60 */       this.currentAnimationTime = 0.0F;
/*     */     }
/*  62 */     this.currentAnimation.animateEntitySectionsAtTime(this.sections, this.currentAnimationTime, deltaInSeconds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void createInstancesOfBones(AnimationComponentBlueprint blueprint)
/*     */   {
/*  69 */     this.sections = new AnimatedSection[blueprint.getNumberOfBones()];
/*  70 */     List<AnimatedSection> nodesToProcess = new ArrayList();
/*  71 */     createHeadNodes(blueprint.getHeadBones(), nodesToProcess);
/*  72 */     while (!nodesToProcess.isEmpty()) {
/*  73 */       processNode((AnimatedSection)nodesToProcess.remove(0), nodesToProcess);
/*     */     }
/*     */   }
/*     */   
/*     */   private void createHeadNodes(BoneBlueprint[] headBones, List<AnimatedSection> nodesToProcess) {
/*  78 */     int bonesNumber = headBones.length;
/*  79 */     this.headNodes = new AnimatedSection[bonesNumber];
/*  80 */     for (int i = 0; i < bonesNumber; i++) {
/*  81 */       AnimatedSection section = new AnimatedSection(headBones[i]);
/*  82 */       this.headNodes[i] = section;
/*  83 */       nodesToProcess.add(section);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processNode(AnimatedSection node, List<AnimatedSection> nodesToProcess) {
/*  88 */     BoneBlueprint nodeBone = node.getBone();
/*     */     try {
/*  90 */       this.sections[nodeBone.getPartID()] = node;
/*     */     } catch (ArrayIndexOutOfBoundsException e) {
/*  92 */       System.err.println("Mismatch for number of bones for animated model! ");
/*  93 */       System.err.println(nodeBone.getPartID() + " is out of bounds!");
/*  94 */       System.exit(-1);
/*     */     }
/*  96 */     List<BoneBlueprint> children = nodeBone.getChildren();
/*  97 */     for (BoneBlueprint child : children) {
/*  98 */       AnimatedSection section = new AnimatedSection(child, node);
/*  99 */       node.addChild(section);
/* 100 */       nodesToProcess.add(section);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\animations\AnimationComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */