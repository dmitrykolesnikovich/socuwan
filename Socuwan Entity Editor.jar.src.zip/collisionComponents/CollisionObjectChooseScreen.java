/*     */ package collisionComponents;
/*     */ 
/*     */ import frontend.ErrorPopUp;
/*     */ import frontend.FileInList;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.Configs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollisionObjectChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a Collision Object!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   private JButton button;
/*     */   private JButton removeButton;
/*     */   private CollisionPanel collisionPanel;
/*     */   private CollisionObject currentObject;
/*     */   private CollisionComponent component;
/*     */   private CollisionObjectPanel buttonsPanel;
/*     */   
/*     */   public CollisionObjectChooseScreen(JButton button, CollisionObject current, CollisionPanel collisionPanel, JButton removeButton, CollisionComponent component, CollisionObjectPanel buttonsPanel)
/*     */   {
/*  49 */     this.button = button;
/*  50 */     this.removeButton = removeButton;
/*  51 */     this.buttonsPanel = buttonsPanel;
/*  52 */     this.collisionPanel = collisionPanel;
/*  53 */     this.component = component;
/*  54 */     this.currentObject = current;
/*  55 */     setUpFrame();
/*  56 */     addLabel();
/*  57 */     addFileList(getAllModelFiles());
/*  58 */     addButton();
/*  59 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  63 */     this.frame = new JDialog();
/*  64 */     this.frame.setAlwaysOnTop(true);
/*  65 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  66 */     this.frame.setSize(300, 500);
/*  67 */     this.frame.setResizable(false);
/*  68 */     this.frame.setLocationRelativeTo(null);
/*  69 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  73 */     GridBagConstraints gc = new GridBagConstraints();
/*  74 */     gc.gridx = 0;
/*  75 */     gc.gridy = 1;
/*  76 */     gc.weightx = 1.0D;
/*  77 */     gc.weighty = 1.0D;
/*     */     
/*  79 */     FileInList[] data = getAllFilesInList(files);
/*  80 */     this.list = new JList(data);
/*  81 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  82 */     this.list.setSelectionMode(1);
/*  83 */     this.list.setLayoutOrientation(0);
/*  84 */     this.list.setVisibleRowCount(-1);
/*  85 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  86 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  87 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  91 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  92 */     for (int i = 0; i < listedFiles.length; i++) {
/*  93 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  95 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  99 */     JLabel text = new JLabel("Choose a Collision Object!");
/* 100 */     text.setFont(new Font("Segoe UI", 1, 15));
/* 101 */     GridBagConstraints gc = new GridBagConstraints();
/* 102 */     gc.gridx = 0;
/* 103 */     gc.gridy = 0;
/* 104 */     gc.weightx = 1.0D;
/* 105 */     gc.weighty = 0.4D;
/* 106 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/* 110 */     this.confirm = new JButton("Open");
/* 111 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/* 112 */     GridBagConstraints gc = new GridBagConstraints();
/* 113 */     gc.gridx = 0;
/* 114 */     gc.gridy = 2;
/* 115 */     gc.weightx = 1.0D;
/* 116 */     gc.weighty = 0.4D;
/* 117 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 121 */         if (!CollisionObjectChooseScreen.this.list.isSelectionEmpty()) {
/* 122 */           File chosen = ((FileInList)CollisionObjectChooseScreen.this.list.getSelectedValue()).getFile();
/*     */           try {
/* 124 */             CollisionObject object = ParserApp.loadCollisionObjectFile(chosen);
/* 125 */             if (CollisionObjectChooseScreen.this.currentObject == null) {
/* 126 */               CollisionObjectChooseScreen.this.removeButton.setVisible(true);
/* 127 */               CollisionObjectChooseScreen.this.collisionPanel.addButtonPanel();
/* 128 */               CollisionObjectChooseScreen.this.buttonsPanel.addSlider();
/*     */             } else {
/* 130 */               CollisionObjectChooseScreen.this.component.removeCollisionObject(CollisionObjectChooseScreen.this.currentObject);
/*     */             }
/* 132 */             CollisionObjectChooseScreen.this.buttonsPanel.setObject(object);
/* 133 */             CollisionObjectChooseScreen.this.component.addCollisionObject(object);
/* 134 */             CollisionObjectChooseScreen.this.button.setText(chosen.getName());
/* 135 */             CollisionObjectChooseScreen.this.button.setForeground(new Color(0, 155, 0));
/* 136 */             CollisionObjectChooseScreen.this.frame.setVisible(false);
/*     */           } catch (Exception e) {
/* 138 */             e.printStackTrace();
/* 139 */             System.err.println("Invalid collision obj file!");
/* 140 */             new ErrorPopUp("Invalid OBJ file format!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 146 */     });
/* 147 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllModelFiles() {
/* 151 */     File[] allFiles = Configs.COLLISION_OBJS_REPOS.listFiles();
/* 152 */     List<File> goodFiles = new ArrayList();
/* 153 */     for (File file : allFiles) {
/* 154 */       if (file.getName().endsWith(".obj")) {
/* 155 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 158 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\CollisionObjectChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */