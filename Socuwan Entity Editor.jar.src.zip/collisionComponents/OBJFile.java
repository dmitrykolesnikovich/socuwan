/*     */ package collisionComponents;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import toolbox.Triangle;
/*     */ 
/*     */ public class OBJFile
/*     */ {
/*     */   private List<Vector3f> points;
/*     */   private List<Triangle> triangles;
/*     */   private float minX;
/*     */   private float maxX;
/*     */   private float minY;
/*     */   private float maxY;
/*     */   private float minZ;
/*     */   private float maxZ;
/*     */   private boolean first;
/*     */   private BufferedReader reader;
/*     */   
/*     */   public OBJFile(java.io.File file) throws Exception
/*     */   {
/*  25 */     java.io.FileReader isr = new java.io.FileReader(file);
/*  26 */     this.reader = new BufferedReader(isr);
/*  27 */     this.points = new ArrayList();
/*  28 */     this.triangles = new ArrayList();
/*  29 */     this.first = true;
/*     */   }
/*     */   
/*     */   public Triangle[] extractTriangles() throws IOException {
/*     */     String line;
/*  34 */     while ((line = this.reader.readLine()) != null) {
/*  35 */       String[] values = line.split(" ");
/*  36 */       if (values[0].equals("v")) {
/*  37 */         processVertex(values);
/*  38 */       } else if (values[0].equals("f")) {
/*  39 */         processFace(values);
/*     */       }
/*     */     }
/*  42 */     Triangle[] triangleArray = new Triangle[this.triangles.size()];
/*  43 */     for (int i = 0; i < this.triangles.size(); i++) {
/*  44 */       triangleArray[i] = ((Triangle)this.triangles.get(i));
/*     */     }
/*  46 */     return triangleArray;
/*     */   }
/*     */   
/*     */   public void closeFile() throws IOException {
/*  50 */     this.reader.close();
/*     */   }
/*     */   
/*     */   public AxisBounds getXBounds() {
/*  54 */     return new AxisBounds(this.minX, this.maxX);
/*     */   }
/*     */   
/*     */   public AxisBounds getYBounds() {
/*  58 */     return new AxisBounds(this.minY, this.maxY);
/*     */   }
/*     */   
/*     */   public AxisBounds getZBounds() {
/*  62 */     return new AxisBounds(this.minZ, this.maxZ);
/*     */   }
/*     */   
/*     */   private void processVertex(String[] vertexValues) {
/*  66 */     float x = Float.parseFloat(vertexValues[1]);
/*  67 */     float y = Float.parseFloat(vertexValues[2]);
/*  68 */     float z = Float.parseFloat(vertexValues[3]);
/*  69 */     Vector3f point = new Vector3f(x, y, z);
/*  70 */     testForBounds(point);
/*  71 */     this.points.add(point);
/*     */   }
/*     */   
/*     */   private void processFace(String[] faceValues) {
/*  75 */     Vector3f p2 = (Vector3f)this.points.get(Integer.parseInt(faceValues[1].split("/")[0]) - 1);
/*  76 */     Vector3f p1 = (Vector3f)this.points.get(Integer.parseInt(faceValues[2].split("/")[0]) - 1);
/*  77 */     Vector3f p0 = (Vector3f)this.points.get(Integer.parseInt(faceValues[3].split("/")[0]) - 1);
/*  78 */     this.triangles.add(new Triangle(p0, p1, p2));
/*     */   }
/*     */   
/*     */   private void testForBounds(Vector3f point) {
/*  82 */     if (this.first) {
/*  83 */       setAllBounds(point);
/*     */     } else {
/*  85 */       if (point.x < this.minX) {
/*  86 */         this.minX = point.x;
/*  87 */       } else if (point.x > this.maxX) {
/*  88 */         this.maxX = point.x;
/*     */       }
/*  90 */       if (point.y < this.minY) {
/*  91 */         this.minY = point.y;
/*  92 */       } else if (point.y > this.maxY) {
/*  93 */         this.maxY = point.y;
/*     */       }
/*  95 */       if (point.z < this.minZ) {
/*  96 */         this.minZ = point.z;
/*  97 */       } else if (point.z > this.maxZ) {
/*  98 */         this.maxZ = point.z;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void setAllBounds(Vector3f point) {
/* 104 */     this.minX = point.x;
/* 105 */     this.maxX = point.x;
/* 106 */     this.minY = point.y;
/* 107 */     this.maxY = point.y;
/* 108 */     this.minZ = point.z;
/* 109 */     this.maxZ = point.z;
/* 110 */     this.first = false;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\OBJFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */