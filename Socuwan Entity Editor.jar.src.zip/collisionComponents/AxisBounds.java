/*    */ package collisionComponents;
/*    */ 
/*    */ public class AxisBounds
/*    */ {
/*    */   private static final float SAFETY_MARGIN = 0.5F;
/*    */   private float min;
/*    */   private float max;
/*    */   
/*    */   public AxisBounds(float min, float max)
/*    */   {
/* 11 */     this.max = (max + 0.5F);
/* 12 */     this.min = (min - 0.5F);
/*    */   }
/*    */   
/*    */   public float getMin() {
/* 16 */     return this.min;
/*    */   }
/*    */   
/*    */   public float getMax() {
/* 20 */     return this.max;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\AxisBounds.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */