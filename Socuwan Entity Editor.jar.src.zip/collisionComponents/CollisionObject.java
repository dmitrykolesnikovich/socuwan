/*     */ package collisionComponents;
/*     */ 
/*     */ import backend.StaticEntity;
/*     */ import blueprintInterfaces.RawModel;
/*     */ import epicRenderEngine.Loader;
/*     */ import java.io.PrintWriter;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import texture.ModelTexture;
/*     */ import toolbox.Triangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollisionObject
/*     */ {
/*     */   private String name;
/*     */   private Triangle[] triangles;
/*     */   private AxisBounds xBounds;
/*     */   private AxisBounds yBounds;
/*     */   private AxisBounds zBounds;
/*  24 */   private float scale = 1.0F;
/*     */   
/*     */   private StaticEntity entity;
/*     */   private float[] vertices;
/*     */   private float[] textures;
/*     */   private float[] normals;
/*     */   private int[] indices;
/*     */   
/*     */   public CollisionObject(String name, Triangle[] hull, AxisBounds x, AxisBounds y, AxisBounds z)
/*     */   {
/*  34 */     this.name = name;
/*  35 */     this.triangles = hull;
/*  36 */     this.xBounds = x;
/*  37 */     this.yBounds = y;
/*  38 */     this.zBounds = z;
/*  39 */     toRawModel();
/*     */   }
/*     */   
/*     */   public float getScale() {
/*  43 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setScale(float scale) {
/*  47 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public float[] getVertices() {
/*  51 */     return this.vertices;
/*     */   }
/*     */   
/*     */   public void setVertices(float[] vertices) {
/*  55 */     this.vertices = vertices;
/*     */   }
/*     */   
/*     */   public float[] getTextures() {
/*  59 */     return this.textures;
/*     */   }
/*     */   
/*     */   public void setTextures(float[] textures) {
/*  63 */     this.textures = textures;
/*     */   }
/*     */   
/*     */   public float[] getNormals() {
/*  67 */     return this.normals;
/*     */   }
/*     */   
/*     */   public void setNormals(float[] normals) {
/*  71 */     this.normals = normals;
/*     */   }
/*     */   
/*     */   public int[] getIndices() {
/*  75 */     return this.indices;
/*     */   }
/*     */   
/*     */   public void setIndices(int[] indices) {
/*  79 */     this.indices = indices;
/*     */   }
/*     */   
/*     */   public void setLoadedRawModel(RawModel model) {
/*  83 */     this.entity = new StaticEntity(model, new ModelTexture(0));
/*  84 */     this.entity.setWireframe(true);
/*     */   }
/*     */   
/*     */   public String getName() {
/*  88 */     return this.name;
/*     */   }
/*     */   
/*     */   public StaticEntity getPreview() {
/*  92 */     return this.entity;
/*     */   }
/*     */   
/*     */   public Triangle[] getTriangles() {
/*  96 */     return this.triangles;
/*     */   }
/*     */   
/*     */   public AxisBounds getxBounds() {
/* 100 */     return this.xBounds;
/*     */   }
/*     */   
/*     */   public AxisBounds getyBounds() {
/* 104 */     return this.yBounds;
/*     */   }
/*     */   
/*     */   public AxisBounds getzBounds() {
/* 108 */     return this.zBounds;
/*     */   }
/*     */   
/*     */   public void writeToFile(PrintWriter writer) {
/* 112 */     writer.println(this.name);
/* 113 */     writer.println(this.xBounds.getMin() * this.scale + ";" + this.xBounds.getMax() * this.scale);
/* 114 */     writer.println(this.yBounds.getMin() * this.scale + ";" + this.scale * this.yBounds.getMax());
/* 115 */     writer.println(this.zBounds.getMin() * this.scale + ";" + this.scale * this.zBounds.getMax());
/* 116 */     writer.println(this.triangles.length);
/* 117 */     for (Triangle triangle : this.triangles) {
/* 118 */       printVector(triangle.getPointN(0), writer);
/* 119 */       printVector(triangle.getPointN(1), writer);
/* 120 */       printVector(triangle.getPointN(2), writer);
/* 121 */       writer.println();
/*     */     }
/*     */   }
/*     */   
/*     */   private void printVector(Vector3f vector, PrintWriter writer) {
/* 126 */     writer.print(vector.x * this.scale + ";" + vector.y * this.scale + ";" + vector.z * this.scale + ";");
/*     */   }
/*     */   
/*     */   public void toRawModel() {
/* 130 */     int pointer = 0;
/* 131 */     this.indices = new int[this.triangles.length * 3];
/* 132 */     this.vertices = new float[this.triangles.length * 9];
/* 133 */     this.normals = new float[this.triangles.length * 9];
/* 134 */     this.textures = new float[this.triangles.length * 6];
/* 135 */     for (Triangle triangle : this.triangles) {
/* 136 */       Vector3f point2 = triangle.getPointN(2);
/* 137 */       Vector3f point1 = triangle.getPointN(1);
/* 138 */       Vector3f point0 = triangle.getPointN(0);
/* 139 */       this.vertices[(pointer++)] = point2.x;
/* 140 */       this.vertices[(pointer++)] = point2.y;
/* 141 */       this.vertices[(pointer++)] = point2.z;
/* 142 */       this.vertices[(pointer++)] = point1.x;
/* 143 */       this.vertices[(pointer++)] = point1.y;
/* 144 */       this.vertices[(pointer++)] = point1.z;
/* 145 */       this.vertices[(pointer++)] = point0.x;
/* 146 */       this.vertices[(pointer++)] = point0.y;
/* 147 */       this.vertices[(pointer++)] = point0.z;
/*     */     }
/* 149 */     for (int i = 0; i < this.indices.length; i++) {
/* 150 */       this.indices[i] = i;
/*     */     }
/* 152 */     for (int i = 0; i < this.textures.length; i++) {
/* 153 */       this.textures[i] = 0.0F;
/*     */     }
/* 155 */     for (int i = 0; i < this.normals.length; i++) {
/* 156 */       this.normals[i] = 0.0F;
/*     */     }
/* 158 */     Loader.requestCollisionObjectLoading(this);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\CollisionObject.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */