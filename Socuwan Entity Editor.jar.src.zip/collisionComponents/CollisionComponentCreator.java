/*    */ package collisionComponents;
/*    */ 
/*    */ import backend.Entity;
/*    */ import componentArchitecture.Component;
/*    */ import componentArchitecture.ComponentCreator;
/*    */ import instances.EntityInstance;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.PrintStream;
/*    */ import org.lwjgl.util.vector.Vector3f;
/*    */ import toolbox.Triangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollisionComponentCreator
/*    */   implements ComponentCreator
/*    */ {
/*    */   public Component createComponent(Entity entity)
/*    */   {
/* 20 */     return new CollisionComponent(entity.getEntityInstance().getTransformation());
/*    */   }
/*    */   
/*    */ 
/*    */   public Component loadComponent(BufferedReader reader, Entity entity)
/*    */   {
/* 26 */     CollisionComponent component = new CollisionComponent(entity.getEntityInstance().getTransformation());
/*    */     try {
/* 28 */       String line = null;
/* 29 */       while (!(line = reader.readLine()).equals("</CD>")) {
/* 30 */         String name = line;
/* 31 */         String[] values = reader.readLine().split(";");
/* 32 */         AxisBounds x = new AxisBounds(Float.parseFloat(values[0]), Float.parseFloat(values[1]));
/*    */         
/* 34 */         values = reader.readLine().split(";");
/* 35 */         AxisBounds y = new AxisBounds(Float.parseFloat(values[0]), Float.parseFloat(values[1]));
/*    */         
/* 37 */         values = reader.readLine().split(";");
/* 38 */         AxisBounds z = new AxisBounds(Float.parseFloat(values[0]), Float.parseFloat(values[1]));
/*    */         
/* 40 */         Triangle[] triangles = new Triangle[Integer.parseInt(reader.readLine())];
/* 41 */         for (int i = 0; i < triangles.length; i++) {
/* 42 */           String[] vertices = reader.readLine().split(";");
/* 43 */           int pointer = 0;
/* 44 */           Vector3f point0 = new Vector3f(Float.parseFloat(vertices[(pointer++)]), Float.parseFloat(vertices[(pointer++)]), Float.parseFloat(vertices[(pointer++)]));
/*    */           
/*    */ 
/* 47 */           Vector3f point1 = new Vector3f(Float.parseFloat(vertices[(pointer++)]), Float.parseFloat(vertices[(pointer++)]), Float.parseFloat(vertices[(pointer++)]));
/*    */           
/*    */ 
/* 50 */           Vector3f point2 = new Vector3f(Float.parseFloat(vertices[(pointer++)]), Float.parseFloat(vertices[(pointer++)]), Float.parseFloat(vertices[(pointer++)]));
/*    */           
/*    */ 
/* 53 */           triangles[i] = new Triangle(point0, point1, point2);
/*    */         }
/* 55 */         component.addCollisionObject(new CollisionObject(name, triangles, x, y, z));
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 59 */       e.printStackTrace();
/* 60 */       System.err.println("Couldn't read collision component");
/* 61 */       return null;
/*    */     }
/* 63 */     return component;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\CollisionComponentCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */