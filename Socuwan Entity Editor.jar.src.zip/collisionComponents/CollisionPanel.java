/*    */ package collisionComponents;
/*    */ 
/*    */ import componentArchitecture.ComponentListPanel;
/*    */ import componentArchitecture.ComponentPanel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class CollisionPanel
/*    */   extends ComponentPanel
/*    */ {
/*    */   private JPanel settingsPanel;
/*    */   private CollisionComponent collisionComponent;
/*    */   
/*    */   public CollisionPanel(CollisionComponent component, ComponentListPanel listPanel)
/*    */   {
/* 15 */     super(component, listPanel);
/* 16 */     component.showPreview(true);
/* 17 */     this.settingsPanel = super.getSettingsPanel();
/* 18 */     this.collisionComponent = component;
/* 19 */     for (CollisionObject object : component.getCollisionObjects()) {
/* 20 */       new CollisionObjectPanel(object, this, this.settingsPanel, this.collisionComponent);
/*    */     }
/* 22 */     addButtonPanel();
/*    */   }
/*    */   
/*    */   public void addButtonPanel() {
/* 26 */     new CollisionObjectPanel(this, this.settingsPanel, this.collisionComponent);
/*    */   }
/*    */   
/*    */   public void cleanUp()
/*    */   {
/* 31 */     this.collisionComponent.showPreview(false);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\CollisionPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */