/*     */ package collisionComponents;
/*     */ 
/*     */ import frontend.MainFrame;
/*     */ import frontend.Slider;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollisionObjectPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final String UNCHOSEN = "Add Collision Object";
/*     */   private CollisionObject object;
/*     */   private Slider slider;
/*     */   
/*     */   public CollisionObjectPanel(CollisionObject object, final CollisionPanel panel, final JPanel settingsPanel, final CollisionComponent component)
/*     */   {
/*  27 */     setLayout(new GridBagLayout());
/*  28 */     this.object = object;
/*  29 */     final JButton addButton = new JButton("Add Collision Object");
/*  30 */     addButton.setPreferredSize(new Dimension(230, 25));
/*  31 */     addButton.setFont(MainFrame.SMALL_FONT);
/*  32 */     addButton.setText(object.getName());
/*  33 */     addButton.setForeground(new Color(0, 155, 0));
/*  34 */     final JButton removeButton = new JButton("Remove");
/*  35 */     removeButton.setPreferredSize(new Dimension(100, 25));
/*  36 */     addSlider();
/*  37 */     addButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  41 */         new CollisionObjectChooseScreen(addButton, CollisionObjectPanel.this.object, panel, removeButton, component, CollisionObjectPanel.this);
/*     */       }
/*     */       
/*  44 */     });
/*  45 */     add(addButton, getGC(0, 0, 1));
/*     */     
/*  47 */     removeButton.setFont(MainFrame.SMALL_FONT);
/*  48 */     add(removeButton, getGC(1, 0, 1));
/*  49 */     removeButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*  53 */         settingsPanel.remove(CollisionObjectPanel.this);
/*  54 */         component.removeCollisionObject(CollisionObjectPanel.this.object);
/*  55 */         settingsPanel.validate();
/*  56 */         settingsPanel.repaint();
/*     */       }
/*     */       
/*  59 */     });
/*  60 */     settingsPanel.add(this);
/*  61 */     settingsPanel.validate();
/*  62 */     settingsPanel.repaint();
/*     */   }
/*     */   
/*     */   public CollisionObjectPanel(final CollisionPanel panel, final JPanel settingsPanel, final CollisionComponent component)
/*     */   {
/*  67 */     setLayout(new GridBagLayout());
/*  68 */     final JButton addButton = new JButton("Add Collision Object");
/*  69 */     addButton.setPreferredSize(new Dimension(230, 25));
/*  70 */     addButton.setFont(MainFrame.SMALL_FONT);
/*  71 */     addButton.setForeground(new Color(255, 0, 0));
/*  72 */     final JButton removeButton = new JButton("Remove");
/*  73 */     removeButton.setPreferredSize(new Dimension(100, 25));
/*  74 */     removeButton.setVisible(false);
/*  75 */     addButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  79 */         new CollisionObjectChooseScreen(addButton, CollisionObjectPanel.this.object, panel, removeButton, component, CollisionObjectPanel.this);
/*     */       }
/*     */       
/*  82 */     });
/*  83 */     add(addButton, getGC(0, 0, 1));
/*     */     
/*  85 */     removeButton.setFont(MainFrame.SMALL_FONT);
/*  86 */     add(removeButton, getGC(1, 0, 1));
/*  87 */     removeButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*  91 */         settingsPanel.remove(CollisionObjectPanel.this);
/*  92 */         component.removeCollisionObject(CollisionObjectPanel.this.object);
/*  93 */         settingsPanel.validate();
/*  94 */         settingsPanel.repaint();
/*     */       }
/*     */       
/*     */ 
/*  98 */     });
/*  99 */     settingsPanel.add(this);
/* 100 */     settingsPanel.validate();
/* 101 */     settingsPanel.repaint();
/*     */   }
/*     */   
/*     */   public void setObject(CollisionObject object) {
/* 105 */     this.object = object;
/* 106 */     object.setScale(this.slider.getSliderReading());
/*     */   }
/*     */   
/*     */   public void addSlider() {
/* 110 */     float start = 1.0F;
/* 111 */     if (this.object != null) {
/* 112 */       start = this.object.getScale();
/*     */     }
/* 114 */     this.slider = new Slider("Scale", start, 0.0F, 8.0F, false, 270, 50);
/* 115 */     this.slider.addSliderListener(new ChangeListener()
/*     */     {
/*     */ 
/*     */       public void stateChanged(ChangeEvent arg0) {
/* 119 */         CollisionObjectPanel.this.object.setScale(CollisionObjectPanel.this.slider.getSliderReading()); }
/* 120 */     });
/* 121 */     add(this.slider, getGC(0, 1, 2));
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y, int width) {
/* 125 */     GridBagConstraints gc = new GridBagConstraints();
/* 126 */     gc.fill = 2;
/* 127 */     gc.gridx = x;
/* 128 */     gc.gridy = y;
/* 129 */     gc.gridwidth = width;
/* 130 */     gc.weightx = 1.0D;
/* 131 */     gc.weighty = 1.0D;
/* 132 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\CollisionObjectPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */