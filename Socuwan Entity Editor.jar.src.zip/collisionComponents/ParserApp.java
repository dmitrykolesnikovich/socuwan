/*    */ package collisionComponents;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ public class ParserApp
/*    */ {
/*    */   public static CollisionObject loadCollisionObjectFile(File objectFile) throws Exception
/*    */   {
/*  9 */     OBJFile objFile = null;
/* 10 */     objFile = new OBJFile(objectFile);
/*    */     
/* 12 */     toolbox.Triangle[] triangles = objFile.extractTriangles();
/* 13 */     AxisBounds x = objFile.getXBounds();
/* 14 */     AxisBounds y = objFile.getYBounds();
/* 15 */     AxisBounds z = objFile.getZBounds();
/* 16 */     objFile.closeFile();
/* 17 */     return new CollisionObject(objectFile.getName(), triangles, x, y, z);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\ParserApp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */