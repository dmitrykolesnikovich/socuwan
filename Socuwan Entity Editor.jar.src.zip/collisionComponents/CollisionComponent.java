/*    */ package collisionComponents;
/*    */ 
/*    */ import componentArchitecture.Component;
/*    */ import componentArchitecture.ComponentFabricator;
/*    */ import componentArchitecture.ComponentListPanel;
/*    */ import componentArchitecture.ComponentPanel;
/*    */ import componentArchitecture.ComponentType;
/*    */ import epicRenderEngine.RenderEngine;
/*    */ import instances.StaticInstance;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import toolbox.Transformation;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollisionComponent
/*    */   extends Component
/*    */ {
/*    */   public static final String END = "</CD>";
/* 21 */   private List<CollisionObject> collisionObjects = new ArrayList();
/*    */   
/* 23 */   private boolean showPreview = false;
/*    */   private Transformation transform;
/*    */   
/*    */   public CollisionComponent(Transformation transform)
/*    */   {
/* 28 */     super(ComponentType.COLLISION_COMPONENT);
/* 29 */     this.transform = transform;
/*    */   }
/*    */   
/*    */   public List<CollisionObject> getCollisionObjects() {
/* 33 */     return this.collisionObjects;
/*    */   }
/*    */   
/*    */   public void showPreview(boolean show) {
/* 37 */     this.showPreview = show;
/*    */   }
/*    */   
/*    */   public void addCollisionObject(CollisionObject object) {
/* 41 */     this.collisionObjects.add(object);
/*    */   }
/*    */   
/*    */   public void removeCollisionObject(CollisionObject object) {
/* 45 */     this.collisionObjects.remove(object);
/*    */   }
/*    */   
/*    */   public void export(PrintWriter writer)
/*    */   {
/* 50 */     for (CollisionObject object : this.collisionObjects) {
/* 51 */       object.writeToFile(writer);
/*    */     }
/* 53 */     writer.println("</CD>");
/*    */   }
/*    */   
/*    */   public void update(RenderEngine engine)
/*    */   {
/* 58 */     for (CollisionObject object : this.collisionObjects) {
/* 59 */       if ((object.getPreview() != null) && (this.showPreview)) {
/* 60 */         Transformation objectTransform = new Transformation(this.transform.getX(), this.transform.getY(), this.transform.getZ(), this.transform.getRotX(), this.transform.getRotY(), this.transform.getRotZ(), object.getScale());
/*    */         
/* 62 */         engine.processStaticEntity(new StaticInstance(object.getPreview(), objectTransform));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void setInFabricator(ComponentFabricator fabricator)
/*    */   {
/* 69 */     fabricator.setCollisionComponent(this);
/*    */   }
/*    */   
/*    */ 
/*    */   public ComponentPanel getComponentPanel(ComponentListPanel listPanel)
/*    */   {
/* 75 */     return new CollisionPanel(this, listPanel);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\collisionComponents\CollisionComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */