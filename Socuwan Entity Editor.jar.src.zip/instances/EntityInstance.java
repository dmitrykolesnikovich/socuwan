/*     */ package instances;
/*     */ 
/*     */ import backend.Entity;
/*     */ import blueprintInterfaces.BlueprintInterface;
/*     */ import componentArchitecture.Component;
/*     */ import componentArchitecture.ComponentFabricator;
/*     */ import entitiesInterfaces.EntityInterface;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import texture.ModelTexture;
/*     */ import toolbox.Colour;
/*     */ import toolbox.Transformation;
/*     */ 
/*     */ 
/*     */ public abstract class EntityInstance
/*     */   implements EntityInterface
/*     */ {
/*  17 */   public static boolean rotateTextures = true;
/*     */   
/*     */   private static final float TEXTURE_TIME = 3.0F;
/*  20 */   private int textureAtlasIndex = 0;
/*     */   
/*     */   private float distance;
/*     */   
/*     */   private int lod;
/*     */   private Entity blueprint;
/*  26 */   private Transformation transformation = new Transformation(400.0F, 0.0F, 400.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   
/*  28 */   private boolean show = true;
/*     */   
/*  30 */   private float countdown = 3.0F;
/*     */   
/*     */   public EntityInstance(Entity blueprint) {
/*  33 */     this.blueprint = blueprint;
/*     */   }
/*     */   
/*     */   public EntityInstance(Entity blueprint, Transformation transform) {
/*  37 */     this.blueprint = blueprint;
/*  38 */     this.transformation = transform;
/*     */   }
/*     */   
/*     */   public BlueprintInterface getBlueprint()
/*     */   {
/*  43 */     return this.blueprint;
/*     */   }
/*     */   
/*     */   public void showEntity(boolean show) {
/*  47 */     this.show = show;
/*     */   }
/*     */   
/*     */   public abstract void sendToRenderer(RenderEngine paramRenderEngine);
/*     */   
/*     */   public void update(RenderEngine engine) {
/*  53 */     for (Component component : this.blueprint.getFabricator().getComponents()) {
/*  54 */       component.update(engine);
/*     */     }
/*  56 */     int numberOfTextures = this.blueprint.getTexture().getNumberOfTextures();
/*  57 */     if (rotateTextures) {
/*  58 */       this.countdown -= RenderEngine.getDeltaInSeconds();
/*  59 */       if (this.countdown <= 0.0F) {
/*  60 */         this.textureAtlasIndex += 1;
/*  61 */         this.countdown = 3.0F;
/*     */       }
/*     */     }
/*  64 */     if (this.textureAtlasIndex >= numberOfTextures) {
/*  65 */       this.textureAtlasIndex = 0;
/*     */     }
/*  67 */     if (this.show) {
/*  68 */       sendToRenderer(engine);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isShown()
/*     */   {
/*  74 */     return this.show;
/*     */   }
/*     */   
/*     */ 
/*     */   public Transformation getTransformation()
/*     */   {
/*  80 */     return this.transformation;
/*     */   }
/*     */   
/*     */   public void setDistance(float distance)
/*     */   {
/*  85 */     this.distance = distance;
/*     */   }
/*     */   
/*     */   public float getDistance()
/*     */   {
/*  90 */     return this.distance;
/*     */   }
/*     */   
/*     */   public void setLOD(int lod)
/*     */   {
/*  95 */     this.lod = lod;
/*     */   }
/*     */   
/*     */   public boolean isVisible()
/*     */   {
/* 100 */     return this.distance < getVisibleDistance();
/*     */   }
/*     */   
/*     */   public float getVisibleDistance()
/*     */   {
/* 105 */     return this.blueprint.getVisibleRange() * this.transformation.getScale();
/*     */   }
/*     */   
/*     */   public int getLOD()
/*     */   {
/* 110 */     return this.lod;
/*     */   }
/*     */   
/*     */   public float getFurthestPoint()
/*     */   {
/* 115 */     return this.blueprint.getFurthestPoint();
/*     */   }
/*     */   
/*     */   public float[] getInstanceTextureCoords()
/*     */   {
/* 120 */     float[] textureCoords = new float[3];
/* 121 */     ModelTexture texture = this.blueprint.getTexture();
/* 122 */     textureCoords[1] = texture.getXOffset(this.textureAtlasIndex);
/* 123 */     textureCoords[2] = texture.getYOffset(this.textureAtlasIndex);
/* 124 */     textureCoords[0] = texture.getSize();
/* 125 */     return textureCoords;
/*     */   }
/*     */   
/*     */   public Colour getMaterial1Colour()
/*     */   {
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   public Colour getMaterial2Colour()
/*     */   {
/* 135 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReflectionFlag() {}
/*     */   
/*     */ 
/*     */   public boolean hasReflection()
/*     */   {
/* 145 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\instances\EntityInstance.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */