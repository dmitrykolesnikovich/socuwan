/*    */ package instances;
/*    */ 
/*    */ import backend.AnimatedEntity;
/*    */ import blueprintInterfaces.BoneBlueprint;
/*    */ import epicRenderEngine.RenderEngine;
/*    */ import texture.ModelTexture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerSettings
/*    */ {
/*    */   private static AnimatedEntity playerBlueprint;
/*    */   
/*    */   public static AnimatedEntity getPlayerBlueprint()
/*    */   {
/* 18 */     if (playerBlueprint == null) {
/* 19 */       createPlayerBlueprint();
/*    */     }
/* 21 */     return playerBlueprint;
/*    */   }
/*    */   
/*    */   private static void createPlayerBlueprint() {
/* 25 */     BoneBlueprint hip = new BoneBlueprint(0, RenderEngine.loadModelFile(2, "hip"), 0.0F, 0.0F, 0.0F);
/* 26 */     BoneBlueprint waist = new BoneBlueprint(1, RenderEngine.loadModelFile(32, "waist"), 0.0F, 4.05F, 0.0F);
/*    */     
/* 28 */     BoneBlueprint chest = new BoneBlueprint(2, RenderEngine.loadModelFile(31, "chest"), 0.0F, 4.85F, 0.0F);
/*    */     
/* 30 */     BoneBlueprint head = new BoneBlueprint(3, RenderEngine.loadModelFile(30, "head"), 0.0F, 5.9F, 0.0F);
/*    */     
/* 32 */     BoneBlueprint upperRightArm = new BoneBlueprint(4, RenderEngine.loadModelFile(40, "upperRightArm"), -1.15F, 5.5F, 0.0F);
/*    */     
/* 34 */     BoneBlueprint lowerRightArm = new BoneBlueprint(5, RenderEngine.loadModelFile(41, "lowerRightArm"), -1.15F, 4.4F, 0.0F);
/*    */     
/* 36 */     BoneBlueprint rightHand = new BoneBlueprint(6, RenderEngine.loadModelFile(42, "rightHand"), -1.15F, 3.3F, 0.0F);
/*    */     
/* 38 */     BoneBlueprint upperLeftArm = new BoneBlueprint(7, RenderEngine.loadModelFile(43, "upperLeftArm"), 1.15F, 5.5F, 0.0F);
/*    */     
/* 40 */     BoneBlueprint lowerLeftArm = new BoneBlueprint(8, RenderEngine.loadModelFile(44, "lowerLeftArm"), 1.15F, 4.4F, 0.0F);
/*    */     
/* 42 */     BoneBlueprint leftHand = new BoneBlueprint(9, RenderEngine.loadModelFile(45, "leftHand"), 1.15F, 3.3F, 0.0F);
/*    */     
/* 44 */     BoneBlueprint upperRightLeg = new BoneBlueprint(10, RenderEngine.loadModelFile(34, "upperRightLeg"), -0.45F, 3.2F, 0.0F);
/*    */     
/* 46 */     BoneBlueprint lowerRightLeg = new BoneBlueprint(11, RenderEngine.loadModelFile(35, "lowerRightLeg"), -0.45F, 1.7F, 0.0F);
/*    */     
/* 48 */     BoneBlueprint rightFoot = new BoneBlueprint(12, RenderEngine.loadModelFile(36, "rightFoot"), -0.45F, 0.37F, 0.0F);
/*    */     
/* 50 */     BoneBlueprint upperLeftLeg = new BoneBlueprint(13, RenderEngine.loadModelFile(37, "upperLeftLeg"), 0.45F, 3.2F, 0.0F);
/*    */     
/* 52 */     BoneBlueprint lowerLeftLeg = new BoneBlueprint(14, RenderEngine.loadModelFile(38, "lowerLeftLeg"), 0.45F, 1.7F, 0.0F);
/*    */     
/* 54 */     BoneBlueprint leftFoot = new BoneBlueprint(15, RenderEngine.loadModelFile(39, "leftFoot"), 0.45F, 0.37F, 0.0F);
/*    */     
/*    */ 
/* 57 */     hip.addChildren(new BoneBlueprint[] { waist, upperRightLeg, upperLeftLeg });
/* 58 */     waist.addChildren(new BoneBlueprint[] { chest });
/* 59 */     chest.addChildren(new BoneBlueprint[] { head, upperLeftArm, upperRightArm });
/* 60 */     upperLeftArm.addChildren(new BoneBlueprint[] { lowerLeftArm });
/* 61 */     lowerLeftArm.addChildren(new BoneBlueprint[] { leftHand });
/* 62 */     upperRightArm.addChildren(new BoneBlueprint[] { lowerRightArm });
/* 63 */     lowerRightArm.addChildren(new BoneBlueprint[] { rightHand });
/* 64 */     upperLeftLeg.addChildren(new BoneBlueprint[] { lowerLeftLeg });
/* 65 */     upperRightLeg.addChildren(new BoneBlueprint[] { lowerRightLeg });
/* 66 */     lowerLeftLeg.addChildren(new BoneBlueprint[] { leftFoot });
/* 67 */     lowerRightLeg.addChildren(new BoneBlueprint[] { rightFoot });
/*    */     
/*    */ 
/* 70 */     playerBlueprint = new AnimatedEntity(hip, 16, new ModelTexture(0, "test"));
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\instances\PlayerSettings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */