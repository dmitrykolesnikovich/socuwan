/*    */ package instances;
/*    */ 
/*    */ import backend.StaticEntity;
/*    */ import entitiesInterfaces.StaticEntityInterface;
/*    */ import epicRenderEngine.RenderEngine;
/*    */ import toolbox.Transformation;
/*    */ 
/*    */ public class StaticInstance extends EntityInstance implements StaticEntityInterface
/*    */ {
/*    */   private StaticEntity blueprint;
/*    */   
/*    */   public StaticInstance(StaticEntity blueprint)
/*    */   {
/* 14 */     super(blueprint);
/* 15 */     this.blueprint = blueprint;
/*    */   }
/*    */   
/*    */   public StaticInstance(StaticEntity blueprint, Transformation transform) {
/* 19 */     super(blueprint, transform);
/* 20 */     this.blueprint = blueprint;
/*    */   }
/*    */   
/*    */   public StaticEntity getBlueprint() {
/* 24 */     return this.blueprint;
/*    */   }
/*    */   
/*    */   public void sendToRenderer(RenderEngine engine)
/*    */   {
/* 29 */     engine.processStaticEntity(this);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\instances\StaticInstance.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */