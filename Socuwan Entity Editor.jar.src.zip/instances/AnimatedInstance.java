/*    */ package instances;
/*    */ 
/*    */ import animations.AnimationComponent;
/*    */ import backend.AnimatedEntity;
/*    */ import entitiesInterfaces.AnimatedEntityInterface;
/*    */ import entitiesInterfaces.AnimatedSection;
/*    */ import epicRenderEngine.RenderEngine;
/*    */ 
/*    */ public class AnimatedInstance
/*    */   extends EntityInstance implements AnimatedEntityInterface
/*    */ {
/*    */   private AnimationComponent animationComponent;
/*    */   
/*    */   public AnimatedInstance(AnimatedEntity blueprint)
/*    */   {
/* 16 */     super(blueprint);
/* 17 */     if (blueprint.getAnimationBlueprint() != null) {
/* 18 */       this.animationComponent = new AnimationComponent(blueprint.getAnimationBlueprint());
/*    */     }
/*    */   }
/*    */   
/*    */   public AnimatedEntity getBlueprint() {
/* 23 */     return (AnimatedEntity)super.getBlueprint();
/*    */   }
/*    */   
/*    */   public AnimationComponent getAnimationComponent() {
/* 27 */     return this.animationComponent;
/*    */   }
/*    */   
/*    */   public void update(RenderEngine engine) {
/* 31 */     if (getBlueprint().hasNewModel()) {
/* 32 */       this.animationComponent = new AnimationComponent(getBlueprint().getAnimationBlueprint());
/*    */     }
/* 34 */     if (this.animationComponent != null) {
/* 35 */       this.animationComponent.update();
/*    */     }
/* 37 */     super.update(engine);
/*    */   }
/*    */   
/*    */   public AnimatedSection[] getSections() {
/* 41 */     if (this.animationComponent != null) {
/* 42 */       return this.animationComponent.getSections();
/*    */     }
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   public AnimatedSection[] getHeadNodes()
/*    */   {
/* 49 */     if (this.animationComponent != null) {
/* 50 */       return this.animationComponent.getHeadNodes();
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public void sendToRenderer(RenderEngine engine)
/*    */   {
/* 58 */     if (this.animationComponent != null) {
/* 59 */       engine.processAnimatedEntity(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\instances\AnimatedInstance.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */