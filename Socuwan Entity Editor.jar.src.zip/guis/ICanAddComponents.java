package guis;

public abstract interface ICanAddComponents
{
  public abstract void addComponent(GUIComponent paramGUIComponent, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  public abstract float getScaleX();
  
  public abstract float getScaleY();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\ICanAddComponents.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */