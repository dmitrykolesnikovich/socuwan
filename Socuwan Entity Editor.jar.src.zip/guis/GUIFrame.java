/*     */ package guis;
/*     */ 
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.opengl.Display;
/*     */ import text.GUIText;
/*     */ import toolbox.MyKeyboard;
/*     */ import toolbox.MyMouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GUIFrame
/*     */   implements ICanAddComponents
/*     */ {
/*     */   private static final String DEFAULT_CORNER_TEX = "newCorner";
/*     */   private static final String DEFAULT_EDGE_TEX = "newEdge";
/*     */   private static final String DEFAULT_BACK_TEX = "newBackground";
/*     */   private static final String POP_CORNER_TEX = "newPopCorner";
/*     */   private static final String POP_EDGE_TEX = "newPopEdge";
/*     */   private static final String POP_BACK_TEX = "newPopBackground";
/*  23 */   private static final Integer CORNER_TEXTURE = Integer.valueOf(RenderEngine.loadTexture("interfaces/newCorner"));
/*     */   
/*  25 */   private static final Integer EDGE_TEXTURE = Integer.valueOf(RenderEngine.loadTexture("interfaces/newEdge"));
/*     */   
/*  27 */   private static final Integer BACK_TEXTURE = Integer.valueOf(RenderEngine.loadTexture("interfaces/newBackground"));
/*     */   
/*     */ 
/*  30 */   private static final Integer POP_CORNER_TEXTURE = Integer.valueOf(RenderEngine.loadTexture("interfaces/newPopCorner"));
/*     */   
/*  32 */   private static final Integer POP_EDGE_TEXTURE = Integer.valueOf(RenderEngine.loadTexture("interfaces/newPopEdge"));
/*     */   
/*  34 */   private static final Integer POP_BACK_TEXTURE = Integer.valueOf(RenderEngine.loadTexture("interfaces/newPopBackground"));
/*     */   
/*     */   private Integer cornerTexture;
/*     */   
/*     */   private Integer edgeTexture;
/*     */   private Integer backgroundTexture;
/*     */   private static final float RIM_SIZE_Y = 0.01F;
/*     */   private static final float POP_UP_RIM_SIZE = 0.01F;
/*     */   private float x;
/*     */   private float y;
/*     */   private float scaleX;
/*     */   private float scaleY;
/*  46 */   private boolean open = false;
/*  47 */   private boolean deleted = false;
/*  48 */   private boolean isPopUp = false;
/*  49 */   private boolean followMouse = false;
/*  50 */   private float lengthsLeft = 1.0F;
/*  51 */   private float lengthsAbove = 1.0F;
/*  52 */   private boolean deleteWhenInactive = false;
/*  53 */   private boolean requiresFullAttention = false;
/*     */   
/*  55 */   private List<GUITexture> frameTextures = new ArrayList();
/*     */   
/*  57 */   private List<GUIComponentLayout> components = new ArrayList();
/*  58 */   private List<GUITextLayout> texts = new ArrayList();
/*     */   
/*     */   public GUIFrame(float x, float y, float scaleX, float scaleY) {
/*  61 */     this.cornerTexture = CORNER_TEXTURE;
/*  62 */     this.edgeTexture = EDGE_TEXTURE;
/*  63 */     this.backgroundTexture = BACK_TEXTURE;
/*  64 */     this.frameTextures = new ArrayList();
/*  65 */     this.x = x;
/*  66 */     this.y = y;
/*  67 */     this.scaleX = scaleX;
/*  68 */     this.scaleY = scaleY;
/*  69 */     initialiseFrameTextures();
/*     */   }
/*     */   
/*     */   public GUIFrame(float x, float y, float scaleX, float scaleY, boolean popUp) {
/*  73 */     if (popUp) {
/*  74 */       this.cornerTexture = POP_CORNER_TEXTURE;
/*  75 */       this.edgeTexture = POP_EDGE_TEXTURE;
/*  76 */       this.backgroundTexture = POP_BACK_TEXTURE;
/*     */     } else {
/*  78 */       this.cornerTexture = CORNER_TEXTURE;
/*  79 */       this.edgeTexture = EDGE_TEXTURE;
/*  80 */       this.backgroundTexture = BACK_TEXTURE;
/*     */     }
/*  82 */     this.isPopUp = popUp;
/*  83 */     this.frameTextures = new ArrayList();
/*  84 */     this.x = x;
/*  85 */     this.y = y;
/*  86 */     this.scaleX = scaleX;
/*  87 */     this.scaleY = scaleY;
/*  88 */     initialiseFrameTextures();
/*     */   }
/*     */   
/*     */   public GUIFrame(float x, float y, float scaleX, float scaleY, boolean popUp, Integer corner, Integer edge, Integer back)
/*     */   {
/*  93 */     this.cornerTexture = corner;
/*  94 */     this.edgeTexture = edge;
/*  95 */     this.backgroundTexture = back;
/*  96 */     this.isPopUp = popUp;
/*  97 */     this.frameTextures = new ArrayList();
/*  98 */     this.x = x;
/*  99 */     this.y = y;
/* 100 */     this.scaleX = scaleX;
/* 101 */     this.scaleY = scaleY;
/* 102 */     initialiseFrameTextures();
/*     */   }
/*     */   
/*     */   public void show() {
/* 106 */     if (!this.open) {
/* 107 */       if (this.isPopUp) {
/* 108 */         GUIManager.openPopUp(this);
/*     */       } else {
/* 110 */         GUIManager.openGUI(this);
/*     */       }
/* 112 */       this.open = true;
/* 113 */       if (this.requiresFullAttention) {
/* 114 */         GUIManager.lockIn(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void hideFrameTextures() {
/* 120 */     this.frameTextures.clear();
/*     */   }
/*     */   
/*     */   public void addSquareComponent(GUIComponent component, float x, float y, float scaleY) {
/* 124 */     float scaleX = this.scaleY / this.scaleX / GUIManager.ASPECT_RATIO * scaleY;
/* 125 */     addComponent(component, x, y, scaleX, scaleY);
/*     */   }
/*     */   
/*     */   public void addSquareComponentX(GUIComponent component, float x, float y, float scaleX) {
/* 129 */     float scaleY = scaleX / (this.scaleY / this.scaleX / GUIManager.ASPECT_RATIO);
/* 130 */     addComponent(component, x, y, scaleX, scaleY);
/*     */   }
/*     */   
/*     */   public void addComponent(GUIComponent component, float x, float y, float scaleX, float scaleY) {
/* 134 */     GUIComponentLayout layout = new GUIComponentLayout(component, x, y, scaleX, scaleY);
/* 135 */     this.components.add(layout);
/* 136 */     setComponentAbsolutePosition(layout);
/*     */   }
/*     */   
/*     */   public void addCenteredComponent(GUIComponent component, float y, float leftLimit, float rightLimit, float scaleX, float scaleY)
/*     */   {
/* 141 */     float x = (rightLimit - leftLimit - scaleX) / 2.0F;
/* 142 */     GUIComponentLayout layout = new GUIComponentLayout(component, x, y, scaleX, scaleY);
/* 143 */     this.components.add(layout);
/* 144 */     setComponentAbsolutePosition(layout);
/*     */   }
/*     */   
/*     */   public void addCenteredSquareComponent(GUIComponent component, float y, float scaleY, float leftLimit, float rightLimit)
/*     */   {
/* 149 */     float scaleX = this.scaleY / this.scaleX / GUIManager.ASPECT_RATIO * scaleY;
/* 150 */     float x = (rightLimit - leftLimit - scaleX) / 2.0F;
/* 151 */     GUIComponentLayout layout = new GUIComponentLayout(component, x, y, scaleX, scaleY);
/* 152 */     this.components.add(layout);
/* 153 */     setComponentAbsolutePosition(layout);
/*     */   }
/*     */   
/*     */   public void addCenteredSquareComponent(GUIComponent component, float y, float scaleY) {
/* 157 */     addCenteredSquareComponent(component, y, scaleY, 0.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public void addText(GUIText text, float x, float y, float xScale) {
/* 161 */     float absX = this.x + this.scaleX * x;
/* 162 */     float absY = this.y + this.scaleY * y;
/* 163 */     float absScaleX = this.scaleX * xScale;
/* 164 */     text.initialise(absX, absY, absScaleX);
/* 165 */     this.texts.add(new GUITextLayout(text, x, y));
/*     */   }
/*     */   
/*     */   public List<GUIText> getTexts() {
/* 169 */     List<GUIText> allTexts = new ArrayList();
/* 170 */     for (GUITextLayout layout : this.texts) {
/* 171 */       allTexts.add(layout.getText());
/*     */     }
/* 173 */     for (GUIComponentLayout componentLayout : this.components) {
/* 174 */       allTexts.addAll(componentLayout.getComponent().getTexts());
/*     */     }
/* 176 */     return allTexts;
/*     */   }
/*     */   
/*     */   public void hide() {
/* 180 */     if (this.open) {
/* 181 */       if (this.isPopUp) {
/* 182 */         GUIManager.closePopUp(this);
/*     */       } else {
/* 184 */         GUIManager.closeGUI(this);
/*     */       }
/* 186 */       this.open = false;
/* 187 */       if (this.requiresFullAttention) {
/* 188 */         GUIManager.releaseLock(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void delete() {
/* 194 */     if (this.deleted == true) {
/* 195 */       return;
/*     */     }
/* 197 */     hide();
/* 198 */     for (GUITextLayout textLayout : this.texts) {
/* 199 */       textLayout.getText().deleteFromMemory();
/*     */     }
/* 201 */     for (GUIComponentLayout componentLayout : this.components) {
/* 202 */       componentLayout.getComponent().delete();
/*     */     }
/* 204 */     this.deleted = true;
/*     */   }
/*     */   
/*     */   public boolean isPopUp() {
/* 208 */     return this.isPopUp;
/*     */   }
/*     */   
/*     */   public boolean isShown() {
/* 212 */     return this.open;
/*     */   }
/*     */   
/*     */   public void setFollowMouse(boolean follow, float lengthsLeft, float lengthsAbove) {
/* 216 */     this.followMouse = true;
/* 217 */     this.lengthsLeft = lengthsLeft;
/* 218 */     this.lengthsAbove = lengthsAbove;
/*     */   }
/*     */   
/*     */   public void setFollowMouse(boolean follow) {
/* 222 */     this.followMouse = true;
/*     */   }
/*     */   
/*     */   public void setDeleteWhenInactive(boolean delete) {
/* 226 */     this.deleteWhenInactive = delete;
/*     */   }
/*     */   
/*     */   public void setRequiresFullAttention(boolean requires) {
/* 230 */     this.requiresFullAttention = requires;
/*     */   }
/*     */   
/*     */   public void moveTo(float x, float y) {
/* 234 */     this.x = x;
/* 235 */     this.y = y;
/* 236 */     for (GUIComponentLayout component : this.components) {
/* 237 */       setComponentAbsolutePosition(component);
/*     */     }
/* 239 */     for (GUITextLayout text : this.texts) {
/* 240 */       setTextAbsolutePosition(text);
/*     */     }
/* 242 */     setTexturePositions();
/*     */   }
/*     */   
/*     */   public List<GUITexture> getFrameTextures() {
/* 246 */     return this.frameTextures;
/*     */   }
/*     */   
/*     */   public List<GUITexture> getTextures() {
/* 250 */     List<GUITexture> info = new ArrayList();
/* 251 */     for (GUIComponentLayout componentLayout : this.components) {
/* 252 */       info.addAll(componentLayout.getComponent().getRenderInfo());
/*     */     }
/* 254 */     return info;
/*     */   }
/*     */   
/*     */   public float getScaleY() {
/* 258 */     return this.scaleY;
/*     */   }
/*     */   
/*     */   protected void updateGUI(MyMouse mouse, MyKeyboard keyboard, boolean frozen) {
/* 262 */     boolean active = false;
/* 263 */     if ((!frozen) && (isMouseOvered(mouse.getX(), mouse.getY()))) {
/* 264 */       mouse.setActiveInGUI(true);
/* 265 */       active = true;
/* 266 */     } else if (this.deleteWhenInactive) {
/* 267 */       delete();
/* 268 */       return;
/*     */     }
/* 270 */     for (GUIComponentLayout componentLayout : this.components) {
/* 271 */       componentLayout.getComponent().update(active, mouse, keyboard);
/*     */     }
/* 273 */     if (this.followMouse) {
/* 274 */       moveTo(mouse.getX() - this.scaleX * this.lengthsLeft, mouse.getY() - this.scaleY * this.lengthsAbove);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getScaleX() {
/* 279 */     return this.scaleX;
/*     */   }
/*     */   
/*     */   protected float getX() {
/* 283 */     return this.x;
/*     */   }
/*     */   
/*     */   protected float getY() {
/* 287 */     return this.y;
/*     */   }
/*     */   
/*     */   private boolean isMouseOvered(float mX, float mY) {
/* 291 */     if ((mX >= this.x) && (mX <= this.x + this.scaleX) && 
/* 292 */       (mY >= this.y) && (mY <= this.y + this.scaleY)) {
/* 293 */       return true;
/*     */     }
/*     */     
/* 296 */     return false;
/*     */   }
/*     */   
/*     */   private void setComponentAbsolutePosition(GUIComponentLayout layout) {
/* 300 */     float absX = this.x + this.scaleX * layout.getRelativeX();
/* 301 */     float absY = this.y + this.scaleY * layout.getRelativeY();
/* 302 */     float absScaleX = this.scaleX * layout.getRelativeScaleX();
/* 303 */     float absScaleY = this.scaleY * layout.getRelativeScaleY();
/* 304 */     layout.getComponent().setPosition(absX, absY, absScaleX, absScaleY);
/*     */   }
/*     */   
/*     */   private void setTextAbsolutePosition(GUITextLayout layout) {
/* 308 */     float absX = this.x + this.scaleX * layout.getRelativeX();
/* 309 */     float absY = this.y + this.scaleY * layout.getRelativeY();
/* 310 */     layout.getText().setPosition(absX, absY);
/*     */   }
/*     */   
/*     */ 
/*     */   private void initialiseFrameTextures()
/*     */   {
/* 316 */     createGUITetures();
/* 317 */     setTexturePositions();
/* 318 */     setTextureSizes();
/* 319 */     setTextureRotations();
/*     */   }
/*     */   
/*     */   private void createGUITetures() {
/* 323 */     this.frameTextures.clear();
/* 324 */     if (this.cornerTexture != null) {
/* 325 */       this.frameTextures.add(new GUITexture(this.cornerTexture.intValue()));
/* 326 */       this.frameTextures.add(new GUITexture(this.cornerTexture.intValue()));
/* 327 */       this.frameTextures.add(new GUITexture(this.cornerTexture.intValue()));
/* 328 */       this.frameTextures.add(new GUITexture(this.cornerTexture.intValue()));
/*     */     }
/* 330 */     if (this.edgeTexture != null) {
/* 331 */       this.frameTextures.add(new GUITexture(this.edgeTexture.intValue()));
/* 332 */       this.frameTextures.add(new GUITexture(this.edgeTexture.intValue()));
/* 333 */       this.frameTextures.add(new GUITexture(this.edgeTexture.intValue()));
/* 334 */       this.frameTextures.add(new GUITexture(this.edgeTexture.intValue()));
/*     */     }
/* 336 */     if (this.backgroundTexture != null) {
/* 337 */       this.frameTextures.add(new GUITexture(this.backgroundTexture.intValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   private void setTexturePositions() {
/* 342 */     float rimSizeY = getRimSizeY();
/* 343 */     float rimX = rimSizeY / (Display.getWidth() / Display.getHeight());
/* 344 */     float yPlusYScaleYMinusRim = this.y + (this.scaleY - rimSizeY);
/* 345 */     float xPlusXScaleMinusRim = this.x + (this.scaleX - rimX);
/* 346 */     float yPlusRim = this.y + rimSizeY;
/* 347 */     float xPlusRim = this.x + rimX;
/* 348 */     int index = 0;
/* 349 */     if (this.cornerTexture != null) {
/* 350 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(this.x, this.y);
/* 351 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(xPlusXScaleMinusRim, this.y);
/* 352 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(this.x, yPlusYScaleYMinusRim);
/* 353 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(xPlusXScaleMinusRim, yPlusYScaleYMinusRim);
/*     */     }
/* 355 */     if (this.edgeTexture != null) {
/* 356 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(xPlusRim, this.y);
/* 357 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(xPlusXScaleMinusRim, yPlusRim);
/* 358 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(xPlusRim, yPlusYScaleYMinusRim);
/* 359 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(this.x, yPlusRim);
/*     */     }
/* 361 */     if (this.backgroundTexture != null) {
/* 362 */       ((GUITexture)this.frameTextures.get(index++)).setPositionValues(xPlusRim, yPlusRim);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setTextureSizes() {
/* 367 */     float rimSizeY = getRimSizeY();
/* 368 */     int index = 0;
/* 369 */     float rimX = rimSizeY / (Display.getWidth() / Display.getHeight());
/* 370 */     float longX = this.scaleX - 2.0F * rimX;
/* 371 */     float longY = this.scaleY - 2.0F * rimSizeY;
/* 372 */     if (this.cornerTexture != null) {
/* 373 */       for (int i = 0; i < 4; i++) {
/* 374 */         ((GUITexture)this.frameTextures.get(index++)).setScaleValues(rimX, rimSizeY);
/*     */       }
/*     */     }
/* 377 */     if (this.edgeTexture != null) {
/* 378 */       ((GUITexture)this.frameTextures.get(index++)).setScaleValues(longX, rimSizeY);
/* 379 */       ((GUITexture)this.frameTextures.get(index++)).setScaleValues(rimX, longY);
/* 380 */       ((GUITexture)this.frameTextures.get(index++)).setScaleValues(longX, rimSizeY);
/* 381 */       ((GUITexture)this.frameTextures.get(index++)).setScaleValues(rimX, longY);
/*     */     }
/* 383 */     if (this.backgroundTexture != null) {
/* 384 */       ((GUITexture)this.frameTextures.get(index++)).setScaleValues(longX, longY);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setTextureRotations() {
/* 389 */     int index = 0;
/* 390 */     if (this.cornerTexture != null) {
/* 391 */       ((GUITexture)this.frameTextures.get(index++)).setRot(0.0F);
/* 392 */       ((GUITexture)this.frameTextures.get(index++)).setRot(-90.0F);
/* 393 */       ((GUITexture)this.frameTextures.get(index++)).setRot(90.0F);
/* 394 */       ((GUITexture)this.frameTextures.get(index++)).setRot(180.0F);
/*     */     }
/* 396 */     if (this.edgeTexture != null) {
/* 397 */       ((GUITexture)this.frameTextures.get(index++)).setRot(0.0F);
/* 398 */       ((GUITexture)this.frameTextures.get(index++)).setRot(-90.0F);
/* 399 */       ((GUITexture)this.frameTextures.get(index++)).setRot(180.0F);
/* 400 */       ((GUITexture)this.frameTextures.get(index++)).setRot(90.0F);
/*     */     }
/* 402 */     if (this.backgroundTexture != null) {
/* 403 */       ((GUITexture)this.frameTextures.get(index++)).setRot(0.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   private float getRimSizeY() {
/* 408 */     float rimSizeY = 0.01F;
/* 409 */     if (this.isPopUp) {
/* 410 */       rimSizeY = 0.01F;
/*     */     }
/* 412 */     return rimSizeY;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\GUIFrame.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */