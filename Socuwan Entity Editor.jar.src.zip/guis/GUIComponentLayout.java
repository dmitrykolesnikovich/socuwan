/*    */ package guis;
/*    */ 
/*    */ public class GUIComponentLayout
/*    */ {
/*    */   private float relativeX;
/*    */   private float relativeY;
/*    */   private float relativeScaleX;
/*    */   private float relativeScaleY;
/*    */   private GUIComponent component;
/*    */   
/*    */   protected GUIComponentLayout(GUIComponent component, float x, float y, float scaleX, float scaleY) {
/* 12 */     this.component = component;
/* 13 */     this.relativeX = x;
/* 14 */     this.relativeY = y;
/* 15 */     this.relativeScaleX = scaleX;
/* 16 */     this.relativeScaleY = scaleY;
/*    */   }
/*    */   
/*    */   protected float getRelativeX() {
/* 20 */     return this.relativeX;
/*    */   }
/*    */   
/*    */   protected float getRelativeY() {
/* 24 */     return this.relativeY;
/*    */   }
/*    */   
/*    */   protected float getRelativeScaleX() {
/* 28 */     return this.relativeScaleX;
/*    */   }
/*    */   
/*    */   protected float getRelativeScaleY() {
/* 32 */     return this.relativeScaleY;
/*    */   }
/*    */   
/*    */   public GUIComponent getComponent() {
/* 36 */     return this.component;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\GUIComponentLayout.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */