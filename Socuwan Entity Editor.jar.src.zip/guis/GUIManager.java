/*     */ package guis;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.opengl.Display;
/*     */ import text.GUIText;
/*     */ import toolbox.MyKeyboard;
/*     */ import toolbox.MyMouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GUIManager
/*     */ {
/*     */   public static final String TEXTURE_SUB_FOLDER = "interfaces/";
/*  16 */   public static final float ASPECT_RATIO = Display.getWidth() / Display.getHeight();
/*     */   
/*  18 */   private static List<GUIFrame> openInterfaces = new ArrayList();
/*  19 */   private static List<GUIFrame> openPopUps = new ArrayList();
/*  20 */   private static List<GUIText> currentTextsInMemory = new ArrayList();
/*     */   
/*  22 */   private static List<GUIFrame> toAdd = new ArrayList();
/*  23 */   private static List<GUIFrame> toRemove = new ArrayList();
/*  24 */   private static List<GUIFrame> popUpsToAdd = new ArrayList();
/*  25 */   private static List<GUIFrame> popUpsToRemove = new ArrayList();
/*     */   
/*     */   private static GUIFrame lock;
/*  28 */   private static boolean releaseLock = false;
/*     */   
/*     */   public static void cleanUp() {
/*  31 */     while (!currentTextsInMemory.isEmpty()) {
/*  32 */       ((GUIText)currentTextsInMemory.get(0)).deleteFromMemory();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void updateGUIs(MyMouse mouse, MyKeyboard keyboard) {
/*  37 */     mouse.setActiveInGUI(false);
/*  38 */     updateLists();
/*  39 */     for (GUIFrame popUp : openPopUps) {
/*  40 */       if ((lock == null) || (popUp == lock)) {
/*  41 */         popUp.updateGUI(mouse, keyboard, false);
/*     */       } else {
/*  43 */         popUp.updateGUI(mouse, keyboard, true);
/*     */       }
/*     */     }
/*  46 */     for (GUIFrame gui : openInterfaces) {
/*  47 */       if ((lock == null) || (gui == lock)) {
/*  48 */         gui.updateGUI(mouse, keyboard, false);
/*     */       } else {
/*  50 */         gui.updateGUI(mouse, keyboard, true);
/*     */       }
/*     */     }
/*     */     
/*  54 */     updateLists();
/*  55 */     if (releaseLock) {
/*  56 */       lock = null;
/*  57 */       releaseLock = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static List<GUIFrame> getGUIsForRender() {
/*  62 */     return openInterfaces;
/*     */   }
/*     */   
/*     */   public static List<GUIFrame> getPopUps() {
/*  66 */     return openPopUps;
/*     */   }
/*     */   
/*     */ 
/*     */   protected static void lockIn(GUIFrame frame)
/*     */   {
/*  72 */     lock = frame;
/*     */   }
/*     */   
/*     */   protected static void releaseLock(GUIFrame frame) {
/*  76 */     if (lock == frame) {
/*  77 */       releaseLock = true;
/*     */     } else {
/*  79 */       System.err.println("GUI attention lock not released, frame doesnt hold lock!!");
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void openGUI(GUIFrame gui) {
/*  84 */     toAdd.add(gui);
/*     */   }
/*     */   
/*     */   protected static void closeGUI(GUIFrame gui) {
/*  88 */     toRemove.add(gui);
/*     */   }
/*     */   
/*     */   protected static void openPopUp(GUIFrame popUp) {
/*  92 */     popUpsToAdd.add(popUp);
/*     */   }
/*     */   
/*     */   protected static void closePopUp(GUIFrame popUp) {
/*  96 */     popUpsToRemove.add(popUp);
/*     */   }
/*     */   
/*     */   public static void addNewText(GUIText text) {
/* 100 */     currentTextsInMemory.add(text);
/*     */   }
/*     */   
/*     */   public static void removeText(GUIText text) {
/* 104 */     currentTextsInMemory.remove(text);
/*     */   }
/*     */   
/*     */   private static void updateLists() {
/* 108 */     openInterfaces.removeAll(toRemove);
/* 109 */     openInterfaces.addAll(toAdd);
/* 110 */     openPopUps.addAll(popUpsToAdd);
/* 111 */     openPopUps.removeAll(popUpsToRemove);
/* 112 */     toAdd.clear();
/* 113 */     toRemove.clear();
/* 114 */     popUpsToRemove.clear();
/* 115 */     popUpsToAdd.clear();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\GUIManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */