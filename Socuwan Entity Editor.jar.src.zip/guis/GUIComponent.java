/*     */ package guis;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import text.GUIText;
/*     */ import toolbox.MyKeyboard;
/*     */ import toolbox.MyMouse;
/*     */ 
/*     */ 
/*     */ public abstract class GUIComponent
/*     */ {
/*     */   private static final float MOUSEOVER_Y_SCALE = 0.05F;
/*     */   private static final float MOUSEOVER_TEXT_SIZE = 0.8F;
/*     */   private static final float MOUSEOVER_MIN_X_SIZE = 0.1F;
/*     */   private static final float MOUSEOVER_TEXT_POS = 0.2F;
/*     */   private float x;
/*     */   private float y;
/*     */   private float scaleX;
/*     */   private float scaleY;
/*  20 */   private List<GUIText> texts = new ArrayList();
/*     */   
/*     */   private GUIFrame mouseOver;
/*     */   
/*     */   private String mouseoverText;
/*     */   
/*     */   public void addMouseoverText(String text)
/*     */   {
/*  28 */     this.mouseoverText = text;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void update(boolean isActive, MyMouse mouse, MyKeyboard keyboard)
/*     */   {
/*  34 */     if (this.mouseoverText != null) {
/*  35 */       if (isActive) {
/*  36 */         if (isMouseOver(mouse)) {
/*  37 */           if (this.mouseOver == null) {
/*  38 */             createMouseover(mouse);
/*     */           }
/*     */         } else {
/*  41 */           deleteMouseover();
/*     */         }
/*     */       } else {
/*  44 */         deleteMouseover();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract List<GUITexture> getRenderInfo();
/*     */   
/*     */   protected List<GUIText> getTexts() {
/*  52 */     return this.texts;
/*     */   }
/*     */   
/*     */   protected void setPosition(float x, float y, float scaleX, float scaleY) {
/*  56 */     this.x = x;
/*  57 */     this.y = y;
/*  58 */     this.scaleX = scaleX;
/*  59 */     this.scaleY = scaleY;
/*     */   }
/*     */   
/*     */   protected float getX() {
/*  63 */     return this.x;
/*     */   }
/*     */   
/*     */   protected float getY() {
/*  67 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getScaleX() {
/*  71 */     return this.scaleX;
/*     */   }
/*     */   
/*     */   public float getScaleY() {
/*  75 */     return this.scaleY;
/*     */   }
/*     */   
/*     */   protected boolean isMouseOver(MyMouse mouse) {
/*  79 */     float mouseX = mouse.getX();
/*  80 */     float mouseY = mouse.getY();
/*  81 */     if ((mouseX >= getX()) && (mouseX <= getX() + getScaleX()) && (mouseY >= getY()) && (mouseY <= getY() + getScaleY()))
/*     */     {
/*  83 */       return true;
/*     */     }
/*  85 */     return false;
/*     */   }
/*     */   
/*     */   public void addText(GUIText text, float x, float y, float sizeX)
/*     */   {
/*  90 */     float absX = this.x + this.scaleX * x;
/*  91 */     float absY = this.y + this.scaleY * y;
/*  92 */     float absScaleX = this.scaleX * sizeX;
/*  93 */     text.initialise(absX, absY, absScaleX);
/*  94 */     this.texts.add(text);
/*     */   }
/*     */   
/*     */   public void removeText(GUIText text) {
/*  98 */     this.texts.remove(text);
/*     */   }
/*     */   
/*     */   public void delete() {
/* 102 */     for (GUIText text : this.texts) {
/* 103 */       text.deleteFromMemory();
/*     */     }
/*     */   }
/*     */   
/*     */   private void createMouseover(MyMouse mouse) {
/* 108 */     deleteMouseover();
/* 109 */     float length = 0.025F / GUIManager.ASPECT_RATIO * this.mouseoverText.length() * 0.8F;
/*     */     
/* 111 */     if (length < 0.1F) {
/* 112 */       length = 0.1F;
/*     */     }
/* 114 */     this.mouseOver = new GUIFrame(mouse.getX() - length, mouse.getY() - 0.05F, length, 0.05F, true);
/*     */     
/* 116 */     this.mouseOver.setFollowMouse(true, 1.0F, 1.0F);
/* 117 */     this.mouseOver.show();
/* 118 */     GUIText guiText = new GUIText(this.mouseoverText, 0.8F);
/* 119 */     guiText.centerText();
/* 120 */     this.mouseOver.addText(guiText, 0.0F, 0.2F, 1.0F);
/*     */   }
/*     */   
/*     */   private void deleteMouseover() {
/* 124 */     if (this.mouseOver != null) {
/* 125 */       this.mouseOver.delete();
/* 126 */       this.mouseOver = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\GUIComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */