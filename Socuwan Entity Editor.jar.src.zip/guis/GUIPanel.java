/*     */ package guis;
/*     */ 
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.opengl.Display;
/*     */ import text.GUIText;
/*     */ import toolbox.MyKeyboard;
/*     */ import toolbox.MyMouse;
/*     */ 
/*     */ 
/*     */ public class GUIPanel
/*     */   extends GUIComponent
/*     */   implements ICanAddComponents
/*     */ {
/*  16 */   private static final int BORDER_EDGE_TEXTURE = RenderEngine.loadTexture("interfaces/panelEdge");
/*     */   
/*  18 */   private static final int BORDER_CORNER_TEXTURE = RenderEngine.loadTexture("interfaces/panelCorner");
/*     */   
/*     */ 
/*     */   private static final float RIM_SIZE_Y = 0.03F;
/*     */   
/*  23 */   private boolean useBorder = true;
/*     */   
/*  25 */   private boolean isPositionSet = false;
/*  26 */   private boolean isShown = false;
/*     */   
/*  28 */   private List<GUITexture> borderTextures = new ArrayList();
/*  29 */   private List<GUIComponentLayout> components = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   public void addComponent(GUIComponent component, float x, float y, float scaleX, float scaleY)
/*     */   {
/*  35 */     GUIComponentLayout layout = new GUIComponentLayout(component, x, y, scaleX, scaleY);
/*  36 */     this.components.add(layout);
/*  37 */     if (this.isPositionSet) {
/*  38 */       setComponentAbsolutePosition(layout);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeComponent(GUIComponent component) {
/*  43 */     GUIComponentLayout toRemove = null;
/*  44 */     for (GUIComponentLayout test : this.components) {
/*  45 */       if (test.getComponent() == component) {
/*  46 */         toRemove = test;
/*  47 */         break;
/*     */       }
/*     */     }
/*  50 */     if (toRemove != null) {
/*  51 */       this.components.remove(toRemove);
/*     */     }
/*     */   }
/*     */   
/*     */   public void show() {
/*  56 */     this.isShown = true;
/*     */   }
/*     */   
/*     */   public void hide() {
/*  60 */     this.isShown = false;
/*     */   }
/*     */   
/*     */   public void turnOffBorder() {
/*  64 */     this.useBorder = false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void update(boolean isActive, MyMouse mouse, MyKeyboard keyboard)
/*     */   {
/*  70 */     if (this.isShown) {
/*  71 */       int i = 0;
/*  72 */       while (i < this.components.size()) {
/*  73 */         ((GUIComponentLayout)this.components.get(i)).getComponent().update(isActive, mouse, keyboard);
/*  74 */         i++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<GUITexture> getRenderInfo()
/*     */   {
/*  81 */     List<GUITexture> allTextures = new ArrayList();
/*  82 */     if (this.isShown) {
/*  83 */       allTextures.addAll(this.borderTextures);
/*  84 */       for (GUIComponentLayout layout : this.components) {
/*  85 */         allTextures.addAll(layout.getComponent().getRenderInfo());
/*     */       }
/*  87 */       return allTextures;
/*     */     }
/*  89 */     return allTextures;
/*     */   }
/*     */   
/*     */   protected void setPosition(float x, float y, float scaleX, float scaleY) {
/*  93 */     super.setPosition(x, y, scaleX, scaleY);
/*  94 */     initialiseFrameTextures(x, y, scaleX, scaleY);
/*  95 */     for (GUIComponentLayout layout : this.components) {
/*  96 */       setComponentAbsolutePosition(layout);
/*     */     }
/*  98 */     this.isPositionSet = true;
/*     */   }
/*     */   
/*     */   protected List<GUIText> getTexts() {
/* 102 */     List<GUIText> texts = new ArrayList();
/* 103 */     if (this.isShown) {
/* 104 */       texts.addAll(super.getTexts());
/* 105 */       for (GUIComponentLayout component : this.components) {
/* 106 */         texts.addAll(component.getComponent().getTexts());
/*     */       }
/*     */     }
/* 109 */     return texts;
/*     */   }
/*     */   
/*     */   private void setComponentAbsolutePosition(GUIComponentLayout layout) {
/* 113 */     float absX = getX() + getScaleX() * layout.getRelativeX();
/* 114 */     float absY = getY() + getScaleY() * layout.getRelativeY();
/* 115 */     float absScaleX = getScaleX() * layout.getRelativeScaleX();
/* 116 */     float absScaleY = getScaleY() * layout.getRelativeScaleY();
/* 117 */     layout.getComponent().setPosition(absX, absY, absScaleX, absScaleY);
/*     */   }
/*     */   
/*     */ 
/*     */   private void initialiseFrameTextures(float x, float y, float scaleX, float scaleY)
/*     */   {
/* 123 */     if (this.useBorder) {
/* 124 */       createGUITetures();
/* 125 */       setTexturePositions(x, y, scaleX, scaleY);
/* 126 */       setTextureSizes(scaleX, scaleY);
/* 127 */       setTextureRotations();
/*     */     }
/*     */   }
/*     */   
/*     */   private void createGUITetures() {
/* 132 */     this.borderTextures.clear();
/*     */     
/* 134 */     this.borderTextures.add(new GUITexture(BORDER_CORNER_TEXTURE));
/* 135 */     this.borderTextures.add(new GUITexture(BORDER_CORNER_TEXTURE));
/* 136 */     this.borderTextures.add(new GUITexture(BORDER_CORNER_TEXTURE));
/* 137 */     this.borderTextures.add(new GUITexture(BORDER_CORNER_TEXTURE));
/*     */     
/* 139 */     this.borderTextures.add(new GUITexture(BORDER_EDGE_TEXTURE));
/* 140 */     this.borderTextures.add(new GUITexture(BORDER_EDGE_TEXTURE));
/* 141 */     this.borderTextures.add(new GUITexture(BORDER_EDGE_TEXTURE));
/* 142 */     this.borderTextures.add(new GUITexture(BORDER_EDGE_TEXTURE));
/*     */   }
/*     */   
/*     */   private void setTexturePositions(float x, float y, float scaleX, float scaleY) {
/* 146 */     float rimX = 0.03F / (Display.getWidth() / Display.getHeight());
/* 147 */     float yPlusYScaleYMinusRim = y + (scaleY - 0.03F);
/* 148 */     float xPlusXScaleMinusRim = x + (scaleX - rimX);
/* 149 */     float yPlusRim = y + 0.03F;
/* 150 */     float xPlusRim = x + rimX;
/*     */     
/* 152 */     int index = 0;
/*     */     
/* 154 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(x, y);
/* 155 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(xPlusXScaleMinusRim, y);
/* 156 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(x, yPlusYScaleYMinusRim);
/* 157 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(xPlusXScaleMinusRim, yPlusYScaleYMinusRim);
/*     */     
/* 159 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(xPlusRim, y);
/* 160 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(xPlusXScaleMinusRim, yPlusRim);
/* 161 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(xPlusRim, yPlusYScaleYMinusRim);
/* 162 */     ((GUITexture)this.borderTextures.get(index++)).setPositionValues(x, yPlusRim);
/*     */   }
/*     */   
/*     */   private void setTextureSizes(float scaleX, float scaleY)
/*     */   {
/* 167 */     float rimX = 0.03F / (Display.getWidth() / Display.getHeight());
/* 168 */     float longX = scaleX - 2.0F * rimX;
/* 169 */     float longY = scaleY - 0.06F;
/*     */     
/* 171 */     int index = 0;
/* 172 */     for (int i = 0; i < 4; i++) {
/* 173 */       ((GUITexture)this.borderTextures.get(index++)).setScaleValues(rimX, 0.03F);
/*     */     }
/* 175 */     ((GUITexture)this.borderTextures.get(index++)).setScaleValues(longX, 0.03F);
/* 176 */     ((GUITexture)this.borderTextures.get(index++)).setScaleValues(rimX, longY);
/* 177 */     ((GUITexture)this.borderTextures.get(index++)).setScaleValues(longX, 0.03F);
/* 178 */     ((GUITexture)this.borderTextures.get(index++)).setScaleValues(rimX, longY);
/*     */   }
/*     */   
/*     */   private void setTextureRotations() {
/* 182 */     int index = 0;
/*     */     
/* 184 */     ((GUITexture)this.borderTextures.get(index++)).setRot(0.0F);
/* 185 */     ((GUITexture)this.borderTextures.get(index++)).setRot(-90.0F);
/* 186 */     ((GUITexture)this.borderTextures.get(index++)).setRot(90.0F);
/* 187 */     ((GUITexture)this.borderTextures.get(index++)).setRot(180.0F);
/*     */     
/* 189 */     ((GUITexture)this.borderTextures.get(index++)).setRot(0.0F);
/* 190 */     ((GUITexture)this.borderTextures.get(index++)).setRot(-90.0F);
/* 191 */     ((GUITexture)this.borderTextures.get(index++)).setRot(180.0F);
/* 192 */     ((GUITexture)this.borderTextures.get(index++)).setRot(90.0F);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\GUIPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */