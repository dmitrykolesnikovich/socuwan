/*    */ package guis;
/*    */ 
/*    */ import text.GUIText;
/*    */ 
/*    */ public class GUITextLayout
/*    */ {
/*    */   private GUIText text;
/*    */   private float relativeX;
/*    */   private float relativeY;
/*    */   
/*    */   protected GUITextLayout(GUIText text, float x, float y)
/*    */   {
/* 13 */     this.text = text;
/* 14 */     this.relativeX = x;
/* 15 */     this.relativeY = y;
/*    */   }
/*    */   
/*    */   protected float getRelativeX() {
/* 19 */     return this.relativeX;
/*    */   }
/*    */   
/*    */   protected float getRelativeY() {
/* 23 */     return this.relativeY;
/*    */   }
/*    */   
/*    */   protected GUIText getText() {
/* 27 */     return this.text;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\GUITextLayout.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */