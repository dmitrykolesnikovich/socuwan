/*     */ package guis;
/*     */ 
/*     */ import toolbox.Colour;
/*     */ 
/*     */ public class GUITexture {
/*     */   private int texture;
/*     */   private float x;
/*     */   private float y;
/*     */   private float rot;
/*     */   private float scaleX;
/*     */   private float scaleY;
/*  12 */   private Colour colour = new Colour(1.0F, 1.0F, 1.0F);
/*  13 */   private boolean customColourUsed = false;
/*     */   
/*  15 */   private int materialCount = 0;
/*  16 */   private Colour colourMaterial1 = null;
/*  17 */   private Colour colourMaterial2 = null;
/*     */   
/*     */   public GUITexture(int texture, float x, float y, float rot, float scaleX, float scaleY) {
/*  20 */     this.texture = texture;
/*  21 */     this.x = x;
/*  22 */     this.y = y;
/*  23 */     this.rot = rot;
/*  24 */     this.scaleX = scaleX;
/*  25 */     this.scaleY = scaleY;
/*     */   }
/*     */   
/*     */   public GUITexture(int texture) {
/*  29 */     this.texture = texture;
/*     */   }
/*     */   
/*     */   public int getTexture() {
/*  33 */     return this.texture;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  37 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  41 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getRot() {
/*  45 */     return this.rot;
/*     */   }
/*     */   
/*     */   public float getScaleX() {
/*  49 */     return this.scaleX;
/*     */   }
/*     */   
/*     */   public float getScaleY() {
/*  53 */     return this.scaleY;
/*     */   }
/*     */   
/*     */   public void setTexture(int texture) {
/*  57 */     this.texture = texture;
/*     */   }
/*     */   
/*     */   public void setX(float x) {
/*  61 */     this.x = x;
/*     */   }
/*     */   
/*     */   public void setY(float y) {
/*  65 */     this.y = y;
/*     */   }
/*     */   
/*     */   public void setRot(float rot) {
/*  69 */     this.rot = rot;
/*     */   }
/*     */   
/*     */   public void setScaleX(float scaleX) {
/*  73 */     this.scaleX = scaleX;
/*     */   }
/*     */   
/*     */   public void setScaleY(float scaleY) {
/*  77 */     this.scaleY = scaleY;
/*     */   }
/*     */   
/*     */   public void setPositionValues(float x, float y) {
/*  81 */     this.x = x;
/*  82 */     this.y = y;
/*     */   }
/*     */   
/*     */   public void setScaleValues(float scaleX, float scaleY) {
/*  86 */     this.scaleX = scaleX;
/*  87 */     this.scaleY = scaleY;
/*     */   }
/*     */   
/*     */   public void setAllPositionValues(float x, float y, float scaleX, float scaleY) {
/*  91 */     this.x = x;
/*  92 */     this.y = y;
/*  93 */     this.scaleX = scaleX;
/*  94 */     this.scaleY = scaleY;
/*     */   }
/*     */   
/*     */   public Colour getColour() {
/*  98 */     return this.colour;
/*     */   }
/*     */   
/*     */   public void changeColour(float r, float g, float b) {
/* 102 */     if ((r == 1.0F) && (g == 1.0F) && (b == 1.0F)) {
/* 103 */       this.customColourUsed = false;
/*     */     } else {
/* 105 */       this.customColourUsed = true;
/*     */     }
/* 107 */     this.colour = new Colour(r, g, b);
/*     */   }
/*     */   
/*     */   public boolean usesCustomColour() {
/* 111 */     return this.customColourUsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void set1MaterialColour(Colour colour1)
/*     */   {
/* 119 */     this.colourMaterial1 = colour1;
/* 120 */     this.materialCount = 1;
/*     */   }
/*     */   
/*     */   public void set2MaterialColours(Colour colour1, Colour colour2) {
/* 124 */     this.colourMaterial1 = colour1;
/* 125 */     this.colourMaterial2 = colour2;
/* 126 */     this.materialCount = 2;
/*     */   }
/*     */   
/*     */   public Colour getColour1() {
/* 130 */     return this.colourMaterial1;
/*     */   }
/*     */   
/*     */   public Colour getColour2() {
/* 134 */     return this.colourMaterial2;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\guis\GUITexture.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */