/*    */ package componentArchitecture;
/*    */ 
/*    */ import collisionComponents.CollisionComponent;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import particleComponent.ParticleComponent;
/*    */ import soundComponents.SoundEmitterComponent;
/*    */ import soundComponents.SoundLooperComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComponentFabricator
/*    */ {
/*    */   private ParticleComponent particleComponent;
/*    */   private CollisionComponent collisionComponent;
/*    */   private SoundEmitterComponent soundComponent;
/*    */   private SoundLooperComponent soundLooper;
/* 19 */   private List<Component> components = new ArrayList();
/*    */   
/*    */ 
/*    */   public List<Component> getComponents()
/*    */   {
/* 24 */     return this.components;
/*    */   }
/*    */   
/*    */   public Component getComponent(ComponentType type) {
/* 28 */     for (Component component : this.components) {
/* 29 */       if (component.getType() == type) {
/* 30 */         return component;
/*    */       }
/*    */     }
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public synchronized void setParticleComponent(ParticleComponent particleComponent) {
/* 37 */     this.particleComponent = particleComponent;
/* 38 */     this.components.add(particleComponent);
/*    */   }
/*    */   
/*    */ 
/*    */   public synchronized SoundLooperComponent getSoundLooper()
/*    */   {
/* 44 */     return this.soundLooper;
/*    */   }
/*    */   
/*    */   public synchronized void setSoundLooper(SoundLooperComponent soundLooper) {
/* 48 */     this.soundLooper = soundLooper;
/* 49 */     this.components.add(soundLooper);
/*    */   }
/*    */   
/*    */   public synchronized void setCollisionComponent(CollisionComponent collisionComponent) {
/* 53 */     this.collisionComponent = collisionComponent;
/* 54 */     this.components.add(collisionComponent);
/*    */   }
/*    */   
/*    */   public synchronized void addUnNeededComponent(Component component) {
/* 58 */     this.components.add(component);
/*    */   }
/*    */   
/*    */   public synchronized void removeComponent(Component component) {
/* 62 */     this.components.remove(component);
/*    */   }
/*    */   
/*    */   public synchronized ParticleComponent getParticleComponent() {
/* 66 */     return this.particleComponent;
/*    */   }
/*    */   
/*    */   public synchronized SoundEmitterComponent getSoundComponent() {
/* 70 */     return this.soundComponent;
/*    */   }
/*    */   
/*    */   public synchronized void setSoundComponent(SoundEmitterComponent soundComponent) {
/* 74 */     this.soundComponent = soundComponent;
/* 75 */     this.components.add(soundComponent);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\componentArchitecture\ComponentFabricator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */