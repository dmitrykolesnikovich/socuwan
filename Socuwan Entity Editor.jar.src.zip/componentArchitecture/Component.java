/*    */ package componentArchitecture;
/*    */ 
/*    */ import epicRenderEngine.RenderEngine;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Component
/*    */ {
/*    */   private ComponentType type;
/* 13 */   private List<Component> requiredBy = new ArrayList();
/* 14 */   private List<Component> requires = new ArrayList();
/*    */   private ComponentPanel panel;
/*    */   
/*    */   public Component(ComponentType type)
/*    */   {
/* 19 */     this.type = type;
/*    */   }
/*    */   
/*    */   public void registerPanel(ComponentPanel panel) {
/* 23 */     this.panel = panel;
/*    */   }
/*    */   
/*    */   public void unregisterPanel(ComponentPanel panel) {
/* 27 */     if (this.panel == panel) {
/* 28 */       this.panel = null;
/*    */     }
/*    */   }
/*    */   
/*    */   public void setRequiredList(List<Component> requires) {
/* 33 */     this.requires = requires;
/*    */   }
/*    */   
/*    */   public List<Component> getRequiredComponents() {
/* 37 */     return this.requires;
/*    */   }
/*    */   
/*    */   public void removeDependentComponent(Component dependent) {
/* 41 */     this.requiredBy.remove(dependent);
/* 42 */     if (this.panel != null) {
/* 43 */       this.panel.updateRequiredBy();
/*    */     }
/*    */   }
/*    */   
/*    */   public List<Component> getDependentComponents() {
/* 48 */     return this.requiredBy;
/*    */   }
/*    */   
/*    */   public abstract void export(PrintWriter paramPrintWriter);
/*    */   
/*    */   public abstract void update(RenderEngine paramRenderEngine);
/*    */   
/*    */   public abstract void setInFabricator(ComponentFabricator paramComponentFabricator);
/*    */   
/*    */   public ComponentType getType() {
/* 58 */     return this.type;
/*    */   }
/*    */   
/*    */   public void notifyRequiredBy(Component component) {
/* 62 */     this.requiredBy.add(component);
/* 63 */     if (this.panel != null) {
/* 64 */       this.panel.updateRequiredBy();
/*    */     }
/*    */   }
/*    */   
/*    */   public abstract ComponentPanel getComponentPanel(ComponentListPanel paramComponentListPanel);
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\componentArchitecture\Component.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */