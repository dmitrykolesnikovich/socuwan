package componentArchitecture;

import backend.Entity;
import java.io.BufferedReader;

public abstract interface ComponentCreator
{
  public abstract Component createComponent(Entity paramEntity);
  
  public abstract Component loadComponent(BufferedReader paramBufferedReader, Entity paramEntity);
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\componentArchitecture\ComponentCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */