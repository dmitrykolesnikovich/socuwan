/*     */ package componentArchitecture;
/*     */ 
/*     */ import backend.AnimatedEntity;
/*     */ import backend.Entity;
/*     */ import backend.StaticEntity;
/*     */ import frontend.MainFrame;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public class AddComponentPanel
/*     */   extends JPanel
/*     */ {
/*     */   private JComboBox<ComponentType> componentMenu;
/*  23 */   private Entity currentEntity = null;
/*     */   private ComponentListPanel listPanel;
/*     */   
/*     */   public AddComponentPanel(int width, int height, ComponentListPanel listPanel) {
/*  27 */     this.listPanel = listPanel;
/*  28 */     listPanel.setAddPanel(this);
/*  29 */     super.setPreferredSize(new Dimension(width, height));
/*  30 */     setLayout(new GridBagLayout());
/*  31 */     addComponentsMenu();
/*  32 */     addButton();
/*     */   }
/*     */   
/*     */   public Entity getCurrentEntity() {
/*  36 */     return this.currentEntity;
/*     */   }
/*     */   
/*     */   public void returnComponentToList(ComponentType type) {
/*  40 */     this.componentMenu.addItem(type);
/*     */   }
/*     */   
/*     */   public void removeComponent(ComponentType type) {
/*  44 */     this.componentMenu.removeItem(type);
/*     */   }
/*     */   
/*     */   public void showStaticEntity(StaticEntity entity) {
/*  48 */     if (entity == this.currentEntity) {
/*  49 */       return;
/*     */     }
/*  51 */     this.currentEntity = entity;
/*  52 */     List<ComponentType> goodTypes = new ArrayList();
/*  53 */     for (ComponentType type : ComponentType.values()) {
/*  54 */       if (!type.isForAnimatedEntitiesOnly()) {
/*  55 */         goodTypes.add(type);
/*     */       }
/*     */     }
/*  58 */     for (Component component : entity.getFabricator().getComponents()) {
/*  59 */       goodTypes.remove(component.getType());
/*     */     }
/*  61 */     ComponentType[] typeArray = new ComponentType[goodTypes.size()];
/*  62 */     for (int i = 0; i < typeArray.length; i++) {
/*  63 */       typeArray[i] = ((ComponentType)goodTypes.get(i));
/*     */     }
/*  65 */     this.componentMenu.setModel(new DefaultComboBoxModel(typeArray));
/*  66 */     this.listPanel.setList(null);
/*     */   }
/*     */   
/*     */   public void showForAnimatedEntity(AnimatedEntity entity) {
/*  70 */     if (entity == this.currentEntity) {
/*  71 */       return;
/*     */     }
/*  73 */     this.currentEntity = entity;
/*  74 */     List<ComponentType> goodTypes = new ArrayList();
/*  75 */     for (ComponentType type : ComponentType.values()) {
/*  76 */       goodTypes.add(type);
/*     */     }
/*  78 */     for (Component component : entity.getFabricator().getComponents()) {
/*  79 */       goodTypes.remove(component.getType());
/*     */     }
/*  81 */     ComponentType[] typeArray = new ComponentType[goodTypes.size()];
/*  82 */     for (int i = 0; i < typeArray.length; i++) {
/*  83 */       typeArray[i] = ((ComponentType)goodTypes.get(i));
/*     */     }
/*  85 */     this.componentMenu.setModel(new DefaultComboBoxModel(typeArray));
/*  86 */     this.listPanel.setList(null);
/*     */   }
/*     */   
/*     */   public void clearAll() {
/*  90 */     this.componentMenu.setModel(new DefaultComboBoxModel(new ComponentType[0]));
/*  91 */     this.listPanel.setList(null);
/*  92 */     this.currentEntity = null;
/*     */   }
/*     */   
/*     */   private void addComponentsMenu() {
/*  96 */     GridBagConstraints gc = new GridBagConstraints();
/*  97 */     gc.fill = 2;
/*  98 */     gc.gridx = 0;
/*  99 */     gc.gridy = 0;
/* 100 */     gc.weightx = 10.0D;
/* 101 */     gc.weighty = 1.0D;
/* 102 */     this.componentMenu = new JComboBox();
/* 103 */     this.componentMenu.setFont(MainFrame.SMALL_FONT);
/* 104 */     add(this.componentMenu, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/* 108 */     GridBagConstraints gc = new GridBagConstraints();
/* 109 */     gc.fill = 2;
/* 110 */     gc.gridx = 1;
/* 111 */     gc.gridy = 0;
/* 112 */     gc.weightx = 1.0D;
/* 113 */     gc.weighty = 1.0D;
/* 114 */     JButton addButton = new JButton("Add");
/* 115 */     addButton.setFont(MainFrame.SMALL_FONT);
/* 116 */     addButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 120 */         if (AddComponentPanel.this.currentEntity != null) {
/* 121 */           ((ComponentType)AddComponentPanel.this.componentMenu.getSelectedItem()).createComponent(AddComponentPanel.this.currentEntity, AddComponentPanel.this.listPanel);
/*     */         }
/*     */         
/*     */       }
/* 125 */     });
/* 126 */     add(addButton, gc);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\componentArchitecture\AddComponentPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */