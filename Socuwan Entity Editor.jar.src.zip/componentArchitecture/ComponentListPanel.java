/*    */ package componentArchitecture;
/*    */ 
/*    */ import backend.Entity;
/*    */ import frontend.MainFrame;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class ComponentListPanel
/*    */   extends JPanel
/*    */ {
/*    */   private int width;
/*    */   private int height;
/* 21 */   private Map<Component, JButton> componentTabs = new HashMap();
/*    */   private AddComponentPanel addPanel;
/*    */   private MainFrame mainFrame;
/*    */   
/*    */   public ComponentListPanel(int width, int height, MainFrame mainFrame) {
/* 26 */     this.width = width;
/* 27 */     this.height = height;
/* 28 */     this.mainFrame = mainFrame;
/* 29 */     setPreferredSize(new Dimension(width, height));
/*    */   }
/*    */   
/*    */   public void setAddPanel(AddComponentPanel addPanel)
/*    */   {
/* 34 */     this.addPanel = addPanel;
/*    */   }
/*    */   
/*    */   public void addComponent(final Component component) {
/* 38 */     this.addPanel.removeComponent(component.getType());
/* 39 */     final JButton button = new JButton(component.getType().toString());
/* 40 */     button.setPreferredSize(new Dimension(this.width - 10, 25));
/* 41 */     button.setFont(MainFrame.SMALL_FONT);
/* 42 */     this.componentTabs.put(component, button);
/* 43 */     add(button);
/* 44 */     button.setForeground(new Color(255, 100, 0));
/* 45 */     button.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent arg0) {
/* 48 */         ComponentListPanel.this.mainFrame.setComponentPanel(component.getComponentPanel(ComponentListPanel.this));
/* 49 */         button.setForeground(new Color(0, 0, 0));
/*    */       }
/* 51 */     });
/* 52 */     super.validate();
/* 53 */     super.repaint();
/*    */   }
/*    */   
/*    */   public void removeComponent(Component component, boolean rootDeletedComponent) {
/* 57 */     if (rootDeletedComponent) {
/* 58 */       for (Component parent : component.getRequiredComponents()) {
/* 59 */         parent.removeDependentComponent(component);
/*    */       }
/* 61 */       this.mainFrame.clearComponentPanel();
/*    */     }
/* 63 */     List<Component> dependentComponents = component.getDependentComponents();
/* 64 */     for (Component dependentComponent : dependentComponents) {
/* 65 */       removeComponent(dependentComponent, false);
/*    */     }
/* 67 */     JButton button = (JButton)this.componentTabs.remove(component);
/* 68 */     remove(button);
/* 69 */     this.addPanel.returnComponentToList(component.getType());
/* 70 */     this.addPanel.getCurrentEntity().getFabricator().removeComponent(component);
/* 71 */     super.validate();
/* 72 */     super.repaint();
/*    */   }
/*    */   
/*    */   public void setList(List<Component> components) {
/* 76 */     for (JButton button : this.componentTabs.values()) {
/* 77 */       remove(button);
/*    */     }
/* 79 */     this.componentTabs.clear();
/* 80 */     if (components != null) {
/* 81 */       for (Component component : components) {
/* 82 */         addComponent(component);
/*    */       }
/*    */     }
/* 85 */     super.validate();
/* 86 */     super.repaint();
/*    */   }
/*    */   
/*    */   private GridBagConstraints createGC() {
/* 90 */     GridBagConstraints gc = new GridBagConstraints();
/* 91 */     gc.fill = 2;
/* 92 */     gc.anchor = 11;
/* 93 */     gc.gridx = 0;
/* 94 */     gc.gridy = 0;
/* 95 */     gc.weightx = 1.0D;
/* 96 */     gc.weighty = 1.0D;
/* 97 */     return gc;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\componentArchitecture\ComponentListPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */