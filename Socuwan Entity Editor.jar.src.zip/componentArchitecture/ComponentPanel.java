/*     */ package componentArchitecture;
/*     */ 
/*     */ import frontend.MainFrame;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ 
/*     */ public abstract class ComponentPanel
/*     */   extends JPanel
/*     */ {
/*     */   private JPanel description;
/*     */   private JPanel settings;
/*     */   private ComponentListPanel listPanel;
/*     */   private Component component;
/*     */   private JLabel requiredBy;
/*     */   
/*     */   public ComponentPanel(Component component, ComponentListPanel list)
/*     */   {
/*  30 */     component.registerPanel(this);
/*  31 */     this.component = component;
/*  32 */     this.listPanel = list;
/*  33 */     setPreferredSize(new Dimension(410, 640));
/*  34 */     setBorder(BorderFactory.createTitledBorder(component.getType().toString()));
/*  35 */     addDescriptionPanel(component);
/*  36 */     this.settings = new JPanel();
/*  37 */     this.settings.setPreferredSize(new Dimension(390, 500));
/*  38 */     this.settings.setBorder(BorderFactory.createLineBorder(new Color(200, 191, 231)));
/*  39 */     add(this.settings);
/*     */   }
/*     */   
/*     */   public JPanel getSettingsPanel() {
/*  43 */     return this.settings;
/*     */   }
/*     */   
/*     */   public void destroy() {
/*  47 */     this.component.unregisterPanel(this);
/*  48 */     cleanUp();
/*     */   }
/*     */   
/*     */   public abstract void cleanUp();
/*     */   
/*     */   private void addDescriptionPanel(final Component component) {
/*  54 */     this.description = new JPanel();
/*  55 */     this.description.setBorder(BorderFactory.createLineBorder(new Color(200, 191, 231)));
/*  56 */     this.description.setPreferredSize(new Dimension(390, 100));
/*  57 */     this.description.setLayout(new GridBagLayout());
/*  58 */     Border border = this.description.getBorder();
/*  59 */     Border margin = new EmptyBorder(10, 10, 10, 10);
/*  60 */     this.description.setBorder(new CompoundBorder(border, margin));
/*  61 */     add(this.description);
/*  62 */     String text = component.getType().getDescription();
/*  63 */     String desc = String.format("<html><div WIDTH=%d>%s</div><html>", new Object[] { Integer.valueOf(370), text });
/*  64 */     JLabel label = new JLabel(desc);
/*  65 */     label.setFont(MainFrame.VSMALL_FONT);
/*  66 */     this.description.add(label, getGC(0, 0));
/*     */     
/*  68 */     ComponentType[] requiresThese = component.getType().getRequiredComponents();
/*  69 */     String requiresString = "Requires: ";
/*  70 */     for (ComponentType requiresThis : requiresThese) {
/*  71 */       requiresString = requiresString + requiresThis.toString() + ", ";
/*     */     }
/*  73 */     JLabel requires = new JLabel(requiresString);
/*  74 */     requires.setFont(MainFrame.VSMALL_FONT);
/*  75 */     requires.setForeground(new Color(0, 0, 255));
/*  76 */     this.description.add(requires, getGC(0, 1));
/*     */     
/*  78 */     String requiredByString = "Required By: ";
/*  79 */     for (Component requiredBy : component.getDependentComponents()) {
/*  80 */       requiredByString = requiredByString + requiredBy.getType().toString() + ", ";
/*     */     }
/*  82 */     this.requiredBy = new JLabel(requiredByString);
/*  83 */     this.requiredBy.setFont(MainFrame.VSMALL_FONT);
/*  84 */     this.requiredBy.setForeground(new Color(244, 0, 255));
/*  85 */     this.description.add(this.requiredBy, getGC(0, 2));
/*     */     
/*  87 */     JButton remove = new JButton("Remove");
/*  88 */     remove.setFont(MainFrame.SMALL_FONT);
/*  89 */     this.description.add(remove, getGC(0, 3));
/*  90 */     remove.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent arg0) {
/*  94 */         ComponentPanel.this.listPanel.removeComponent(component, true); }
/*     */     });
/*     */   }
/*     */   
/*     */   public void updateRequiredBy() {
/*  99 */     String requiredByString = "Required By: ";
/* 100 */     for (Component requiredBy : this.component.getDependentComponents()) {
/* 101 */       requiredByString = requiredByString + requiredBy.getType().toString() + ", ";
/*     */     }
/* 103 */     this.requiredBy.setText(requiredByString);
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y) {
/* 107 */     GridBagConstraints gc = new GridBagConstraints();
/*     */     
/* 109 */     gc.gridx = x;
/* 110 */     gc.gridy = y;
/* 111 */     gc.weightx = 1.0D;
/* 112 */     gc.weighty = 1.0D;
/* 113 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\componentArchitecture\ComponentPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */