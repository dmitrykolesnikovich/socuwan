/*    */ package componentArchitecture;
/*    */ 
/*    */ import backend.Entity;
/*    */ import collisionComponents.CollisionComponentCreator;
/*    */ import java.io.BufferedReader;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import lightComponent.LightComponentCreator;
/*    */ import particleComponent.ParticleComponentCreator;
/*    */ import soundComponents.SoundComponentCreator;
/*    */ import soundComponents.SoundLooperCreator;
/*    */ 
/*    */ 
/*    */ public enum ComponentType
/*    */ {
/* 16 */   PARTICLE_COMPONENT("Particle Effect", false, new ParticleComponentCreator(), new ComponentType[0], "Add particle effects to the entity to make it look all awesome and sparkly with fire and cool stuff."), 
/* 17 */   COLLISION_COMPONENT("Collision Box", false, new CollisionComponentCreator(), new ComponentType[0], "Add a static collision box that players can collide against."), 
/* 18 */   EMITTER_COMPONENT("Sound Emitter", false, new SoundComponentCreator(), new ComponentType[0], "Adds the ability to emit sound."), 
/* 19 */   SOUND_LOOPER_COMPONENT("Sound Looper", false, new SoundLooperCreator(), new ComponentType[] { EMITTER_COMPONENT }, "Emits random sound effects from the entity from a list of possible sound effects"), 
/* 20 */   LIGHT_COMPONENT("Light Component", false, new LightComponentCreator(), new ComponentType[0], "Emits light from a certain point on an enity. When possible just use glow effect instead!");
/*    */   
/*    */   private String name;
/*    */   private ComponentCreator creator;
/*    */   private ComponentType[] requiredComponents;
/*    */   private String description;
/*    */   private boolean animatedOnly;
/*    */   
/*    */   private ComponentType(String name, boolean animatedOnly, ComponentCreator creator, ComponentType[] requiredComponents, String description)
/*    */   {
/* 30 */     this.name = name;
/* 31 */     this.creator = creator;
/* 32 */     this.requiredComponents = requiredComponents;
/* 33 */     this.description = description;
/* 34 */     this.animatedOnly = animatedOnly;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 38 */     return this.name;
/*    */   }
/*    */   
/*    */   public boolean isForAnimatedEntitiesOnly() {
/* 42 */     return this.animatedOnly;
/*    */   }
/*    */   
/*    */   public String getActualName() {
/* 46 */     return super.toString();
/*    */   }
/*    */   
/*    */   public Component loadComponent(BufferedReader reader, Entity entity) {
/* 50 */     Component component = this.creator.loadComponent(reader, entity);
/* 51 */     component.setInFabricator(entity.getFabricator());
/* 52 */     return component;
/*    */   }
/*    */   
/*    */   public Component createComponent(Entity entity, ComponentListPanel listPanel)
/*    */   {
/* 57 */     List<Component> allComponentsRequired = new ArrayList();
/* 58 */     for (ComponentType required : this.requiredComponents) {
/* 59 */       Component requiredComponent = entity.getFabricator().getComponent(required);
/* 60 */       if (requiredComponent == null) {
/* 61 */         allComponentsRequired.add(required.createComponent(entity, listPanel));
/*    */       } else {
/* 63 */         allComponentsRequired.add(requiredComponent);
/*    */       }
/*    */     }
/* 66 */     Component component = this.creator.createComponent(entity);
/* 67 */     component.setRequiredList(allComponentsRequired);
/* 68 */     for (Component needsNotifying : allComponentsRequired) {
/* 69 */       needsNotifying.notifyRequiredBy(component);
/*    */     }
/* 71 */     component.setInFabricator(entity.getFabricator());
/* 72 */     listPanel.addComponent(component);
/* 73 */     return component;
/*    */   }
/*    */   
/*    */   public ComponentType[] getRequiredComponents() {
/* 77 */     return this.requiredComponents;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 81 */     return this.description;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\componentArchitecture\ComponentType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */