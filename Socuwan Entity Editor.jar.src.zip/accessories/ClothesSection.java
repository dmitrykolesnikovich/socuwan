/*    */ package accessories;
/*    */ 
/*    */ import blueprintInterfaces.RawModel;
/*    */ 
/*    */ public class ClothesSection
/*    */ {
/*    */   private int partID;
/*    */   private RawModel model;
/*    */   private boolean fullyCoversSkin;
/* 10 */   private boolean coversAccessory = true;
/*    */   
/*    */   public ClothesSection(int partID, RawModel model, boolean fullyCoversSkin) {
/* 13 */     this.partID = partID;
/* 14 */     this.model = model;
/* 15 */     this.fullyCoversSkin = fullyCoversSkin;
/*    */   }
/*    */   
/*    */   public ClothesSection(int partID, RawModel model, boolean fullyCoversSkin, boolean coversAccessory) {
/* 19 */     this.partID = partID;
/* 20 */     this.model = model;
/* 21 */     this.fullyCoversSkin = fullyCoversSkin;
/* 22 */     this.coversAccessory = coversAccessory;
/*    */   }
/*    */   
/*    */   public int getPartID() {
/* 26 */     return this.partID;
/*    */   }
/*    */   
/*    */   public RawModel getModel() {
/* 30 */     return this.model;
/*    */   }
/*    */   
/*    */   public boolean isFullyCoveringSkin() {
/* 34 */     return this.fullyCoversSkin;
/*    */   }
/*    */   
/*    */   public boolean isCoveringAccessory() {
/* 38 */     return this.coversAccessory;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\accessories\ClothesSection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */