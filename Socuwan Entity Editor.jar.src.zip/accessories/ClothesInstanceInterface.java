package accessories;

import toolbox.Colour;

public abstract interface ClothesInstanceInterface
{
  public abstract ClothesBlueprintInterface getItemBlueprint();
  
  public abstract Colour getMaterial1Colour();
  
  public abstract Colour getMaterial2Colour();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\accessories\ClothesInstanceInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */