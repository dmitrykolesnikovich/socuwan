package accessories;

import toolbox.Colour;

public abstract interface AccessoryInterface
{
  public abstract Colour getMaterial1Colour();
  
  public abstract Colour getMaterial2Colour();
  
  public abstract AccessoryBlueprint getBlueprint();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\accessories\AccessoryInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */