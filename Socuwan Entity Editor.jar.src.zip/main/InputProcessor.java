/*    */ package main;
/*    */ 
/*    */ import toolbox.MyKeyboard;
/*    */ import toolbox.MyMouse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputProcessor
/*    */ {
/*    */   private boolean exit;
/*    */   private MyMouse mouse;
/*    */   private MyKeyboard keyboard;
/*    */   
/*    */   public InputProcessor(MyMouse mouse, MyKeyboard keyboard)
/*    */   {
/* 18 */     this.keyboard = keyboard;
/* 19 */     this.exit = false;
/* 20 */     this.mouse = mouse;
/*    */   }
/*    */   
/*    */   public void checkInput() {
/* 24 */     this.mouse.update();
/* 25 */     this.keyboard.update();
/* 26 */     processKeyboardInputForOther();
/*    */   }
/*    */   
/*    */   private void processKeyboardInputForOther()
/*    */   {
/* 31 */     if (this.keyboard.keyDownEventOccurred(Integer.valueOf(1))) {
/* 32 */       this.exit = true;
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean exitRequested() {
/* 37 */     return this.exit;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\main\InputProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */