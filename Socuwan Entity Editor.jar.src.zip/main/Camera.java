/*     */ package main;
/*     */ 
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import toolbox.MyMouse;
/*     */ import toolbox.Transformation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Camera
/*     */   implements epicRenderEngine.Camera
/*     */ {
/*  15 */   private final float FIELD_OF_VIEW = 70.0F;
/*  16 */   private final float NEAR_PLANE = 0.1F;
/*  17 */   private final float FAR_PLANE = 1040.0F;
/*     */   
/*     */   private MyMouse mouse;
/*     */   
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private float horizontalDistanceFromPlayer;
/*     */   private float verticalDistanceFromPlayer;
/*     */   private float pitch;
/*     */   private float yaw;
/*  28 */   private float actualDistanceFromPlayer = 10.4F;
/*  29 */   private float angleOfElevation = 0.37F;
/*  30 */   private float angleAroundPlayer = 0.0F;
/*  31 */   private boolean change = false;
/*     */   
/*     */   private static final float CAMERA_AIM_OFFSET = 2.5F;
/*     */   
/*     */   private static final int INFLUENCE_OF_MOUSEDY = 300;
/*     */   private static final int INFLUENCE_OF_MOUSEDX = 4;
/*     */   private static final int INFLUENCE_OF_MOUSE_WHEEL = 100;
/*     */   private static final float MAX_ANGLE_OF_ELEVATION = 1.5F;
/*     */   private static final float SPEED_OF_CAM_RETURN = 25.0F;
/*     */   private static final float CAM_RETURN_DISTANCE_EFFECT = 0.25F;
/*     */   private static final float PITCH_OFFSET = 1.8F;
/*     */   private static final float MINIMUM_ZOOM = 8.0F;
/*     */   private static final float MAX_HORIZONTAL_CHANGE = 500.0F;
/*     */   private static final float MAX_VERTICAL_CHANGE = 5.0F;
/*  45 */   private boolean rotate = true;
/*  46 */   Transformation transformation = new Transformation(400.0F, 0.0F, 400.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   
/*     */   public Camera(MyMouse mouse)
/*     */   {
/*  50 */     this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */     
/*  52 */     this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*  53 */     this.mouse = mouse;
/*     */   }
/*     */   
/*     */   public void setRotate(boolean rotate) {
/*  57 */     this.rotate = rotate;
/*     */   }
/*     */   
/*     */   public void setDistanceFromPlayer(float distance) {
/*  61 */     this.actualDistanceFromPlayer = distance;
/*  62 */     this.change = true;
/*     */   }
/*     */   
/*     */   public void moveCamera(float delta) {
/*  66 */     calculateHorizontalAngle(delta);
/*  67 */     calculateVerticalAngle(delta);
/*  68 */     calculateZoom();
/*  69 */     calculateDistances();
/*  70 */     calculatePosition();
/*  71 */     this.change = false;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  75 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  79 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  83 */     return this.z;
/*     */   }
/*     */   
/*     */   public float getPitch() {
/*  87 */     return this.pitch;
/*     */   }
/*     */   
/*     */   public float getYaw() {
/*  91 */     return this.yaw;
/*     */   }
/*     */   
/*     */   public float getFieldOfView() {
/*  95 */     return 70.0F;
/*     */   }
/*     */   
/*     */   public float getNearPlane() {
/*  99 */     return 0.1F;
/*     */   }
/*     */   
/*     */   public float getFarPlane() {
/* 103 */     return 1040.0F;
/*     */   }
/*     */   
/*     */   private void calculatePosition() {
/* 107 */     if (this.rotate) {
/* 108 */       this.transformation.increaseRotation(0.0F, 0.1F, 0.0F);
/*     */     }
/* 110 */     float playerRot = this.transformation.getRotY();
/* 111 */     this.x = (this.transformation.getX() - (float)(this.horizontalDistanceFromPlayer * Math.sin(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/* 114 */     this.z = (this.transformation.getZ() - (float)(this.horizontalDistanceFromPlayer * Math.cos(Math.toRadians(playerRot + this.angleAroundPlayer))));
/*     */     
/*     */ 
/* 117 */     this.y = (this.verticalDistanceFromPlayer + 2.5F + 0.0F);
/*     */     
/* 119 */     if (this.transformation.getY() + 2.5F > this.y) {
/* 120 */       this.y = (this.transformation.getY() + 2.5F);
/*     */     }
/* 122 */     this.yaw = (playerRot + 180.0F + this.angleAroundPlayer);
/* 123 */     this.pitch = ((float)Math.toDegrees(this.angleOfElevation) - 1.8F);
/*     */   }
/*     */   
/*     */   private void calculateHorizontalAngle(float delta) {
/* 127 */     if ((this.mouse.isLeftButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 128 */       float angleChange = this.mouse.getDX() / 4.0F;
/* 129 */       if (angleChange > 500.0F * delta) {
/* 130 */         angleChange = 500.0F * delta;
/* 131 */       } else if (angleChange < -500.0F * delta) {
/* 132 */         angleChange = -500.0F * delta;
/*     */       }
/* 134 */       this.angleAroundPlayer -= angleChange;
/*     */       
/* 136 */       if (this.angleAroundPlayer >= 180.0F) {
/* 137 */         this.angleAroundPlayer -= 360.0F;
/* 138 */       } else if (this.angleAroundPlayer <= -180.0F) {
/* 139 */         this.angleAroundPlayer += 360.0F;
/*     */       }
/* 141 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void returnCamera(float delta) {
/* 146 */     float distanceRecoverySpeed = this.angleAroundPlayer / 0.25F * delta;
/* 147 */     float returningSpeed = 25.0F * delta;
/* 148 */     if (this.angleAroundPlayer > returningSpeed) {
/* 149 */       this.angleAroundPlayer -= returningSpeed + distanceRecoverySpeed;
/* 150 */       this.change = true;
/* 151 */     } else if (this.angleAroundPlayer < -returningSpeed) {
/* 152 */       this.angleAroundPlayer += returningSpeed - distanceRecoverySpeed;
/* 153 */       this.change = true;
/*     */     } else {
/* 155 */       this.angleAroundPlayer = 0.0F;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateVerticalAngle(float delta) {
/* 160 */     if ((this.mouse.isRightButtonDown()) && (!this.mouse.isActiveInGUI())) {
/* 161 */       float angleChange = this.mouse.getDY() / 300.0F;
/* 162 */       if (angleChange > 5.0F * delta) {
/* 163 */         angleChange = 5.0F * delta;
/* 164 */       } else if (angleChange < -5.0F * delta) {
/* 165 */         angleChange = -5.0F * delta;
/*     */       }
/* 167 */       this.angleOfElevation -= angleChange;
/* 168 */       if (this.angleOfElevation >= 1.5F) {
/* 169 */         this.angleOfElevation = 1.5F;
/* 170 */       } else if (this.angleOfElevation <= 0.0F) {
/* 171 */         this.angleOfElevation = 0.0F;
/*     */       }
/* 173 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateZoom() {
/* 178 */     if (Keyboard.isKeyDown(46)) {
/* 179 */       this.actualDistanceFromPlayer -= 1.0F;
/* 180 */       this.change = true;
/*     */     }
/* 182 */     float zoomLevel = this.mouse.getDWheel() / 100;
/* 183 */     if (zoomLevel != 0.0F) {
/* 184 */       this.actualDistanceFromPlayer -= zoomLevel;
/* 185 */       if (this.actualDistanceFromPlayer < 8.0F) {
/* 186 */         this.actualDistanceFromPlayer = 8.0F;
/*     */       }
/* 188 */       this.change = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void calculateDistances() {
/* 193 */     if (this.change) {
/* 194 */       this.horizontalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.cos(this.angleOfElevation)));
/*     */       
/* 196 */       this.verticalDistanceFromPlayer = ((float)(this.actualDistanceFromPlayer * Math.sin(this.angleOfElevation)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\main\Camera.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */