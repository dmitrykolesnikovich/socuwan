/*     */ package main;
/*     */ 
/*     */ import animations.AnimationComponent;
/*     */ import backend.StaticEntity;
/*     */ import backend.Workspace;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import frontend.MainFrame;
/*     */ import instances.AnimatedInstance;
/*     */ import instances.EntityInstance;
/*     */ import instances.PlayerSettings;
/*     */ import instances.StaticInstance;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Locale;
/*     */ import javax.swing.JOptionPane;
/*     */ import sound.SoundMaestro;
/*     */ import terrains.Terrain;
/*     */ import terrains.TerrainBlock;
/*     */ import texture.ModelTexture;
/*     */ import texture.TerrainTexture;
/*     */ import texture.TerrainTexturePack;
/*     */ import toolbox.MyKeyboard;
/*     */ import toolbox.MyMouse;
/*     */ import toolbox.Transformation;
/*     */ import weather.Weather;
/*     */ 
/*     */ public class MainApp
/*     */ {
/*     */   public static final float CENTER_X = 400.0F;
/*     */   public static final float CENTER_Z = 400.0F;
/*  31 */   public static boolean close = false;
/*     */   public static EntityInstance currentEntity;
/*     */   public static AnimatedInstance player;
/*     */   public static StaticInstance sphere;
/*     */   public static StaticInstance lightSphere;
/*     */   public static MainFrame mainFrame;
/*  37 */   public static boolean showTerrain = true;
/*     */   
/*  39 */   public static float time = 6500.0F;
/*     */   
/*     */   public static void init() {
/*  42 */     Locale.setDefault(Locale.US);
/*     */     
/*  44 */     System.out.println(new File("natives").getAbsolutePath());
/*     */     
/*  46 */     String osname = System.getProperty("os.name").toLowerCase();
/*  47 */     System.out.println("OS Name: " + osname);
/*  48 */     System.out.println("OS Arch: " + System.getProperty("os.arch"));
/*  49 */     String pathExtension = "";
/*     */     
/*  51 */     if (osname.contains("win")) {
/*  52 */       pathExtension = "win";
/*  53 */     } else if (osname.contains("lin")) {
/*  54 */       pathExtension = "lin";
/*  55 */     } else if (osname.contains("mac")) {
/*  56 */       pathExtension = "mac";
/*     */     } else {
/*  58 */       JOptionPane.showMessageDialog(null, "Sorry, but your system is not supported by LWJGL :(");
/*  59 */       System.exit(-1);
/*     */     }
/*     */     
/*     */ 
/*  63 */     System.setProperty("org.lwjgl.librarypath", new File("natives").getAbsolutePath() + "/" + pathExtension);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/*  67 */     init();
/*  68 */     MyMouse mouse = new MyMouse();
/*  69 */     MyKeyboard keyboard = new MyKeyboard();
/*  70 */     InputProcessor inputs = new InputProcessor(mouse, keyboard);
/*  71 */     Camera camera = new Camera(mouse);
/*  72 */     Workspace workspace = new Workspace();
/*  73 */     mainFrame = new MainFrame(workspace, camera);
/*  74 */     RenderEngine engine = new RenderEngine(camera, mainFrame.getCanvas());
/*  75 */     Weather weather = new Weather(camera);
/*  76 */     SoundMaestro.initialize();
/*     */     
/*  78 */     TerrainTexture main = new TerrainTexture(0, "grassy256");
/*  79 */     TerrainTexture r = new TerrainTexture(0, "dirt256");
/*  80 */     TerrainTexture g = new TerrainTexture(0, "pinkFlowers256");
/*  81 */     TerrainTexture b = new TerrainTexture(0, "MarblePath512");
/*  82 */     TerrainTexturePack pack = new TerrainTexturePack(main, r, g, b, null);
/*  83 */     int alphaMap = RenderEngine.loadTexture("terrains/newAlpha");
/*  84 */     pack.setShiny();
/*  85 */     pack.setUseSpecularMap();
/*  86 */     Terrain terrain = new Terrain(0, 0, "flatty", pack, alphaMap);
/*  87 */     player = new AnimatedInstance(PlayerSettings.getPlayerBlueprint());
/*  88 */     player.getAnimationComponent().suggestAnimation(Configs.PLAYER_ANIM);
/*  89 */     player.getTransformation().increasePosition(6.0F, 0.0F, 0.0F);
/*  90 */     player.getTransformation().setScale(0.5F);
/*  91 */     StaticEntity guide = new StaticEntity(RenderEngine.loadModelFile(0, "guide"), new ModelTexture(RenderEngine.loadTexture("test")));
/*     */     
/*  93 */     sphere = new StaticInstance(guide);
/*  94 */     lightSphere = new StaticInstance(guide);
/*  95 */     guide.setWireframe(true);
/*  96 */     sphere.showEntity(false);
/*  97 */     lightSphere.showEntity(false);
/*  98 */     lightSphere.getTransformation().setScale(1.0F);
/*     */     
/* 100 */     while (!close) {
/* 101 */       epicRenderEngine.Loader.dealWithRequests();
/*     */       
/* 103 */       camera.moveCamera(RenderEngine.getDeltaInSeconds());
/* 104 */       weather.updateWeather(time, RenderEngine.getDeltaInSeconds());
/* 105 */       engine.updateView();
/* 106 */       inputs.checkInput();
/* 107 */       if (currentEntity != null) {
/* 108 */         currentEntity.update(engine);
/* 109 */         sphere.update(engine);
/* 110 */         lightSphere.update(engine);
/*     */       }
/* 112 */       player.update(engine);
/* 113 */       if (showTerrain) {
/* 114 */         for (TerrainBlock tile : terrain.getTerrainBlocks()) {
/* 115 */           engine.processTerrainBlock(tile);
/*     */         }
/*     */       }
/* 118 */       SoundMaestro.update(camera.getX(), camera.getY(), camera.getZ());
/* 119 */       engine.render(weather.getSky());
/* 120 */       engine.updateDisplay();
/*     */     }
/*     */     
/* 123 */     SoundMaestro.cleanUp();
/* 124 */     engine.closeDisplay();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\main\MainApp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */