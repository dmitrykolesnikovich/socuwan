/*    */ package main;
/*    */ 
/*    */ import animations.Animation;
/*    */ import animations.AnimationLoader;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Configs
/*    */ {
/*    */   public static final String FILE_SEPARATOR = "/";
/*    */   public static final String CSV_SEPARATOR = ";";
/*    */   public static final String NEW_LINE_CHAR = "\n";
/*    */   public static final String RES_LOC = "/res/";
/*    */   public static final String SKYBOX_LOC = "skybox";
/*    */   public static final String DEFAULT_ICON_LOC = "/res/defaultIcon.png";
/*    */   public static final String DEFAULT_DIFFUSE_LOC = "/res/defaultDiffuseTexture.png";
/*    */   public static final String DEFAULT_EXTRA_LOC = "/res/defaultExtraTexture.png";
/*    */   public static final String NATIVES_FOLDER = "natives";
/* 24 */   public static final Animation PLAYER_ANIM = AnimationLoader.loadAnimationFile("standing");
/*    */   
/* 26 */   public static final File REPOSITORY = new File("repository");
/* 27 */   public static final File SAVES_FILE = new File(REPOSITORY, "entities");
/* 28 */   public static final File MODELS_REPOS = new File(REPOSITORY, "models");
/* 29 */   public static final File COLLISION_OBJS_REPOS = new File(REPOSITORY, "collisionObjects");
/* 30 */   public static final File ICONS_REPOS = new File(REPOSITORY, "icons");
/* 31 */   public static final File TEXTURES_REPOS = new File(REPOSITORY, "modelTextures");
/* 32 */   public static final File STRUCTURES_REPOS = new File(REPOSITORY, "structures");
/* 33 */   public static final File PARTICLES_REPOS = new File(REPOSITORY, "particleAtlases");
/* 34 */   public static final File SOUND_EFFECTS_REPOS = new File(REPOSITORY, "soundEffects");
/*    */   public static final String ENTITY_INFO_FILE = "info.txt";
/*    */   public static final String STATIC_MODEL_FILE = "MODEL.csv";
/*    */   public static final String DIFFUSE_NAME = "diffuse.png";
/*    */   public static final String EXTRA_NAME = "extra.png";
/*    */   public static final String TEXTURE_FILE_NAME = "texture";
/*    */   public static final String TEXTURE_CONFIG_FILE_NAME = "configs.txt";
/*    */   public static final String SHADERS_LOC = "/renderPrograms/";
/*    */   public static final String CLUTTER_VERTEX_FILE = "/renderPrograms/clutterVertex.txt";
/*    */   public static final String CLUTTER_FRAGMENT_FILE = "/renderPrograms/clutterFragment.txt";
/*    */   public static final String PARTICLE_VERTEX_FILE = "/renderPrograms/particlesVertex.txt";
/*    */   public static final String PARTICLE_FRAGMENT_FILE = "/renderPrograms/particlesFragment.txt";
/*    */   public static final String HR_STATIC_VERTEX_FILE = "/renderPrograms/simpleVertex.txt";
/*    */   public static final String HR_STATIC_FRAGMENT_FILE = "/renderPrograms/simpleFragment.txt";
/*    */   public static final String HR_TERRAIN_VERTEX_FILE = "/renderPrograms/terrainVertex.txt";
/*    */   public static final String HR_TERRAIN_FRAGMENT_FILE = "/renderPrograms/terrainFragment.txt";
/*    */   public static final String LR_STATIC_VERTEX_FILE = "/renderPrograms/simpleLowResVertex.txt";
/*    */   public static final String LR_STATIC_FRAGMENT_FILE = "/renderPrograms/simpleLowResFragment.txt";
/*    */   public static final String LR_TERRAIN_VERTEX_FILE = "/renderPrograms/terrainLowResVertex.txt";
/*    */   public static final String LR_TERRAIN_FRAGMENT_FILE = "/renderPrograms/terrainLowResFragment.txt";
/*    */   public static final String SKYBOX_VERTEX_FILE = "/renderPrograms/skyboxVertex.txt";
/*    */   public static final String SKYBOX_FRAGMENT_FILE = "/renderPrograms/skyboxFragment.txt";
/*    */   public static final String GUI_VERTEX_FILE = "/renderPrograms/guiVertex.txt";
/*    */   public static final String GUI_FRAGMENT_FILE = "/renderPrograms/guiFragment.txt";
/*    */   public static final String WATER_VERTEX_FILE = "/renderPrograms/waterVertex.txt";
/*    */   public static final String WATER_FRAGMENT_FILE = "/renderPrograms/waterFragment.txt";
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\main\Configs.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */