/*    */ package main;
/*    */ 
/*    */ public class ReaderUtils
/*    */ {
/*    */   public static int booleanToInt(boolean check) {
/*  6 */     if (check) {
/*  7 */       return 1;
/*    */     }
/*  9 */     return 0;
/*    */   }
/*    */   
/*    */   public static boolean readBoolean(String bool)
/*    */   {
/* 14 */     int indicator = Integer.parseInt(bool);
/* 15 */     if (indicator == 0) {
/* 16 */       return false;
/*    */     }
/* 18 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\main\ReaderUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */