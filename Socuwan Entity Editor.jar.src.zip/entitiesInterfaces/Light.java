/*     */ package entitiesInterfaces;
/*     */ 
/*     */ public class Light { private float x;
/*     */   private float y;
/*     */   private float z;
/*   6 */   private float r = 1.0F;
/*   7 */   private float g = 1.0F;
/*   8 */   private float b = 1.0F;
/*   9 */   private float attenuation1 = 1.0F;
/*  10 */   private float attenuation2 = 0.08F;
/*  11 */   private float attenuation3 = 0.005F;
/*     */   
/*  13 */   private boolean dirtyColour = true;
/*  14 */   private boolean dirtyAttenuation = true;
/*     */   
/*     */   public Light(float x, float y, float z, float r, float g, float b) {
/*  17 */     this.x = x;
/*  18 */     this.y = y;
/*  19 */     this.z = z;
/*  20 */     this.r = r;
/*  21 */     this.g = g;
/*  22 */     this.b = b;
/*     */   }
/*     */   
/*     */   public Light(float x, float y, float z) {
/*  26 */     this.x = x;
/*  27 */     this.y = y;
/*  28 */     this.z = z;
/*     */   }
/*     */   
/*     */   public Light(float x, float y, float z, float r, float g, float b, float attenuation1, float attenuation2, float attenuation3)
/*     */   {
/*  33 */     this.x = x;
/*  34 */     this.y = y;
/*  35 */     this.z = z;
/*  36 */     this.r = r;
/*  37 */     this.g = g;
/*  38 */     this.b = b;
/*  39 */     this.attenuation1 = attenuation1;
/*  40 */     this.attenuation2 = attenuation2;
/*  41 */     this.attenuation3 = attenuation3;
/*     */   }
/*     */   
/*     */   public void setPosition(float x, float y, float z) {
/*  45 */     this.x = x;
/*  46 */     this.y = y;
/*  47 */     this.z = z;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  51 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  55 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  59 */     return this.z;
/*     */   }
/*     */   
/*     */   public void setR(float r) {
/*  63 */     this.r = r;
/*  64 */     this.dirtyColour = true;
/*     */   }
/*     */   
/*     */   public void setG(float g) {
/*  68 */     this.g = g;
/*  69 */     this.dirtyColour = true;
/*     */   }
/*     */   
/*     */   public void setB(float b) {
/*  73 */     this.b = b;
/*  74 */     this.dirtyColour = true;
/*     */   }
/*     */   
/*     */   public void setAttenuation1(float attenuation1) {
/*  78 */     this.attenuation1 = attenuation1;
/*  79 */     this.dirtyAttenuation = true;
/*     */   }
/*     */   
/*     */   public void setAttenuation2(float attenuation2) {
/*  83 */     this.attenuation2 = attenuation2;
/*  84 */     this.dirtyAttenuation = true;
/*     */   }
/*     */   
/*     */   public void setAttenuation3(float attenuation3) {
/*  88 */     this.attenuation3 = attenuation3;
/*  89 */     this.dirtyAttenuation = true;
/*     */   }
/*     */   
/*     */   public void setColour(float r, float g, float b) {
/*  93 */     this.r = r;
/*  94 */     this.g = g;
/*  95 */     this.b = b;
/*  96 */     this.dirtyColour = true;
/*     */   }
/*     */   
/*     */   public float getR() {
/* 100 */     return this.r;
/*     */   }
/*     */   
/*     */   public float getG() {
/* 104 */     return this.g;
/*     */   }
/*     */   
/*     */   public float getB() {
/* 108 */     return this.b;
/*     */   }
/*     */   
/*     */   public float getAttenuation1() {
/* 112 */     return this.attenuation1;
/*     */   }
/*     */   
/*     */   public float getAttenuation2() {
/* 116 */     return this.attenuation2;
/*     */   }
/*     */   
/*     */   public float getAttenuation3() {
/* 120 */     return this.attenuation3;
/*     */   }
/*     */   
/*     */   public void setAttenuation(float att1, float att2, float att3) {
/* 124 */     this.attenuation1 = att1;
/* 125 */     this.attenuation2 = att2;
/* 126 */     this.attenuation3 = att3;
/* 127 */     this.dirtyAttenuation = true;
/*     */   }
/*     */   
/*     */   public boolean isDirtyColour() {
/* 131 */     return this.dirtyColour;
/*     */   }
/*     */   
/*     */   public void resetColourFlag() {
/* 135 */     this.dirtyColour = false;
/*     */   }
/*     */   
/*     */   public boolean isDirtyAttenuation() {
/* 139 */     return this.dirtyAttenuation;
/*     */   }
/*     */   
/*     */   public void resetAttenuationFlag() {
/* 143 */     this.dirtyAttenuation = false;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\entitiesInterfaces\Light.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */