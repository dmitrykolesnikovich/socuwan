package entitiesInterfaces;

import blueprintInterfaces.BlueprintInterface;
import toolbox.Colour;
import toolbox.Transformation;

public abstract interface EntityInterface
{
  public abstract BlueprintInterface getBlueprint();
  
  public abstract Transformation getTransformation();
  
  public abstract void setDistance(float paramFloat);
  
  public abstract float getDistance();
  
  public abstract void setLOD(int paramInt);
  
  public abstract boolean isVisible();
  
  public abstract float getVisibleDistance();
  
  public abstract int getLOD();
  
  public abstract float getFurthestPoint();
  
  public abstract float[] getInstanceTextureCoords();
  
  public abstract Colour getMaterial1Colour();
  
  public abstract Colour getMaterial2Colour();
  
  public abstract void setReflectionFlag();
  
  public abstract boolean hasReflection();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\entitiesInterfaces\EntityInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */