/*     */ package entitiesInterfaces;
/*     */ 
/*     */ import animations.AnimatablePart;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AnimatedSection implements AnimatablePart
/*     */ {
/*     */   private static final int NO_MORE_CHILDREN = -1;
/*     */   private BoneBlueprint bone;
/*     */   private float x;
/*     */   private float y;
/*     */   private float z;
/*     */   private double rotW;
/*     */   private double rotX;
/*     */   private double rotY;
/*     */   private double rotZ;
/*     */   private float scale;
/*  20 */   private List<AnimatedSection> childrenNodes = new ArrayList();
/*     */   private AnimatedSection parentNode;
/*     */   private int currentChild;
/*     */   private boolean hasParent;
/*     */   
/*     */   public AnimatedSection(BoneBlueprint bone, AnimatedSection parent)
/*     */   {
/*  27 */     this.bone = bone;
/*  28 */     this.x = 0.0F;
/*  29 */     this.y = 0.0F;
/*  30 */     this.z = 0.0F;
/*  31 */     this.rotW = 1.0D;
/*  32 */     this.rotX = 0.0D;
/*  33 */     this.rotY = 0.0D;
/*  34 */     this.rotZ = 0.0D;
/*  35 */     this.scale = 1.0F;
/*  36 */     this.hasParent = true;
/*  37 */     this.parentNode = parent;
/*  38 */     this.currentChild = -1;
/*     */   }
/*     */   
/*     */   public AnimatedSection(BoneBlueprint bone)
/*     */   {
/*  43 */     this.bone = bone;
/*  44 */     this.x = 0.0F;
/*  45 */     this.y = 0.0F;
/*  46 */     this.z = 0.0F;
/*  47 */     this.rotW = 1.0D;
/*  48 */     this.rotX = 0.0D;
/*  49 */     this.rotY = 0.0D;
/*  50 */     this.rotZ = 0.0D;
/*  51 */     this.scale = 1.0F;
/*  52 */     this.hasParent = false;
/*  53 */     this.currentChild = -1;
/*     */   }
/*     */   
/*     */   public BoneBlueprint getBone()
/*     */   {
/*  58 */     return this.bone;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  62 */     return this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  66 */     return this.y;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  70 */     return this.z;
/*     */   }
/*     */   
/*     */   public double getRotW() {
/*  74 */     return this.rotW;
/*     */   }
/*     */   
/*     */   public double getRotX() {
/*  78 */     return this.rotX;
/*     */   }
/*     */   
/*     */   public double getRotY() {
/*  82 */     return this.rotY;
/*     */   }
/*     */   
/*     */   public double getRotZ() {
/*  86 */     return this.rotZ;
/*     */   }
/*     */   
/*     */   public float getScale() {
/*  90 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setPosition(float x, float y, float z) {
/*  94 */     this.x = x;
/*  95 */     this.y = y;
/*  96 */     this.z = z;
/*     */   }
/*     */   
/*     */   public void setScale(float scale) {
/* 100 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public void setRotation(double w, double x, double y, double z) {
/* 104 */     this.rotW = w;
/* 105 */     this.rotX = x;
/* 106 */     this.rotY = y;
/* 107 */     this.rotZ = z;
/*     */   }
/*     */   
/*     */   public void addChild(AnimatedSection child) {
/* 111 */     this.childrenNodes.add(child);
/* 112 */     this.currentChild += 1;
/*     */   }
/*     */   
/*     */   public AnimatedSection getNextChild() {
/* 116 */     if (this.currentChild == -1) {
/* 117 */       this.currentChild = (this.childrenNodes.size() - 1);
/* 118 */       return null;
/*     */     }
/* 120 */     return (AnimatedSection)this.childrenNodes.get(this.currentChild--);
/*     */   }
/*     */   
/*     */   public AnimatedSection getParent()
/*     */   {
/* 125 */     return this.parentNode;
/*     */   }
/*     */   
/*     */   public boolean hasParent() {
/* 129 */     return this.hasParent;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\entitiesInterfaces\AnimatedSection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */