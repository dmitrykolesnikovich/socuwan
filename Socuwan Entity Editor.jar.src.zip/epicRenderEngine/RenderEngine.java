/*     */ package epicRenderEngine;
/*     */ 
/*     */ import atmosphere.Sky;
/*     */ import blueprintInterfaces.RawModel;
/*     */ import entitiesInterfaces.AnimatedEntityInterface;
/*     */ import entitiesInterfaces.HumanEntityInterface;
/*     */ import entitiesInterfaces.Light;
/*     */ import entitiesInterfaces.StaticEntityInterface;
/*     */ import guis.GUIManager;
/*     */ import java.awt.Canvas;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import processing.LightSorter;
/*     */ import processing.RenderProcessor;
/*     */ import renderPrograms.MasterRenderer;
/*     */ import terrains.TerrainBlock;
/*     */ import water.WaterTile;
/*     */ 
/*     */ 
/*     */ public class RenderEngine
/*     */ {
/*     */   private RenderProcessor processor;
/*     */   private MasterRenderer renderer;
/*     */   private LightSorter lightSorter;
/*  26 */   private List<Light> localLights = new ArrayList();
/*     */   
/*     */   public RenderEngine(Camera camera, Canvas canvas) {
/*  29 */     DisplayManager.setUpDisplay(canvas);
/*  30 */     this.renderer = new MasterRenderer(camera);
/*  31 */     this.processor = new RenderProcessor(this.renderer, camera);
/*  32 */     this.lightSorter = new LightSorter(4, camera);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void updateDisplay() {}
/*     */   
/*     */ 
/*     */   public static void goFullscreen() {}
/*     */   
/*     */ 
/*     */   public static void goWireframe(boolean wireframe)
/*     */   {
/*  45 */     OpenglUtils.goWireframe(wireframe);
/*     */   }
/*     */   
/*     */   public static RawModel loadModelFile(File modelFile) {
/*  49 */     return Loader.loadModelFile(modelFile);
/*     */   }
/*     */   
/*     */   public static RawModel loadModelFile(int id, String file) {
/*  53 */     return Loader.loadModelFile(id, file);
/*     */   }
/*     */   
/*     */   public static int loadTexture(String texture) {
/*  57 */     return Loader.loadTexture(texture);
/*     */   }
/*     */   
/*     */   public static float getDeltaInSeconds() {
/*  61 */     return DisplayManager.getDeltaInSeconds();
/*     */   }
/*     */   
/*     */   public void addLocalLight(Light light) {
/*  65 */     this.localLights.add(light);
/*     */   }
/*     */   
/*     */   public void processStaticEntity(StaticEntityInterface instance) {
/*  69 */     this.processor.processStaticInstance(instance);
/*     */   }
/*     */   
/*     */   public void processAnimatedEntity(AnimatedEntityInterface instance) {
/*  73 */     this.processor.processAnimatedInstance(instance);
/*     */   }
/*     */   
/*     */   public void processHumanEntity(HumanEntityInterface instance) {
/*  77 */     this.processor.processHumanInstance(instance);
/*     */   }
/*     */   
/*     */   public void processTerrainBlock(TerrainBlock terrainBlock) {
/*  81 */     this.processor.processTerrainBlock(terrainBlock);
/*     */   }
/*     */   
/*     */   public void processWaterTile(WaterTile tile) {
/*  85 */     this.processor.processWaterTile(tile);
/*     */   }
/*     */   
/*     */   public void render(Sky sky) {
/*  89 */     for (Light light : this.localLights) {
/*  90 */       this.lightSorter.sortLight(light);
/*     */     }
/*  92 */     this.localLights.clear();
/*  93 */     this.processor.render(sky, this.lightSorter.getClosestLights());
/*  94 */     this.lightSorter.reset();
/*  95 */     this.processor.renderGUIs(GUIManager.getGUIsForRender(), GUIManager.getPopUps());
/*     */   }
/*     */   
/*     */   public void updateView() {
/*  99 */     this.processor.updateFrustum();
/*     */   }
/*     */   
/*     */   public void closeDisplay() {
/* 103 */     GUIManager.cleanUp();
/* 104 */     this.processor.cleanUp();
/* 105 */     Loader.cleanUpModelMemory();
/* 106 */     DisplayManager.closeWindow();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\epicRenderEngine\RenderEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */