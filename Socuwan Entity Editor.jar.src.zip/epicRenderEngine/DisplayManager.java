/*     */ package epicRenderEngine;
/*     */ 
/*     */ import java.awt.Canvas;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import org.lwjgl.LWJGLException;
/*     */ import org.lwjgl.Sys;
/*     */ import org.lwjgl.opengl.ContextAttribs;
/*     */ import org.lwjgl.opengl.Display;
/*     */ import org.lwjgl.opengl.DisplayMode;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.PixelFormat;
/*     */ 
/*     */ public class DisplayManager
/*     */ {
/*  16 */   private static String title = "Version0_0_4_2";
/*     */   
/*     */   private static final int FRAME_TIME_CAP = 120;
/*     */   
/*     */   private static final boolean vSync = false;
/*     */   
/*     */   private static final boolean START_FULLSCREEN = false;
/*     */   private static final int ROLLING_AVERAGE_LENGTH = 10;
/*     */   private static final float FULLSCREEN_ASPECT_MARGIN = 0.05F;
/*     */   private static final float FULLSCREEN_RESOLUTION = 0.75F;
/*     */   private static final float DELTA_FACTOR = 1000.0F;
/*     */   private static final boolean showAlert = false;
/*  28 */   private static float delta = 0.0F;
/*  29 */   private static long lastFrame = 0L;
/*  30 */   private static List<Float> previousTimes = new java.util.ArrayList();
/*     */   
/*     */   protected static void setUpDisplay(Canvas canvas) {
/*  33 */     PixelFormat format = new PixelFormat();
/*  34 */     ContextAttribs attributes = new ContextAttribs(3, 3).withForwardCompatible(true).withProfileCore(true);
/*     */     
/*     */     try
/*     */     {
/*  38 */       Display.setTitle(title);
/*  39 */       goToWindowDisplay(canvas.getWidth(), canvas.getHeight());
/*     */       
/*     */ 
/*     */ 
/*  43 */       Display.setParent(canvas);
/*  44 */       Display.create(format, attributes);
/*     */     } catch (LWJGLException e) {
/*  46 */       e.printStackTrace();
/*  47 */       System.err.println("Failed to create a display.");
/*  48 */       System.exit(-1);
/*     */     }
/*  50 */     GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
/*  51 */     lastFrame = getTime();
/*     */   }
/*     */   
/*     */   protected static void updateScreen() {
/*  55 */     Display.update();
/*  56 */     Display.sync(120);
/*  57 */     calculateDelta();
/*     */   }
/*     */   
/*     */   public static float getDeltaInSeconds() {
/*  61 */     return delta;
/*     */   }
/*     */   
/*     */   protected static void closeWindow() {}
/*     */   
/*     */   protected static void goToFullScreenDisplay()
/*     */   {
/*     */     try
/*     */     {
/*  70 */       DisplayMode mode = getBestCompatableDisplayMode();
/*  71 */       if (mode == null) {
/*  72 */         System.err.println("Couldn't go fullscreen!");
/*  73 */         return;
/*     */       }
/*  75 */       System.out.println("Going fullscreen with resolution: " + mode.getWidth() + " x " + mode.getHeight() + " x " + mode.getBitsPerPixel() + ", aspect: " + mode.getWidth() / mode.getHeight());
/*     */       
/*     */ 
/*  78 */       Display.setDisplayMode(mode);
/*  79 */       Display.setFullscreen(true);
/*  80 */       if (Display.isCreated()) {
/*  81 */         GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
/*     */       }
/*  83 */       Display.setVSyncEnabled(false);
/*     */     } catch (LWJGLException e) {
/*  85 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void goToWindowDisplay(int width, int height) {
/*     */     try {
/*  91 */       Display.setDisplayMode(new DisplayMode(width, height));
/*  92 */       if (Display.isCreated()) {
/*  93 */         GL11.glViewport(0, 0, width, height);
/*     */       }
/*     */     } catch (LWJGLException e) {
/*  96 */       e.printStackTrace();
/*  97 */       System.err.println("Error changing window size!");
/*     */     }
/*     */   }
/*     */   
/*     */   private static long getTime() {
/* 102 */     return Sys.getTime() * 1000L / Sys.getTimerResolution();
/*     */   }
/*     */   
/*     */   private static void calculateDelta() {
/* 106 */     long time = getTime();
/* 107 */     long difference = time - lastFrame;
/* 108 */     float value = (float)difference / 1000.0F;
/* 109 */     delta = updateRollingAverage(value);
/* 110 */     lastFrame = time;
/*     */   }
/*     */   
/*     */   private static float updateRollingAverage(float value)
/*     */   {
/* 115 */     previousTimes.add(0, Float.valueOf(value));
/* 116 */     if (previousTimes.size() > 10) {
/* 117 */       previousTimes.remove(10);
/*     */     }
/* 119 */     if (previousTimes.size() < 10) {
/* 120 */       return value;
/*     */     }
/* 122 */     return toolbox.Maths.getAverageOfList(previousTimes);
/*     */   }
/*     */   
/*     */   private static DisplayMode getBestCompatableDisplayMode() {
/* 126 */     DisplayMode bestMode = null;
/* 127 */     DisplayMode desktop = Display.getDesktopDisplayMode();
/* 128 */     float perfectAspect = desktop.getWidth() / desktop.getHeight();
/* 129 */     float perfectWidth = desktop.getWidth() * 0.75F;
/*     */     try {
/* 131 */       DisplayMode[] modes = Display.getAvailableDisplayModes();
/* 132 */       for (DisplayMode mode : modes) {
/* 133 */         float testAspect = mode.getWidth() / mode.getHeight();
/* 134 */         if ((testAspect < perfectAspect + 0.05F) && (testAspect > perfectAspect - 0.05F))
/*     */         {
/* 136 */           if (mode.getBitsPerPixel() == desktop.getBitsPerPixel()) {
/* 137 */             if (bestMode == null) {
/* 138 */               bestMode = mode;
/*     */             }
/*     */             else {
/* 141 */               float bestWidthDiff = Math.abs(perfectWidth - bestMode.getWidth());
/* 142 */               float testWidthDiff = Math.abs(perfectWidth - mode.getWidth());
/* 143 */               if (testWidthDiff < bestWidthDiff) {
/* 144 */                 bestMode = mode;
/* 145 */               } else if ((testWidthDiff == bestWidthDiff) && 
/* 146 */                 (mode.getFrequency() > bestMode.getFrequency())) {
/* 147 */                 bestMode = mode;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 155 */       e.printStackTrace();
/*     */     }
/* 157 */     return bestMode;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\epicRenderEngine\DisplayManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */