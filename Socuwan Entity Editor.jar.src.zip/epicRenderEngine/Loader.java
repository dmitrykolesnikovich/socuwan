/*     */ package epicRenderEngine;
/*     */ 
/*     */ import backend.StaticEntity;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import blueprintInterfaces.RawModel;
/*     */ import collisionComponents.CollisionObject;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL15;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ import org.lwjgl.opengl.GL33;
/*     */ import org.newdawn.slick.opengl.Texture;
/*     */ import org.newdawn.slick.opengl.TextureLoader;
/*     */ import particleEffects.ParticleTextureAtlas;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Loader
/*     */ {
/*     */   public static final String FAR_POINT = "FP";
/*     */   private static final String MODEL_FILE_EXT = ".csv";
/*     */   private static final float MIPMAP_BIAS = -0.5F;
/*  44 */   private static Map<Integer, Integer> vaoCache = new HashMap();
/*  45 */   private static List<Integer> vboCache = new ArrayList();
/*  46 */   private static List<Integer> textureCache = new ArrayList();
/*     */   
/*  48 */   private static ModelTexture waitingDiffuse = null;
/*  49 */   private static ModelTexture waitingExtra = null;
/*     */   private static StaticEntity waitingStatic;
/*     */   private static ParticleTextureAtlas waitingParticleAtlas;
/*  52 */   private static List<BoneBlueprint> waitingBones = new ArrayList();
/*  53 */   private static List<CollisionObject> waitingCollisionObjects = new ArrayList();
/*  54 */   private static List<GlRequest> requests = new ArrayList();
/*     */   
/*     */   public static synchronized void dealWithRequests()
/*     */   {
/*  58 */     if ((waitingDiffuse != null) && 
/*  59 */       (waitingDiffuse.getDiffuseFile() != null)) {
/*  60 */       waitingDiffuse.setDiffuseTexture(loadTexture(waitingDiffuse.getDiffuseFile()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  65 */     if (waitingParticleAtlas != null) {
/*  66 */       waitingParticleAtlas.setTexture(loadTexture(waitingParticleAtlas.getFile()));
/*     */     }
/*     */     
/*  69 */     waitingParticleAtlas = null;
/*  70 */     waitingDiffuse = null;
/*  71 */     if ((waitingExtra != null) && 
/*  72 */       (waitingExtra.getSpecularFile() != null)) {
/*  73 */       waitingExtra.setExtraTexture(loadTexture(waitingExtra.getSpecularFile()));
/*     */     }
/*     */     
/*     */ 
/*  77 */     waitingExtra = null;
/*     */     
/*  79 */     if (waitingStatic != null) {
/*  80 */       File modelFile = waitingStatic.getModelFile();
/*  81 */       waitingStatic.setRawModel(loadModelFile(modelFile));
/*     */     }
/*  83 */     waitingStatic = null;
/*     */     
/*  85 */     if (!waitingBones.isEmpty()) {
/*  86 */       for (BoneBlueprint bone : waitingBones) {
/*  87 */         File modelFile = bone.getModelFile();
/*  88 */         bone.setRawModel(loadModelFile(modelFile));
/*     */       }
/*     */     }
/*  91 */     waitingBones.clear();
/*  92 */     if (!waitingCollisionObjects.isEmpty()) {
/*  93 */       for (CollisionObject object : waitingCollisionObjects) {
/*  94 */         RawModel model = new RawModel(0, loadModelToVAO(object.getVertices(), object.getNormals(), object.getTextures(), object.getIndices()), new int[] { object.getIndices().length });
/*     */         
/*     */ 
/*  97 */         object.setLoadedRawModel(model);
/*     */       }
/*     */     }
/* 100 */     waitingCollisionObjects.clear();
/* 101 */     for (GlRequest request : requests) {
/* 102 */       request.excecute();
/*     */     }
/* 104 */     requests.clear();
/*     */   }
/*     */   
/*     */   public static synchronized void sendRequest(GlRequest request) {
/* 108 */     requests.add(request);
/*     */   }
/*     */   
/*     */   public static synchronized void requestCollisionObjectLoading(CollisionObject object) {
/* 112 */     waitingCollisionObjects.add(object);
/*     */   }
/*     */   
/*     */   public static synchronized void requestParticleTextureLoading(ParticleTextureAtlas texture) {
/* 116 */     waitingParticleAtlas = texture;
/*     */   }
/*     */   
/*     */   public static synchronized void requestDiffuseTextureLoading(ModelTexture texture) {
/* 120 */     waitingDiffuse = texture;
/*     */   }
/*     */   
/*     */   public static synchronized void requestBoneModelLoading(BoneBlueprint bone) {
/* 124 */     waitingBones.add(bone);
/*     */   }
/*     */   
/*     */   public static synchronized void requestExtraTextureLoading(ModelTexture texture) {
/* 128 */     waitingExtra = texture;
/*     */   }
/*     */   
/*     */   public static synchronized void requestRawModelLoading(StaticEntity entity) {
/* 132 */     waitingStatic = entity;
/*     */   }
/*     */   
/*     */   public static int loadMipmappedTexture(String fileName) {
/* 136 */     return loadTexture(fileName, true);
/*     */   }
/*     */   
/*     */   public static int loadTexture(String fileName) {
/* 140 */     return loadTexture(fileName, false);
/*     */   }
/*     */   
/*     */   protected static RawModel loadModelFile(int id, String modelFile) {
/*     */     try {
/* 145 */       BufferedReader reader = openModelFile(modelFile);
/* 146 */       float[] vertices = readIntoArray(reader);
/* 147 */       float[] textureCoords = readIntoArray(reader);
/* 148 */       float[] normals = readIntoArray(reader);
/* 149 */       int[][] indicesData = readInAllIndices(reader);
/* 150 */       int vertexArrayID = loadModelToVAO(vertices, normals, textureCoords, indicesData[0]);
/* 151 */       RawModel model = new RawModel(id, vertexArrayID, indicesData[1]);
/*     */       try {
/* 153 */         reader.close();
/*     */       }
/*     */       catch (IOException e) {}
/* 156 */       return model;
/*     */     } catch (Exception e) {
/* 158 */       e.printStackTrace();
/* 159 */       System.exit(-1); }
/* 160 */     return null;
/*     */   }
/*     */   
/*     */   public static RawModel loadRawModel(ModelData data)
/*     */   {
/* 165 */     int vertexArrayID = loadModelToVAO(data.getVertices(), data.getNormals(), data.getTextureCoords(), data.getIndices());
/*     */     
/* 167 */     RawModel model = new RawModel(0, vertexArrayID, data.getLengths());
/* 168 */     model.setFurthestPoint(data.getFarPoint());
/* 169 */     return model;
/*     */   }
/*     */   
/*     */   public static ModelData loadModelData(File modelFile) throws Exception {
/* 173 */     BufferedReader reader = openFile(modelFile);
/* 174 */     String lineValue = null;
/* 175 */     float farPoint = 10.0F;
/* 176 */     lineValue = reader.readLine();
/* 177 */     if (lineValue.contains("FP")) {
/* 178 */       farPoint = Float.parseFloat(lineValue.split(",")[1]);
/* 179 */       lineValue = reader.readLine();
/*     */     }
/* 181 */     float[] vertices = readIntoArray(reader, lineValue);
/* 182 */     float[] textureCoords = readIntoArray(reader);
/* 183 */     float[] normals = readIntoArray(reader);
/* 184 */     int[][] indicesData = readInAllIndices(reader);
/* 185 */     ModelData modelData = new ModelData(vertices, normals, textureCoords, indicesData[0], indicesData[1], farPoint);
/*     */     
/* 187 */     reader.close();
/* 188 */     return modelData;
/*     */   }
/*     */   
/*     */   public static void clearVaoFromMemory(Integer vao) {
/* 192 */     Integer vbo = (Integer)vaoCache.remove(vao);
/* 193 */     if (vbo != null) {
/* 194 */       GL15.glDeleteBuffers(vbo.intValue());
/* 195 */       GL30.glDeleteVertexArrays(vao.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] normals, float[] textureCoords) {
/* 200 */     int vertexArrayID = createVAO();
/* 201 */     storeInterleavedDataInVAO(vertexArrayID, vertices, normals, textureCoords);
/* 202 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] textureCoords) {
/* 206 */     int vertexArrayID = createVAO();
/* 207 */     storeInterleavedDataInVAO(vertexArrayID, vertices, textureCoords);
/* 208 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] textureCoords, int[] indices) {
/* 212 */     int vertexArrayID = createVAO();
/* 213 */     createIndicesVBO(indices);
/* 214 */     storeInterleavedDataInVAO(vertexArrayID, vertices, textureCoords);
/* 215 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices, float[] normals, float[] textureCoords, int[] indices)
/*     */   {
/* 220 */     int vertexArrayID = createVAO();
/* 221 */     createIndicesVBO(indices);
/* 222 */     storeInterleavedDataInVAO(vertexArrayID, vertices, normals, textureCoords);
/* 223 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int loadModelToVAO(float[] vertices) {
/* 227 */     int vertexArrayID = createVAO();
/* 228 */     storePositionDataInVAO(vertexArrayID, vertices);
/* 229 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   public static int createIndicesVBO(int[] indices) {
/* 233 */     IntBuffer indicesBuffer = BufferUtils.createIntBuffer(indices.length);
/* 234 */     indicesBuffer.put(indices);
/* 235 */     indicesBuffer.flip();
/* 236 */     int indicesBufferId = GL15.glGenBuffers();
/* 237 */     vboCache.add(Integer.valueOf(indicesBufferId));
/* 238 */     GL15.glBindBuffer(34963, indicesBufferId);
/* 239 */     GL15.glBufferData(34963, indicesBuffer, 35044);
/* 240 */     return indicesBufferId;
/*     */   }
/*     */   
/*     */   protected static void cleanUpModelMemory() {
/* 244 */     GL20.glDisableVertexAttribArray(0);
/* 245 */     GL15.glBindBuffer(34962, 0);
/* 246 */     GL30.glBindVertexArray(0);
/*     */     
/* 248 */     for (Iterator i$ = textureCache.iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 249 */       GL11.glDeleteTextures(id);
/*     */     }
/* 251 */     for (Iterator i$ = vboCache.iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 252 */       GL15.glDeleteBuffers(id);
/*     */     }
/* 254 */     for (Iterator i$ = vaoCache.keySet().iterator(); i$.hasNext();) { int id = ((Integer)i$.next()).intValue();
/* 255 */       GL30.glDeleteVertexArrays(id);
/* 256 */       GL15.glDeleteBuffers(((Integer)vaoCache.get(Integer.valueOf(id))).intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   protected static RawModel loadModelFile(File modelFile) {
/* 261 */     BufferedReader reader = openFile(modelFile);
/* 262 */     String lineValue = null;
/* 263 */     float farPoint = 10.0F;
/*     */     try {
/* 265 */       lineValue = reader.readLine();
/* 266 */       if (lineValue.contains("FP")) {
/* 267 */         farPoint = Float.parseFloat(lineValue.split(",")[1]);
/* 268 */         lineValue = reader.readLine();
/*     */       }
/* 270 */       float[] vertices = readIntoArray(reader, lineValue);
/* 271 */       float[] textureCoords = readIntoArray(reader);
/* 272 */       float[] normals = readIntoArray(reader);
/* 273 */       int[][] indicesData = readInAllIndices(reader);
/* 274 */       int vertexArrayID = loadModelToVAO(vertices, normals, textureCoords, indicesData[0]);
/* 275 */       RawModel model = new RawModel(0, vertexArrayID, indicesData[1]);
/* 276 */       model.setFurthestPoint(farPoint);
/*     */       try {
/* 278 */         reader.close();
/*     */       }
/*     */       catch (IOException e) {}
/* 281 */       return model;
/*     */     } catch (Exception e) {
/* 283 */       e.printStackTrace();
/* 284 */       System.exit(-1); }
/* 285 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private static void storeInterleavedDataInVAO(int vaoID, float[] vertices, float[] normals, float[] textureCoords)
/*     */   {
/* 291 */     FloatBuffer interleavedData = interleaveDataInBuffer(vertices, normals, textureCoords);
/* 292 */     int bufferObjectID = GL15.glGenBuffers();
/* 293 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 294 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 295 */     GL15.glBufferData(34962, interleavedData, 35044);
/*     */     
/* 297 */     int vertexByteCount = 32;
/* 298 */     GL20.glVertexAttribPointer(0, 3, 5126, false, vertexByteCount, 0L);
/* 299 */     GL20.glVertexAttribPointer(1, 3, 5126, false, vertexByteCount, 12L);
/*     */     
/* 301 */     GL20.glVertexAttribPointer(2, 2, 5126, false, vertexByteCount, 24L);
/*     */     
/*     */ 
/* 304 */     GL15.glBindBuffer(34962, 0);
/* 305 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   private static void storePositionDataInVAO(int vaoID, float[] vertices) {
/* 309 */     FloatBuffer buffer = BufferUtils.createFloatBuffer(vertices.length);
/* 310 */     buffer.put(vertices);
/* 311 */     buffer.flip();
/* 312 */     int bufferObjectID = GL15.glGenBuffers();
/* 313 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 314 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 315 */     GL15.glBufferData(34962, buffer, 35044);
/* 316 */     GL20.glVertexAttribPointer(0, 3, 5126, false, 0, 0L);
/* 317 */     GL15.glBindBuffer(34962, 0);
/* 318 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   public static void updateInstanceVBO(int vbo, float[] data, int elementMaxCount, int elementSize, FloatBuffer buffer)
/*     */   {
/* 323 */     if (data.length >= elementMaxCount * elementSize) {
/* 324 */       System.err.println("TOO MUCH DATA UPDATED IN VBO!");
/* 325 */       return;
/*     */     }
/* 327 */     buffer.clear();
/* 328 */     buffer.put(data);
/* 329 */     buffer.flip();
/* 330 */     GL15.glBindBuffer(34962, vbo);
/* 331 */     GL15.glBufferData(34962, elementMaxCount * elementSize * 4, 35040);
/*     */     
/* 333 */     GL15.glBufferSubData(34962, 0L, buffer);
/* 334 */     GL15.glBindBuffer(34962, 0);
/*     */   }
/*     */   
/*     */   public static int createEmptyInstanceVBO(int vaoID, int attribute, int maxElementCount, int elementSize)
/*     */   {
/* 339 */     GL30.glBindVertexArray(vaoID);
/* 340 */     int vboID = GL15.glGenBuffers();
/* 341 */     vboCache.add(Integer.valueOf(vboID));
/* 342 */     GL15.glBindBuffer(34962, vboID);
/* 343 */     GL15.glBufferData(34962, maxElementCount * elementSize * 4, 35040);
/*     */     
/* 345 */     GL20.glVertexAttribPointer(attribute, elementSize, 5126, false, 0, 0L);
/* 346 */     GL33.glVertexAttribDivisor(attribute, 1);
/* 347 */     GL15.glBindBuffer(34962, 0);
/* 348 */     GL30.glBindVertexArray(0);
/* 349 */     return vboID;
/*     */   }
/*     */   
/*     */   public static int createInterleavedInstanceVBO(int vaoID, int startingAttribute, int maxElementCount, int... sizes)
/*     */   {
/* 354 */     GL30.glBindVertexArray(vaoID);
/* 355 */     int vboID = GL15.glGenBuffers();
/* 356 */     vboCache.add(Integer.valueOf(vboID));
/* 357 */     int totalElementSize = 0;
/* 358 */     for (int size : sizes) {
/* 359 */       totalElementSize += size;
/*     */     }
/* 361 */     totalElementSize *= 4;
/* 362 */     GL15.glBindBuffer(34962, vboID);
/* 363 */     GL15.glBufferData(34962, maxElementCount * totalElementSize, 35040);
/*     */     
/*     */ 
/* 366 */     int offset = 0;
/* 367 */     for (int i = 0; i < sizes.length; i++) {
/* 368 */       GL20.glVertexAttribPointer(i + startingAttribute, sizes[i], 5126, false, totalElementSize, offset);
/*     */       
/* 370 */       GL33.glVertexAttribDivisor(i + startingAttribute, 1);
/* 371 */       offset += sizes[i] * 4;
/*     */     }
/*     */     
/* 374 */     GL15.glBindBuffer(34962, 0);
/* 375 */     GL30.glBindVertexArray(0);
/* 376 */     return vboID;
/*     */   }
/*     */   
/*     */   private static BufferedReader openFile(File file) {
/* 380 */     BufferedReader reader = null;
/*     */     try {
/* 382 */       FileReader isr = new FileReader(file);
/* 383 */       reader = new BufferedReader(isr);
/*     */     } catch (FileNotFoundException e) {
/* 385 */       System.err.println("File not found!");
/* 386 */       e.printStackTrace();
/* 387 */       System.exit(-1);
/*     */     }
/* 389 */     return reader;
/*     */   }
/*     */   
/*     */   private static void storeInterleavedDataInVAO(int vaoID, float[] vertices, float[] textureCoords) {
/* 393 */     FloatBuffer interleavedData = interleaveDataInBuffer(vertices, textureCoords);
/* 394 */     int bufferObjectID = GL15.glGenBuffers();
/* 395 */     vaoCache.put(Integer.valueOf(vaoID), Integer.valueOf(bufferObjectID));
/* 396 */     GL15.glBindBuffer(34962, bufferObjectID);
/* 397 */     GL15.glBufferData(34962, interleavedData, 35044);
/*     */     
/* 399 */     int vertexByteCount = 20;
/* 400 */     GL20.glVertexAttribPointer(0, 3, 5126, false, vertexByteCount, 0L);
/* 401 */     GL20.glVertexAttribPointer(1, 2, 5126, false, vertexByteCount, 12L);
/*     */     
/*     */ 
/* 404 */     GL15.glBindBuffer(34962, 0);
/* 405 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */   
/*     */   private static FloatBuffer interleaveDataInBuffer(float[] vertices, float[] normals, float[] textureCoords)
/*     */   {
/* 410 */     FloatBuffer interleavedBuffer = BufferUtils.createFloatBuffer(vertices.length + normals.length + textureCoords.length);
/*     */     
/* 412 */     int veticesPointer = 0;
/* 413 */     int normalsPointer = 0;
/* 414 */     int texturePointer = 0;
/* 415 */     for (int i = 0; i < vertices.length / 3; i++) {
/* 416 */       interleavedBuffer.put(new float[] { vertices[(veticesPointer++)], vertices[(veticesPointer++)], vertices[(veticesPointer++)] });
/*     */       
/* 418 */       interleavedBuffer.put(new float[] { normals[(normalsPointer++)], normals[(normalsPointer++)], normals[(normalsPointer++)] });
/*     */       
/* 420 */       interleavedBuffer.put(new float[] { textureCoords[(texturePointer++)], textureCoords[(texturePointer++)] });
/*     */     }
/*     */     
/* 423 */     interleavedBuffer.flip();
/* 424 */     return interleavedBuffer;
/*     */   }
/*     */   
/*     */   private static FloatBuffer interleaveDataInBuffer(float[] vertices, float[] textureCoords) {
/* 428 */     FloatBuffer interleavedBuffer = BufferUtils.createFloatBuffer(vertices.length + textureCoords.length);
/*     */     
/* 430 */     int veticesPointer = 0;
/* 431 */     int texturePointer = 0;
/* 432 */     for (int i = 0; i < vertices.length / 3; i++) {
/* 433 */       interleavedBuffer.put(new float[] { vertices[(veticesPointer++)], vertices[(veticesPointer++)], vertices[(veticesPointer++)] });
/*     */       
/* 435 */       interleavedBuffer.put(new float[] { textureCoords[(texturePointer++)], textureCoords[(texturePointer++)] });
/*     */     }
/*     */     
/* 438 */     interleavedBuffer.flip();
/* 439 */     return interleavedBuffer;
/*     */   }
/*     */   
/*     */   private static int createVAO() {
/* 443 */     int vertexArrayID = GL30.glGenVertexArrays();
/* 444 */     GL30.glBindVertexArray(vertexArrayID);
/* 445 */     return vertexArrayID;
/*     */   }
/*     */   
/*     */   private static BufferedReader openModelFile(String fileStem) {
/* 449 */     BufferedReader reader = null;
/*     */     try {
/* 451 */       InputStream in = Class.class.getResourceAsStream("/res/" + fileStem + ".csv");
/*     */       
/* 453 */       InputStreamReader isr = new InputStreamReader(in);
/* 454 */       reader = new BufferedReader(isr);
/*     */     } catch (Exception e) {
/* 456 */       e.printStackTrace();
/* 457 */       System.out.println();
/* 458 */       System.err.println("Unable to find model file: " + fileStem);
/* 459 */       System.exit(-1);
/*     */     }
/* 461 */     return reader;
/*     */   }
/*     */   
/*     */   private static float[] readIntoArray(BufferedReader reader) throws Exception {
/* 465 */     float[] theArray = null;
/* 466 */     String lineValue = reader.readLine();
/* 467 */     if (lineValue.contains("FP")) {
/* 468 */       float farPoint = Float.parseFloat(lineValue.split(",")[1]);
/* 469 */       lineValue = reader.readLine();
/*     */     }
/* 471 */     theArray = new float[Integer.valueOf(lineValue).intValue()];
/* 472 */     String[] line = reader.readLine().split(",");
/* 473 */     for (int i = 0; i < theArray.length; i++) {
/* 474 */       theArray[i] = Float.valueOf(line[i]).floatValue();
/*     */     }
/* 476 */     return theArray;
/*     */   }
/*     */   
/*     */   private static float[] readIntoArray(BufferedReader reader, String firstLine) throws Exception {
/* 480 */     float[] theArray = null;
/* 481 */     String lineValue = firstLine;
/* 482 */     theArray = new float[Integer.valueOf(lineValue).intValue()];
/* 483 */     String[] line = reader.readLine().split(",");
/* 484 */     for (int i = 0; i < theArray.length; i++) {
/* 485 */       theArray[i] = Float.valueOf(line[i]).floatValue();
/*     */     }
/* 487 */     return theArray;
/*     */   }
/*     */   
/*     */   private static int[][] readInAllIndices(BufferedReader reader) throws Exception {
/* 491 */     List<Integer> listOfIndices = new ArrayList();
/* 492 */     List<Integer> listOfLengths = new ArrayList();
/* 493 */     listOfLengths.add(Integer.valueOf(reader.readLine()));
/* 494 */     String[] line = reader.readLine().split(",");
/* 495 */     for (int i = 0; i < line.length; i++) {
/* 496 */       listOfIndices.add(Integer.valueOf(line[i]));
/*     */     }
/*     */     
/*     */     String fullLine;
/* 500 */     while (((fullLine = reader.readLine()) != null) && (!fullLine.equals("NEWSECTION"))) {
/* 501 */       line = fullLine.split(",");
/* 502 */       int lod = Integer.valueOf(line[0]).intValue();
/* 503 */       while (listOfLengths.size() < lod) {
/* 504 */         listOfLengths.add(Integer.valueOf(0));
/*     */       }
/* 506 */       listOfLengths.add(Integer.valueOf(Integer.valueOf(line[1]).intValue()));
/* 507 */       line = reader.readLine().split(",");
/* 508 */       for (int i = 0; i < line.length; i++) {
/* 509 */         listOfIndices.add(Integer.valueOf(line[i]));
/*     */       }
/*     */     }
/* 512 */     int[] indicesArray = new int[listOfIndices.size()];
/* 513 */     for (int i = 0; i < indicesArray.length; i++) {
/* 514 */       indicesArray[i] = ((Integer)listOfIndices.get(i)).intValue();
/*     */     }
/* 516 */     int[] lengthsArray = new int[listOfLengths.size()];
/* 517 */     for (int i = 0; i < lengthsArray.length; i++) {
/* 518 */       lengthsArray[i] = ((Integer)listOfLengths.get(i)).intValue();
/*     */     }
/* 520 */     return new int[][] { indicesArray, lengthsArray };
/*     */   }
/*     */   
/*     */   private static int loadTexture(String fileName, boolean mipmap) {
/* 524 */     Texture texture = null;
/*     */     try {
/* 526 */       InputStream is = Class.class.getResourceAsStream("/res/" + fileName + ".png");
/* 527 */       texture = TextureLoader.getTexture("PNG", is);
/* 528 */       is.close();
/*     */     } catch (Exception e) {
/* 530 */       e.printStackTrace();
/* 531 */       System.err.println("Tried to load texture " + fileName + ".png , didn't work");
/* 532 */       System.exit(-1);
/*     */     }
/* 534 */     if (mipmap) {
/* 535 */       GL30.glGenerateMipmap(3553);
/* 536 */       GL11.glTexParameteri(3553, 10240, 9729);
/* 537 */       GL11.glTexParameteri(3553, 10241, 9987);
/*     */       
/* 539 */       GL11.glTexParameterf(3553, 34049, -0.5F);
/*     */     }
/* 541 */     textureCache.add(Integer.valueOf(texture.getTextureID()));
/* 542 */     return texture.getTextureID();
/*     */   }
/*     */   
/*     */   public static int loadTexture(File file) {
/* 546 */     Texture texture = null;
/*     */     try {
/* 548 */       FileInputStream is = new FileInputStream(file);
/* 549 */       texture = TextureLoader.getTexture("PNG", is);
/* 550 */       is.close();
/*     */     } catch (Exception e) {
/* 552 */       e.printStackTrace();
/* 553 */       System.err.println("Tried to load texture " + file.getName() + ", didn't work");
/* 554 */       System.exit(-1);
/*     */     }
/* 556 */     GL30.glGenerateMipmap(3553);
/* 557 */     GL11.glTexParameteri(3553, 10240, 9729);
/* 558 */     GL11.glTexParameteri(3553, 10241, 9987);
/*     */     
/* 560 */     GL11.glTexParameterf(3553, 34049, -0.5F);
/* 561 */     textureCache.add(Integer.valueOf(texture.getTextureID()));
/* 562 */     return texture.getTextureID();
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\epicRenderEngine\Loader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */