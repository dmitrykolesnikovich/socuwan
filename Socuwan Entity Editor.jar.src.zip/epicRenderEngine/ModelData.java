/*    */ package epicRenderEngine;
/*    */ 
/*    */ public class ModelData
/*    */ {
/*    */   private float[] vertices;
/*    */   private float[] normals;
/*    */   private float[] textureCoords;
/*    */   private int[] indices;
/*    */   private int[] lengths;
/*    */   private float farPoint;
/*    */   
/*    */   public ModelData(float[] vertices, float[] normals, float[] textureCoords, int[] indices, int[] lengths, float farPoint) {
/* 13 */     this.vertices = vertices;
/* 14 */     this.normals = normals;
/* 15 */     this.textureCoords = textureCoords;
/* 16 */     this.indices = indices;
/* 17 */     this.lengths = lengths;
/* 18 */     this.farPoint = farPoint;
/*    */   }
/*    */   
/*    */   public float[] getVertices() {
/* 22 */     return this.vertices;
/*    */   }
/*    */   
/*    */   public float[] getNormals() {
/* 26 */     return this.normals;
/*    */   }
/*    */   
/*    */   public float[] getTextureCoords() {
/* 30 */     return this.textureCoords;
/*    */   }
/*    */   
/*    */   public int[] getIndices() {
/* 34 */     return this.indices;
/*    */   }
/*    */   
/*    */   public int[] getLengths() {
/* 38 */     return this.lengths;
/*    */   }
/*    */   
/*    */   public float getFarPoint() {
/* 42 */     return this.farPoint;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\epicRenderEngine\ModelData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */