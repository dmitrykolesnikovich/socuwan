/*     */ package frontend;
/*     */ 
/*     */ import backend.AnimatedEntity;
/*     */ import backend.Entity;
/*     */ import backend.EntityType;
/*     */ import backend.RenderOption;
/*     */ import backend.StaticEntity;
/*     */ import instances.StaticInstance;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.NumberFormatter;
/*     */ import main.MainApp;
/*     */ import toolbox.Transformation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardInfoPanel
/*     */   extends JPanel
/*     */ {
/*     */   private JPanel idPanel;
/*     */   private JPanel modelPanel;
/*     */   private JButton modelButton;
/*     */   private JPanel distanceSettings;
/*     */   private JPanel reflactSettings;
/*     */   private JPanel extraReflectSettings;
/*     */   private JFormattedTextField visibility;
/*     */   private JFormattedTextField radiusField;
/*     */   private JCheckBox hasReflectionCheck;
/*     */   private JCheckBox hasRefractionCheck;
/*     */   private JComboBox<RenderOption> options;
/*     */   private JCheckBox hasLimitedReflectionCheck;
/*     */   private JFormattedTextField reflectionLimit;
/*     */   private JTextField id;
/*     */   private Entity entity;
/*     */   private MainFrame mainFrame;
/*     */   
/*     */   public StandardInfoPanel(int width, int height, Entity entity, MainFrame mainFrame)
/*     */   {
/*  56 */     this.entity = entity;
/*  57 */     this.mainFrame = mainFrame;
/*  58 */     setPreferredSize(new Dimension(width, height));
/*  59 */     setLayout(new GridBagLayout());
/*  60 */     initFields();
/*  61 */     updateFields();
/*     */   }
/*     */   
/*     */   public void setEntity(Entity entity) {
/*  65 */     this.entity = entity;
/*  66 */     updateFields();
/*     */   }
/*     */   
/*     */   private void initFields() {
/*  70 */     GridBagConstraints gc = new GridBagConstraints();
/*  71 */     gc.gridy = 0;
/*  72 */     initIDPanel(gc);
/*  73 */     gc.gridy = 1;
/*  74 */     initModelButton(gc);
/*  75 */     gc.gridy = 2;
/*  76 */     initDistanceSettings(gc);
/*  77 */     gc.gridy = 3;
/*  78 */     initReflactSettings(gc);
/*  79 */     gc.gridy = 4;
/*  80 */     initExtraReflectSettings(gc);
/*     */   }
/*     */   
/*     */   private void updateFields() {
/*  84 */     this.id.setText(Integer.toString(this.entity.getId()));
/*  85 */     if (this.entity.hasModel()) {
/*  86 */       this.modelButton.setText("Change Model...");
/*  87 */       this.modelButton.setForeground(new Color(0, 255, 0));
/*     */     } else {
/*  89 */       this.modelButton.setText("Choose Model...");
/*  90 */       this.modelButton.setForeground(new Color(255, 0, 0));
/*     */     }
/*  92 */     this.visibility.setText(Float.toString(this.entity.getVisibleRange()));
/*  93 */     this.radiusField.setText(Float.toString(this.entity.getFurthestPoint()));
/*  94 */     MainApp.sphere.getTransformation().setScale(this.entity.getFurthestPoint());
/*  95 */     this.hasReflectionCheck.setSelected(this.entity.hasReflection());
/*  96 */     this.hasRefractionCheck.setSelected(this.entity.isVisibleUnderWater());
/*  97 */     this.extraReflectSettings.setVisible(this.hasReflectionCheck.isSelected());
/*  98 */     this.hasLimitedReflectionCheck.setSelected(this.entity.hasLimitedReflection());
/*  99 */     this.reflectionLimit.setText(Float.toString(this.entity.getReflectionLimit()));
/* 100 */     this.reflectionLimit.setVisible((this.hasReflectionCheck.isSelected()) && (this.hasLimitedReflectionCheck.isSelected()));
/* 101 */     this.options.setSelectedItem(this.entity.getRenderMethod());
/*     */   }
/*     */   
/*     */   public void updateRadius() {
/* 105 */     this.radiusField.setText(Float.toString(this.entity.getFurthestPoint()));
/* 106 */     MainApp.sphere.getTransformation().setScale(this.entity.getFurthestPoint());
/*     */   }
/*     */   
/*     */   private void initIDPanel(GridBagConstraints gc) {
/* 110 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 111 */     gc2.fill = 1;
/* 112 */     gc2.gridx = 0;
/* 113 */     this.idPanel = new JPanel();
/* 114 */     add(this.idPanel, gc);
/* 115 */     this.idPanel.setLayout(new GridBagLayout());
/* 116 */     JLabel label = new JLabel("ID: ");
/* 117 */     label.setFont(MainFrame.MEDIUM_FONT);
/* 118 */     this.idPanel.add(label, gc2);
/*     */     
/* 120 */     this.id = new JTextField(Integer.toString(this.entity.getId()), 10);
/* 121 */     this.id.setFont(MainFrame.MEDIUM_FONT);
/* 122 */     ((AbstractDocument)this.id.getDocument()).setDocumentFilter(new MyDocumentFilter(9));
/* 123 */     this.id.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 125 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 129 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 133 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 137 */         String text = StandardInfoPanel.this.removeLetters();
/* 138 */         if (text.equals("")) {
/* 139 */           return;
/*     */         }
/* 141 */         StandardInfoPanel.this.entity.setID(Integer.parseInt(text));
/*     */       }
/* 143 */     });
/* 144 */     gc2.gridx = 1;
/* 145 */     this.idPanel.add(this.id, gc2);
/*     */   }
/*     */   
/*     */   private void initModelButton(GridBagConstraints gc) {
/* 149 */     this.modelPanel = new JPanel();
/* 150 */     this.options = new JComboBox(RenderOption.values());
/* 151 */     this.options.setFont(MainFrame.SMALL_FONT);
/* 152 */     this.options.setSelectedItem(this.entity.getRenderMethod());
/* 153 */     this.options.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 157 */         StandardInfoPanel.this.entity.setRenderOption((RenderOption)StandardInfoPanel.this.options.getSelectedItem()); }
/* 158 */     });
/* 159 */     this.modelPanel.add(this.options);
/* 160 */     if (this.entity.hasModel()) {
/* 161 */       this.modelButton = new JButton("Change Model...");
/* 162 */       this.modelButton.setForeground(new Color(0, 255, 0));
/*     */     } else {
/* 164 */       this.modelButton = new JButton("Choose Model...");
/* 165 */       this.modelButton.setForeground(new Color(255, 0, 0));
/*     */     }
/* 167 */     this.modelButton.setFont(MainFrame.SMALL_FONT);
/* 168 */     this.modelButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 172 */         if (StandardInfoPanel.this.entity.getType() == EntityType.STATIC) {
/* 173 */           new ModelChooseScreen(StandardInfoPanel.this.mainFrame, (StaticEntity)StandardInfoPanel.this.entity, StandardInfoPanel.this.modelButton);
/*     */         } else {
/* 175 */           new ColladaChooseScreen((AnimatedEntity)StandardInfoPanel.this.entity, StandardInfoPanel.this.modelButton, StandardInfoPanel.this.mainFrame);
/*     */         }
/*     */         
/*     */       }
/* 179 */     });
/* 180 */     this.modelPanel.add(this.modelButton);
/* 181 */     add(this.modelPanel, gc);
/*     */   }
/*     */   
/*     */   private void initDistanceSettings(GridBagConstraints gc) {
/* 185 */     this.distanceSettings = new JPanel();
/* 186 */     JLabel visibilityLabel = new JLabel("Visibility: ");
/* 187 */     visibilityLabel.setFont(MainFrame.SMALL_FONT);
/* 188 */     this.distanceSettings.add(visibilityLabel);
/*     */     
/* 190 */     this.visibility = createTextField(5);
/* 191 */     this.visibility.setText(Float.toString(this.entity.getVisibleRange()));
/* 192 */     this.visibility.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 194 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 198 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 202 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 206 */         if (StandardInfoPanel.this.visibility.getText().equals("")) {
/* 207 */           return;
/*     */         }
/* 209 */         StandardInfoPanel.this.entity.setVisibleRange(Float.parseFloat(StandardInfoPanel.this.visibility.getText().replaceAll(",", "")));
/*     */       }
/* 211 */     });
/* 212 */     this.distanceSettings.add(this.visibility);
/*     */     
/* 214 */     JLabel furthest = new JLabel("Radius: ");
/* 215 */     furthest.setFont(MainFrame.SMALL_FONT);
/* 216 */     this.distanceSettings.add(furthest);
/*     */     
/* 218 */     this.radiusField = createTextField(5);
/* 219 */     this.radiusField.setText(Float.toString(this.entity.getFurthestPoint()));
/* 220 */     this.radiusField.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 222 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 226 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 230 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 234 */         if (StandardInfoPanel.this.radiusField.getText().equals("")) {
/* 235 */           return;
/*     */         }
/* 237 */         StandardInfoPanel.this.entity.setFurthestPoint(Float.parseFloat(StandardInfoPanel.this.radiusField.getText().replaceAll(",", "")));
/* 238 */         MainApp.sphere.getTransformation().setScale(StandardInfoPanel.this.entity.getFurthestPoint());
/*     */       }
/* 240 */     });
/* 241 */     this.distanceSettings.add(this.radiusField);
/* 242 */     add(this.distanceSettings, gc);
/*     */   }
/*     */   
/*     */   private void initReflactSettings(GridBagConstraints gc) {
/* 246 */     this.reflactSettings = new JPanel();
/* 247 */     add(this.reflactSettings, gc);
/* 248 */     this.reflactSettings.setLayout(new GridBagLayout());
/* 249 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 250 */     gc2.fill = 1;
/* 251 */     gc2.gridx = 0;
/* 252 */     this.hasReflectionCheck = new JCheckBox("Has a reflection ");
/* 253 */     this.hasReflectionCheck.setFont(MainFrame.SMALL_FONT);
/* 254 */     this.hasReflectionCheck.setSelected(this.entity.hasReflection());
/* 255 */     this.hasReflectionCheck.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 259 */         StandardInfoPanel.this.entity.setHasReflection(StandardInfoPanel.this.hasReflectionCheck.isSelected());
/* 260 */         StandardInfoPanel.this.extraReflectSettings.setVisible(StandardInfoPanel.this.hasReflectionCheck.isSelected());
/* 261 */         StandardInfoPanel.this.reflectionLimit.setVisible((StandardInfoPanel.this.hasReflectionCheck.isSelected()) && (StandardInfoPanel.this.hasLimitedReflectionCheck.isSelected()));
/*     */       }
/* 263 */     });
/* 264 */     this.reflactSettings.add(this.hasReflectionCheck, gc2);
/*     */     
/* 266 */     gc2.gridx = 1;
/* 267 */     this.hasRefractionCheck = new JCheckBox("Visible under water");
/* 268 */     this.hasRefractionCheck.setFont(MainFrame.SMALL_FONT);
/* 269 */     this.hasRefractionCheck.setSelected(this.entity.isVisibleUnderWater());
/* 270 */     this.hasRefractionCheck.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 274 */         StandardInfoPanel.this.entity.setVisibleUnderWater(StandardInfoPanel.this.hasRefractionCheck.isSelected());
/*     */       }
/* 276 */     });
/* 277 */     this.reflactSettings.add(this.hasRefractionCheck, gc2);
/*     */   }
/*     */   
/*     */   private void initExtraReflectSettings(GridBagConstraints gc)
/*     */   {
/* 282 */     this.extraReflectSettings = new JPanel();
/* 283 */     this.extraReflectSettings.setVisible(this.hasReflectionCheck.isSelected());
/* 284 */     add(this.extraReflectSettings, gc);
/* 285 */     this.extraReflectSettings.setLayout(new GridBagLayout());
/* 286 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 287 */     gc2.fill = 1;
/* 288 */     gc2.gridx = 0;
/* 289 */     this.hasLimitedReflectionCheck = new JCheckBox("Has limited reflection ");
/* 290 */     this.hasLimitedReflectionCheck.setFont(MainFrame.SMALL_FONT);
/* 291 */     this.hasLimitedReflectionCheck.setSelected(this.entity.hasLimitedReflection());
/* 292 */     this.hasLimitedReflectionCheck.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 296 */         StandardInfoPanel.this.extraReflectSettings.setVisible(false);
/* 297 */         StandardInfoPanel.this.reflectionLimit.setVisible((StandardInfoPanel.this.hasReflectionCheck.isSelected()) && (StandardInfoPanel.this.hasLimitedReflectionCheck.isSelected()));
/* 298 */         StandardInfoPanel.this.extraReflectSettings.setVisible(StandardInfoPanel.this.hasReflectionCheck.isSelected());
/* 299 */         StandardInfoPanel.this.entity.setHasLimitedReflection(StandardInfoPanel.this.hasLimitedReflectionCheck.isSelected());
/*     */       }
/* 301 */     });
/* 302 */     this.extraReflectSettings.add(this.hasLimitedReflectionCheck, gc2);
/* 303 */     gc2.gridx = 1;
/* 304 */     this.reflectionLimit = createTextField(5);
/* 305 */     this.reflectionLimit.setText(Float.toString(this.entity.getReflectionLimit()));
/* 306 */     this.reflectionLimit.getDocument().addDocumentListener(new DocumentListener() {
/*     */       public void changedUpdate(DocumentEvent e) {
/* 308 */         warn();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent e) {
/* 312 */         warn();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent e) {
/* 316 */         warn();
/*     */       }
/*     */       
/*     */       public void warn() {
/* 320 */         if (StandardInfoPanel.this.reflectionLimit.getText().equals("")) {
/* 321 */           return;
/*     */         }
/* 323 */         StandardInfoPanel.this.entity.setLimitedReflection(Float.parseFloat(StandardInfoPanel.this.reflectionLimit.getText().replaceAll(",", "")));
/*     */       }
/* 325 */     });
/* 326 */     this.extraReflectSettings.add(this.reflectionLimit, gc2);
/*     */   }
/*     */   
/*     */   private String removeLetters() {
/* 330 */     String text = this.id.getText();
/* 331 */     String number = text.replaceAll("[^0-9]", "");
/* 332 */     return number;
/*     */   }
/*     */   
/*     */   private JFormattedTextField createTextField(int columns) {
/* 336 */     NumberFormat floatFormat = NumberFormat.getNumberInstance();
/* 337 */     floatFormat.setMinimumFractionDigits(1);
/* 338 */     floatFormat.setMaximumFractionDigits(5);
/* 339 */     NumberFormatter numberFormatter = new NumberFormatter(floatFormat);
/* 340 */     numberFormatter.setValueClass(Float.class);
/* 341 */     numberFormatter.setAllowsInvalid(false);
/* 342 */     numberFormatter.setMinimum(Float.valueOf(0.0F));
/* 343 */     JFormattedTextField text = new JFormattedTextField(numberFormatter);
/* 344 */     text.setColumns(columns);
/* 345 */     text.setFont(MainFrame.SMALL_FONT);
/* 346 */     text.setHorizontalAlignment(0);
/* 347 */     return text;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\StandardInfoPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */