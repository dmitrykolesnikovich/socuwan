/*     */ package frontend;
/*     */ 
/*     */ import backend.AnimatedEntity;
/*     */ import backend.Entity;
/*     */ import backend.EntityType;
/*     */ import backend.StaticEntity;
/*     */ import backend.Workspace;
/*     */ import componentArchitecture.AddComponentPanel;
/*     */ import componentArchitecture.Component;
/*     */ import componentArchitecture.ComponentListPanel;
/*     */ import componentArchitecture.ComponentPanel;
/*     */ import componentArchitecture.ComponentType;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.IOException;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import main.Camera;
/*     */ 
/*     */ public class MainFrame
/*     */ {
/*     */   public static final int PANEL_HEIGHTS = 650;
/*     */   public static final int MAIN_PANEL_WIDTH = 600;
/*     */   public static final int COMPONENT_PANEL_WIDTH = 230;
/*     */   public static final int SETTINGS_PANEL_WIDTH = 420;
/*     */   private static final int MAIN_SETTINGS_HEIGHT = 180;
/*     */   private static final int PREVIEW_SETTINGS_HEIGHT = 105;
/*     */   private static final int COMPONENT_ADD_PANEL_HEIGHT = 50;
/*     */   private static final String TITLE = "Socuwan Entity Editor";
/*     */   private static final int WIDTH = 1280;
/*     */   private static final int HEIGHT = 720;
/*     */   public static final String FONT_NAME = "Segoe UI";
/*  37 */   public static final Font VSMALL_FONT = new Font("Segoe UI", 0, 11);
/*  38 */   public static final Font SMALL_FONT = new Font("Segoe UI", 1, 13);
/*  39 */   public static final Font MEDIUM_FONT = new Font("Segoe UI", 1, 20);
/*     */   
/*     */   public static final int CANVAS_WIDTH = 580;
/*     */   
/*     */   public static final int CANVAS_HEIGHT = 345;
/*     */   
/*     */   private JFrame frame;
/*     */   
/*     */   private Canvas canvas;
/*     */   
/*     */   private Workspace workspace;
/*     */   
/*     */   private JPanel mainPanel;
/*     */   private JPanel componentsPanel;
/*     */   private JPanel settingsPanel;
/*     */   private AddComponentPanel addComponentPanel;
/*     */   private ComponentListPanel componentListPanel;
/*     */   private PreviewSettingsPanel previewSettings;
/*     */   private MainSettingsPanel mainSettings;
/*     */   private ComponentPanel currentComponentPanel;
/*     */   
/*     */   public MainFrame(Workspace workspace, Camera camera)
/*     */   {
/*  62 */     this.workspace = workspace;
/*  63 */     initFrame();
/*  64 */     setIcon();
/*  65 */     initMenuBar(workspace);
/*  66 */     initMainPanels();
/*  67 */     initInnerPanels(camera);
/*  68 */     this.frame.setVisible(true);
/*  69 */     this.frame.addWindowListener(new java.awt.event.WindowListener()
/*     */     {
/*     */       public void windowActivated(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowClosed(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowClosing(WindowEvent arg0)
/*     */       {
/*  81 */         main.MainApp.close = true;
/*     */         try {
/*  83 */           Thread.sleep(400L);
/*     */         } catch (InterruptedException e) {
/*  85 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowDeactivated(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void windowDeiconified(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void windowIconified(WindowEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void windowOpened(WindowEvent arg0) {}
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateRadius()
/*     */   {
/* 108 */     this.mainSettings.updateRadius();
/*     */   }
/*     */   
/*     */   public void setNewEntity(Entity entity) {
/* 112 */     this.mainSettings.setEntity(entity);
/* 113 */     this.previewSettings.showExtraOptions();
/* 114 */     if (this.currentComponentPanel != null) {
/* 115 */       this.currentComponentPanel.destroy();
/* 116 */       this.settingsPanel.remove(this.currentComponentPanel);
/* 117 */       this.currentComponentPanel = null;
/*     */     }
/* 119 */     if (entity.hasModel()) {
/* 120 */       if (entity.getType() == EntityType.STATIC) {
/* 121 */         this.addComponentPanel.showStaticEntity((StaticEntity)entity);
/*     */       } else {
/* 123 */         this.addComponentPanel.showForAnimatedEntity((AnimatedEntity)entity);
/*     */       }
/* 125 */       for (Component loaded : entity.getLoadedComponents()) {
/* 126 */         addLoadedComponent(loaded, entity, this.componentListPanel);
/*     */       }
/*     */     } else {
/* 129 */       this.addComponentPanel.clearAll();
/*     */     }
/* 131 */     this.frame.validate();
/* 132 */     this.frame.repaint();
/*     */   }
/*     */   
/*     */   public void setComponentPanel(ComponentPanel panel) {
/* 136 */     if (this.currentComponentPanel != null) {
/* 137 */       this.currentComponentPanel.destroy();
/* 138 */       this.settingsPanel.remove(this.currentComponentPanel);
/*     */     }
/* 140 */     this.currentComponentPanel = panel;
/* 141 */     this.settingsPanel.add(panel);
/* 142 */     this.frame.validate();
/* 143 */     this.frame.repaint();
/*     */   }
/*     */   
/*     */   public void clearComponentPanel() {
/* 147 */     if (this.currentComponentPanel != null) {
/* 148 */       this.currentComponentPanel.destroy();
/* 149 */       this.settingsPanel.remove(this.currentComponentPanel);
/*     */     }
/* 151 */     this.currentComponentPanel = null;
/* 152 */     this.frame.validate();
/* 153 */     this.frame.repaint();
/*     */   }
/*     */   
/*     */   public void notifyModelSet() {
/* 157 */     Entity entity = this.workspace.getCurrentEntity();
/* 158 */     if (entity.getType() == EntityType.STATIC) {
/* 159 */       this.addComponentPanel.showStaticEntity((StaticEntity)entity);
/*     */     } else {
/* 161 */       this.addComponentPanel.showForAnimatedEntity((AnimatedEntity)entity);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initFrame() {
/* 166 */     this.frame = new JFrame("Socuwan Entity Editor");
/* 167 */     this.frame.setDefaultCloseOperation(3);
/* 168 */     this.frame.setSize(1280, 720);
/* 169 */     this.frame.setResizable(false);
/* 170 */     this.frame.setLocationRelativeTo(null);
/* 171 */     this.frame.setLayout(new java.awt.GridBagLayout());
/*     */   }
/*     */   
/*     */   private void initMenuBar(Workspace workspace) {
/* 175 */     MenuBar menuBar = new MenuBar(workspace, this);
/* 176 */     this.frame.setJMenuBar(menuBar);
/*     */   }
/*     */   
/*     */   private void setIcon() {
/* 180 */     java.awt.image.BufferedImage myPicture = null;
/*     */     try {
/* 182 */       myPicture = javax.imageio.ImageIO.read(MainFrame.class.getResourceAsStream("/res/defaultIcon.png"));
/* 183 */       ImageIcon original = new ImageIcon(myPicture);
/* 184 */       this.frame.setIconImage(original.getImage());
/*     */     } catch (IOException e) {
/* 186 */       System.err.println("Couldn't change app icon!");
/*     */     }
/*     */   }
/*     */   
/*     */   private void initMainPanels() {
/* 191 */     GridBagConstraints gc = new GridBagConstraints();
/* 192 */     gc.gridx = 0;
/* 193 */     gc.gridy = 0;
/* 194 */     gc.weightx = 1.0D;
/* 195 */     gc.weighty = 1.0D;
/* 196 */     this.mainPanel = new JPanel();
/* 197 */     this.mainPanel.setPreferredSize(new Dimension(600, 650));
/* 198 */     this.frame.add(this.mainPanel, gc);
/* 199 */     gc.gridx = 1;
/* 200 */     this.componentsPanel = new JPanel();
/* 201 */     this.componentsPanel.setPreferredSize(new Dimension(230, 650));
/* 202 */     this.frame.add(this.componentsPanel, gc);
/* 203 */     gc.gridx = 2;
/* 204 */     this.settingsPanel = new JPanel();
/* 205 */     this.settingsPanel.setPreferredSize(new Dimension(420, 650));
/* 206 */     this.frame.add(this.settingsPanel, gc);
/*     */   }
/*     */   
/*     */   public Canvas getCanvas() {
/* 210 */     return this.canvas;
/*     */   }
/*     */   
/*     */   private void initInnerPanels(Camera camera) {
/* 214 */     GridBagConstraints gc = new GridBagConstraints();
/* 215 */     gc.gridx = 0;
/* 216 */     gc.gridy = 0;
/* 217 */     gc.weightx = 1.0D;
/* 218 */     gc.weighty = 1.0D;
/* 219 */     this.mainSettings = new MainSettingsPanel(580, 180, this);
/* 220 */     this.mainPanel.add(this.mainSettings, gc);
/* 221 */     gc.gridy = 1;
/* 222 */     this.previewSettings = new PreviewSettingsPanel(580, 105, camera);
/*     */     
/* 224 */     this.mainPanel.add(this.previewSettings, gc);
/* 225 */     this.canvas = new Canvas();
/* 226 */     this.canvas.setPreferredSize(new Dimension(580, 345));
/* 227 */     gc.gridy = 2;
/* 228 */     this.mainPanel.add(this.canvas);
/* 229 */     this.componentListPanel = new ComponentListPanel(220, 585, this);
/*     */     
/* 231 */     this.addComponentPanel = new AddComponentPanel(220, 50, this.componentListPanel);
/*     */     
/* 233 */     this.componentsPanel.add(this.addComponentPanel);
/* 234 */     this.componentsPanel.add(this.componentListPanel);
/*     */   }
/*     */   
/*     */   private void addLoadedComponent(Component loadedComponent, Entity entity, ComponentListPanel listPanel)
/*     */   {
/* 239 */     java.util.List<Component> allComponentsRequired = new java.util.ArrayList();
/* 240 */     for (ComponentType required : loadedComponent.getType().getRequiredComponents()) {
/* 241 */       Component requiredComponent = entity.getFabricator().getComponent(required);
/* 242 */       allComponentsRequired.add(requiredComponent);
/*     */     }
/* 244 */     loadedComponent.setRequiredList(allComponentsRequired);
/* 245 */     for (Component needsNotifying : allComponentsRequired) {
/* 246 */       needsNotifying.notifyRequiredBy(loadedComponent);
/*     */     }
/* 248 */     listPanel.addComponent(loadedComponent);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\MainFrame.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */