/*    */ package frontend;
/*    */ 
/*    */ import javax.swing.JSlider;
/*    */ 
/*    */ public class JFloatSlider extends JSlider
/*    */ {
/*    */   private static final int TICKS = 200;
/*    */   private float min;
/*    */   private float scale;
/*    */   
/*    */   public JFloatSlider(int orientation, float min, float max, float start)
/*    */   {
/* 13 */     super(orientation, 0, 200, (int)(200.0F * ((start - min) / (max - min))));
/* 14 */     this.min = min;
/* 15 */     this.scale = (max - min);
/*    */   }
/*    */   
/*    */   public float getActualValue() {
/* 19 */     return super.getValue() / 200.0F * this.scale + this.min;
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\JFloatSlider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */