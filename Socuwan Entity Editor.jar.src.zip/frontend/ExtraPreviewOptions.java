/*    */ package frontend;
/*    */ 
/*    */ import blueprintInterfaces.BlueprintInterface;
/*    */ import instances.EntityInstance;
/*    */ import instances.StaticInstance;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JCheckBox;
/*    */ import javax.swing.JPanel;
/*    */ import main.Camera;
/*    */ import main.MainApp;
/*    */ 
/*    */ public class ExtraPreviewOptions extends JPanel
/*    */ {
/*    */   private Camera camera;
/*    */   
/*    */   public ExtraPreviewOptions(int width, int height, Camera camera)
/*    */   {
/* 21 */     this.camera = camera;
/* 22 */     setPreferredSize(new java.awt.Dimension(width, height));
/* 23 */     super.setLayout(new java.awt.GridBagLayout());
/* 24 */     addGuideShowOption();
/* 25 */     addDistancePreviewButton();
/* 26 */     addNormalCameraButton();
/*    */   }
/*    */   
/*    */   private void addGuideShowOption() {
/* 30 */     GridBagConstraints gc = getGC(0);
/* 31 */     final JCheckBox showGuideBox = new JCheckBox("Show Radius");
/* 32 */     showGuideBox.setFont(MainFrame.SMALL_FONT);
/* 33 */     showGuideBox.setSelected(MainApp.sphere.isShown());
/* 34 */     showGuideBox.addActionListener(new ActionListener()
/*    */     {
/*    */ 
/*    */       public void actionPerformed(ActionEvent e) {
/* 38 */         MainApp.sphere.showEntity(showGuideBox.isSelected()); }
/* 39 */     });
/* 40 */     add(showGuideBox, gc);
/*    */   }
/*    */   
/*    */   private GridBagConstraints getGC(int y) {
/* 44 */     GridBagConstraints gc = new GridBagConstraints();
/* 45 */     gc.anchor = 17;
/* 46 */     gc.gridx = 0;
/* 47 */     gc.gridy = y;
/* 48 */     gc.weightx = 1.0D;
/* 49 */     gc.weighty = 1.0D;
/* 50 */     return gc;
/*    */   }
/*    */   
/*    */   private void addDistancePreviewButton() {
/* 54 */     GridBagConstraints gc = getGC(1);
/* 55 */     JButton preview = new JButton("Visibility Preview");
/* 56 */     preview.setFont(MainFrame.SMALL_FONT);
/* 57 */     preview.setSelected(MainApp.sphere.isShown());
/* 58 */     preview.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/* 62 */         System.out.println(MainApp.currentEntity.getBlueprint().getVisibleRange());
/* 63 */         ExtraPreviewOptions.this.camera.setDistanceFromPlayer(MainApp.currentEntity.getBlueprint().getVisibleRange());
/* 64 */       } });
/* 65 */     add(preview, gc);
/*    */   }
/*    */   
/*    */   private void addNormalCameraButton() {
/* 69 */     GridBagConstraints gc = getGC(2);
/* 70 */     JButton preview = new JButton("Reset Camera");
/* 71 */     preview.setFont(MainFrame.SMALL_FONT);
/* 72 */     preview.setSelected(MainApp.sphere.isShown());
/* 73 */     preview.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/* 77 */         System.out.println(MainApp.currentEntity.getBlueprint().getVisibleRange());
/* 78 */         ExtraPreviewOptions.this.camera.setDistanceFromPlayer(40.0F);
/* 79 */       } });
/* 80 */     add(preview, gc);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\ExtraPreviewOptions.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */