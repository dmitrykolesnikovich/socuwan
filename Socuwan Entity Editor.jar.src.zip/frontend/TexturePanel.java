/*     */ package frontend;
/*     */ 
/*     */ import backend.Entity;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JSpinner.DefaultEditor;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import texture.ModelTexture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TexturePanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final int TEXTURE_PREVIEW_SIZE = 40;
/*     */   private ModelTexture texture;
/*     */   private JLabel diffuseIcon;
/*     */   private JLabel extraIcon;
/*     */   private JCheckBox glows;
/*     */   
/*     */   public TexturePanel(Entity entity, int width, int height)
/*     */   {
/*  50 */     setPreferredSize(new Dimension(width, height));
/*  51 */     this.texture = entity.getTexture();
/*  52 */     setLayout(new GridBagLayout());
/*  53 */     GridBagConstraints gc = new GridBagConstraints();
/*  54 */     gc.fill = 1;
/*  55 */     gc.gridx = 0;
/*  56 */     gc.gridy = 0;
/*  57 */     gc.weightx = 1.0D;
/*  58 */     gc.weighty = 1.0D;
/*  59 */     boolean showGlow = setUpIconPanel(gc);
/*  60 */     gc.gridx = 1;
/*  61 */     gc.weightx = 4.0D;
/*  62 */     setUpSettingsPanel(gc, showGlow);
/*     */   }
/*     */   
/*     */   public boolean setNewIcon(File image, boolean diffuse)
/*     */   {
/*     */     try {
/*  68 */       BufferedImage myPicture = ImageIO.read(image);
/*  69 */       ImageIcon original = new ImageIcon(myPicture);
/*  70 */       ImageIcon resized = resizeImage(original);
/*  71 */       if (diffuse) {
/*  72 */         this.diffuseIcon.setIcon(resized);
/*  73 */         this.texture.setDiffuseFile(image);
/*     */       } else {
/*  75 */         this.glows.setVisible(true);
/*  76 */         this.extraIcon.setIcon(resized);
/*  77 */         this.texture.setSpecularFile(image);
/*     */       }
/*  79 */       return true;
/*     */     } catch (Exception e) {
/*  81 */       e.printStackTrace();
/*  82 */       System.err.println("Failed to load texture!"); }
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   private boolean setUpIconPanel(GridBagConstraints gc)
/*     */   {
/*  88 */     JPanel iconPanel = new JPanel();
/*  89 */     iconPanel.setLayout(new GridBagLayout());
/*  90 */     GridBagConstraints gc2 = new GridBagConstraints();
/*  91 */     gc2.fill = 1;
/*  92 */     gc2.gridx = 0;
/*  93 */     gc2.gridy = 0;
/*  94 */     gc2.weightx = 1.0D;
/*  95 */     gc2.weighty = 1.0D;
/*  96 */     File diffuseFile = this.texture.getDiffuseFile();
/*  97 */     if (diffuseFile != null) {
/*     */       try {
/*  99 */         this.diffuseIcon = createIcon(new FileInputStream(diffuseFile), true);
/*     */       } catch (FileNotFoundException e) {
/* 101 */         e.printStackTrace();
/*     */       }
/*     */     } else {
/* 104 */       this.diffuseIcon = createIcon(TexturePanel.class.getResourceAsStream("/res/defaultDiffuseTexture.png"), true);
/*     */     }
/*     */     
/* 107 */     iconPanel.add(this.diffuseIcon, gc2);
/* 108 */     gc2.gridy = 1;
/* 109 */     File specularFile = this.texture.getSpecularFile();
/* 110 */     if (specularFile != null) {
/*     */       try {
/* 112 */         this.extraIcon = createIcon(new FileInputStream(specularFile), false);
/*     */       } catch (FileNotFoundException e) {
/* 114 */         e.printStackTrace();
/*     */       }
/*     */     } else {
/* 117 */       this.extraIcon = createIcon(TexturePanel.class.getResourceAsStream("/res/defaultExtraTexture.png"), false);
/*     */     }
/*     */     
/* 120 */     iconPanel.add(this.extraIcon, gc2);
/*     */     
/* 122 */     add(iconPanel, gc);
/* 123 */     if (specularFile != null) {
/* 124 */       return true;
/*     */     }
/* 126 */     return false;
/*     */   }
/*     */   
/*     */   private void setUpSettingsPanel(GridBagConstraints gc, boolean showGlow)
/*     */   {
/* 131 */     JPanel settingsPanel = new JPanel();
/* 132 */     settingsPanel.setLayout(new GridBagLayout());
/* 133 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 134 */     gc2.fill = 1;
/* 135 */     gc2.gridx = 0;
/* 136 */     gc2.gridy = 0;
/* 137 */     gc2.weightx = 1.0D;
/* 138 */     gc2.weighty = 1.0D;
/* 139 */     settingsPanel.add(createShineSlider(), gc2);
/* 140 */     gc2.gridy = 1;
/* 141 */     settingsPanel.add(createReflectivitySlider(), gc2);
/* 142 */     gc2.gridy = 2;
/* 143 */     final JCheckBox transparency = new JCheckBox("Has Transparency?");
/* 144 */     transparency.setFont(MainFrame.SMALL_FONT);
/* 145 */     transparency.setSelected(this.texture.hasTransparency());
/* 146 */     transparency.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 150 */         TexturePanel.this.texture.setTransparent(transparency.isSelected());
/*     */       }
/* 152 */     });
/* 153 */     settingsPanel.add(transparency, gc2);
/* 154 */     gc2.gridy = 3;
/* 155 */     final JCheckBox realLighting = new JCheckBox("Use Real Light?");
/* 156 */     realLighting.setFont(MainFrame.SMALL_FONT);
/* 157 */     realLighting.setSelected(this.texture.usesRealLighting());
/* 158 */     realLighting.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 162 */         TexturePanel.this.texture.setUseRealLighting(realLighting.isSelected());
/*     */       }
/* 164 */     });
/* 165 */     settingsPanel.add(realLighting, gc2);
/* 166 */     gc2.gridy = 4;
/* 167 */     addSpinner(gc2, settingsPanel);
/* 168 */     gc2.gridy = 5;
/* 169 */     this.glows = new JCheckBox("Glows?");
/* 170 */     this.glows.setFont(MainFrame.SMALL_FONT);
/* 171 */     this.glows.setSelected(this.texture.hasGlow());
/* 172 */     this.glows.setVisible(showGlow);
/* 173 */     this.glows.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 177 */         TexturePanel.this.texture.setGlows(TexturePanel.this.glows.isSelected());
/*     */       }
/* 179 */     });
/* 180 */     settingsPanel.add(this.glows, gc2);
/* 181 */     add(settingsPanel, gc);
/*     */   }
/*     */   
/*     */   private void addSpinner(GridBagConstraints gc, JPanel settingsPanel)
/*     */   {
/* 186 */     SpinnerNumberModel model = new SpinnerNumberModel(this.texture.getOrderOfAtlas(), 1, 10, 1);
/* 187 */     final JSpinner spinner = new JSpinner(model);
/* 188 */     spinner.setFont(MainFrame.SMALL_FONT);
/* 189 */     ((JSpinner.DefaultEditor)spinner.getEditor()).getTextField().setEditable(false);
/* 190 */     spinner.setPreferredSize(new Dimension(30, 20));
/* 191 */     JPanel panel = new JPanel();
/* 192 */     settingsPanel.add(panel, gc);
/* 193 */     panel.setLayout(new GridBagLayout());
/* 194 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 195 */     gc2.fill = 1;
/* 196 */     gc2.gridx = 0;
/* 197 */     gc2.weightx = 1.0D;
/* 198 */     gc2.weighty = 1.0D;
/* 199 */     JLabel label = new JLabel("Order of Atlas: ");
/* 200 */     label.setFont(MainFrame.SMALL_FONT);
/* 201 */     panel.add(label, gc2);
/* 202 */     gc2.gridx = 1;
/* 203 */     panel.add(spinner, gc2);
/* 204 */     spinner.addChangeListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/* 208 */         TexturePanel.this.texture.setOrderOfAtlas(((Integer)spinner.getValue()).intValue());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private JPanel createReflectivitySlider() {
/* 214 */     return createSlider("Reflectivity:", 1.0F, reverseConvertReflectValue(this.texture.getReflectivity()[0]), false);
/*     */   }
/*     */   
/*     */   private JPanel createShineSlider()
/*     */   {
/* 219 */     return createSlider("Shinyness:", 1.0F, reverseConvertShineValue(this.texture.getShininess()), true);
/*     */   }
/*     */   
/*     */   private JPanel createSlider(String name, float maximum, float start, boolean shine) {
/* 223 */     JPanel panelSlider = new JPanel();
/* 224 */     panelSlider.setLayout(new GridBagLayout());
/* 225 */     GridBagConstraints gc = new GridBagConstraints();
/* 226 */     gc.fill = 1;
/* 227 */     gc.gridx = 0;
/* 228 */     gc.gridy = 0;
/* 229 */     gc.weightx = 1.0D;
/* 230 */     gc.weighty = 1.0D;
/*     */     
/* 232 */     JLabel nameLabel = new JLabel(name);
/* 233 */     nameLabel.setFont(MainFrame.SMALL_FONT);
/* 234 */     nameLabel.setPreferredSize(new Dimension(60, 20));
/* 235 */     panelSlider.add(nameLabel, gc);
/* 236 */     gc.weightx = 4.0D;
/* 237 */     gc.gridx = 1;
/* 238 */     final JLabel valueReading = new JLabel();
/* 239 */     valueReading.setPreferredSize(new Dimension(20, 20));
/* 240 */     valueReading.setFont(MainFrame.SMALL_FONT);
/* 241 */     final JFloatSlider slider = new JFloatSlider(0, 0.0F, maximum, start);
/* 242 */     if (shine) {
/* 243 */       valueReading.setText(limitChars(Float.toString(slider.getActualValue()), 5));
/*     */     } else {
/* 245 */       valueReading.setText(limitChars(Float.toString(convertReflectValue(slider.getActualValue())), 5));
/*     */     }
/* 247 */     if (shine) {
/* 248 */       slider.addChangeListener(new ChangeListener()
/*     */       {
/*     */         public void stateChanged(ChangeEvent arg0)
/*     */         {
/* 252 */           valueReading.setText(TexturePanel.this.limitChars(Float.toString(slider.getActualValue()), 5));
/* 253 */           TexturePanel.this.texture.setShine(TexturePanel.this.convertShineValue(slider.getActualValue()));
/*     */         }
/*     */       });
/*     */     } else {
/* 257 */       slider.addChangeListener(new ChangeListener()
/*     */       {
/*     */         public void stateChanged(ChangeEvent arg0)
/*     */         {
/* 261 */           valueReading.setText(TexturePanel.this.limitChars(Float.toString(TexturePanel.access$400(TexturePanel.this, slider.getActualValue())), 5));
/*     */           
/* 263 */           TexturePanel.this.texture.setReflectivity(TexturePanel.this.convertReflectValue(slider.getActualValue()));
/*     */         }
/*     */       });
/*     */     }
/* 267 */     panelSlider.add(slider, gc);
/* 268 */     slider.setPreferredSize(new Dimension(20, 20));
/* 269 */     gc.gridx = 2;
/* 270 */     gc.weightx = 1.0D;
/* 271 */     panelSlider.add(valueReading, gc);
/* 272 */     return panelSlider;
/*     */   }
/*     */   
/*     */   private String limitChars(String original, int limit)
/*     */   {
/* 277 */     if (original.length() <= limit) {
/* 278 */       return original;
/*     */     }
/* 280 */     return original.substring(0, 5);
/*     */   }
/*     */   
/*     */ 
/*     */   private JLabel createIcon(InputStream stream, final boolean diffuse)
/*     */   {
/* 286 */     BufferedImage myPicture = null;
/*     */     try {
/* 288 */       myPicture = ImageIO.read(stream);
/* 289 */       stream.close();
/*     */     } catch (IOException e) {
/* 291 */       e.printStackTrace();
/*     */     }
/* 293 */     ImageIcon original = new ImageIcon(myPicture);
/* 294 */     ImageIcon resized = resizeImage(original);
/* 295 */     JLabel icon = new JLabel(resized);
/* 296 */     icon.addMouseListener(new MouseListener()
/*     */     {
/*     */       public void mouseClicked(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseEntered(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseExited(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void mousePressed(MouseEvent arg0) {}
/*     */       
/*     */ 
/*     */       public void mouseReleased(MouseEvent arg0)
/*     */       {
/* 315 */         new TextureChooseScreen(TexturePanel.this, diffuse);
/*     */       }
/* 317 */     });
/* 318 */     icon.setPreferredSize(new Dimension(40, 40));
/* 319 */     return icon;
/*     */   }
/*     */   
/*     */   private ImageIcon resizeImage(ImageIcon original) {
/* 323 */     Image img = original.getImage();
/* 324 */     Image resized = getScaledImage(img, 40, 40);
/* 325 */     return new ImageIcon(resized);
/*     */   }
/*     */   
/*     */   private Image getScaledImage(Image srcImg, int w, int h) {
/* 329 */     BufferedImage resizedImg = new BufferedImage(w, h, 2);
/* 330 */     Graphics2D g2 = resizedImg.createGraphics();
/* 331 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     
/* 333 */     g2.drawImage(srcImg, 0, 0, w, h, null);
/* 334 */     g2.dispose();
/* 335 */     return resizedImg;
/*     */   }
/*     */   
/*     */   private float convertShineValue(float sliderValue) {
/* 339 */     float value = (float)(sliderValue * 1.5707963267948966D);
/* 340 */     value = (float)Math.sin(value);
/* 341 */     value = (float)Math.sin(value * 1.5707963267948966D);
/* 342 */     value *= 100.0F;
/* 343 */     return 100.0F - value;
/*     */   }
/*     */   
/*     */   private float reverseConvertShineValue(float shine)
/*     */   {
/* 348 */     float value = 100.0F - shine;
/* 349 */     value /= 100.0F;
/* 350 */     value = (float)Math.asin(value);
/* 351 */     value = (float)(value / 1.5707963267948966D);
/* 352 */     value = (float)Math.asin(value);
/* 353 */     value = (float)(value / 1.5707963267948966D);
/* 354 */     return value;
/*     */   }
/*     */   
/*     */   private float convertReflectValue(float sliderValue) {
/* 358 */     float value = sliderValue * sliderValue;
/* 359 */     value *= 5.0F;
/* 360 */     return value;
/*     */   }
/*     */   
/*     */   private float reverseConvertReflectValue(float reflectValue) {
/* 364 */     float value = reflectValue / 5.0F;
/* 365 */     return (float)Math.sqrt(value);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\TexturePanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */