/*    */ package frontend;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Dialog.ModalityType;
/*    */ import java.awt.Font;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JLabel;
/*    */ 
/*    */ public class ErrorPopUp
/*    */ {
/*    */   private JDialog frame;
/*    */   
/*    */   public ErrorPopUp(String message)
/*    */   {
/* 21 */     Toolkit.getDefaultToolkit().beep();
/* 22 */     setUpFrame();
/* 23 */     addLabel(message);
/* 24 */     addButton();
/* 25 */     this.frame.setVisible(true);
/*    */   }
/*    */   
/*    */   private void setUpFrame() {
/* 29 */     this.frame = new JDialog();
/* 30 */     this.frame.setAlwaysOnTop(true);
/* 31 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/* 32 */     this.frame.setSize(400, 200);
/* 33 */     this.frame.setResizable(false);
/* 34 */     this.frame.setLocationRelativeTo(null);
/* 35 */     this.frame.setLayout(new GridBagLayout());
/*    */   }
/*    */   
/*    */   private void addLabel(String message) {
/* 39 */     JLabel text = new JLabel("Error!");
/* 40 */     text.setForeground(new Color(255, 0, 0));
/* 41 */     text.setFont(new Font("Segoe UI", 1, 40));
/* 42 */     GridBagConstraints gc = new GridBagConstraints();
/* 43 */     gc.gridx = 0;
/* 44 */     gc.gridy = 0;
/* 45 */     gc.weightx = 1.0D;
/* 46 */     gc.weighty = 1.0D;
/* 47 */     this.frame.add(text, gc);
/* 48 */     gc.gridy = 1;
/* 49 */     JLabel messageText = new JLabel(message);
/* 50 */     messageText.setForeground(new Color(255, 0, 0));
/* 51 */     messageText.setFont(new Font("Segoe UI", 1, 15));
/* 52 */     this.frame.add(messageText, gc);
/*    */   }
/*    */   
/*    */   private void addButton() {
/* 56 */     JButton confirm = new JButton("Close");
/* 57 */     confirm.setFont(new Font("Segoe UI", 1, 15));
/* 58 */     GridBagConstraints gc = new GridBagConstraints();
/* 59 */     gc.gridx = 0;
/* 60 */     gc.gridy = 2;
/* 61 */     gc.weightx = 1.0D;
/* 62 */     gc.weighty = 1.0D;
/* 63 */     confirm.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent arg0)
/*    */       {
/* 67 */         ErrorPopUp.this.frame.setVisible(false);
/*    */       }
/*    */       
/* 70 */     });
/* 71 */     this.frame.add(confirm, gc);
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\ErrorPopUp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */