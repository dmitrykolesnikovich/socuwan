/*     */ package frontend;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.NumberFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VectorPanel
/*     */   extends JPanel
/*     */ {
/*     */   private JFormattedTextField xField;
/*     */   private JFormattedTextField yField;
/*     */   private JFormattedTextField zField;
/*     */   
/*     */   public VectorPanel(int width, int height, String name, float x, float y, float z)
/*     */   {
/*  26 */     setPreferredSize(new Dimension(width, height));
/*  27 */     setLayout(new GridBagLayout());
/*  28 */     setUpName(name);
/*  29 */     setUpInputs(x, y, z);
/*     */   }
/*     */   
/*     */   private void setUpName(String name) {
/*  33 */     JLabel label = new JLabel(name);
/*  34 */     label.setFont(MainFrame.SMALL_FONT);
/*  35 */     add(label, getGC(0, 0));
/*     */   }
/*     */   
/*     */   public void addTotalListener(DocumentListener listener) {
/*  39 */     this.xField.getDocument().addDocumentListener(listener);
/*  40 */     this.yField.getDocument().addDocumentListener(listener);
/*  41 */     this.zField.getDocument().addDocumentListener(listener);
/*     */   }
/*     */   
/*     */   public void addVectorPanelListener(final VectorPanelListener listener) {
/*  45 */     addTotalListener(new DocumentListener()
/*     */     {
/*     */       public void changedUpdate(DocumentEvent arg0)
/*     */       {
/*  49 */         listener.doAction();
/*     */       }
/*     */       
/*     */       public void insertUpdate(DocumentEvent arg0)
/*     */       {
/*  54 */         listener.doAction();
/*     */       }
/*     */       
/*     */       public void removeUpdate(DocumentEvent arg0)
/*     */       {
/*  59 */         listener.doAction();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*  64 */   public void addXFieldListener(DocumentListener listener) { this.xField.getDocument().addDocumentListener(listener); }
/*     */   
/*     */   public void addYFieldListener(DocumentListener listener)
/*     */   {
/*  68 */     this.yField.getDocument().addDocumentListener(listener);
/*     */   }
/*     */   
/*     */   public void addZFieldListener(DocumentListener listener) {
/*  72 */     this.zField.getDocument().addDocumentListener(listener);
/*     */   }
/*     */   
/*     */   private void setUpInputs(float x, float y, float z) {
/*  76 */     setUpLabel(" x:", 1);
/*  77 */     this.xField = setUpValueInput(x, 2);
/*  78 */     setUpLabel(" y:", 3);
/*  79 */     this.yField = setUpValueInput(y, 4);
/*  80 */     setUpLabel(" z:", 5);
/*  81 */     this.zField = setUpValueInput(z, 6);
/*     */   }
/*     */   
/*     */   public float getXValue() {
/*  85 */     String value = this.xField.getText().replaceAll(",", "");
/*  86 */     if (value.equals("")) {
/*  87 */       return 0.0F;
/*     */     }
/*  89 */     return Float.parseFloat(value);
/*     */   }
/*     */   
/*     */   public float getYValue() {
/*  93 */     String value = this.yField.getText().replaceAll(",", "");
/*  94 */     if (value.equals("")) {
/*  95 */       return 0.0F;
/*     */     }
/*  97 */     return Float.parseFloat(value);
/*     */   }
/*     */   
/*     */   public float getZValue() {
/* 101 */     String value = this.zField.getText().replaceAll(",", "");
/* 102 */     if (value.equals("")) {
/* 103 */       return 0.0F;
/*     */     }
/* 105 */     return Float.parseFloat(value);
/*     */   }
/*     */   
/*     */   public JFormattedTextField getXField() {
/* 109 */     return this.xField;
/*     */   }
/*     */   
/*     */   public JFormattedTextField getYField() {
/* 113 */     return this.yField;
/*     */   }
/*     */   
/*     */   public JFormattedTextField getZField() {
/* 117 */     return this.zField;
/*     */   }
/*     */   
/*     */   private void setUpLabel(String name, int gcX) {
/* 121 */     JLabel label = new JLabel(name);
/* 122 */     label.setFont(MainFrame.SMALL_FONT);
/* 123 */     add(label, getGC(gcX, 0));
/*     */   }
/*     */   
/*     */   private JFormattedTextField setUpValueInput(float value, int gcX)
/*     */   {
/* 128 */     JFormattedTextField field = createTextField(5);
/* 129 */     field.setText(Float.toString(value));
/* 130 */     add(field, getGC(gcX, 0));
/* 131 */     return field;
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y) {
/* 135 */     GridBagConstraints gc = new GridBagConstraints();
/* 136 */     gc.fill = 1;
/* 137 */     gc.gridx = x;
/* 138 */     gc.gridy = y;
/* 139 */     gc.weightx = 1.0D;
/* 140 */     gc.weighty = 1.0D;
/* 141 */     return gc;
/*     */   }
/*     */   
/*     */   private JFormattedTextField createTextField(int columns) {
/* 145 */     NumberFormat floatFormat = NumberFormat.getNumberInstance();
/* 146 */     floatFormat.setMinimumFractionDigits(1);
/* 147 */     floatFormat.setMaximumFractionDigits(5);
/* 148 */     NumberFormatter numberFormatter = new NumberFormatter(floatFormat);
/* 149 */     numberFormatter.setValueClass(Float.class);
/* 150 */     numberFormatter.setAllowsInvalid(false);
/* 151 */     JFormattedTextField text = new JFormattedTextField(numberFormatter);
/* 152 */     text.setColumns(columns);
/* 153 */     text.setFont(MainFrame.SMALL_FONT);
/* 154 */     text.setHorizontalAlignment(0);
/* 155 */     return text;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\VectorPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */