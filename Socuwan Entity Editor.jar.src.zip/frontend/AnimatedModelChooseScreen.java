/*     */ package frontend;
/*     */ 
/*     */ import animations.AnimationComponentBlueprint;
/*     */ import backend.AnimatedEntity;
/*     */ import blueprintInterfaces.BoneBlueprint;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimatedModelChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a model file for each bone.";
/*     */   private JDialog frame;
/*     */   private AnimationComponentBlueprint animationComponent;
/*     */   private AnimatedEntity entity;
/*     */   private JButton originalButton;
/*     */   private JPanel panel;
/*     */   private int boneCount;
/*  34 */   private int modelsSet = 0;
/*     */   private MainFrame mainFrame;
/*     */   
/*     */   public AnimatedModelChooseScreen(AnimationComponentBlueprint animationComponent, AnimatedEntity entity, JButton button, MainFrame mainFrame)
/*     */   {
/*  39 */     this.animationComponent = animationComponent;
/*  40 */     this.originalButton = button;
/*  41 */     this.mainFrame = mainFrame;
/*  42 */     this.entity = entity;
/*  43 */     setUpFrame();
/*  44 */     addLabel();
/*  45 */     addPanel();
/*  46 */     addSubPanels();
/*  47 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   protected void increaseSetModelCount() {
/*  51 */     this.modelsSet += 1;
/*  52 */     if (this.modelsSet == this.boneCount) {
/*  53 */       JButton okay = new JButton("Finished!");
/*  54 */       okay.setFont(new Font("Segoe UI", 1, 15));
/*  55 */       okay.addActionListener(new ActionListener()
/*     */       {
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/*  59 */           boolean success = AnimatedModelChooseScreen.this.entity.setAnimationComponent(AnimatedModelChooseScreen.this.animationComponent);
/*  60 */           if (success) {
/*  61 */             AnimatedModelChooseScreen.this.originalButton.setForeground(new Color(0, 255, 0));
/*  62 */             AnimatedModelChooseScreen.this.originalButton.setText("Change Model...");
/*  63 */             AnimatedModelChooseScreen.this.mainFrame.notifyModelSet();
/*  64 */             AnimatedModelChooseScreen.this.frame.setVisible(false);
/*     */           }
/*     */         }
/*  67 */       });
/*  68 */       GridBagConstraints gc = new GridBagConstraints();
/*  69 */       gc.gridx = 0;
/*  70 */       gc.gridy = 3;
/*  71 */       gc.weightx = 1.0D;
/*  72 */       gc.weighty = 0.4D;
/*  73 */       this.frame.add(okay, gc);
/*  74 */       this.frame.validate();
/*  75 */       this.frame.repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  80 */     this.frame = new JDialog();
/*  81 */     this.frame.setAlwaysOnTop(true);
/*  82 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  83 */     this.frame.setSize(300, 500);
/*  84 */     this.frame.setResizable(false);
/*  85 */     this.frame.setLocationRelativeTo(null);
/*  86 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  90 */     JLabel text = new JLabel("Choose a model file for each bone.");
/*  91 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  92 */     GridBagConstraints gc = new GridBagConstraints();
/*  93 */     gc.gridx = 0;
/*  94 */     gc.gridy = 0;
/*  95 */     gc.weightx = 1.0D;
/*  96 */     gc.weighty = 0.4D;
/*  97 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addPanel() {
/* 101 */     this.panel = new JPanel();
/* 102 */     this.panel.setFont(new Font("Segoe UI", 1, 15));
/* 103 */     this.panel.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addSubPanels() {
/* 107 */     List<BoneBlueprint> bones = this.animationComponent.getAllBones();
/* 108 */     this.boneCount = bones.size();
/* 109 */     GridBagConstraints gc = new GridBagConstraints();
/* 110 */     gc.gridx = 0;
/* 111 */     gc.gridy = 0;
/* 112 */     gc.weightx = 1.0D;
/* 113 */     gc.weighty = 1.0D;
/* 114 */     for (final BoneBlueprint bone : bones) {
/* 115 */       JPanel bonePanel = new JPanel();
/* 116 */       JLabel name = new JLabel(bone.getName());
/* 117 */       name.setFont(MainFrame.SMALL_FONT);
/* 118 */       bonePanel.add(name);
/* 119 */       final JButton chooseModel = new JButton("Choose...");
/* 120 */       chooseModel.setFont(MainFrame.SMALL_FONT);
/* 121 */       chooseModel.setForeground(new Color(255, 0, 0));
/* 122 */       chooseModel.addActionListener(new ActionListener()
/*     */       {
/*     */         public void actionPerformed(ActionEvent arg0)
/*     */         {
/* 126 */           new BoneModelChooseScreen(AnimatedModelChooseScreen.this, bone, chooseModel);
/*     */         }
/*     */         
/*     */ 
/* 130 */       });
/* 131 */       bonePanel.add(chooseModel);
/* 132 */       this.panel.add(bonePanel, gc);
/* 133 */       gc.gridy += 1;
/*     */     }
/* 135 */     JScrollPane pane = new JScrollPane(this.panel);
/* 136 */     pane.setPreferredSize(new Dimension(250, 380));
/* 137 */     GridBagConstraints gc2 = new GridBagConstraints();
/* 138 */     gc2.gridx = 0;
/* 139 */     gc2.gridy = 1;
/* 140 */     gc2.weightx = 1.0D;
/* 141 */     gc2.weighty = 1.0D;
/* 142 */     this.frame.add(pane, gc2);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\AnimatedModelChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */