/*    */ package frontend;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JPanel;
/*    */ import main.Camera;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreviewSettingsPanel
/*    */   extends JPanel
/*    */ {
/*    */   private int width;
/*    */   private int height;
/* 17 */   private boolean extraIsShown = false;
/*    */   private Camera camera;
/*    */   
/*    */   public PreviewSettingsPanel(int width, int height, Camera camera) {
/* 21 */     this.camera = camera;
/* 22 */     this.width = width;
/* 23 */     this.height = height;
/* 24 */     setBorder(BorderFactory.createTitledBorder("Preview Settings"));
/* 25 */     setPreferredSize(new Dimension(width, height));
/* 26 */     super.setLayout(new BorderLayout());
/*    */     
/* 28 */     add(new StandardPreviewSettings(width / 3 * 2 - 10, height - 15, camera), "West");
/*    */   }
/*    */   
/*    */   public void showExtraOptions() {
/* 32 */     if (!this.extraIsShown) {
/* 33 */       add(new ExtraPreviewOptions(this.width / 3 - 10, this.height - 15, this.camera), "East");
/* 34 */       this.extraIsShown = true;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\PreviewSettingsPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */