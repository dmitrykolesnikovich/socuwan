/*     */ package frontend;
/*     */ 
/*     */ import backend.StaticEntity;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.Configs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a Model!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   private StaticEntity entity;
/*     */   private JButton button;
/*     */   
/*     */   public ModelChooseScreen(MainFrame mainFrame, StaticEntity entity, JButton button)
/*     */   {
/*  44 */     this.entity = entity;
/*  45 */     this.button = button;
/*  46 */     setUpFrame();
/*  47 */     addLabel();
/*  48 */     addFileList(getAllModelFiles());
/*  49 */     addButton(mainFrame);
/*  50 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  54 */     this.frame = new JDialog();
/*  55 */     this.frame.setAlwaysOnTop(true);
/*  56 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  57 */     this.frame.setSize(300, 500);
/*  58 */     this.frame.setResizable(false);
/*  59 */     this.frame.setLocationRelativeTo(null);
/*  60 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  64 */     GridBagConstraints gc = new GridBagConstraints();
/*  65 */     gc.gridx = 0;
/*  66 */     gc.gridy = 1;
/*  67 */     gc.weightx = 1.0D;
/*  68 */     gc.weighty = 1.0D;
/*     */     
/*  70 */     FileInList[] data = getAllFilesInList(files);
/*  71 */     this.list = new JList(data);
/*  72 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  73 */     this.list.setSelectionMode(1);
/*  74 */     this.list.setLayoutOrientation(0);
/*  75 */     this.list.setVisibleRowCount(-1);
/*  76 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  77 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  78 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  82 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  83 */     for (int i = 0; i < listedFiles.length; i++) {
/*  84 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  86 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  90 */     JLabel text = new JLabel("Choose a Model!");
/*  91 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  92 */     GridBagConstraints gc = new GridBagConstraints();
/*  93 */     gc.gridx = 0;
/*  94 */     gc.gridy = 0;
/*  95 */     gc.weightx = 1.0D;
/*  96 */     gc.weighty = 0.4D;
/*  97 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton(final MainFrame mainFrame) {
/* 101 */     this.confirm = new JButton("Open");
/* 102 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/* 103 */     GridBagConstraints gc = new GridBagConstraints();
/* 104 */     gc.gridx = 0;
/* 105 */     gc.gridy = 2;
/* 106 */     gc.weightx = 1.0D;
/* 107 */     gc.weighty = 0.4D;
/* 108 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 112 */         if (!ModelChooseScreen.this.list.isSelectionEmpty()) {
/* 113 */           File chosen = ((FileInList)ModelChooseScreen.this.list.getSelectedValue()).getFile();
/*     */           try {
/* 115 */             ModelChooseScreen.this.entity.setModelFile(chosen);
/* 116 */             mainFrame.notifyModelSet();
/* 117 */             ModelChooseScreen.this.button.setText("Change Model...");
/* 118 */             ModelChooseScreen.this.button.setForeground(new Color(0, 155, 0));
/* 119 */             ModelChooseScreen.this.frame.setVisible(false);
/*     */           } catch (Exception e) {
/* 121 */             e.printStackTrace();
/* 122 */             System.err.println("Invalid Model File!");
/* 123 */             new ErrorPopUp("Invalid model file!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 129 */     });
/* 130 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllModelFiles() {
/* 134 */     File[] allFiles = Configs.MODELS_REPOS.listFiles();
/* 135 */     List<File> goodFiles = new ArrayList();
/* 136 */     for (File file : allFiles) {
/* 137 */       if (file.getName().endsWith(".csv")) {
/* 138 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 141 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\ModelChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */