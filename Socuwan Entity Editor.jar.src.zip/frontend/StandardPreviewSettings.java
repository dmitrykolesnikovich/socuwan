/*     */ package frontend;
/*     */ 
/*     */ import instances.AnimatedInstance;
/*     */ import instances.EntityInstance;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import main.Camera;
/*     */ import main.MainApp;
/*     */ 
/*     */ public class StandardPreviewSettings
/*     */   extends JPanel
/*     */ {
/*     */   private JCheckBox showPlayerBox;
/*     */   private JCheckBox rotateCameraBox;
/*     */   private JCheckBox rotateTexturesBox;
/*     */   private Camera camera;
/*     */   
/*     */   public StandardPreviewSettings(int width, int height, Camera camera)
/*     */   {
/*  27 */     this.camera = camera;
/*  28 */     setPreferredSize(new Dimension(width, height));
/*  29 */     super.setLayout(new GridBagLayout());
/*  30 */     addShowPlayerBox();
/*  31 */     addRotateCameraBox();
/*  32 */     addRotateTexturesBox();
/*  33 */     addShowTerrainBox();
/*  34 */     addTimeSlider();
/*     */   }
/*     */   
/*     */   private void addShowPlayerBox() {
/*  38 */     GridBagConstraints gc = getGC(0, 0, 1);
/*  39 */     this.showPlayerBox = new JCheckBox("Show Player");
/*  40 */     this.showPlayerBox.setFont(MainFrame.SMALL_FONT);
/*  41 */     this.showPlayerBox.setSelected(true);
/*  42 */     this.showPlayerBox.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent e) {
/*  46 */         MainApp.player.showEntity(StandardPreviewSettings.this.showPlayerBox.isSelected()); }
/*  47 */     });
/*  48 */     add(this.showPlayerBox, gc);
/*     */   }
/*     */   
/*     */   private void addRotateCameraBox() {
/*  52 */     GridBagConstraints gc = getGC(0, 1, 1);
/*  53 */     this.rotateCameraBox = new JCheckBox("Rotate Camera");
/*  54 */     this.rotateCameraBox.setFont(MainFrame.SMALL_FONT);
/*  55 */     this.rotateCameraBox.setSelected(true);
/*  56 */     this.rotateCameraBox.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent e) {
/*  60 */         StandardPreviewSettings.this.camera.setRotate(StandardPreviewSettings.this.rotateCameraBox.isSelected()); }
/*  61 */     });
/*  62 */     add(this.rotateCameraBox, gc);
/*     */   }
/*     */   
/*     */   private void addRotateTexturesBox() {
/*  66 */     GridBagConstraints gc = getGC(1, 0, 1);
/*  67 */     this.rotateTexturesBox = new JCheckBox("Rotate Textures");
/*  68 */     this.rotateTexturesBox.setFont(MainFrame.SMALL_FONT);
/*  69 */     this.rotateTexturesBox.setSelected(EntityInstance.rotateTextures);
/*  70 */     this.rotateTexturesBox.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent e) {
/*  74 */         EntityInstance.rotateTextures = StandardPreviewSettings.this.rotateTexturesBox.isSelected(); }
/*  75 */     });
/*  76 */     add(this.rotateTexturesBox, gc);
/*     */   }
/*     */   
/*     */   private void addTimeSlider() {
/*  80 */     final Slider slider = new Slider("Time", MainApp.time, 0.0F, 24000.0F, true, 220, 40);
/*  81 */     slider.addSliderListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  85 */         MainApp.time = slider.getSliderReading();
/*     */       }
/*  87 */     });
/*  88 */     add(slider, getGC(0, 2, 2));
/*     */   }
/*     */   
/*     */   private void addShowTerrainBox() {
/*  92 */     GridBagConstraints gc = getGC(1, 1, 1);
/*  93 */     final JCheckBox showTerrain = new JCheckBox("Show Terrain");
/*  94 */     showTerrain.setFont(MainFrame.SMALL_FONT);
/*  95 */     showTerrain.setSelected(MainApp.showTerrain);
/*  96 */     showTerrain.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent e) {
/* 100 */         MainApp.showTerrain = showTerrain.isSelected(); }
/* 101 */     });
/* 102 */     add(showTerrain, gc);
/*     */   }
/*     */   
/*     */   private GridBagConstraints getGC(int x, int y, int width) {
/* 106 */     GridBagConstraints gc = new GridBagConstraints();
/* 107 */     gc.anchor = 17;
/* 108 */     gc.gridx = x;
/* 109 */     gc.gridy = y;
/* 110 */     gc.weightx = 1.0D;
/* 111 */     gc.weighty = 1.0D;
/* 112 */     gc.gridwidth = width;
/* 113 */     return gc;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\StandardPreviewSettings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */