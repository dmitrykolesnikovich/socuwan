/*     */ package frontend;
/*     */ 
/*     */ import backend.Workspace;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileChooseScreen
/*     */ {
/*     */   private static final int MAIN_FONT_SIZE = 15;
/*     */   private static final int LIST_FONT_SIZE = 13;
/*     */   private static final String MESSAGE = "Choose an entity file!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private Workspace workspace;
/*     */   private MainFrame mainFrame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   
/*     */   public FileChooseScreen(List<File> files, Workspace workspace, MainFrame mainFrame)
/*     */   {
/*  39 */     this.workspace = workspace;
/*  40 */     this.mainFrame = mainFrame;
/*  41 */     setUpFrame();
/*  42 */     addLabel();
/*  43 */     addFileList(files);
/*  44 */     addButton();
/*  45 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  49 */     this.frame = new JDialog();
/*  50 */     this.frame.setAlwaysOnTop(true);
/*  51 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  52 */     this.frame.setSize(300, 300);
/*  53 */     this.frame.setResizable(false);
/*  54 */     this.frame.setLocationRelativeTo(null);
/*  55 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  59 */     GridBagConstraints gc = new GridBagConstraints();
/*  60 */     gc.gridx = 0;
/*  61 */     gc.gridy = 1;
/*  62 */     gc.weightx = 1.0D;
/*  63 */     gc.weighty = 1.0D;
/*     */     
/*  65 */     FileInList[] data = getAllFilesInList(removeBadFiles(files));
/*  66 */     this.list = new JList(data);
/*  67 */     this.list.setFont(new Font("Segoe UI", 1, 13));
/*  68 */     this.list.setSelectionMode(1);
/*  69 */     this.list.setLayoutOrientation(0);
/*  70 */     this.list.setVisibleRowCount(-1);
/*  71 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  72 */     listScroller.setPreferredSize(new Dimension(250, 180));
/*  73 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private List<File> removeBadFiles(List<File> files) {
/*  77 */     List<File> goodFiles = new ArrayList();
/*  78 */     for (File file : files) {
/*     */       try {
/*  80 */         Integer.parseInt(file.getName());
/*  81 */         goodFiles.add(file);
/*     */       } catch (Exception e) {
/*  83 */         System.err.println("Invalid Entity File: " + file.getName());
/*     */       }
/*     */     }
/*  86 */     return goodFiles;
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  90 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  91 */     for (int i = 0; i < listedFiles.length; i++) {
/*  92 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  94 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  98 */     JLabel text = new JLabel("Choose an entity file!");
/*  99 */     text.setFont(new Font("Segoe UI", 1, 15));
/* 100 */     GridBagConstraints gc = new GridBagConstraints();
/* 101 */     gc.gridx = 0;
/* 102 */     gc.gridy = 0;
/* 103 */     gc.weightx = 1.0D;
/* 104 */     gc.weighty = 0.4D;
/* 105 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/* 109 */     this.confirm = new JButton("Open");
/* 110 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/* 111 */     GridBagConstraints gc = new GridBagConstraints();
/* 112 */     gc.gridx = 0;
/* 113 */     gc.gridy = 2;
/* 114 */     gc.weightx = 1.0D;
/* 115 */     gc.weighty = 0.4D;
/* 116 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 120 */         if (!FileChooseScreen.this.list.isSelectionEmpty()) {
/* 121 */           File chosen = ((FileInList)FileChooseScreen.this.list.getSelectedValue()).getFile();
/* 122 */           boolean opened = FileChooseScreen.this.workspace.open(chosen);
/* 123 */           if (opened) {
/* 124 */             FileChooseScreen.this.frame.setVisible(false);
/* 125 */             FileChooseScreen.this.mainFrame.setNewEntity(FileChooseScreen.this.workspace.getCurrentEntity());
/*     */           } else {
/* 127 */             new ErrorPopUp("Invalid Entity File Format!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 133 */     });
/* 134 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\FileChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */