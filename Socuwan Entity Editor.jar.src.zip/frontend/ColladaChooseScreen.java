/*     */ package frontend;
/*     */ 
/*     */ import animations.AnimationComponentBlueprint;
/*     */ import backend.AnimatedEntity;
/*     */ import backend.ColladaParser;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.Configs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColladaChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a Collada File!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   private AnimatedEntity entity;
/*     */   private JButton button;
/*     */   private MainFrame mainFrame;
/*     */   
/*     */   public ColladaChooseScreen(AnimatedEntity entity, JButton button, MainFrame mainFrame)
/*     */   {
/*  44 */     this.entity = entity;
/*  45 */     this.button = button;
/*  46 */     this.mainFrame = mainFrame;
/*  47 */     setUpFrame();
/*  48 */     addLabel();
/*  49 */     addFileList(getAllModelFiles());
/*  50 */     addButton();
/*  51 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  55 */     this.frame = new JDialog();
/*  56 */     this.frame.setAlwaysOnTop(true);
/*  57 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  58 */     this.frame.setSize(300, 500);
/*  59 */     this.frame.setResizable(false);
/*  60 */     this.frame.setLocationRelativeTo(null);
/*  61 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  65 */     GridBagConstraints gc = new GridBagConstraints();
/*  66 */     gc.gridx = 0;
/*  67 */     gc.gridy = 1;
/*  68 */     gc.weightx = 1.0D;
/*  69 */     gc.weighty = 1.0D;
/*     */     
/*  71 */     FileInList[] data = getAllFilesInList(files);
/*  72 */     this.list = new JList(data);
/*  73 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  74 */     this.list.setSelectionMode(1);
/*  75 */     this.list.setLayoutOrientation(0);
/*  76 */     this.list.setVisibleRowCount(-1);
/*  77 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  78 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  79 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  83 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  84 */     for (int i = 0; i < listedFiles.length; i++) {
/*  85 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  87 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  91 */     JLabel text = new JLabel("Choose a Collada File!");
/*  92 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  93 */     GridBagConstraints gc = new GridBagConstraints();
/*  94 */     gc.gridx = 0;
/*  95 */     gc.gridy = 0;
/*  96 */     gc.weightx = 1.0D;
/*  97 */     gc.weighty = 0.4D;
/*  98 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton() {
/* 102 */     this.confirm = new JButton("Open");
/* 103 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/* 104 */     GridBagConstraints gc = new GridBagConstraints();
/* 105 */     gc.gridx = 0;
/* 106 */     gc.gridy = 2;
/* 107 */     gc.weightx = 1.0D;
/* 108 */     gc.weighty = 0.4D;
/* 109 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 113 */         if (!ColladaChooseScreen.this.list.isSelectionEmpty()) {
/* 114 */           File chosen = ((FileInList)ColladaChooseScreen.this.list.getSelectedValue()).getFile();
/*     */           try {
/* 116 */             AnimationComponentBlueprint animatedModel = ColladaParser.loadBones(chosen, ColladaChooseScreen.this.entity);
/* 117 */             ColladaChooseScreen.this.frame.setVisible(false);
/* 118 */             if (animatedModel != null) {
/* 119 */               new AnimatedModelChooseScreen(animatedModel, ColladaChooseScreen.this.entity, ColladaChooseScreen.this.button, ColladaChooseScreen.this.mainFrame);
/*     */             }
/*     */           } catch (Exception e) {
/* 122 */             e.printStackTrace();
/* 123 */             System.err.println("Error with Collada file: " + chosen.getName());
/* 124 */             new ErrorPopUp("Collada file not in the correct format!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 130 */     });
/* 131 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllModelFiles() {
/* 135 */     File[] allFiles = Configs.STRUCTURES_REPOS.listFiles();
/* 136 */     List<File> goodFiles = new ArrayList();
/* 137 */     for (File file : allFiles) {
/* 138 */       if (file.getName().endsWith(".dae")) {
/* 139 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 142 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\ColladaChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */