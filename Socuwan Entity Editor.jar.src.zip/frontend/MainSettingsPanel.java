/*    */ package frontend;
/*    */ 
/*    */ import backend.Entity;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MainSettingsPanel
/*    */   extends JPanel
/*    */ {
/*    */   private static final int HEIGHT_PADDING = 25;
/*    */   private static final int WIDTH_PADDING = 10;
/*    */   private final int WIDTH;
/*    */   private final int HEIGHT;
/* 20 */   private boolean isSetUp = false;
/*    */   private StandardInfoPanel standardInfo;
/*    */   private TexturePanel textureInfo;
/*    */   private MainFrame mainFrame;
/*    */   
/*    */   public MainSettingsPanel(int width, int height, MainFrame mainFrame) {
/* 26 */     this.WIDTH = width;
/* 27 */     this.HEIGHT = height;
/* 28 */     this.mainFrame = mainFrame;
/* 29 */     setBorder(BorderFactory.createTitledBorder("Main Settings"));
/* 30 */     setPreferredSize(new Dimension(width, height));
/* 31 */     super.setLayout(new GridBagLayout());
/*    */   }
/*    */   
/*    */   public void updateRadius() {
/* 35 */     if (this.standardInfo != null) {
/* 36 */       this.standardInfo.updateRadius();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setEntity(Entity entity) {
/* 41 */     if (this.isSetUp) {
/* 42 */       updateFields(entity);
/*    */     } else {
/* 44 */       initialiseFields(entity);
/* 45 */       updateFields(entity);
/* 46 */       this.isSetUp = true;
/*    */     }
/*    */   }
/*    */   
/*    */   private void initialiseFields(Entity entity) {
/* 51 */     GridBagConstraints gc = new GridBagConstraints();
/* 52 */     gc.gridx = 0;
/* 53 */     gc.gridy = 0;
/* 54 */     gc.weightx = 1.0D;
/* 55 */     gc.weighty = 1.0D;
/* 56 */     this.standardInfo = new StandardInfoPanel((this.WIDTH - 10) / 2, this.HEIGHT - 25, entity, this.mainFrame);
/*    */     
/* 58 */     add(this.standardInfo, gc);
/* 59 */     gc.gridx = 1;
/* 60 */     this.textureInfo = new TexturePanel(entity, (this.WIDTH - 10) / 2, this.HEIGHT - 25);
/* 61 */     add(this.textureInfo, gc);
/*    */   }
/*    */   
/*    */   private void updateFields(Entity newEntity) {
/* 65 */     this.standardInfo.setEntity(newEntity);
/* 66 */     remove(this.textureInfo);
/* 67 */     GridBagConstraints gc = new GridBagConstraints();
/* 68 */     gc.gridx = 1;
/* 69 */     gc.gridy = 0;
/* 70 */     gc.weightx = 1.0D;
/* 71 */     gc.weighty = 1.0D;
/* 72 */     this.textureInfo = new TexturePanel(newEntity, (this.WIDTH - 10) / 2, this.HEIGHT - 25);
/*    */     
/* 74 */     add(this.textureInfo, gc);
/* 75 */     validate();
/* 76 */     repaint();
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\MainSettingsPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */