/*    */ package frontend;
/*    */ 
/*    */ import backend.EntityType;
/*    */ import backend.Workspace;
/*    */ import java.awt.Font;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JMenuBar;
/*    */ import javax.swing.JMenuItem;
/*    */ 
/*    */ 
/*    */ public class MenuBar
/*    */   extends JMenuBar
/*    */ {
/*    */   private Workspace workspace;
/*    */   private MainFrame mainFrame;
/*    */   
/*    */   public MenuBar(Workspace workspace, MainFrame mainFrame)
/*    */   {
/* 21 */     this.workspace = workspace;
/* 22 */     this.mainFrame = mainFrame;
/* 23 */     createMenu(mainFrame);
/*    */   }
/*    */   
/*    */   private void createMenu(MainFrame mainFrame) {
/* 27 */     JMenu file = new JMenu("File");
/* 28 */     add(file);
/* 29 */     JMenuItem newStaticFile = new JMenuItem("New Static Entity");
/* 30 */     JMenuItem newAnimatedFile = new JMenuItem("New Animated Entity");
/* 31 */     JMenuItem openFile = new JMenuItem("Open File");
/* 32 */     JMenuItem save = new JMenuItem("Save");
/* 33 */     file.add(newStaticFile);
/* 34 */     file.add(newAnimatedFile);
/* 35 */     file.add(openFile);
/* 36 */     file.add(save);
/* 37 */     addOpenFileFunction(openFile, mainFrame);
/* 38 */     addSaveFunction(save);
/* 39 */     addNewStaticFileFunction(newStaticFile);
/* 40 */     addNewAnimatedFileFunction(newAnimatedFile);
/* 41 */     file.setFont(new Font("Segoe UI", 1, 12));
/* 42 */     newStaticFile.setFont(new Font("Segoe UI", 1, 12));
/* 43 */     newAnimatedFile.setFont(new Font("Segoe UI", 1, 12));
/* 44 */     openFile.setFont(new Font("Segoe UI", 1, 12));
/* 45 */     save.setFont(new Font("Segoe UI", 1, 12));
/*    */   }
/*    */   
/*    */ 
/*    */   private void addOpenFileFunction(JMenuItem open, final MainFrame mainFrame)
/*    */   {
/* 51 */     open.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/* 55 */         MenuBar.this.workspace.save();
/* 56 */         new FileChooseScreen(MenuBar.this.workspace.getAvailableItems(), MenuBar.this.workspace, mainFrame);
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   private void addSaveFunction(JMenuItem save)
/*    */   {
/* 63 */     save.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/* 67 */         MenuBar.this.workspace.save();
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   private void addNewStaticFileFunction(JMenuItem newStaticFile)
/*    */   {
/* 74 */     newStaticFile.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e) {
/* 77 */         MenuBar.this.workspace.save();
/* 78 */         MenuBar.this.workspace.createNewEntity(EntityType.STATIC);
/* 79 */         MenuBar.this.mainFrame.setNewEntity(MenuBar.this.workspace.getCurrentEntity());
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   private void addNewAnimatedFileFunction(JMenuItem newAnimatedFile)
/*    */   {
/* 86 */     newAnimatedFile.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent e) {
/* 89 */         MenuBar.this.workspace.save();
/* 90 */         MenuBar.this.workspace.createNewEntity(EntityType.ANIMATED);
/* 91 */         MenuBar.this.mainFrame.setNewEntity(MenuBar.this.workspace.getCurrentEntity());
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\MenuBar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */