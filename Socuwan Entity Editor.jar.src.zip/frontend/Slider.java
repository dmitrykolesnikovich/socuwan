/*     */ package frontend;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ public class Slider
/*     */   extends JPanel
/*     */ {
/*     */   private float max;
/*     */   private float start;
/*     */   private boolean linear;
/*     */   private JFloatSlider slider;
/*  18 */   private int nameWidth = 100;
/*  19 */   private int width = 200;
/*     */   
/*     */   public Slider(String name, float current, float start, float max, boolean linear) {
/*  22 */     this.max = max;
/*  23 */     this.start = start;
/*  24 */     this.linear = linear;
/*  25 */     add(createSlider(name, current));
/*     */   }
/*     */   
/*     */   public Slider(String name, float current, float start, float max, boolean linear, int width, int nameWidth) {
/*  29 */     this.max = max;
/*  30 */     this.start = start;
/*  31 */     this.linear = linear;
/*  32 */     this.width = width;
/*  33 */     this.nameWidth = nameWidth;
/*  34 */     add(createSlider(name, current));
/*     */   }
/*     */   
/*     */   public void addSliderListener(ChangeListener listener) {
/*  38 */     this.slider.addChangeListener(listener);
/*     */   }
/*     */   
/*     */   private JPanel createSlider(String name, float start) {
/*  42 */     JPanel panelSlider = new JPanel();
/*  43 */     panelSlider.setLayout(new GridBagLayout());
/*  44 */     GridBagConstraints gc = new GridBagConstraints();
/*  45 */     gc.fill = 1;
/*  46 */     gc.gridx = 0;
/*  47 */     gc.gridy = 0;
/*  48 */     gc.weightx = 1.0D;
/*  49 */     gc.weighty = 1.0D;
/*     */     
/*  51 */     JLabel nameLabel = new JLabel(name);
/*  52 */     nameLabel.setFont(MainFrame.SMALL_FONT);
/*  53 */     nameLabel.setPreferredSize(new Dimension(this.nameWidth, 20));
/*  54 */     panelSlider.add(nameLabel, gc);
/*  55 */     gc.weightx = 1.0D;
/*  56 */     gc.gridx = 1;
/*  57 */     final JLabel valueReading = new JLabel();
/*  58 */     valueReading.setPreferredSize(new Dimension(50, 20));
/*  59 */     valueReading.setFont(MainFrame.SMALL_FONT);
/*  60 */     this.slider = new JFloatSlider(0, 0.0F, 1.0F, reverseConvertValue(start));
/*  61 */     valueReading.setText(limitChars(Float.toString(convertScaleValue(this.slider.getActualValue())), 5));
/*     */     
/*     */ 
/*  64 */     this.slider.addChangeListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent arg0)
/*     */       {
/*  68 */         valueReading.setText(Slider.this.limitChars(Float.toString(Slider.access$100(Slider.this, Slider.this.slider.getActualValue())), 5));
/*     */       }
/*     */       
/*  71 */     });
/*  72 */     panelSlider.add(this.slider, gc);
/*     */     
/*  74 */     this.slider.setPreferredSize(new Dimension(this.width, 20));
/*     */     
/*  76 */     gc.gridx = 2;
/*  77 */     gc.weightx = 1.0D;
/*  78 */     panelSlider.add(valueReading, gc);
/*  79 */     return panelSlider;
/*     */   }
/*     */   
/*     */   private String limitChars(String original, int limit)
/*     */   {
/*  84 */     if (original.length() <= limit) {
/*  85 */       return original;
/*     */     }
/*  87 */     return original.substring(0, 5);
/*     */   }
/*     */   
/*     */ 
/*     */   public float getSliderReading()
/*     */   {
/*  93 */     return convertScaleValue(this.slider.getActualValue());
/*     */   }
/*     */   
/*     */   private float convertScaleValue(float sliderValue) {
/*  97 */     float value = sliderValue;
/*  98 */     if (!this.linear) {
/*  99 */       value *= sliderValue;
/* 100 */       value *= sliderValue;
/*     */     }
/* 102 */     value *= (this.max - this.start);
/* 103 */     return value + this.start;
/*     */   }
/*     */   
/*     */   private float reverseConvertValue(float reflectValue) {
/* 107 */     reflectValue -= this.start;
/* 108 */     float value = reflectValue / (this.max - this.start);
/* 109 */     if (this.linear) {
/* 110 */       return value;
/*     */     }
/* 112 */     return (float)Math.cbrt(value);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\Slider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */