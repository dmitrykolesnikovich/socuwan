/*     */ package frontend;
/*     */ 
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import main.Configs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextureChooseScreen
/*     */ {
/*     */   private static final String MESSAGE = "Choose a texture!";
/*     */   private static final String SELECT_TEXT = "Open";
/*     */   private JDialog frame;
/*     */   private JList<FileInList> list;
/*     */   private JButton confirm;
/*     */   private TexturePanel panel;
/*     */   
/*     */   public TextureChooseScreen(TexturePanel panel, boolean diffuse)
/*     */   {
/*  38 */     this.panel = panel;
/*  39 */     setUpFrame();
/*  40 */     addLabel();
/*  41 */     addFileList(getAllIconFiles());
/*  42 */     addButton(diffuse);
/*  43 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setUpFrame() {
/*  47 */     this.frame = new JDialog();
/*  48 */     this.frame.setAlwaysOnTop(true);
/*  49 */     this.frame.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  50 */     this.frame.setSize(300, 500);
/*  51 */     this.frame.setResizable(false);
/*  52 */     this.frame.setLocationRelativeTo(null);
/*  53 */     this.frame.setLayout(new GridBagLayout());
/*     */   }
/*     */   
/*     */   private void addFileList(List<File> files) {
/*  57 */     GridBagConstraints gc = new GridBagConstraints();
/*  58 */     gc.gridx = 0;
/*  59 */     gc.gridy = 1;
/*  60 */     gc.weightx = 1.0D;
/*  61 */     gc.weighty = 1.0D;
/*     */     
/*  63 */     FileInList[] data = getAllFilesInList(files);
/*  64 */     this.list = new JList(data);
/*  65 */     this.list.setFont(new Font("Segoe UI", 1, 12));
/*  66 */     this.list.setSelectionMode(1);
/*  67 */     this.list.setLayoutOrientation(0);
/*  68 */     this.list.setVisibleRowCount(-1);
/*  69 */     JScrollPane listScroller = new JScrollPane(this.list);
/*  70 */     listScroller.setPreferredSize(new Dimension(250, 350));
/*  71 */     this.frame.add(listScroller, gc);
/*     */   }
/*     */   
/*     */   private FileInList[] getAllFilesInList(List<File> files) {
/*  75 */     FileInList[] listedFiles = new FileInList[files.size()];
/*  76 */     for (int i = 0; i < listedFiles.length; i++) {
/*  77 */       listedFiles[i] = new FileInList((File)files.get(i));
/*     */     }
/*  79 */     return listedFiles;
/*     */   }
/*     */   
/*     */   private void addLabel() {
/*  83 */     JLabel text = new JLabel("Choose a texture!");
/*  84 */     text.setFont(new Font("Segoe UI", 1, 15));
/*  85 */     GridBagConstraints gc = new GridBagConstraints();
/*  86 */     gc.gridx = 0;
/*  87 */     gc.gridy = 0;
/*  88 */     gc.weightx = 1.0D;
/*  89 */     gc.weighty = 0.4D;
/*  90 */     this.frame.add(text, gc);
/*     */   }
/*     */   
/*     */   private void addButton(final boolean diffuse) {
/*  94 */     this.confirm = new JButton("Open");
/*  95 */     this.confirm.setFont(new Font("Segoe UI", 1, 15));
/*  96 */     GridBagConstraints gc = new GridBagConstraints();
/*  97 */     gc.gridx = 0;
/*  98 */     gc.gridy = 2;
/*  99 */     gc.weightx = 1.0D;
/* 100 */     gc.weighty = 0.4D;
/* 101 */     this.confirm.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 105 */         if (!TextureChooseScreen.this.list.isSelectionEmpty()) {
/* 106 */           File chosen = ((FileInList)TextureChooseScreen.this.list.getSelectedValue()).getFile();
/* 107 */           boolean success = TextureChooseScreen.this.panel.setNewIcon(chosen, diffuse);
/* 108 */           if (success) {
/* 109 */             TextureChooseScreen.this.frame.setVisible(false);
/*     */           } else {
/* 111 */             new ErrorPopUp("Couldn't open texture file!");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 117 */     });
/* 118 */     this.frame.add(this.confirm, gc);
/*     */   }
/*     */   
/*     */   private List<File> getAllIconFiles() {
/* 122 */     File[] allFiles = Configs.TEXTURES_REPOS.listFiles();
/* 123 */     List<File> goodFiles = new ArrayList();
/* 124 */     for (File file : allFiles) {
/* 125 */       if (file.getName().endsWith(".png")) {
/* 126 */         goodFiles.add(file);
/*     */       }
/*     */     }
/* 129 */     return goodFiles;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\frontend\TextureChooseScreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */