package org.lwjgl.opengl;

public final class HPOcclusionTest
{
  public static final int GL_OCCLUSION_TEST_HP = 33125;
  public static final int GL_OCCLUSION_TEST_RESULT_HP = 33126;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\HPOcclusionTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */