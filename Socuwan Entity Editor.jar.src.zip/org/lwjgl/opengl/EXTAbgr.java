package org.lwjgl.opengl;

public final class EXTAbgr
{
  public static final int GL_ABGR_EXT = 32768;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\EXTAbgr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */