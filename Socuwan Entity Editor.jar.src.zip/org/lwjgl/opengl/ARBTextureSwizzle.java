package org.lwjgl.opengl;

public final class ARBTextureSwizzle
{
  public static final int GL_TEXTURE_SWIZZLE_R = 36418;
  public static final int GL_TEXTURE_SWIZZLE_G = 36419;
  public static final int GL_TEXTURE_SWIZZLE_B = 36420;
  public static final int GL_TEXTURE_SWIZZLE_A = 36421;
  public static final int GL_TEXTURE_SWIZZLE_RGBA = 36422;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\ARBTextureSwizzle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */