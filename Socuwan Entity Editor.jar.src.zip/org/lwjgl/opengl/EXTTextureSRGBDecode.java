package org.lwjgl.opengl;

public final class EXTTextureSRGBDecode
{
  public static final int GL_TEXTURE_SRGB_DECODE_EXT = 35400;
  public static final int GL_DECODE_EXT = 35401;
  public static final int GL_SKIP_DECODE_EXT = 35402;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\EXTTextureSRGBDecode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */