package org.lwjgl.opengl;

public final class ARBHalfFloatPixel
{
  public static final int GL_HALF_FLOAT_ARB = 5131;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\ARBHalfFloatPixel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */