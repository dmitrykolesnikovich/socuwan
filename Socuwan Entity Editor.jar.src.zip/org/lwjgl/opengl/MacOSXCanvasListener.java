/*     */ package org.lwjgl.opengl;
/*     */ 
/*     */ import java.awt.Canvas;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.HierarchyEvent;
/*     */ import java.awt.event.HierarchyListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacOSXCanvasListener
/*     */   implements ComponentListener, HierarchyListener
/*     */ {
/*     */   private final Canvas canvas;
/*     */   private int width;
/*     */   private int height;
/*     */   private boolean context_update;
/*     */   private boolean resized;
/*     */   
/*     */   MacOSXCanvasListener(Canvas canvas)
/*     */   {
/*  53 */     this.canvas = canvas;
/*  54 */     canvas.addComponentListener(this);
/*  55 */     canvas.addHierarchyListener(this);
/*  56 */     setUpdate();
/*     */   }
/*     */   
/*     */   public void disableListeners()
/*     */   {
/*  61 */     EventQueue.invokeLater(new Runnable() {
/*     */       public void run() {
/*  63 */         MacOSXCanvasListener.this.canvas.removeComponentListener(MacOSXCanvasListener.this);
/*  64 */         MacOSXCanvasListener.this.canvas.removeHierarchyListener(MacOSXCanvasListener.this);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public boolean syncShouldUpdateContext() {
/*     */     boolean should_update;
/*  71 */     synchronized (this) {
/*  72 */       should_update = this.context_update;
/*  73 */       this.context_update = false;
/*     */     }
/*  75 */     return should_update;
/*     */   }
/*     */   
/*     */   private synchronized void setUpdate() {
/*  79 */     synchronized (this) {
/*  80 */       this.width = this.canvas.getWidth();
/*  81 */       this.height = this.canvas.getHeight();
/*  82 */       this.context_update = true;
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int syncGetWidth()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: astore_1
/*     */     //   3: monitorenter
/*     */     //   4: aload_0
/*     */     //   5: getfield 11	org/lwjgl/opengl/MacOSXCanvasListener:width	I
/*     */     //   8: aload_1
/*     */     //   9: monitorexit
/*     */     //   10: ireturn
/*     */     //   11: astore_2
/*     */     //   12: aload_1
/*     */     //   13: monitorexit
/*     */     //   14: aload_2
/*     */     //   15: athrow
/*     */     // Line number table:
/*     */     //   Java source line #87	-> byte code offset #0
/*     */     //   Java source line #88	-> byte code offset #4
/*     */     //   Java source line #89	-> byte code offset #11
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	16	0	this	MacOSXCanvasListener
/*     */     //   2	11	1	Ljava/lang/Object;	Object
/*     */     //   11	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	10	11	finally
/*     */     //   11	14	11	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int syncGetHeight()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: astore_1
/*     */     //   3: monitorenter
/*     */     //   4: aload_0
/*     */     //   5: getfield 13	org/lwjgl/opengl/MacOSXCanvasListener:height	I
/*     */     //   8: aload_1
/*     */     //   9: monitorexit
/*     */     //   10: ireturn
/*     */     //   11: astore_2
/*     */     //   12: aload_1
/*     */     //   13: monitorexit
/*     */     //   14: aload_2
/*     */     //   15: athrow
/*     */     // Line number table:
/*     */     //   Java source line #93	-> byte code offset #0
/*     */     //   Java source line #94	-> byte code offset #4
/*     */     //   Java source line #95	-> byte code offset #11
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	16	0	this	MacOSXCanvasListener
/*     */     //   2	11	1	Ljava/lang/Object;	Object
/*     */     //   11	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	10	11	finally
/*     */     //   11	14	11	finally
/*     */   }
/*     */   
/*     */   public void componentShown(ComponentEvent e) {}
/*     */   
/*     */   public void componentHidden(ComponentEvent e) {}
/*     */   
/*     */   public void componentResized(ComponentEvent e)
/*     */   {
/* 105 */     setUpdate();
/* 106 */     this.resized = true;
/*     */   }
/*     */   
/*     */   public void componentMoved(ComponentEvent e) {
/* 110 */     setUpdate();
/*     */   }
/*     */   
/*     */   public void hierarchyChanged(HierarchyEvent e) {
/* 114 */     setUpdate();
/*     */   }
/*     */   
/*     */   public boolean wasResized() {
/* 118 */     if (this.resized) {
/* 119 */       this.resized = false;
/* 120 */       return true;
/*     */     }
/*     */     
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\MacOSXCanvasListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */