package org.lwjgl.opengl;

abstract interface ContextAttribsImplementation
{
  public abstract int getMajorVersionAttrib();
  
  public abstract int getMinorVersionAttrib();
  
  public abstract int getLayerPlaneAttrib();
  
  public abstract int getFlagsAttrib();
  
  public abstract int getDebugBit();
  
  public abstract int getForwardCompatibleBit();
  
  public abstract int getProfileMaskAttrib();
  
  public abstract int getProfileCoreBit();
  
  public abstract int getProfileCompatibilityBit();
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\ContextAttribsImplementation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */