package org.lwjgl.opengl;

public final class EXTCgShader
{
  public static final int GL_CG_VERTEX_SHADER_EXT = 35086;
  public static final int GL_CG_FRAGMENT_SHADER_EXT = 35087;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\EXTCgShader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */