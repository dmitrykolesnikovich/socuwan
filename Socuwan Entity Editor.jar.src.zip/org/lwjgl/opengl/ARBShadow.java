package org.lwjgl.opengl;

public final class ARBShadow
{
  public static final int GL_TEXTURE_COMPARE_MODE_ARB = 34892;
  public static final int GL_TEXTURE_COMPARE_FUNC_ARB = 34893;
  public static final int GL_COMPARE_R_TO_TEXTURE_ARB = 34894;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\ARBShadow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */