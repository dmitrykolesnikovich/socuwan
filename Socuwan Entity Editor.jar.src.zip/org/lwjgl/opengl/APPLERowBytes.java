package org.lwjgl.opengl;

public final class APPLERowBytes
{
  public static final int GL_PACK_ROW_BYTES_APPLE = 35349;
  public static final int GL_UNPACK_ROW_BYTES_APPLE = 35350;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\APPLERowBytes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */