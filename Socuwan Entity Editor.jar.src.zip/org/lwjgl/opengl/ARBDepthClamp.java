package org.lwjgl.opengl;

public final class ARBDepthClamp
{
  public static final int GL_DEPTH_CLAMP = 34383;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opengl\ARBDepthClamp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */