/*    */ package org.lwjgl.opencl;
/*    */ 
/*    */ import org.lwjgl.PointerWrapperAbstract;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CLPrintfCallback
/*    */   extends PointerWrapperAbstract
/*    */ {
/*    */   protected CLPrintfCallback()
/*    */   {
/* 45 */     super(CallbackUtil.getPrintfCallback());
/*    */   }
/*    */   
/*    */   protected abstract void handleMessage(String paramString);
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opencl\CLPrintfCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */