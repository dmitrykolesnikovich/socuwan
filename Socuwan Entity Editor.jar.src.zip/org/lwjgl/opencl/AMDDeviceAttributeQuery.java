package org.lwjgl.opencl;

public final class AMDDeviceAttributeQuery
{
  public static final int CL_DEVICE_PROFILING_TIMER_OFFSET_AMD = 16438;
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opencl\AMDDeviceAttributeQuery.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */