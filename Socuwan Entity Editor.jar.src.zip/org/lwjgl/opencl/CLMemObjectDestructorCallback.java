/*    */ package org.lwjgl.opencl;
/*    */ 
/*    */ import org.lwjgl.PointerWrapperAbstract;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CLMemObjectDestructorCallback
/*    */   extends PointerWrapperAbstract
/*    */ {
/*    */   protected CLMemObjectDestructorCallback()
/*    */   {
/* 44 */     super(CallbackUtil.getMemObjectDestructorCallback());
/*    */   }
/*    */   
/*    */   protected abstract void handleMessage(long paramLong);
/*    */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opencl\CLMemObjectDestructorCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */