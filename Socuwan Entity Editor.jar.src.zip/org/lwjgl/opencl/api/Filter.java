package org.lwjgl.opencl.api;

public abstract interface Filter<T>
{
  public abstract boolean accept(T paramT);
}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opencl\api\Filter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */