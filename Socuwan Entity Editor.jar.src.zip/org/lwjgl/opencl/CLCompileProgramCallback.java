package org.lwjgl.opencl;

public abstract class CLCompileProgramCallback
  extends CLProgramCallback
{}


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\org\lwjgl\opencl\CLCompileProgramCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */