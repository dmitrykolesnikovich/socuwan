/*     */ package atmosphere;
/*     */ 
/*     */ import epicRenderEngine.Camera;
/*     */ import epicRenderEngine.Loader;
/*     */ import epicRenderEngine.RenderEngine;
/*     */ import toolbox.Colour;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SkyBox
/*     */ {
/*     */   private static final float ROTATION_SPEED = 0.6F;
/*     */   private final int vao;
/*     */   private Camera camera;
/*     */   private int primaryTexture;
/*     */   private int secondaryTexture;
/*  17 */   private float blendValue = 0.0F;
/*  18 */   private float curentRotation = 0.0F;
/*     */   private Colour tint;
/*     */   
/*     */   public SkyBox(Camera camera, float visibility)
/*     */   {
/*  23 */     this.camera = camera;
/*  24 */     this.vao = createVAO(visibility);
/*     */   }
/*     */   
/*     */   public int getVAO() {
/*  28 */     return this.vao;
/*     */   }
/*     */   
/*     */   public void setTextures(int primaryTexture, int secondaryTexture, float blendValue) {
/*  32 */     this.primaryTexture = primaryTexture;
/*  33 */     this.secondaryTexture = secondaryTexture;
/*  34 */     this.blendValue = blendValue;
/*     */   }
/*     */   
/*     */   public int getPrimaryTexture() {
/*  38 */     return this.primaryTexture;
/*     */   }
/*     */   
/*     */   public int getSecondaryTexture() {
/*  42 */     return this.secondaryTexture;
/*     */   }
/*     */   
/*     */   public float getBlendValue() {
/*  46 */     return this.blendValue;
/*     */   }
/*     */   
/*     */   public float getX() {
/*  50 */     return this.camera.getX();
/*     */   }
/*     */   
/*     */   public float getY() {
/*  54 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public float getZ() {
/*  58 */     return this.camera.getZ();
/*     */   }
/*     */   
/*     */   public float getRotation() {
/*  62 */     return this.curentRotation;
/*     */   }
/*     */   
/*     */   public void update(Colour colour) {
/*  66 */     this.tint = colour;
/*  67 */     this.curentRotation += 0.6F * RenderEngine.getDeltaInSeconds();
/*     */   }
/*     */   
/*     */   public Colour getTint() {
/*  71 */     return this.tint;
/*     */   }
/*     */   
/*     */   private static int createVAO(float visibility) {
/*  75 */     float[] vertices = { -visibility, visibility, -visibility, -visibility, -visibility, -visibility, visibility, visibility, -visibility, visibility, visibility, -visibility, -visibility, -visibility, -visibility, visibility, -visibility, -visibility, -visibility, visibility, visibility, -visibility, -visibility, visibility, -visibility, visibility, -visibility, -visibility, visibility, -visibility, -visibility, -visibility, visibility, -visibility, -visibility, -visibility, visibility, visibility, visibility, visibility, -visibility, visibility, -visibility, visibility, visibility, -visibility, visibility, visibility, visibility, -visibility, visibility, -visibility, -visibility, visibility, visibility, visibility, -visibility, visibility, -visibility, -visibility, visibility, visibility, visibility, visibility, visibility, visibility, visibility, -visibility, -visibility, visibility, -visibility, visibility };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */     float[] textureCoords = { 0.5F, 0.5F, 0.5F, 1.0F, 1.0F, 0.5F, 1.0F, 0.5F, 0.5F, 1.0F, 1.0F, 1.0F, 0.0F, 0.5F, 0.0F, 1.0F, 0.5F, 0.5F, 0.5F, 0.5F, 0.0F, 1.0F, 0.5F, 1.0F, 0.5F, 0.0F, 0.5F, 0.5F, 1.0F, 0.0F, 1.0F, 0.0F, 0.5F, 0.5F, 1.0F, 0.5F, 0.0F, 0.0F, 0.0F, 0.5F, 0.5F, 0.0F, 0.5F, 0.0F, 0.0F, 0.5F, 0.5F, 0.5F };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */     return Loader.loadModelToVAO(vertices, textureCoords);
/*     */   }
/*     */ }


/* Location:              D:\Version 1_2\Version 1_2\Socuwan Entity Editor.jar!\atmosphere\SkyBox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */